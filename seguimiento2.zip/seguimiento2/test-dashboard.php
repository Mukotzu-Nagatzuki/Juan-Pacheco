<?php
// test-dashboard.php
session_start();
require_once "core/app/database/Database.php";
require_once "core/app/database/Executor.php";
require_once "core/app/database/Model.php";

echo "<h2>Diagnóstico del Dashboard</h2>";

// Test de conexión a la base de datos
try {
    $db = new Database();
    echo "<p style='color: green;'>✓ Conexión a la base de datos: OK</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error de conexión: " . $e->getMessage() . "</p>";
    exit;
}

// Test de tablas
$tablas = ['estudiante', 'empresa', 'prog_estudios', 'situacion_laboral', 'matricula'];
foreach ($tablas as $tabla) {
    $sql = "SELECT COUNT(*) as total FROM $tabla";
    $query = Executor::doit($sql);
    if ($query[0]) {
        $result = Model::one($query[0], new stdClass());
        echo "<p>✓ Tabla $tabla: " . $result->total . " registros</p>";
    } else {
        echo "<p style='color: red;'>✗ Error en tabla $tabla: " . ($query[1] ?? 'Error desconocido') . "</p>";
    }
}
?>