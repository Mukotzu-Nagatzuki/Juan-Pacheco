<?php
// Conectar a la base de datos
$host = '50.31.174.34';
$dbname = 'wxwdrnht_integrado_db';
$username = 'wxwdrnht_wxwdrnht_integrado_db';
$password = 'integrado_db2025.';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "=== ACTUALIZACIÓN DE ACTIVIDADES ===\n";
    
    // 1. Obtener la última actividad activa o creada
    $sql_actividad = "SELECT id FROM actividades WHERE estado = 1 
                     AND CURDATE() BETWEEN fecha_inicio AND fecha_fin 
                     ORDER BY id DESC LIMIT 1";
    $stmt = $conn->query($sql_actividad);
    $actividad = $stmt->fetch();
    
    if ($actividad) {
        $actividad_id = $actividad['id'];
        echo "Actividad encontrada: ID $actividad_id\n";
        
        // 2. Actualizar registros sin actividad
        $sql_update = "UPDATE situacion_laboral SET actividad = ? WHERE actividad IS NULL";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->execute([$actividad_id]);
        
        $affected = $stmt_update->rowCount();
        echo "Registros actualizados: $affected\n";
    } else {
        echo "No hay actividad activa actualmente.\n";
        
        // Buscar la última actividad creada
        $sql_ultima = "SELECT id FROM actividades ORDER BY id DESC LIMIT 1";
        $stmt_ultima = $conn->query($sql_ultima);
        $ultima = $stmt_ultima->fetch();
        
        if ($ultima) {
            $actividad_id = $ultima['id'];
            echo "Usando última actividad creada: ID $actividad_id\n";
            
            $sql_update = "UPDATE situacion_laboral SET actividad = ? WHERE actividad IS NULL";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->execute([$actividad_id]);
            
            $affected = $stmt_update->rowCount();
            echo "Registros actualizados: $affected\n";
        } else {
            echo "No hay actividades en la base de datos.\n";
        }
    }
    
    // 3. Verificar resultados
    echo "\n=== VERIFICACIÓN ===\n";
    $sql_verificar = "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN actividad IS NULL THEN 1 ELSE 0 END) as sin_actividad,
        SUM(CASE WHEN actividad IS NOT NULL THEN 1 ELSE 0 END) as con_actividad
        FROM situacion_laboral";
    
    $stmt_verificar = $conn->query($sql_verificar);
    $resultado = $stmt_verificar->fetch();
    
    echo "Total registros: " . $resultado['total'] . "\n";
    echo "Con actividad: " . $resultado['con_actividad'] . "\n";
    echo "Sin actividad: " . $resultado['sin_actividad'] . "\n";
    
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>