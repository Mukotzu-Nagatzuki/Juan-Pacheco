
	create table  ubdepartamento(
		id int primary key not null auto_increment,
		departamento varchar(250)
	);

	create table  ubprovincia(
		id int primary key not null auto_increment,
		provincia varchar(250),
		ubdepartamento int,
		foreign key (ubdepartamento) references ubdepartamento(id)
	);

	create table  ubdistrito(
		id int primary key not null auto_increment,
		distrito varchar(250),
		ubprovincia int,
		foreign key (ubprovincia) references ubprovincia(id)
	);

	create table  estudiante(
		id int primary key not null auto_increment,
		ubdistrito int,
		dni_est char(8),
		ap_est varchar(40),
		am_est varchar(40),
		nom_est varchar(40),
		sex_est char(1),
		cel_est  char(9),
		ubigeodir_est char(6),
		ubigeonac_est char(6),
		dir_est varchar(40),
		mailp_est varchar(40),
		maili_est varchar(40),
		fecnac_est date,
		foto_est varchar(40),
		estado int,
		foreign key (ubdistrito) references ubdistrito(id)
	);

	create table  prog_estudios(
		id int primary key not null auto_increment,
		nom_progest varchar(40),
		perfilingre_progest text,
		perfilegre_progest text
	);


	create table  matricula(
		id int primary key not null auto_increment,
		estudiante int,
		prog_estudios int,
		id_matricula char(9),
		per_lectivo varchar(7),
		per_acad varchar(3),
		per_acad2 int(1),
		seccion char(1),
		turno char(1),
		fec_matricula date,
		cond_matricula char(1),
		est_matricula char(1),
		est_perlec char(1),
		obs_matricula varchar(50),
		foreign key (estudiante) references estudiante(id),
		foreign key (prog_estudios) references prog_estudios(id)
	);

	create table  usuarios(
		id int primary key not null auto_increment,
		usuario varchar(200),
		password text,
		tipo int, -- 1 ES EMPLEADO, 2 ES ESTUDIANTE, 3 ES EMPRESA  
		estuempleado int,
		token text
	);













/* SISTEMA DE SEGUIMIENTOS DE EGRESADO   */






create table condicion_laboral(
	id int primary key not null auto_increment,
	nombre_condicion varchar(100)
);

create table sector(
	id int primary key not null auto_increment,
	nombre_sector varchar(100)
);


create table situacion_laboral(
	id int primary key not null auto_increment,
	estudiante int,
	empresa int,
	trabaja int,
	labora_programa_estudios int,
	cargo_actual varchar(200),
	condicion_laboral int,
	ingreso_bruto_mensual decimal(10,2),
	satisfaccion_trabajo varchar(50),
	fecha_inicio date,
	foreign key (estudiante) references estudiante(id),
	foreign key (empresa) references empresa(id),
	foreign key (condicion_laboral) references condicion_laboral(id)
);

create table seguimiento(
	id int primary key not null auto_increment,
	estudiante int,
	tipo int,
	observaciones text,
	fecha date,
	foreign key (estudiante) references estudiante(id),
	foreign key (tipo) references tipo_seguimiento(id)
);
create table actividades(
    id int primary key not null auto_increment,
    titulo varchar(150),
    descripcion text,
    fecha_inicio date,
    fecha_fin date,
    estado int default 1,
    fecha_registro datetime default current_timestamp
);
alter table situacion_laboral
add column actividad int,
add foreign key (actividad) references actividades(id);










