<?php
class Module {

	public static function loadLayout(){
		include "core/app/layouts/layout.php";
	}


} ?>