<?php
class Action
{
    const ACTION_PATH = "core/app/action/";
    const VIEW_PATH = "core/app/view/";
    const LAYOUT_PATH = "core/app/layouts/";

    // Carga la acción solicitada
    public static function load($defaultAction)
    {
        $action = $_GET['action'] ?? $defaultAction;

        // DEBUG: Verificar qué acción se está cargando
        error_log("ACTION DEBUG: Cargando acción: " . $action);

        // Excluir estas acciones para que usen el sistema de vistas
        $excludedActions = [
            'crear_usuario', 
            'registros', 
            'editar_usuario', 
            'actualizar_usuario', 
            'eliminar_usuario',
            'eliminar_egresado',
            'eliminar_empresa',
            'guardar_empresa'
        ];

        // Verificar si es una acción de actividades (que comienza con "actividades")
        if (strpos($action, 'actividades') === 0) {
            // Si comienza con "actividades", usar actividades-action.php
            $actionFile = self::ACTION_PATH . 'actividades-action.php';
            error_log("ACTION DEBUG: Redirigiendo acción de actividades a: " . $actionFile);
            if (file_exists($actionFile)) {
                include $actionFile;
                return;
            } else {
                error_log("ACTION DEBUG: ERROR - Archivo actividades-action.php no encontrado");
                self::Error("Archivo de actividades no encontrado");
                return;
            }
        }

        // Verificar si el archivo de acción existe
        $actionFile = self::ACTION_PATH . $action . '-action.php';
        if (file_exists($actionFile) && !in_array($action, $excludedActions)) {
            error_log("ACTION DEBUG: Incluyendo archivo de acción: " . $actionFile);
            include $actionFile;
        } else {
            // Si no es un archivo de acción o es una excepción, manejar las vistas
            error_log("ACTION DEBUG: Manejando vista para: " . $action);
            self::handleView($action);
        }
    }

    // Verifica si el archivo de la acción es válido
    public static function isValid($action)
    {
        $file = self::ACTION_PATH . basename($action) . "-action.php";
        $exists = file_exists($file);
        error_log("ACTION DEBUG: Validando acción $action - Archivo: $file - Existe: " . ($exists ? 'Sí' : 'No'));
        return $exists;
    }

    // Manejo de vistas cuando no hay archivo de acción
    public static function handleView($action)
    {
        error_log("ACTION DEBUG: handleView para: " . $action);
        
        switch ($action) {
            case 'dashboard':
            case '':
                // Para dashboard, usar dashboard-action.php
                $dashboardFile = self::ACTION_PATH . 'dashboard-action.php';
                error_log("ACTION DEBUG: Intentando incluir dashboard: " . $dashboardFile);
                if (file_exists($dashboardFile)) {
                    include $dashboardFile;
                } else {
                    error_log("ACTION DEBUG: ERROR - Archivo dashboard no encontrado: " . $dashboardFile);
                    self::Error("Archivo dashboard no encontrado");
                }
                return;

            case 'crear_usuario':
                // Para crear_usuario, siempre usar usuario-action.php
                include self::ACTION_PATH . 'usuario-action.php';
                return;

            case 'registros':
                // Para registros, usar registros-action.php
                include self::ACTION_PATH . 'registros-action.php';
                return;

            case 'editar_usuario':
                // Para editar_usuario, usar usuario-action.php
                include self::ACTION_PATH . 'usuario-action.php';
                return;

            case 'eliminar_usuario':
                // Para eliminar_usuario, usar usuario-action.php
                include self::ACTION_PATH . 'usuario-action.php';
                return;

            case 'eliminar_egresado':
                // Para eliminar_egresado, usar egresado-action.php
                include self::ACTION_PATH . 'egresado-action.php';
                return;

            case 'eliminar_empresa':
                // Para eliminar_empresa, usar empresa-action.php
                include self::ACTION_PATH . 'empresa-action.php';
                return;

            case 'guardar_empresa':
                include self::ACTION_PATH . 'empresa-action.php';
                return;
                
            case 'egresado':
                include self::ACTION_PATH . 'egresado-action.php';
                return;
                
            case 'empresas':
                include self::ACTION_PATH . 'empresa-action.php';
                return;
                
            case 'situacion':
                include self::ACTION_PATH . 'situacion-action.php';
                return;    
                
            case 'reportes':
                include self::ACTION_PATH . 'reportes-action.php';
                return;  

            case 'actividades':
                include self::ACTION_PATH . 'actividades-action.php';
                return; 

            //mensaje de correo
            case 'mensaje':
                include self::ACTION_PATH . 'mensaje-action.php';
                return;

            // Ya no necesitamos estos casos porque se manejan en el bloque strpos()
            // pero los dejamos por compatibilidad
            case 'actividades-create':
            case 'actividades-toggle':
            case 'actividades-delete':
                include self::ACTION_PATH . 'actividades-action.php';
                return;

            default:
                self::Error("404 NOT FOUND: Action <b>{$action}</b> not found.");
                return;
        }
    }

    // Método simple para renderizar vistas
    public static function renderView($viewName, $data = [])
    {
        // Extraer los datos para que estén disponibles en la vista
        extract($data);

        // Iniciar buffer de salida
        ob_start();

        // Incluir la vista específica
        $viewFile = self::VIEW_PATH . $viewName . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            echo "<p>Error: Vista no encontrada - {$viewName}</p>";
        }

        // Obtener el contenido del buffer
        $viewContent = ob_get_clean();

        // Ahora renderizar el layout completo
        ob_start();
        $layoutFile = self::LAYOUT_PATH . 'layout.php';
        if (file_exists($layoutFile)) {
            include $layoutFile;
        } else {
            echo "<p>Error: Layout no encontrado</p>";
        }

        return ob_get_clean();
    }

    // Manejo de errores
    public static function Error($message)
    {
        echo "
        <div style='
            padding: 20px;
            margin: 50px auto;
            max-width: 600px;
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 8px;
            color: #721c24;
            text-align: center;
        '>
            <h3>Error</h3>
            <p>{$message}</p>
            <a href='index.php' style='
                display: inline-block;
                padding: 10px 20px;
                background: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                margin-top: 10px;
            '>Volver al Inicio</a>
        </div>";
    }

    // Ejecuta una acción específica con parámetros
    public function execute($action, $params = [])
    {
        $fullpath = self::ACTION_PATH . basename($action) . "-action.php";
        if (file_exists($fullpath)) {
            include $fullpath;
        } else {
            throw new Exception("Error: Action file <b>{$action}-action.php</b> not found.");
        }
    }
}