<div class="container mt-4">
    <div class="admin-content-header">
        <div class="admin-header-title py-4">
            <h1 class="display-6 fw-bold">ENCUESTA INTERNA</h1>
            <p class="lead mb-0">Gestión de todos los registros de la encuesta</p>
            
            <!-- Añade este bloque para mostrar el estado de la encuesta -->
            <?php 
            // Verificar si hay actividad activa
            require_once "core/app/model/ActividadesData.php";
            $encuestaHabilitada = ActividadesData::isEncuestaHabilitada();
            $actividadActual = ActividadesData::getEncuestaActividadInfo();
            ?>
            
            <div class="mt-3">
                <?php if ($encuestaHabilitada && $actividadActual): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> 
                        <strong>Encuesta HABILITADA para el público</strong><br>
                        Actividad: <?php echo htmlspecialchars($actividadActual->titulo); ?><br>
                        Período: <?php echo date('d/m/Y', strtotime($actividadActual->fecha_inicio)); ?> 
                        al <?php echo date('d/m/Y', strtotime($actividadActual->fecha_fin)); ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <strong>Encuesta DESHABILITADA para el público</strong><br>
                        No hay actividades activas en este momento. Los usuarios no podrán acceder a la encuesta pública.
                    </div>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> 
                    <strong>Nota:</strong> Este formulario es para uso administrativo. Puede registrar encuestas incluso si no hay actividad activa.
                </div>
            </div>
        </div>
    </div>
<br>
    <!-- Mostrar mensajes -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['message']; unset($_SESSION['message']); ?>
        </div>
    <?php elseif (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?= $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <?php
    // Recuperar datos del formulario si hubo error (pasados desde el action)
    // Estos se definen en el action y se pasan a la vista
    $dni_est = $formData['dni_est'] ?? '';
    $ruc_empresa = $formData['ruc_empresa'] ?? '';
    $trabaja = $formData['trabaja'] ?? '';
    $labora_programa_estudios = $formData['labora_programa_estudios'] ?? '';
    $cargo_actual = $formData['cargo_actual'] ?? '';
    $condicion_laboral = $formData['condicion_laboral'] ?? '';
    $ingreso_bruto_mensual = $formData['ingreso_bruto_mensual'] ?? '';
    $satisfaccion_trabajo = $formData['satisfaccion_trabajo'] ?? '';
    $fecha_inicio = $formData['fecha_inicio'] ?? '';
    $fecha_fin = $formData['fecha_fin'] ?? '';
    ?>

    <form action="index.php?action=encuesta" method="POST" id="encuestaForm">

        <!-- DNI del Estudiante -->
        <div class="form-group mb-3">
            <label for="dni_est" class="form-label required-field">DNI del Estudiante <span id="dni_status"></span></label>
            <input type="text" name="dni_est" id="dni_est" maxlength="8" class="form-control" 
                   placeholder="Ingrese 8 dígitos" required value="<?php echo htmlspecialchars($dni_est); ?>">
            <span class="validation-rules">Debe contener exactamente 8 dígitos numéricos</span>
            <span class="field-status" id="dni_message"></span>
        </div>

        <!-- RUC de la Empresa -->
        <div class="form-group mb-3">
            <label for="ruc_empresa" class="form-label required-field">RUC de la Empresa <span id="ruc_status"></span></label>
            <input type="text" name="ruc_empresa" id="ruc_empresa" maxlength="11" class="form-control" 
                   placeholder="Ingrese 11 dígitos" value="<?php echo htmlspecialchars($ruc_empresa); ?>">
            <span class="validation-rules">Debe contener exactamente 11 dígitos numéricos</span>
            <span class="field-status" id="ruc_message"></span>
            
            <!-- Mensaje informativo sobre estado de la empresa -->
            <div class="alert alert-info mt-2" id="empresa_info_message" style="display: none;"></div>
        </div>

        <!-- Pregunta: ¿Actualmente trabajas? -->
        <div class="form-group mb-3">
            <label for="trabaja" class="form-label required-field">¿Estás trabajando actualmente? <span id="trabaja_status"></span></label>
            <select name="trabaja" id="trabaja" class="form-control" required>
                <option value="">Seleccione...</option>
                <option value="1" <?php echo $trabaja == '1' ? 'selected' : ''; ?>>Sí</option>
                <option value="0" <?php echo $trabaja == '0' ? 'selected' : ''; ?>>No</option>
            </select>
            <span class="field-status" id="trabaja_message"></span>
        </div>

        <!-- Pregunta: ¿Laboras en tu área de estudios? -->
        <div class="form-group mb-3">
            <label for="labora_programa_estudios" class="form-label">¿Trabajas en el área de tu carrera? <span id="labora_status"></span></label>
            <select name="labora_programa_estudios" id="labora_programa_estudios" class="form-control">
                <option value="">Seleccione...</option>
                <option value="1" <?php echo $labora_programa_estudios == '1' ? 'selected' : ''; ?>>Sí</option>
                <option value="0" <?php echo $labora_programa_estudios == '0' ? 'selected' : ''; ?>>No</option>
            </select>
            <span class="field-status" id="labora_message"></span>
        </div>

        <!-- Cargo -->
        <div class="form-group mb-3">
            <label for="cargo_actual" class="form-label">Cargo actual <span id="cargo_status"></span></label>
            <input type="text" name="cargo_actual" id="cargo_actual" class="form-control" 
                   placeholder="Ej: Analista de Sistemas" maxlength="100" 
                   value="<?php echo htmlspecialchars($cargo_actual); ?>">
            <span class="validation-rules">Mínimo 2 caracteres, máximo 100 caracteres</span>
            <span class="field-status" id="cargo_message"></span>
        </div>

        <!-- Condición Laboral -->
        <div class="form-group mb-3">
            <label for="condicion_laboral" class="form-label">Condición laboral <span id="condicion_status"></span></label>
            <select name="condicion_laboral" id="condicion_laboral" class="form-control">
                <option value="">Seleccione...</option>
                <option value="1" <?php echo $condicion_laboral == '1' ? 'selected' : ''; ?>>Dependiente</option>
                <option value="2" <?php echo $condicion_laboral == '2' ? 'selected' : ''; ?>>Independiente</option>
                <option value="3" <?php echo $condicion_laboral == '3' ? 'selected' : ''; ?>>Prácticas</option>
            </select>
            <span class="field-status" id="condicion_message"></span>
        </div>

        <!-- Ingreso mensual -->
        <div class="form-group mb-3">
            <label for="ingreso_bruto_mensual" class="form-label">Ingreso Bruto Mensual <span id="ingreso_status"></span></label>
            <input type="number" step="0.01" name="ingreso_bruto_mensual" id="ingreso_bruto_mensual" 
                   class="form-control" placeholder="Ej: 1500.00" min="0.01" max="999999.99"
                   oninput="validarIngreso(this)" value="<?php echo htmlspecialchars($ingreso_bruto_mensual); ?>">
            <span class="validation-rules">Máximo 7 dígitos (999,999.99)</span>
            <span class="field-status" id="ingreso_message"></span>
        </div>

        <!-- Satisfacción -->
        <div class="form-group mb-3">
            <label for="satisfaccion_trabajo" class="form-label">Nivel de satisfacción con tu trabajo <span id="satisfaccion_status"></span></label>
            <select name="satisfaccion_trabajo" id="satisfaccion_trabajo" class="form-control">
                <option value="">Seleccione...</option>
                <option value="Muy satisfecho" <?php echo $satisfaccion_trabajo == 'Muy satisfecho' ? 'selected' : ''; ?>>Muy satisfecho</option>
                <option value="Satisfecho" <?php echo $satisfaccion_trabajo == 'Satisfecho' ? 'selected' : ''; ?>>Satisfecho</option>
                <option value="Neutral" <?php echo $satisfaccion_trabajo == 'Neutral' ? 'selected' : ''; ?>>Neutral</option>
                <option value="Insatisfecho" <?php echo $satisfaccion_trabajo == 'Insatisfecho' ? 'selected' : ''; ?>>Insatisfecho</option>
                <option value="Muy insatisfecho" <?php echo $satisfaccion_trabajo == 'Muy insatisfecho' ? 'selected' : ''; ?>>Muy insatisfecho</option>
            </select>
            <span class="field-status" id="satisfaccion_message"></span>
        </div>

        <!-- Fecha de inicio -->
        <div class="form-group mb-3">
            <label for="fecha_inicio" class="form-label">Fecha de inicio en el trabajo <span id="fecha_inicio_status"></span></label>
            <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-control" 
                   max="<?php echo date('Y-m-d'); ?>" value="<?php echo htmlspecialchars($fecha_inicio); ?>">
            <span class="validation-rules">No puede ser una fecha futura</span>
            <span class="field-status" id="fecha_inicio_message"></span>
        </div>

        <!-- NUEVO: Fecha de fin (Opcional) -->
        <div class="form-group mb-3">
            <label for="fecha_fin" class="form-label">Fecha de fin en el trabajo (opcional) <span id="fecha_fin_status"></span></label>
            <input type="date" name="fecha_fin" id="fecha_fin" class="form-control" 
                   value="<?php echo htmlspecialchars($fecha_fin); ?>">
            <span class="validation-rules">Puede estar vacío o ser una fecha futura (para trabajos que planea dejar)</span>
            <span class="field-status" id="fecha_fin_message"></span>
        </div>

        <!-- Botones -->
        <div class="row mt-3">
            <div class="col-12 mb-2">
                <button type="submit" class="btn btn-primary w-100">Enviar Encuesta</button>
            </div>
            <div class="col-12 col-md-6 mb-2">
                <button type="button" class="btn btn-success w-100" id="btnEnviarCorreo">Enviar Correo Masivo</button>
            </div>
            <div class="col-12 col-md-6 mb-2">
                <button type="button" class="btn btn-info w-100" id="btnCopiarEnlace">Copiar Enlace</button>
            </div>
            <div class="col-12 col-md-6 mb-2">
                <button type="button" class="btn btn-secondary w-100" onclick="clearLocalStorage()">Limpiar Datos Guardados</button>
            </div>
        </div>
    </form>
</div>

<script>
    // Objeto para almacenar datos temporalmente
    let encuestaData = JSON.parse(localStorage.getItem('encuestaData')) || {};
    let submitted = false; // Controlar si se hizo clic en enviar
    let empresaExiste = false; // Nuevo: para verificar si empresa ya existe
    let empresaRazonSocial = ''; // Nuevo: razón social de la empresa

    // ========== NUEVAS FUNCIONES DE VERIFICACIÓN DE EMPRESA ==========
    
    // Función para verificar si una empresa existe por RUC
    async function verificarEmpresa(ruc) {
        if (!ruc || ruc.length !== 11) {
            const infoMessage = document.getElementById('empresa_info_message');
            infoMessage.style.display = 'none';
            empresaExiste = false;
            empresaRazonSocial = '';
            return;
        }

        // Mostrar indicador de carga
        const infoMessage = document.getElementById('empresa_info_message');
        infoMessage.innerHTML = '🔍 Verificando empresa en la base de datos...';
        infoMessage.className = 'alert alert-info';
        infoMessage.style.display = 'block';

        try {
            // CORREGIDO: Usar la ruta correcta
            const response = await fetch(`index.php?action=encuesta&check_empresa=1&ruc=${ruc}`);
            
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                if (data.exists) {
                    // Empresa EXISTE
                    empresaExiste = true;
                    empresaRazonSocial = data.razon_social;
                    
                    infoMessage.innerHTML = `
                        <i class="fas fa-check-circle"></i> 
                        <strong>Empresa ya registrada</strong><br>
                        Razón Social: ${data.razon_social}<br>
                        <small>Esta empresa ya está en el sistema</small>
                    `;
                    infoMessage.className = 'alert alert-success';
                    
                } else {
                    // Empresa NO EXISTE
                    empresaExiste = false;
                    
                    infoMessage.innerHTML = `
                        <i class="fas fa-exclamation-triangle"></i> 
                        <strong>Empresa no encontrada</strong><br>
                        El RUC ${ruc} no está registrado en el sistema<br>
                        <small>Se creará automáticamente con datos básicos al enviar la encuesta</small>
                    `;
                    infoMessage.className = 'alert alert-warning';
                }
            } else {
                infoMessage.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${data.message || 'Error al verificar empresa'}`;
                infoMessage.className = 'alert alert-danger';
            }
        } catch (error) {
            console.error('Error al verificar empresa:', error);
            infoMessage.innerHTML = `<i class="fas fa-exclamation-circle"></i> Error de conexión. Intente nuevamente.`;
            infoMessage.className = 'alert alert-danger';
        }
    }

    // ========== FUNCIÓN PARA HABILITAR/DESHABILITAR CAMPOS SEGÚN "¿TRABAJA?" ==========
    function toggleLaboralFields() {
        const trabajaSelect = document.getElementById('trabaja');
        const trabajaValue = parseInt(trabajaSelect.value);
        
        // Campos que se habilitan/deshabilitan
        const camposLaborales = [
            'ruc_empresa', 'labora_programa_estudios', 'cargo_actual',
            'condicion_laboral', 'ingreso_bruto_mensual', 'satisfaccion_trabajo',
            'fecha_inicio', 'fecha_fin'
        ];

        if (trabajaValue === 1) {
            // Si responde "Sí", habilitar todos los campos laborales
            camposLaborales.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    // Quitar disabled y readonly
                    field.disabled = false;
                    field.readOnly = false;
                    field.classList.remove('disabled-field');
                    
                    // Solo hacer required los campos esenciales
                    if (['ruc_empresa', 'cargo_actual', 'fecha_inicio', 'ingreso_bruto_mensual'].includes(fieldId)) {
                        field.required = true;
                    } else {
                        field.required = false;
                    }
                    
                    // Si es RUC, verificar empresa si tiene valor
                    if (fieldId === 'ruc_empresa' && field.value && field.value.length === 11) {
                        verificarEmpresa(field.value);
                    }
                }
            });

        } else if (trabajaValue === 0) {
            // Si responde "No", deshabilitar campos laborales
            camposLaborales.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.required = false;
                    field.disabled = true;
                    field.readOnly = true;
                    field.classList.add('disabled-field');
                    
                    // NO LIMPIAR LOS VALORES aquí, déjalos como están
                    // field.value = ''; // <-- COMENTA ESTA LÍNEA
                    
                    // Mostrar placeholder informativo
                    if (fieldId === 'ruc_empresa') {
                        field.placeholder = "No aplica - No trabaja";
                    } else if (fieldId === 'cargo_actual') {
                        field.placeholder = "No aplica - No trabaja";
                    } else if (fieldId === 'ingreso_bruto_mensual') {
                        field.placeholder = "No aplica - No trabaja";
                    }
                }
            });

            // Ocultar mensaje de empresa
            document.getElementById('empresa_info_message').style.display = 'none';
            empresaExiste = false;
            empresaRazonSocial = '';
            
        } else {
            // Si no ha seleccionado nada, limpiar campos
            camposLaborales.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.required = false;
                    field.value = '';
                }
            });
            
            // Ocultar mensaje de empresa
            document.getElementById('empresa_info_message').style.display = 'none';
            empresaExiste = false;
            empresaRazonSocial = '';
        }
    }

    // ========== FUNCIÓN PARA VALIDAR FECHAS ==========
    function validarFechaFin() {
        const fechaInicio = document.getElementById('fecha_inicio').value;
        const fechaFin = document.getElementById('fecha_fin').value;
        const messageElement = document.getElementById('fecha_fin_message');
        const fechaFinInput = document.getElementById('fecha_fin');
        
        // Solo validar si ambas fechas tienen valor
        if (fechaInicio && fechaFin) {
            if (new Date(fechaFin) < new Date(fechaInicio)) {
                if (messageElement) {
                    messageElement.innerHTML = '❌ La fecha fin no puede ser anterior a la fecha inicio';
                    messageElement.style.color = '#dc3545';
                }
                fechaFinInput.classList.remove('is-valid');
                fechaFinInput.classList.add('is-invalid');
                return false;
            } else {
                if (messageElement) messageElement.innerHTML = '';
                fechaFinInput.classList.remove('is-invalid');
                fechaFinInput.classList.add('is-valid');
                return true;
            }
        }
        
        // Si no hay fecha fin o no hay fecha inicio, no hay error
        if (messageElement) messageElement.innerHTML = '';
        if (fechaFinInput) {
            fechaFinInput.classList.remove('is-invalid');
            fechaFinInput.classList.add('is-valid');
        }
        return true;
    }

    // ========== FUNCIONES EXISTENTES MODIFICADAS ==========
    
    function validarIngreso(input) {
        let valor = input.value;
        
        // Remover caracteres no numéricos excepto punto decimal
        valor = valor.replace(/[^0-9.]/g, '');
        
        // Evitar más de un punto decimal
        const puntos = valor.split('.').length - 1;
        if (puntos > 1) {
            valor = valor.substring(0, valor.lastIndexOf('.'));
        }
        
        // Limitar a 6 dígitos enteros (máximo 999,999)
        const partes = valor.split('.');
        if (partes[0].length > 6) {
            partes[0] = partes[0].substring(0, 6);
        }
        
        // Limitar decimales a 2 dígitos
        if (partes.length > 1 && partes[1].length > 2) {
            partes[1] = partes[1].substring(0, 2);
        }
        
        // Reconstruir valor
        valor = partes.join('.');
        
        // Validar máximo 999999.99
        const numero = parseFloat(valor);
        if (numero > 999999.99) {
            valor = "999999.99";
        }
        
        input.value = valor;
        
        // Actualizar validación visual
        validateField('ingreso_bruto_mensual', valor, submitted);
        saveField('ingreso_bruto_mensual', valor);
    }

    function saveField(field, value) {
        encuestaData[field] = value;
        localStorage.setItem('encuestaData', JSON.stringify(encuestaData));
        showSavedBadge(field + '_status');
    }

    function showSavedBadge(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = '<span class="badge bg-success">✓ Guardado</span>';
            setTimeout(() => {
                element.innerHTML = '';
            }, 2000);
        }
    }

    function validateField(field, value, showVisual = false) {
        const messageElement = document.getElementById(field + '_message');
        const statusElement = document.getElementById(field + '_status');
        const inputElement = document.getElementById(field);
        
        const validationResult = validations[field] ? validations[field](value) : '';
        
        // Limpiar clases anteriores
        if (inputElement) {
            inputElement.classList.remove('is-valid', 'is-invalid');
        }
        
        if (!validationResult) {
            // Campo válido
            if (messageElement) messageElement.innerHTML = '';
            if (statusElement) statusElement.innerHTML = '';
            
            // Solo mostrar verde si se ha hecho submit o showVisual es true
            if ((submitted || showVisual) && inputElement && value) {
                inputElement.classList.add('is-valid');
                if (statusElement) statusElement.innerHTML = '✅';
            }
            return true;
        } else {
            // Campo inválido - solo mostrar rojo si se ha hecho submit
            if (messageElement) {
                if (submitted || showVisual) {
                    messageElement.innerHTML = validationResult;
                } else {
                    messageElement.innerHTML = '';
                }
            }
            
            if (statusElement) {
                if (submitted || showVisual) {
                    statusElement.innerHTML = '❌';
                } else {
                    statusElement.innerHTML = '';
                }
            }
            
            if (inputElement && (submitted || showVisual)) {
                inputElement.classList.add('is-invalid');
            }
            return false;
        }
    }

    // Validaciones específicas para cada campo (ACTUALIZADAS)
    const validations = {
        dni_est: (value) => {
            if (!value) return '❌ El DNI es requerido';
            if (value.length !== 8) return '❌ El DNI debe tener exactamente 8 dígitos';
            if (!/^\d+$/.test(value)) return '❌ El DNI debe contener solo números';
            return '';
        },
        ruc_empresa: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Si no trabaja, no validar RUC
            if (trabajaValue === 0) return '';
            
            // Si trabaja, validar RUC
            if (!value) return '❌ El RUC es requerido cuando se trabaja';
            if (value.length !== 11) return '❌ El RUC debe tener exactamente 11 dígitos';
            if (!/^\d+$/.test(value)) return '❌ El RUC debe contener solo números';
            return '';
        },
        trabaja: (value) => {
            if (value === '' || value === null) return '❌ Debe seleccionar si trabaja o no';
            return '';
        },
        labora_programa_estudios: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja y no tiene valor
            if (trabajaValue === 1 && (value === '' || value === null)) {
                return '⚠️ Este campo es opcional pero recomendado';
            }
            return '';
        },
        cargo_actual: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja
            if (trabajaValue === 1) {
                if (!value) return '❌ El cargo actual es requerido cuando se trabaja';
                if (value.length < 2) return '❌ El cargo debe tener al menos 2 caracteres';
                if (value.length > 100) return '❌ El cargo no puede tener más de 100 caracteres';
                if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s\-\.,0-9]+$/.test(value)) return '❌ Solo se permiten letras, números y espacios';
            }
            return '';
        },
        condicion_laboral: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja y no tiene valor
            if (trabajaValue === 1 && (value === '' || value === null)) {
                return '⚠️ Este campo es opcional pero recomendado';
            }
            return '';
        },
        ingreso_bruto_mensual: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja
            if (trabajaValue === 1) {
                if (!value) return '❌ El ingreso bruto mensual es requerido cuando se trabaja';
                
                const numero = parseFloat(value);
                if (isNaN(numero)) return '❌ Debe ser un número válido';
                if (numero <= 0) return '❌ El ingreso debe ser mayor a 0';
                if (numero > 999999.99) return '❌ El ingreso no puede ser mayor a 999,999.99';
                
                // Validar máximo 7 dígitos (6 enteros + 2 decimales)
                const valorStr = value.toString();
                const partes = valorStr.split('.');
                const enteros = partes[0];
                const decimales = partes[1] || '';
                
                if (enteros.length > 6) return '❌ Máximo 6 dígitos enteros';
                if (decimales.length > 2) return '❌ Máximo 2 decimales';
            }
            return '';
        },
        satisfaccion_trabajo: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja y no tiene valor
            if (trabajaValue === 1 && (value === '' || value === null)) {
                return '⚠️ Este campo es opcional pero recomendado';
            }
            return '';
        },
        fecha_inicio: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja
            if (trabajaValue === 1) {
                if (!value) return '❌ La fecha de inicio es requerida cuando se trabaja';
                const selectedDate = new Date(value);
                const today = new Date();
                today.setHours(23, 59, 59, 999);
                if (selectedDate > today) return '❌ La fecha no puede ser futura';
                
                const minDate = new Date();
                minDate.setFullYear(today.getFullYear() - 50);
                if (selectedDate < minDate) return '❌ La fecha no puede ser menor a 50 años atrás';
            }
            return '';
        },
        fecha_fin: (value) => {
            const trabajaValue = parseInt(document.getElementById('trabaja').value);
            
            // Solo validar si trabaja y tiene valor
            if (trabajaValue === 1 && value) {
                // Validar que fecha_fin sea mayor que fecha_inicio
                const fechaInicioInput = document.getElementById('fecha_inicio');
                if (fechaInicioInput && fechaInicioInput.value) {
                    const fechaInicio = new Date(fechaInicioInput.value);
                    const fechaFin = new Date(value);
                    if (fechaFin < fechaInicio) return '❌ La fecha de fin no puede ser anterior a la fecha de inicio';
                }
                
                // Validar que no sea muy antigua (opcional)
                const minDate = new Date();
                minDate.setFullYear(minDate.getFullYear() - 50);
                const fechaFin = new Date(value);
                if (fechaFin < minDate) return '❌ La fecha no puede ser menor a 50 años atrás';
            }
            return '';
        }
    };

    function applySilentValidation(fieldId) {
        const element = document.getElementById(fieldId);
        if (element) {
            // Validar silenciosamente mientras se escribe (sin mostrar colores)
            element.addEventListener('input', function() {
                validateField(fieldId, this.value, false);
                saveField(fieldId, this.value);
            });
            
            // Validar silenciosamente al cambiar (para selects)
            element.addEventListener('change', function() {
                validateField(fieldId, this.value, false);
                saveField(fieldId, this.value);
            });
        }
    }

    function loadSavedData() {
        if (Object.keys(encuestaData).length > 0) {
            for (const [field, value] of Object.entries(encuestaData)) {
                const element = document.getElementById(field);
                if (element) {
                    element.value = value;
                    // Validar el campo cargado silenciosamente
                    validateField(field, value, false);
                }
            }
        }
    }

    function clearLocalStorage() {
        localStorage.removeItem('encuestaData');
        encuestaData = {};
        document.getElementById('encuestaForm').reset();
        submitted = false;
        
        // Limpiar mensajes de estado y clases
        const statusElements = document.querySelectorAll('[id$="_status"], [id$="_message"]');
        statusElements.forEach(element => {
            element.innerHTML = '';
        });
        
        const inputElements = document.querySelectorAll('.form-control');
        inputElements.forEach(element => {
            element.classList.remove('is-valid', 'is-invalid');
        });
        
        // Ocultar mensaje de empresa
        document.getElementById('empresa_info_message').style.display = 'none';
        
        // Resetear valores de empresa
        empresaExiste = false;
        empresaRazonSocial = '';
        
        alert('Datos temporales eliminados');
    }

    function validateAllFieldsWithColors() {
        let allValid = true;
        for (const field in validations) {
            const element = document.getElementById(field);
            if (element) {
                // Verificar si el campo está deshabilitado
                if (element.disabled) {
                    continue; // Saltar validación si está deshabilitado
                }
                
                if (!validateField(field, element.value, true)) {
                    allValid = false;
                }
            }
        }
        
        // Validación adicional de fecha_fin
        if (!validarFechaFin()) {
            allValid = false;
        }
        
        return allValid;
    }

    function initializeSilentValidations() {
        // Aplicar validación silenciosa a todos los campos
        for (const field in validations) {
            applySilentValidation(field);
        }
        
        // Validaciones especiales para campos numéricos
        document.getElementById('dni_est').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 8) {
                this.value = this.value.slice(0, 8);
            }
        });

        document.getElementById('ruc_empresa').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 11) {
                this.value = this.value.slice(0, 11);
            }
        });
        
        // Validación especial para ingreso bruto mensual (máximo 7 dígitos)
        document.getElementById('ingreso_bruto_mensual').addEventListener('input', function(e) {
            validarIngreso(this);
        });
        
        // Validación cruzada entre fecha_inicio y fecha_fin
        document.getElementById('fecha_inicio').addEventListener('change', function() {
            // Si hay fecha_fin, validar que sea mayor que fecha_inicio
            const fechaFin = document.getElementById('fecha_fin').value;
            if (fechaFin) {
                validateField('fecha_fin', fechaFin, submitted);
            }
            validarFechaFin();
        });
        
        document.getElementById('fecha_fin').addEventListener('change', validarFechaFin);
    }

    // Event listeners para cada campo
    document.addEventListener('DOMContentLoaded', function() {
        loadSavedData();
        initializeSilentValidations();

        // Configurar evento para "¿Estás trabajando actualmente?"
        document.getElementById('trabaja').addEventListener('change', function() {
            toggleLaboralFields();
            // Revalidar todos los campos cuando cambia esta opción
            for (const field in validations) {
                const element = document.getElementById(field);
                if (element) {
                    validateField(field, element.value, submitted);
                }
            }
        });

        // Configurar evento para verificar empresa cuando se escribe RUC
        document.getElementById('ruc_empresa').addEventListener('input', function() {
            const ruc = this.value;
            
            // Limpiar solo números y limitar a 11 dígitos
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 11) {
                this.value = this.value.slice(0, 11);
            }
            
            // Verificar empresa después de 500ms de inactividad
            clearTimeout(this.verificarTimeout);
            this.verificarTimeout = setTimeout(() => {
                if (ruc.length === 11) {
                    verificarEmpresa(ruc);
                } else {
                    // Si no es RUC completo, ocultar mensaje
                    document.getElementById('empresa_info_message').style.display = 'none';
                    empresaExiste = false;
                    empresaRazonSocial = '';
                }
            }, 500);
        });

        // Validación antes de enviar el formulario
        document.getElementById('encuestaForm').addEventListener('submit', function(e) {
            submitted = true;
            
            if (!validateAllFieldsWithColors()) {
                e.preventDefault();
                alert('❌ Por favor, complete todos los campos correctamente antes de enviar.');
                // Hacer scroll al primer campo con error
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            } else {
                // Mostrar confirmación con resumen
                const trabajaValue = parseInt(document.getElementById('trabaja').value);
                let mensaje = "¿Confirma el envío de la encuesta?\n\n";
                mensaje += "DNI: " + document.getElementById('dni_est').value + "\n";
                mensaje += "Trabaja actualmente: " + (trabajaValue === 1 ? "Sí" : "No");

                if (trabajaValue === 1) {
                    const fechaInicio = document.getElementById('fecha_inicio').value;
                    const fechaFin = document.getElementById('fecha_fin').value;
                    
                    if (fechaInicio) {
                        mensaje += "\nFecha inicio: " + fechaInicio;
                    }
                    if (fechaFin) {
                        mensaje += "\nFecha fin: " + fechaFin + " (opcional)";
                    }
                    
                    const ruc = document.getElementById('ruc_empresa').value;
                    if (ruc && ruc.length === 11) {
                        mensaje += "\nRUC Empresa: " + ruc;
                        
                        // Información sobre estado de la empresa
                        if (empresaExiste) {
                            mensaje += "\n\nEsta empresa ya está registrada: " + empresaRazonSocial;
                        } else {
                            mensaje += "\n\nEsta empresa no está registrada aún.";
                            mensaje += "\nSe creará automáticamente con datos básicos.";
                        }
                    }
                }

                if (!confirm(mensaje)) {
                    e.preventDefault();
                }
            }
        });

        // Botón enviar correo MASIVO (versión AJAX)
        const enviarCorreoBtn = document.getElementById('btnEnviarCorreo');
        enviarCorreoBtn.addEventListener('click', async function(event) {
            // Confirmar que el usuario quiere enviar correos masivos
            if (!confirm('⚠️ ¿Está seguro de enviar correos de la encuesta a TODOS los estudiantes egresados?\n\nEsta acción enviará correos a todos los estudiantes con estado "egresado".')) {
                return;
            }
            
            // Mostrar indicador de carga
            const originalText = enviarCorreoBtn.innerHTML;
            enviarCorreoBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Enviando masivamente...';
            enviarCorreoBtn.disabled = true;
            
            try {
                const response = await fetch('index.php?action=mensaje', {
                    method: 'GET',
                    headers: {
                        'Accept': 'text/html',
                    }
                });
                
                if (response.ok) {
                    const html = await response.text();
                    
                    const modal = document.createElement('div');
                    modal.style.cssText = `
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(0,0,0,0.5);
                        z-index: 9999;
                        overflow-y: auto;
                        padding: 20px;
                    `;
                    
                    const content = document.createElement('div');
                    content.style.cssText = `
                        background: white;
                        max-width: 900px;
                        margin: 20px auto;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    `;
                    
                    content.innerHTML = html;
                    
                    const closeBtn = document.createElement('button');
                    closeBtn.textContent = 'Cerrar';
                    closeBtn.style.cssText = `
                        display: block;
                        margin: 20px auto 0;
                        padding: 8px 20px;
                        background: #666;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    `;
                    closeBtn.onclick = () => document.body.removeChild(modal);
                    
                    content.appendChild(closeBtn);
                    modal.appendChild(content);
                    document.body.appendChild(modal);
                    
                } else {
                    throw new Error('Error en la respuesta del servidor');
                }
                
            } catch (error) {
                console.error('Error:', error);
                alert('❌ Error al enviar correos: ' + error.message);
            } finally {
                // Restaurar botón
                enviarCorreoBtn.innerHTML = originalText;
                enviarCorreoBtn.disabled = false;
            }
        });

        // Botón copiar enlace
        const copyBtn = document.getElementById('btnCopiarEnlace');
        copyBtn.addEventListener('click', function(event) {
            const urlEncuesta = `https://seguimiento.mallfers.com/encuesta.php`;
            navigator.clipboard.writeText(urlEncuesta)
                .then(() => {
                    alert("🔗 Enlace copiado. Ahora puedes compartirlo libremente 💌");
                })
                .catch(err => {
                    console.error("Error al copiar el enlace: ", err);
                    alert("⚠ Error copiando el enlace. Hazlo manual si es urgente.");
                });
        });

        // Inicializar el estado de los campos según la selección actual
        toggleLaboralFields();
    });
</script>

<style>
.disabled-field {
    background-color: #f8f9fa;
    color: #6c757d;
    cursor: not-allowed;
    opacity: 0.7;
}

.required-field::after {
    content: " *";
    color: #dc3545;
}

.field-status {
    display: block;
    font-size: 0.875em;
    margin-top: 0.25rem;
}

.validation-rules {
    display: block;
    font-size: 0.875em;
    color: #6c757d;
    margin-top: 0.25rem;
}

.alert {
    border-radius: 0.375rem;
    padding: 1rem;
    margin-bottom: 1rem;
    border: 1px solid transparent;
}

.alert-success {
    color: #0f5132;
    background-color: #d1e7dd;
    border-color: #badbcc;
}

.alert-warning {
    color: #664d03;
    background-color: #fff3cd;
    border-color: #ffecb5;
}

.alert-danger {
    color: #842029;
    background-color: #f8d7da;
    border-color: #f5c2c7;
}

.alert-info {
    color: #055160;
    background-color: #cff4fc;
    border-color: #b6effb;
}

/* Estilo para campos opcionales */
.form-label:not(.required-field)::after {
    content: " (opcional)";
    color: #6c757d;
    font-size: 0.9em;
    font-weight: normal;
}
</style>