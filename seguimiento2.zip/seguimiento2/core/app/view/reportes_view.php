<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Reporte General del Sistema</title>
<!-- ICONOS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<!-- AOS Animaciones -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/reportes.css">
</head>
<body>
<!-- Logo oculto para PDF -->
<img id="logoInstitucional" src="assets/img/inst.png" style="display:none;">

<div class="container">
    <div class="admin-content-header">
        <div class="admin-header-title py-4">
            <h1 class="display-6 fw-bold">Reporte General del Sistema</h1>
            <p class="lead mb-0">Generar reportes estadísticos del seguimiento de egresados</p>
        </div>
    </div>

    <!-- ========================= -->
    <!-- ESTADÍSTICAS GENERALES    -->
    <!-- ========================= -->
    <div class="stats-container">
        <div class="stat-card carreras" data-aos="fade-up">
            <div class="stat-icon" style="color: #4fc3f7;">
                <i class="fa-solid fa-graduation-cap"></i>
            </div>
            <div class="stat-value" id="total-carreras">0</div>
            <div class="stat-label">Total de Carreras</div>
        </div>
        
        <div class="stat-card estudiantes" data-aos="fade-up" data-aos-delay="100">
            <div class="stat-icon" style="color: #43a047;">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="stat-value" id="total-estudiantes">0</div>
            <div class="stat-label">Total de Estudiantes</div>
        </div>
        
        <div class="stat-card empresas" data-aos="fade-up" data-aos-delay="200">
            <div class="stat-icon" style="color: #ff5722;">
                <i class="fa-solid fa-building"></i>
            </div>
            <div class="stat-value" id="total-empresas">0</div>
            <div class="stat-label">Total de Empresas</div>
        </div>
        
        <div class="stat-card origen-encuestas" data-aos="fade-up" data-aos-delay="300">
            <div class="stat-icon" style="color: #9c27b0;">
                <i class="fa-solid fa-chart-pie"></i>
            </div>
            <div class="stat-value" id="total-encuestas">0</div>
            <div class="stat-label">Total Encuestas</div>
        </div>
    </div>

    <!-- RESUMEN COMPACTO DE ORIGEN -->
    <div class="summary-stats">
        <div class="summary-stat-card bg-info" id="llamada-summary">
            <h6>Por Llamada</h6>
            <h3 id="llamada-count">0</h3>
            <small id="llamada-estudiantes">0 estudiantes</small>
        </div>
        <div class="summary-stat-card bg-warning" id="correo-summary">
            <h6>Por Correo</h6>
            <h3 id="correo-count">0</h3>
            <small id="correo-estudiantes">0 estudiantes</small>
        </div>
    </div>

    <!-- ========================= -->
    <!-- BOTONES GENERALES         -->
    <!-- ========================= -->
    <div class="general-buttons">
        <button class="general-btn general-btn-excel" id="btnGeneralExcel">
            <i class="fa-solid fa-file-excel"></i> Exportar Todo a Excel
        </button>
        <button class="general-btn general-btn-pdf" id="btnGeneralPDF">
            <i class="fa-solid fa-file-pdf"></i> Exportar Todo a PDF
        </button>
        <button class="general-btn general-btn-origen" id="btnExportOrigen">
            <i class="fa-solid fa-file-excel"></i> Exportar Origen Excel
        </button>
    </div>

    <!-- ========================= -->
    <!-- FILTRO DE REPORTES        -->
    <!-- ========================= -->
    <div class="filter-container">
        <label for="filtroReportes" class="filter-label">
            Seleccionar reporte:
        </label>
        <select id="filtroReportes" class="filter-select">
            <option value="">-- Mostrar todos --</option>
            <option value="origen">Origen de Encuestas</option>
            <option value="sector">Empresas por Sector</option>
            <option value="ingreso">Ingreso Promedio Mensual</option>
            <option value="trabaja">¿Están trabajando?</option>
            <option value="condicion">Condición Laboral</option>
            <option value="cargo">Cargos Laborales</option>
            <option value="detalle_egresados">Detalle de Egresados</option>
            <option value="egresados_encuesta">Egresados que respondieron encuesta</option>
            <option value="tipo_seguimiento">Tipo de Seguimiento (Correo/Llamada)</option>
            <option value="respuesta_programa">Respuesta por Programa</option>
        </select>
        <p style="font-size: 14px; color: #666; margin-top: 5px;">
            Selecciona un reporte para verlo individualmente o "Mostrar todos" para ver todos los gráficos
        </p>
    </div>

    <div class="grid">
        <!-- ORIGEN DE ENCUESTAS -->
        <div class="chart-card" data-report="origen" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-chart-pie"></i> Distribución de Encuestas por Origen</h5>
            <div class="chart-container">
                <canvas id="origenChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="origen"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="origen"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- EMPRESAS POR SECTOR -->
        <div class="chart-card" data-report="sector" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-building"></i> Empresas por Sector</h5>
            <div class="chart-container">
                <canvas id="sectorChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="sector"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="sector"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- INGRESO PROMEDIO MENSUAL -->
        <div class="chart-card" data-report="ingreso" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-money-bill-wave"></i> Ingreso Promedio Mensual</h5>
            <div class="chart-container">
                <canvas id="ingresoChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="ingreso"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="ingreso"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- ¿LOS EGRESADOS ESTÁN TRABAJANDO? -->
        <div class="chart-card" data-report="trabaja" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-briefcase"></i> ¿Los egresados están trabajando?</h5>
            <div class="chart-container">
                <canvas id="trabajaChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="trabaja"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="trabaja"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- CONDICIÓN LABORAL -->
        <div class="chart-card" data-report="condicion" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-id-card"></i> Condición Laboral</h5>
            <div class="chart-container">
                <canvas id="condicionChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="condicion"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="condicion"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- CARGOS LABORALES -->
        <div class="chart-card" data-report="cargo" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-suitcase"></i> Cargos Laborales Frecuentes</h5>
            <div class="chart-container">
                <canvas id="cargoChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="cargo"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="cargo"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- EGRESADOS QUE RESPONDIERON ENCUESTA -->
        <div class="chart-card" data-report="egresados_encuesta" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-clipboard-check"></i> Egresados que respondieron la encuesta</h5>
            <div class="chart-container">
                <canvas id="egresadosEncuestaChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="egresados_encuesta"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="egresados_encuesta"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>


        <!-- RESPUESTA POR PROGRAMA -->
        <div class="chart-card" data-report="respuesta_programa" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-chart-bar"></i> Porcentaje de Respuesta por Programa</h5>
            <div class="chart-container">
                <canvas id="respuestaProgramaChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="respuesta_programa"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="respuesta_programa"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>

        <!-- DETALLE DE EGRESADOS -->
        <div class="chart-card" data-report="detalle_egresados" data-aos="zoom-in">
            <h5 class="chart-title"><i class="fa-solid fa-list"></i> Detalle de Egresados con/Sin Encuesta</h5>
            <div class="chart-container">
                <canvas id="detalleEgresadosChart"></canvas>
            </div>
            <div class="btn-row">
                <button class="btn btn-excel btnExcel" data-chart="detalle_egresados"><i class="fa-solid fa-file-excel"></i> Excel</button>
                <button class="btn btn-pdf btnPDF" data-chart="detalle_egresados"><i class="fa-solid fa-file-pdf"></i> PDF</button>
            </div>
        </div>
    </div>

    <!-- ========================= -->
    <!-- TABLA DE ORIGEN ENCUESTA  -->
    <!-- ========================= -->
    <div class="table-container" data-report="origen" data-aos="fade-up">
        <div class="table-title">
            <i class="fa-solid fa-chart-pie"></i> Resumen por Origen de Encuesta
        </div>
        <div class="table-responsive">
            <table id="origenTable">
                <thead>
                    <tr>
                        <th>Origen</th>
                        <th>Estudiantes</th>
                        <th>Encuestas</th>
                        <th>Ingreso Promedio</th>
                        <th>% del Total</th>
                        <th>Primera Encuesta</th>
                    </tr>
                </thead>
                <tbody id="origenTableBody">
                    <!-- Datos se llenarán con JavaScript -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- LIBRERÍAS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>AOS.init();</script>
<script>
// =========================
// DATOS PHP → JS
// =========================
const empresasSector = <?= json_encode($empresas_sector ?? []) ?>;
const estudiantesPrograma = <?= json_encode($estudiantes_programa ?? []) ?>;
const estudiantesTurno = <?= json_encode($estudiantes_turno ?? []) ?>;
const ingresoPromedio = <?= json_encode($ingreso_promedio ?? []) ?>;

const encuestaTrabaja = <?= json_encode($encuesta_trabaja ?? []) ?>;
const encuestaArea = <?= json_encode($encuesta_area ?? []) ?>;
const encuestaCondicion = <?= json_encode($encuesta_condicion ?? []) ?>;
const encuestaCargo = <?= json_encode($encuesta_cargo ?? []) ?>;

const egresadosEncuesta = <?= json_encode($egresados_encuesta ?? []) ?>;
const tipoSeguimiento = <?= json_encode($tipo_seguimiento ?? []) ?>;
const detalleEgresados = <?= json_encode($detalle_egresados ?? []) ?>;
const respuestaPrograma = <?= json_encode($respuesta_programa ?? []) ?>;

// NUEVO: Datos de origen de encuesta
const origenEncuestas = <?= json_encode($origen_encuestas ?? []) ?>;
const totalEgresados = <?= json_encode($total_egresados ?? 0) ?>;

console.log("=== DATOS CARGADOS ===");
console.log("Empresas por sector:", empresasSector);
console.log("Estudiantes por programa:", estudiantesPrograma);
console.log("Origen encuestas:", origenEncuestas);
console.log("Total egresados:", totalEgresados);

// =========================
// CALCULAR ESTADÍSTICAS
// =========================
function calcularEstadisticas() {
    // Total de carreras (programas diferentes)
    const totalCarreras = estudiantesPrograma ? estudiantesPrograma.length : 0;
    
    // Total de estudiantes (suma de todos los estudiantes)
    const totalEstudiantes = estudiantesPrograma ? 
        estudiantesPrograma.reduce((sum, item) => sum + (parseInt(item.total_estudiantes) || 0), 0) : 0;
    
    // Total de empresas (suma de todas las empresas por sector)
    const totalEmpresas = empresasSector ? 
        empresasSector.reduce((sum, item) => sum + (parseInt(item.total) || 0), 0) : 0;

    // Total de egresados
    const totalEgresadosVal = <?= json_encode($total_egresados ?? 0) ?>;
    
    // Calcular total de encuestas y estadísticas por origen
    let totalEncuestas = 0;
    let totalEncuestasLlamada = 0;
    let totalEncuestasCorreo = 0;
    let totalEstudiantesLlamada = 0;
    let totalEstudiantesCorreo = 0;
    
    if (origenEncuestas && origenEncuestas.length > 0) {
        origenEncuestas.forEach(row => {
            const origen_original = row.origen_encuesta || '';
            let origen_display = origen_original;
            
            // Transformar nombres según lo solicitado
            if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
                origen_original.toLowerCase().includes('encuesta interna') ||
                origen_original.toLowerCase().includes('llamada')) {
                origen_display = 'Llamada';
            } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                      origen_original.toLowerCase().includes('encuesta externa') ||
                      origen_original.toLowerCase().includes('correo')) {
                origen_display = 'Correo';
            } else if (origen_original.toLowerCase() === 'origen desconocido') {
                origen_display = 'Otros';
            }
            
            const encuestas = parseInt(row.total_encuestas) || 0;
            const estudiantes = parseInt(row.total_estudiantes) || 0;
            
            totalEncuestas += encuestas;
            
            if (origen_display.includes('Llamada')) {
                totalEncuestasLlamada += encuestas;
                totalEstudiantesLlamada += estudiantes;
            } else if (origen_display.includes('Correo')) {
                totalEncuestasCorreo += encuestas;
                totalEstudiantesCorreo += estudiantes;
            }
        });
    } else {
        console.warn("No hay datos de origen de encuestas");
    }
    
    // Actualizar estadísticas en la página
    document.getElementById('total-carreras').textContent = totalCarreras;
    document.getElementById('total-estudiantes').textContent = totalEstudiantes;
    document.getElementById('total-empresas').textContent = totalEmpresas;
    document.getElementById('total-encuestas').textContent = totalEncuestas;
    
    // Actualizar resumen de origen
    document.getElementById('llamada-count').textContent = totalEncuestasLlamada;
    document.getElementById('llamada-estudiantes').textContent = totalEstudiantesLlamada + ' estudiantes';
    document.getElementById('correo-count').textContent = totalEncuestasCorreo;
    document.getElementById('correo-estudiantes').textContent = totalEstudiantesCorreo + ' estudiantes';
    
    // Actualizar tabla de origen
    actualizarTablaOrigen();
    
    return { 
        totalCarreras, 
        totalEstudiantes, 
        totalEmpresas, 
        totalEgresados: totalEgresadosVal,
        totalEncuestas,
        totalEncuestasLlamada,
        totalEncuestasCorreo,
        totalEstudiantesLlamada,
        totalEstudiantesCorreo
    };
}

// =========================
// ACTUALIZAR TABLA DE ORIGEN
// =========================
function actualizarTablaOrigen() {
    const tbody = document.getElementById('origenTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (!origenEncuestas || origenEncuestas.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No hay datos disponibles</td></tr>';
        return;
    }
    
    origenEncuestas.forEach(row => {
        const origen_original = row.origen_encuesta || '';
        let origen_display = origen_original;
        let origen_class = 'origen-sin-especificar';
        
        // Transformar los nombres según lo solicitado
        if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
            origen_original.toLowerCase().includes('encuesta interna') ||
            origen_original.toLowerCase().includes('llamada')) {
            origen_display = 'Llamada';
            origen_class = 'origen-llamada';
        } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                  origen_original.toLowerCase().includes('encuesta externa') ||
                  origen_original.toLowerCase().includes('correo')) {
            origen_display = 'Correo';
            origen_class = 'origen-correo';
        } else if (origen_original.toLowerCase() === 'origen desconocido') {
            origen_display = 'Otros';
            origen_class = 'origen-sin-especificar';
        }
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <span class="origen-badge ${origen_class}">
                    ${origen_display}
                </span>
            </td>
            <td>${row.total_estudiantes || 0}</td>
            <td>${row.total_encuestas || 0}</td>
            <td>S/ ${(parseFloat(row.ingreso_promedio) || 0).toFixed(2)}</td>
            <td>${(parseFloat(row.porcentaje_total) || 0).toFixed(2)}%</td>
            <td>${row.primera_encuesta || 'N/A'}</td>
        `;
        tbody.appendChild(tr);
    });
}

// =========================
// PROCESAR DATOS DE ORIGEN PARA GRÁFICO
// =========================
function procesarDatosOrigen() {
    if (!origenEncuestas || origenEncuestas.length === 0) {
        console.warn("No hay datos de origen para procesar");
        return {
            labels: ['Llamada', 'Correo', 'Otros'],
            data: [0, 0, 0],
            colors: [
                'rgba(76, 175, 80, 0.7)',   // Verde para Llamada
                'rgba(33, 150, 243, 0.7)',  // Azul para Correo
                'rgba(158, 158, 158, 0.7)'  // Gris para Otros
            ]
        };
    }
    
    const agrupados = {
        'Llamada': { encuestas: 0, estudiantes: 0 },
        'Correo': { encuestas: 0, estudiantes: 0 },
        'Otros': { encuestas: 0, estudiantes: 0 }
    };
    
    origenEncuestas.forEach(row => {
        const origen_original = row.origen_encuesta || '';
        let origen_display = origen_original;
        
        // Transformar nombres según lo solicitado
        if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
            origen_original.toLowerCase().includes('encuesta interna') ||
            origen_original.toLowerCase().includes('llamada')) {
            origen_display = 'Llamada';
        } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                  origen_original.toLowerCase().includes('encuesta externa') ||
                  origen_original.toLowerCase().includes('correo')) {
            origen_display = 'Correo';
        } else if (origen_original.toLowerCase() === 'origen desconocido') {
            origen_display = 'Otros';
        }
        
        const encuestas = parseInt(row.total_encuestas) || 0;
        const estudiantes = parseInt(row.total_estudiantes) || 0;
        
        if (origen_display === 'Llamada') {
            agrupados['Llamada'].encuestas += encuestas;
            agrupados['Llamada'].estudiantes += estudiantes;
        } else if (origen_display === 'Correo') {
            agrupados['Correo'].encuestas += encuestas;
            agrupados['Correo'].estudiantes += estudiantes;
        } else {
            agrupados['Otros'].encuestas += encuestas;
            agrupados['Otros'].estudiantes += estudiantes;
        }
    });
    
    // Filtrar solo los que tienen datos
    const labels = [];
    const data = [];
    const colors = [];
    
    Object.entries(agrupados).forEach(([key, value]) => {
        if (value.encuestas > 0) {
            labels.push(key);
            data.push(value.encuestas);
            
            if (key === 'Llamada') {
                colors.push('rgba(76, 175, 80, 0.7)');
            } else if (key === 'Correo') {
                colors.push('rgba(33, 150, 243, 0.7)');
            } else {
                colors.push('rgba(158, 158, 158, 0.7)');
            }
        }
    });
    
    console.log("Datos origen procesados:", { labels, data, colors });
    return { labels, data, colors };
}

// =========================
// NORMALIZADOR SÍ / NO
// =========================
function normalizarSN(valor) {
    if (valor === null || valor === undefined || valor === "" || valor === "no definido" || valor === "No definido") {
        return null;
    }
    
    const strValor = String(valor).trim();
    
    const valoresSi = ["1", "true", "sí", "si", "yes", "y", "verdadero", "s", "t", "v", "true", "t"];
    const valoresNo = ["0", "false", "no", "not", "n", "falso", "f", "n"];
    
    if (valoresSi.includes(strValor.toLowerCase())) {
        return "Sí";
    }
    
    if (valoresNo.includes(strValor.toLowerCase())) {
        return "No";
    }
    
    const numValor = parseInt(strValor);
    if (!isNaN(numValor)) {
        return numValor === 1 ? "Sí" : "No";
    }
    
    if (strValor === "Sí" || strValor === "No") {
        return strValor;
    }
    
    return null;
}

// =========================
// PROCESAR DATOS DE ENCUESTA
// =========================
function procesarDatosEncuesta(datos, esArea = false) {
    if (!datos || datos.length === 0) {
        console.log(`Datos de encuesta ${esArea ? 'Área' : 'Trabaja'} vacíos o nulos`);
        return [
            { respuesta: "Sí", total: 0 },
            { respuesta: "No", total: 0 }
        ];
    }
    
    console.log(`Procesando datos de encuesta ${esArea ? 'Área' : 'Trabaja'}:`, datos);
    
    let si = 0, no = 0;
    
    datos.forEach(item => {
        let valor = null;
        
        if (item.trabaja !== undefined) valor = item.trabaja;
        else if (item.labora_area !== undefined) valor = item.labora_area;
        else if (item.labora_programa_estudios !== undefined) valor = item.labora_programa_estudios;
        else if (item.respuesta !== undefined) valor = item.respuesta;
        else if (item.valor !== undefined) valor = item.valor;
        else if (item.estado !== undefined) valor = item.estado;
        else if (item.area !== undefined) valor = item.area;
        
        const respuestaNormalizada = normalizarSN(valor);
        const total = parseInt(item.total || item.cantidad || item.count || 1);
        
        if (respuestaNormalizada === "Sí") {
            si += total;
        } else if (respuestaNormalizada === "No") {
            no += total;
        } else {
            // Si no es Sí ni No, contamos como "Sin respuesta"
            console.log("Respuesta no reconocida:", valor);
        }
    });
    
    if (si === 0 && no === 0) {
        console.warn(`No se encontraron datos válidos Sí/No para la encuesta ${esArea ? 'Área' : 'Trabaja'}`);
        // Retornar datos de ejemplo solo para demostración
        return [
            { respuesta: "Sí", total: 1 },
            { respuesta: "No", total: 1 }
        ];
    }
    
    const resultado = [];
    if (si > 0) resultado.push({ respuesta: "Sí", total: si });
    if (no > 0) resultado.push({ respuesta: "No", total: no });
    
    console.log(`Resultado procesado ${esArea ? 'Área' : 'Trabaja'}:`, resultado);
    return resultado;
}

// =========================
// PROCESAR DATOS DE CARGO
// =========================
function procesarDatosCargo(datos) {
    if (!datos || datos.length === 0) {
        console.log("Datos de cargo vacíos o nulos");
        return [
            { cargo: "Sin datos", total: 0 }
        ];
    }
    
    // Ordenar por total descendente y tomar solo los primeros 4
    const datosOrdenados = datos
        .filter(item => item.cargo && item.cargo.trim() !== '')
        .sort((a, b) => (parseInt(b.total) || 0) - (parseInt(a.total) || 0))
        .slice(0, 4);
    
    if (datosOrdenados.length === 0) {
        return [
            { cargo: "Sin datos", total: 0 }
        ];
    }
    
    return datosOrdenados;
}

// =========================
// PROCESAR DATOS DE RESPUESTA POR PROGRAMA
// =========================
function procesarDatosRespuestaPrograma(datos) {
    if (!datos || datos.length === 0) {
        console.log("Datos de respuesta por programa vacíos o nulos");
        return [];
    }
    
    return datos.map(item => ({
        programa: item.programa || 'Sin nombre',
        porcentaje_respuesta: parseFloat(item.porcentaje_respuesta) || 0
    }));
}

// =========================
// PROCESAR LOS DATOS
// =========================
const datosTrabajaProcesados = procesarDatosEncuesta(encuestaTrabaja, false);
const datosAreaProcesados = procesarDatosEncuesta(encuestaArea, true);
const datosOrigenProcesados = procesarDatosOrigen();
const datosCargoProcesados = procesarDatosCargo(encuestaCargo);
const datosRespuestaProgramaProcesados = procesarDatosRespuestaPrograma(respuestaPrograma);

console.log("=== DATOS PROCESADOS ===");
console.log("Trabaja procesados:", datosTrabajaProcesados);
console.log("Área procesados:", datosAreaProcesados);
console.log("Origen procesados:", datosOrigenProcesados);
console.log("Cargo procesados:", datosCargoProcesados);
console.log("Respuesta programa procesados:", datosRespuestaProgramaProcesados);

// =========================
// OBJETOS DE DATOS
// =========================
const chartData = {
    origen: origenEncuestas,
    sector: empresasSector,
    programa: estudiantesPrograma,
    turno: estudiantesTurno,
    ingreso: ingresoPromedio,
    trabaja: datosTrabajaProcesados,
    area: datosAreaProcesados,
    condicion: encuestaCondicion,
    cargo: datosCargoProcesados,
    egresados_encuesta: egresadosEncuesta,
    tipo_seguimiento: tipoSeguimiento,
    respuesta_programa: datosRespuestaProgramaProcesados,
    detalle_egresados: detalleEgresados
};

// COLUMNAS POR TABLA
const chartColumns = {
    origen: ["Origen", "Estudiantes", "Encuestas", "Ingreso Promedio", "% Total", "Primera Encuesta"],
    sector: ["Sector", "Total"],
    programa: ["Programa", "Total"],
    turno: ["Turno", "Total"],
    ingreso: ["Programa", "Ingreso Promedio"],
    trabaja: ["Respuesta", "Total"],
    area: ["Respuesta", "Total"],
    condicion: ["Condición", "Total"],
    cargo: ["Cargo", "Total"],
    egresados_encuesta: ["Estado", "Cantidad", "Porcentaje"],
    tipo_seguimiento: ["Tipo de Seguimiento", "Estudiantes", "Seguimientos"],
    respuesta_programa: ["Programa", "Egresados", "Respondieron", "% Respuesta"],
    detalle_egresados: ["Nombre", "DNI", "Carrera", "Turno", "Estado Encuesta", "Tipo Seguimiento", "Fecha"]
};

// TÍTULOS PARA PDF
const chartTitles = {
    origen: "Origen de Encuestas",
    sector: "Empresas por Sector",
    programa: "Estudiantes por Programa Académico",
    turno: "Estudiantes por Turno",
    ingreso: "Ingreso Promedio Mensual por Programa",
    trabaja: "¿Los egresados están trabajando?",
    area: "¿Trabajan en su área de estudio?",
    condicion: "Condición Laboral",
    cargo: "Cargos Laborales Frecuentes (Top 4)",
    egresados_encuesta: "Egresados que respondieron la encuesta",
    tipo_seguimiento: "Tipo de Seguimiento (Correo/Llamada)",
    respuesta_programa: "Porcentaje de Respuesta por Programa",
    detalle_egresados: "Detalle de Egresados con/Sin Encuesta"
};

// =========================
// VARIABLES GLOBALES
// =========================
const chartInstances = {};
const filtro = document.getElementById("filtroReportes");
const chartCards = document.querySelectorAll(".chart-card");

// =========================
// FUNCIÓN PARA CREAR GRÁFICOS
// =========================
function createCharts() {
    console.log("=== CREANDO GRÁFICOS ===");
    
    // Destruir gráficos existentes
    Object.values(chartInstances).forEach(chart => {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    });

    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { 
                display: true, 
                position: 'top',
                labels: {
                    font: {
                        family: "'Poppins', sans-serif",
                        size: 14,
                        weight: '600'
                    },
                    padding: 20,
                    usePointStyle: true,
                    pointStyle: 'circle',
                    color: '#333'
                }
            },
            tooltip: {
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                titleFont: {
                    family: "'Poppins', sans-serif",
                    size: 12,
                    weight: '600'
                },
                bodyFont: {
                    family: "'Poppins', sans-serif",
                    size: 12
                },
                padding: 12,
                cornerRadius: 8,
                displayColors: true,
                callbacks: {
                    label: function(context) {
                        let label = context.label || '';
                        if (label) {
                            label += ': ';
                        }
                        const value = context.raw || 0;
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                        label += `${value} (${percentage}%)`;
                        return label;
                    }
                }
            }
        }
    };

    const colors = {
        primary: '#1a237e',
        success: '#43a047',
        warning: '#ff5722',
        info: '#4fc3f7',
        danger: '#d72638',
        purple: '#9c27b0',
        orange: '#fb8c00',
        teal: '#17a2b8'
    };

    const chartsConfig = [
        { 
            id: 'origenChart', 
            data: datosOrigenProcesados, 
            type: 'pie', 
            getLabels: d => d.labels,
            getData: d => d.data,
            getColors: d => d.colors,
            title: 'Distribución de Encuestas por Origen'
        },
        
        { 
            id: 'sectorChart', 
            data: empresasSector, 
            type: 'pie', 
            getLabels: d => d.map(e => e.sector || 'Sin nombre'),
            getData: d => d.map(e => parseInt(e.total) || 0),
            colors: [colors.info, colors.success, colors.orange, colors.warning, colors.purple, colors.danger, colors.primary, '#ffeb3b'],
            title: 'Empresas por Sector'
        },
        
        { 
            id: 'programaChart', 
            data: estudiantesPrograma, 
            type: 'bar',
            getLabels: d => d.map(e => e.nom_progest || 'Sin nombre'),
            getData: d => d.map(e => parseInt(e.total_estudiantes) || 0),
            colors: colors.primary,
            title: 'Estudiantes por Programa'
        },
        
        { 
            id: 'turnoChart', 
            data: estudiantesTurno, 
            type: 'bar',
            getLabels: d => d.map(e => e.turno || 'Sin turno'),
            getData: d => d.map(e => parseInt(e.total) || 0),
            colors: colors.warning,
            title: 'Estudiantes por Turno'
        },
        
        { 
            id: 'ingresoChart', 
            data: ingresoPromedio, 
            type: 'line',
            getLabels: d => d.map(e => e.nom_progest || 'Sin nombre'),
            getData: d => d.map(e => parseFloat(e.ingreso_promedio) || 0),
            colors: colors.success,
            title: 'Ingreso Promedio Mensual'
        },
        
        { 
            id: 'trabajaChart', 
            data: datosTrabajaProcesados, 
            type: 'pie',
            getLabels: d => d.map(e => e.respuesta || 'Sin respuesta'),
            getData: d => d.map(e => parseInt(e.total) || 0),
            getColors: d => d.map(e => e.respuesta === "Sí" ? colors.success : colors.danger),
            title: '¿Los egresados están trabajando?'
        },
        
        { 
            id: 'areaChart', 
            data: datosAreaProcesados, 
            type: 'pie',
            getLabels: d => d.map(e => e.respuesta || 'Sin respuesta'),
            getData: d => d.map(e => parseInt(e.total) || 0),
            getColors: d => d.map(e => e.respuesta === "Sí" ? colors.teal : '#ffc107'),
            title: '¿Trabajan en su área de estudio?'
        },
        
        { 
            id: 'condicionChart', 
            data: encuestaCondicion, 
            type: 'bar',
            getLabels: d => d.map(e => e.condicion || 'No especificado'),
            getData: d => d.map(e => parseInt(e.total) || 0),
            colors: colors.primary,
            title: 'Condición Laboral'
        },
        
        { 
            id: 'cargoChart', 
            data: datosCargoProcesados, 
            type: 'bar',
            getLabels: d => d.map(e => e.cargo || 'No especificado'),
            getData: d => d.map(e => parseInt(e.total) || 0),
            colors: colors.purple,
            title: 'Cargos Laborales Frecuentes'
        },

        { 
            id: 'egresadosEncuestaChart', 
            data: egresadosEncuesta, 
            type: 'pie',
            getLabels: d => {
                if (d && d.length > 0) {
                    const total = parseInt(d[0].total_egresados) || 0;
                    const respondieron = parseInt(d[0].total_respondieron) || 0;
                    const noRespondieron = total - respondieron;
                    
                    return [
                        `Respondieron (${respondieron})`,
                        `No respondieron (${noRespondieron})`
                    ];
                }
                return ['No hay datos', 'Sin datos'];
            },
            getData: d => {
                if (d && d.length > 0) {
                    const total = parseInt(d[0].total_egresados) || 0;
                    const respondieron = parseInt(d[0].total_respondieron) || 0;
                    const noRespondieron = total - respondieron;
                    
                    return [respondieron, noRespondieron];
                }
                return [1, 1];
            },
            colors: ['#43a047', '#e53935'],
            title: 'Egresados que respondieron la encuesta'
        },

        { 
            id: 'tipoSeguimientoChart', 
            data: tipoSeguimiento, 
            type: 'bar',
            getLabels: d => d.map(e => e.tipo_seguimiento || 'No especificado'),
            getData: d => d.map(e => parseInt(e.total_estudiantes) || 0),
            colors: '#3949ab',
            title: 'Tipo de Seguimiento'
        },

        { 
            id: 'respuestaProgramaChart', 
            data: datosRespuestaProgramaProcesados, 
            type: 'bar',
            getLabels: d => d.map(e => e.programa || 'Sin nombre'),
            getData: d => d.map(e => parseFloat(e.porcentaje_respuesta) || 0),
            colors: '#8e24aa',
            title: 'Porcentaje de Respuesta por Programa'
        },

        { 
            id: 'detalleEgresadosChart', 
            data: detalleEgresados, 
            type: 'bar',
            getLabels: d => {
                if (d && d.length > 0) {
                    const respondieron = d.filter(e => e.estado_encuesta === 'Sí respondió').length;
                    const noRespondieron = d.filter(e => e.estado_encuesta === 'No respondió').length;
                    
                    return ['Respondieron', 'No respondieron'];
                }
                return ['Sin datos', 'Sin datos'];
            },
            getData: d => {
                if (d && d.length > 0) {
                    const respondieron = d.filter(e => e.estado_encuesta === 'Sí respondió').length;
                    const noRespondieron = d.filter(e => e.estado_encuesta === 'No respondió').length;
                    
                    return [respondieron, noRespondieron];
                }
                return [1, 1];
            },
            colors: ['#43a047', '#e53935'],
            title: 'Detalle de Egresados'
        }
        
    ];

    chartsConfig.forEach(config => {
        const canvas = document.getElementById(config.id);
        if (!canvas) {
            console.warn(`Canvas no encontrado: ${config.id}`);
            return;
        }
        
        console.log(`Creando gráfico: ${config.id}`, config.data);
        
        // Verificar si hay datos
        const hasData = config.data && 
            ((Array.isArray(config.data) && config.data.length > 0 && config.data.some(item => 
                (config.id === 'origenChart' ? (config.data.labels && config.data.labels.length > 0) : true)
            )) || 
            (!Array.isArray(config.data) && Object.keys(config.data).length > 0));
        
        if (!hasData) {
            console.warn(`Datos vacíos para: ${config.id}`);
            
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#f8f9fa';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#6c757d';
            ctx.font = '16px Poppins';
            ctx.textAlign = 'center';
            ctx.fillText('Datos no disponibles', canvas.width/2, canvas.height/2);
            
            // Agregar título
            ctx.font = '14px Poppins';
            ctx.fillText(config.title || 'Sin título', canvas.width/2, canvas.height/2 - 30);
            return;
        }

        try {
            if (config.type === 'pie' || config.type === 'doughnut') {
                const pieOptions = {
                    ...commonOptions,
                    plugins: {
                        ...commonOptions.plugins,
                        legend: {
                            ...commonOptions.plugins.legend,
                            position: 'right',
                            align: 'center'
                        },
                        title: {
                            display: true,
                            text: config.title,
                            font: {
                                size: 16,
                                weight: 'bold'
                            },
                            padding: 20
                        }
                    }
                };

                const chartConfig = {
                    type: config.type,
                    data: {
                        labels: config.getLabels(config.data),
                        datasets: [{
                            data: config.getData(config.data),
                            backgroundColor: config.getColors ? config.getColors(config.data) : config.colors,
                            borderColor: '#fff',
                            borderWidth: 3,
                            hoverOffset: 20,
                            borderRadius: 8
                        }]
                    },
                    options: pieOptions
                };

                chartInstances[config.id.replace('Chart', '')] = new Chart(canvas, chartConfig);
                
            } else if (config.type === 'bar') {
                const chartConfig = {
                    type: config.type,
                    data: {
                        labels: config.getLabels(config.data),
                        datasets: [{
                            label: config.title || 'Cantidad',
                            data: config.getData(config.data),
                            backgroundColor: config.colors,
                            borderColor: config.colors,
                            borderWidth: 1,
                            borderRadius: 6,
                            barPercentage: 0.7,
                            categoryPercentage: 0.8
                        }]
                    },
                    options: {
                        ...commonOptions,
                        plugins: {
                            ...commonOptions.plugins,
                            title: {
                                display: true,
                                text: config.title,
                                font: {
                                    size: 16,
                                    weight: 'bold'
                                },
                                padding: 20
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    font: {
                                        family: "'Poppins', sans-serif",
                                        size: 12
                                    },
                                    color: '#666'
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)',
                                    drawBorder: false
                                }
                            },
                            x: {
                                ticks: {
                                    font: {
                                        family: "'Poppins', sans-serif",
                                        size: 12
                                    },
                                    color: '#666'
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)',
                                    drawBorder: false
                                }
                            }
                        }
                    }
                };

                // Configuración especial para gráfico horizontal
                if (config.id === 'respuestaProgramaChart') {
                    chartConfig.options = {
                        ...commonOptions,
                        indexAxis: 'y',
                        plugins: {
                            ...commonOptions.plugins,
                            title: {
                                display: true,
                                text: config.title,
                                font: {
                                    size: 16,
                                    weight: 'bold'
                                },
                                padding: 20
                            }
                        },
                        scales: {
                            x: {
                                beginAtZero: true,
                                ticks: {
                                    font: {
                                        family: "'Poppins', sans-serif",
                                        size: 12
                                    },
                                    color: '#666',
                                    callback: function(value) {
                                        return value + '%';
                                    }
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)',
                                    drawBorder: false
                                }
                            },
                            y: {
                                ticks: {
                                    font: {
                                        family: "'Poppins', sans-serif",
                                        size: 12
                                    },
                                    color: '#666'
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)',
                                    drawBorder: false
                                }
                            }
                        }
                    };
                }

                chartInstances[config.id.replace('Chart', '')] = new Chart(canvas, chartConfig);
                
            } else if (config.type === 'line') {
                const chartConfig = {
                    type: config.type,
                    data: {
                        labels: config.getLabels(config.data),
                        datasets: [{
                            label: 'Ingreso Promedio',
                            data: config.getData(config.data),
                            backgroundColor: 'rgba(67, 160, 71, 0.1)',
                            borderColor: config.colors,
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4,
                            pointBackgroundColor: config.colors,
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 6,
                            pointHoverRadius: 8
                        }]
                    },
                    options: {
                        ...commonOptions,
                        plugins: {
                            ...commonOptions.plugins,
                            title: {
                                display: true,
                                text: config.title,
                                font: {
                                    size: 16,
                                    weight: 'bold'
                                },
                                padding: 20
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    font: {
                                        family: "'Poppins', sans-serif",
                                        size: 12
                                    },
                                    color: '#666',
                                    callback: function(value) {
                                        return 'S/. ' + value;
                                    }
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)',
                                    drawBorder: false
                                }
                            },
                            x: {
                                ticks: {
                                    font: {
                                        family: "'Poppins', sans-serif",
                                        size: 12
                                    },
                                    color: '#666'
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)',
                                    drawBorder: false
                                }
                            }
                        }
                    }
                };

                chartInstances[config.id.replace('Chart', '')] = new Chart(canvas, chartConfig);
            }
            
            console.log(`Gráfico ${config.id} creado exitosamente`);
        } catch (error) {
            console.error(`Error al crear gráfico ${config.id}:`, error);
            
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#f8f9fa';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#d72638';
            ctx.font = '14px Poppins';
            ctx.textAlign = 'center';
            ctx.fillText('Error al crear gráfico', canvas.width/2, canvas.height/2);
            ctx.fillText(config.title || 'Sin título', canvas.width/2, canvas.height/2 - 30);
        }
    });
}

// =========================
// EXPORTAR PDF INDIVIDUAL
// =========================
document.querySelectorAll('.btnPDF').forEach(btn => {
    btn.addEventListener("click", () => {
        const chart = btn.dataset.chart;
        exportarPDFIndividual(chart);
    });
});

function exportarPDFIndividual(chartType) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const margin = 20;
    const width = doc.internal.pageSize.getWidth();
    const height = doc.internal.pageSize.getHeight();
    const fechaHora = new Date().toLocaleString('es-ES');
    
    // ENCABEZADO
    doc.setFillColor(26, 35, 126);
    doc.rect(0, 0, width, 40, 'F');
    
    const logo = document.getElementById('logoInstitucional');
    if (logo && logo.src) {
        try {
            doc.addImage(logo.src, 'PNG', margin, 10, 30, 20);
        } catch(e) {
            console.log("Logo no cargado");
        }
    }
    
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.text("SEGUIMIENTO DE EGRESADOS", width/2, 25, { align: "center" });
    
    doc.setFillColor(255, 255, 255);
    doc.rect(0, 40, width, height - 40, 'F');
    
    // TÍTULO DEL REPORTE
    doc.setTextColor(26, 35, 126);
    doc.setFontSize(18);
    doc.text(chartTitles[chartType], width/2, 60, { align: "center" });
    
    doc.setTextColor(100, 100, 100);
    doc.setFontSize(10);
    doc.text(`Fecha de generación: ${fechaHora}`, width/2, 68, { align: "center" });
    
    // GRÁFICO
    const canvas = document.getElementById(`${chartType}Chart`);
    let startY = 75;
    
    if (canvas && canvas.height > 0) {
        try {
            const img = canvas.toDataURL("image/png", 1.0);
            const imgWidth = width - 2*margin;
            const imgHeight = (canvas.height / canvas.width) * imgWidth * 0.6;
            
            doc.addImage(img, "PNG", margin, startY, imgWidth, imgHeight);
            startY += imgHeight + 15;
        } catch(e) {
            console.log("Error al exportar gráfico:", e);
            doc.setFontSize(12);
            doc.setTextColor(200, 0, 0);
            doc.text("Error al exportar el gráfico", width/2, 100, { align: "center" });
            startY += 30;
        }
    } else {
        startY += 10;
    }
    
    // TABLA DE DATOS
    let bodyData = [];
    const data = chartData[chartType] || [];
    
    if (chartType === 'trabaja' || chartType === 'area') {
        bodyData = data.map(r => [r.respuesta || '', r.total || 0]);
    } else if (chartType === 'egresados_encuesta') {
        if (data && data.length > 0) {
            const row = data[0];
            const total = parseInt(row.total_egresados) || 0;
            const respondieron = parseInt(row.total_respondieron) || 0;
            const noRespondieron = total - respondieron;
            const porcentaje = total > 0 ? ((respondieron / total) * 100).toFixed(2) : 0;
            
            bodyData = [
                ['Respondieron', respondieron, `${porcentaje}%`],
                ['No respondieron', noRespondieron, `${(100 - parseFloat(porcentaje)).toFixed(2)}%`]
            ];
        }
    } else if (chartType === 'detalle_egresados') {
        bodyData = data.map(row => [
            row.nombre_completo || '',
            row.dni_est || '',
            row.carrera || '',
            row.turno || '',
            row.estado_encuesta || '',
            row.tipo_seguimiento || '',
            row.fecha_seguimiento || ''
        ]);
    } else if (chartType === 'cargo') {
        bodyData = data.map(r => [r.cargo || '', r.total || 0]);
    } else if (chartType === 'origen') {
        // Procesar datos de origen
        data.forEach(row => {
            const origen_original = row.origen_encuesta || '';
            let origen_display = origen_original;
            
            if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
                origen_original.toLowerCase().includes('encuesta interna')) {
                origen_display = 'Llamada';
            } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                      origen_original.toLowerCase().includes('encuesta externa')) {
                origen_display = 'Correo';
            } else if (origen_original.toLowerCase() === 'origen desconocido') {
                origen_display = 'Otros';
            }
            
            bodyData.push([
                origen_display,
                row.total_estudiantes || 0,
                row.total_encuestas || 0,
                row.ingreso_promedio ? 'S/ ' + parseFloat(row.ingreso_promedio).toFixed(2) : '0.00',
                (parseFloat(row.porcentaje_total) || 0).toFixed(2) + '%',
                row.primera_encuesta || 'N/A'
            ]);
        });
    } else if (chartType === 'respuesta_programa') {
        bodyData = data.map(row => [
            row.programa || '',
            row.total_egresados || 0,
            row.total_respondieron || 0,
            (parseFloat(row.porcentaje_respuesta) || 0).toFixed(2) + '%'
        ]);
    } else {
        bodyData = data.map(row => Object.values(row).map(v => 
            v !== null && v !== undefined ? v.toString() : ''
        ));
    }
    
    if (bodyData.length > 0) {
        if (startY > height - 50) {
            doc.addPage();
            startY = 20;
        }
        
        doc.autoTable({
            head: [chartColumns[chartType]],
            body: bodyData,
            startY: startY,
            theme: "striped",
            styles: { 
                fontSize: 9, 
                halign: "center",
                cellPadding: 5,
                font: "helvetica",
                textColor: [50, 50, 50],
                lineWidth: 0.1
            },
            headStyles: { 
                fillColor: [26, 35, 126], 
                textColor: [255, 255, 255], 
                fontStyle: "bold",
                cellPadding: 6,
                fontSize: 10
            },
            alternateRowStyles: { fillColor: [248, 249, 250] },
            margin: { left: margin, right: margin },
            tableLineWidth: 0.1,
            tableLineColor: [200, 200, 200],
            didDrawPage: function(data) {
                doc.setFontSize(8);
                doc.setTextColor(100, 100, 100);
                doc.text(
                    `Página ${data.pageNumber}`, 
                    width/2, 
                    height - 10, 
                    { align: "center" }
                );
            }
        });
    }
    
    // PIE DE PÁGINA
    doc.setPage(1);
    const pageCount = doc.internal.getNumberOfPages();
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    
    doc.setDrawColor(200, 200, 200);
    doc.line(margin, height - 20, width - margin, height - 20);
    
    doc.text(`Página 1 de ${pageCount}`, width/2, height - 15, { align: "center" });
    doc.text(`Generado: ${fechaHora}`, width - margin, height - 15, { align: "right" });
    doc.text("Sistema de Seguimiento de Egresados", margin, height - 15, { align: "left" });
    
    doc.save(`reporte_${chartType}_${new Date().toISOString().split('T')[0]}.pdf`);
}

// =========================
// EXPORTAR EXCEL INDIVIDUAL
// =========================
document.querySelectorAll('.btnExcel').forEach(btn => {
    btn.addEventListener("click", () => {
        const chart = btn.dataset.chart;
        exportarExcelIndividual(chart);
    });
});

function exportarExcelIndividual(chartType) {
    const data = chartData[chartType] || [];
    const columns = chartColumns[chartType] || [];
    const title = chartTitles[chartType] || 'Reporte';
    
    let html = `
        <html>
        <head>
            <title>${title}</title>
            <style>
                body { font-family: Arial, sans-serif; }
                h1 { color: #1a237e; }
                table { border-collapse: collapse; width: 100%; }
                th { background-color: #1a237e; color: white; padding: 10px; font-weight: bold; }
                td { border: 1px solid #ddd; padding: 8px; }
                .header { margin-bottom: 20px; }
                .date { color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>${title}</h1>
                <p class="date">Generado: ${new Date().toLocaleString('es-ES')}</p>
            </div>
            <table border='1'>
                <tr>
    `;
    
    // Encabezados
    columns.forEach(col => {
        html += `<th>${col}</th>`;
    });
    html += `</tr>`;
    
    // Datos
    if (chartType === 'trabaja' || chartType === 'area') {
        data.forEach(row => {
            html += `<tr>`;
            html += `<td>${row.respuesta || ''}</td>`;
            html += `<td>${row.total || 0}</td>`;
            html += `</tr>`;
        });
    } else if (chartType === 'egresados_encuesta') {
        if (data && data.length > 0) {
            const row = data[0];
            const total = parseInt(row.total_egresados) || 0;
            const respondieron = parseInt(row.total_respondieron) || 0;
            const noRespondieron = total - respondieron;
            const porcentaje = total > 0 ? ((respondieron / total) * 100).toFixed(2) : 0;
            
            html += `<tr><td>Respondieron</td><td>${respondieron}</td><td>${porcentaje}%</td></tr>`;
            html += `<tr><td>No respondieron</td><td>${noRespondieron}</td><td>${(100 - parseFloat(porcentaje)).toFixed(2)}%</td></tr>`;
        }
    } else if (chartType === 'detalle_egresados') {
        data.forEach(row => {
            html += `<tr>`;
            html += `<td>${row.nombre_completo || ''}</td>`;
            html += `<td>${row.dni_est || ''}</td>`;
            html += `<td>${row.carrera || ''}</td>`;
            html += `<td>${row.turno || ''}</td>`;
            html += `<td>${row.estado_encuesta || ''}</td>`;
            html += `<td>${row.tipo_seguimiento || ''}</td>`;
            html += `<td>${row.fecha_seguimiento || ''}</td>`;
            html += `</tr>`;
        });
    } else if (chartType === 'cargo') {
        data.forEach(row => {
            html += `<tr>`;
            html += `<td>${row.cargo || ''}</td>`;
            html += `<td>${row.total || 0}</td>`;
            html += `</tr>`;
        });
    } else if (chartType === 'origen') {
        // Procesar datos de origen
        data.forEach(row => {
            const origen_original = row.origen_encuesta || '';
            let origen_display = origen_original;
            
            if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
                origen_original.toLowerCase().includes('encuesta interna')) {
                origen_display = 'Llamada';
            } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                      origen_original.toLowerCase().includes('encuesta externa')) {
                origen_display = 'Correo';
            } else if (origen_original.toLowerCase() === 'origen desconocido') {
                origen_display = 'Otros';
            }
            
            html += `<tr>`;
            html += `<td>${origen_display}</td>`;
            html += `<td>${row.total_estudiantes || 0}</td>`;
            html += `<td>${row.total_encuestas || 0}</td>`;
            html += `<td>S/ ${(parseFloat(row.ingreso_promedio) || 0).toFixed(2)}</td>`;
            html += `<td>${(parseFloat(row.porcentaje_total) || 0).toFixed(2)}%</td>`;
            html += `<td>${row.primera_encuesta || 'N/A'}</td>`;
            html += `</tr>`;
        });
    } else if (chartType === 'respuesta_programa') {
        data.forEach(row => {
            html += `<tr>`;
            html += `<td>${row.programa || ''}</td>`;
            html += `<td>${row.total_egresados || 0}</td>`;
            html += `<td>${row.total_respondieron || 0}</td>`;
            html += `<td>${(parseFloat(row.porcentaje_respuesta) || 0).toFixed(2)}%</td>`;
            html += `</tr>`;
        });
    } else {
        data.forEach(row => {
            html += `<tr>`;
            for (let key in row) {
                if (row.hasOwnProperty(key)) html += `<td>${row[key] || ''}</td>`;
            }
            html += `</tr>`;
        });
    }
    
    html += `</table>`;
    html += `</body></html>`;
    
    // Crear y descargar el archivo
    const a = document.createElement("a");
    a.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
    a.download = `reporte_${chartType}_${new Date().toISOString().split('T')[0]}.xls`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// =========================
// EXPORTAR TODO A PDF
// =========================
document.getElementById('btnGeneralPDF').addEventListener('click', function() {
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
        const margin = 20;
        const width = doc.internal.pageSize.getWidth();
        const fechaHora = new Date().toLocaleString('es-ES');
        const stats = calcularEstadisticas();
        
        // ENCABEZADO
        doc.setFillColor(26, 35, 126);
        doc.rect(0, 0, width, 50, 'F');
        
        const logo = document.getElementById('logoInstitucional');
        if (logo && logo.src) {
            try {
                doc.addImage(logo.src, 'PNG', margin, 15, 35, 20);
            } catch(e) {
                console.log("Logo no cargado");
            }
        }
        
        doc.setTextColor(255, 255, 255);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(24);
        doc.text("REPORTE GENERAL", width/2, 25, { align: "center" });
        
        doc.setFontSize(18);
        doc.text("SEGUIMIENTO DE EGRESADOS", width/2, 35, { align: "center" });
        
        doc.setFillColor(255, 255, 255);
        doc.rect(0, 50, width, doc.internal.pageSize.getHeight() - 50, 'F');
        
        doc.setTextColor(100, 100, 100);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        doc.text(`Fecha de generación: ${fechaHora}`, width/2, 62, { align: "center" });
        
        // ESTADÍSTICAS
        doc.setTextColor(26, 35, 126);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(16);
        doc.text("ESTADÍSTICAS GENERALES", margin, 80);
        
        const statsY = 88;
        const cardWidth = (width - 2*margin - 60) / 4;
        
        // Tarjeta 1: Carreras
        doc.setFillColor(79, 195, 247);
        doc.roundedRect(margin, statsY, cardWidth, 30, 3, 3, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text(stats.totalCarreras.toString(), margin + cardWidth/2, statsY + 15, { align: "center" });
        doc.setFontSize(10);
        doc.text("Carreras", margin + cardWidth/2, statsY + 22, { align: "center" });
        
        // Tarjeta 2: Estudiantes
        doc.setFillColor(67, 160, 71);
        doc.roundedRect(margin + cardWidth + 20, statsY, cardWidth, 30, 3, 3, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text(stats.totalEstudiantes.toString(), margin + cardWidth + 20 + cardWidth/2, statsY + 15, { align: "center" });
        doc.setFontSize(10);
        doc.text("Estudiantes", margin + cardWidth + 20 + cardWidth/2, statsY + 22, { align: "center" });
        
        // Tarjeta 3: Empresas
        doc.setFillColor(255, 87, 34);
        doc.roundedRect(margin + 2*cardWidth + 40, statsY, cardWidth, 30, 3, 3, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text(stats.totalEmpresas.toString(), margin + 2*cardWidth + 40 + cardWidth/2, statsY + 15, { align: "center" });
        doc.setFontSize(10);
        doc.text("Empresas", margin + 2*cardWidth + 40 + cardWidth/2, statsY + 22, { align: "center" });
        
        // Tarjeta 4: Encuestas
        doc.setFillColor(156, 39, 176);
        doc.roundedRect(margin + 3*cardWidth + 60, statsY, cardWidth, 30, 3, 3, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text(stats.totalEncuestas.toString(), margin + 3*cardWidth + 60 + cardWidth/2, statsY + 15, { align: "center" });
        doc.setFontSize(10);
        doc.text("Encuestas", margin + 3*cardWidth + 60 + cardWidth/2, statsY + 22, { align: "center" });
        
        let currentY = statsY + 45;
        
        // RESUMEN DE ORIGEN
        doc.setTextColor(26, 35, 126);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(14);
        doc.text("RESUMEN POR ORIGEN DE ENCUESTA", margin, currentY);
        currentY += 10;
        
        // Tarjeta Llamada
        doc.setFillColor(33, 150, 243);
        doc.roundedRect(margin, currentY, (width - 2*margin - 20)/2, 25, 3, 3, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.text("Llamada", margin + 10, currentY + 10);
        doc.setFontSize(12);
        doc.text(`${stats.totalEncuestasLlamada} encuestas`, width/2 - 30, currentY + 10);
        doc.text(`${stats.totalEstudiantesLlamada} estudiantes`, width/2 - 30, currentY + 17);
        
        // Tarjeta Correo
        doc.setFillColor(255, 152, 0);
        doc.roundedRect(width/2 + 10, currentY, (width - 2*margin - 20)/2, 25, 3, 3, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.text("Correo", width/2 + 20, currentY + 10);
        doc.setFontSize(12);
        doc.text(`${stats.totalEncuestasCorreo} encuestas`, width - margin - 50, currentY + 10);
        doc.text(`${stats.totalEstudiantesCorreo} estudiantes`, width - margin - 50, currentY + 17);
        
        currentY += 35;
        
        // Agregar cada reporte
        const chartTypes = ['origen', 'sector', 'programa', 'turno', 'ingreso', 'trabaja', 'area', 'condicion', 'cargo', 
                          'egresados_encuesta', 'tipo_seguimiento', 'respuesta_programa', 'detalle_egresados'];
        
        for (const chartType of chartTypes) {
            const data = chartData[chartType];
            if (!data || (Array.isArray(data) && data.length === 0)) {
                console.log(`No hay datos para ${chartType}`);
                continue;
            }
            
            if (currentY > doc.internal.pageSize.getHeight() - 80) {
                doc.addPage();
                currentY = 20;
                
                doc.setFillColor(26, 35, 126);
                doc.rect(0, 0, width, 30, 'F');
                doc.setTextColor(255, 255, 255);
                doc.setFontSize(16);
                doc.text("REPORTE GENERAL - CONTINUACIÓN", width/2, 20, { align: "center" });
                doc.setFillColor(255, 255, 255);
                doc.rect(0, 30, width, doc.internal.pageSize.getHeight() - 30, 'F');
                
                currentY = 40;
            }
            
            doc.setTextColor(26, 35, 126);
            doc.setFont("helvetica", "bold");
            doc.setFontSize(16);
            
            doc.setFillColor(248, 249, 250);
            doc.rect(margin - 5, currentY - 5, width - 2*margin + 10, 20, 'F');
            
            doc.setDrawColor(26, 35, 126);
            doc.setLineWidth(0.5);
            doc.line(margin, currentY + 15, width - margin, currentY + 15);
            
            doc.text(chartTitles[chartType], margin, currentY + 10);
            currentY += 20;
            
            const canvas = document.getElementById(`${chartType}Chart`);
            if (canvas && canvas.height > 0) {
                try {
                    const img = canvas.toDataURL("image/png", 1.0);
                    const imgHeight = 80;
                    const imgWidth = width - 2*margin;
                    
                    if (currentY + imgHeight > doc.internal.pageSize.getHeight() - 60) {
                        doc.addPage();
                        currentY = 40;
                    }
                    
                    doc.addImage(img, "PNG", margin, currentY, imgWidth, imgHeight);
                    currentY += imgHeight + 15;
                } catch(e) {
                    console.log(`Error al exportar gráfico ${chartType}:`, e);
                    currentY += 10;
                }
            } else {
                currentY += 10;
            }
            
            let bodyData = [];
            if (chartType === 'trabaja' || chartType === 'area') {
                bodyData = data.map(r => [r.respuesta || '', r.total || 0]);
            } else if (chartType === 'egresados_encuesta') {
                if (data && data.length > 0) {
                    const row = data[0];
                    const total = parseInt(row.total_egresados) || 0;
                    const respondieron = parseInt(row.total_respondieron) || 0;
                    const noRespondieron = total - respondieron;
                    const porcentaje = total > 0 ? ((respondieron / total) * 100).toFixed(2) : 0;
                    
                    bodyData = [
                        ['Respondieron', respondieron, `${porcentaje}%`],
                        ['No respondieron', noRespondieron, `${(100 - parseFloat(porcentaje)).toFixed(2)}%`]
                    ];
                }
            } else if (chartType === 'detalle_egresados') {
                bodyData = data.map(row => [
                    row.nombre_completo || '',
                    row.dni_est || '',
                    row.carrera || '',
                    row.turno || '',
                    row.estado_encuesta || '',
                    row.tipo_seguimiento || '',
                    row.fecha_seguimiento || ''
                ]);
            } else if (chartType === 'cargo') {
                bodyData = data.map(r => [r.cargo || '', r.total || 0]);
            } else if (chartType === 'origen') {
                // Procesar datos de origen
                data.forEach(row => {
                    const origen_original = row.origen_encuesta || '';
                    let origen_display = origen_original;
                    
                    if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
                        origen_original.toLowerCase().includes('encuesta interna')) {
                        origen_display = 'Llamada';
                    } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                              origen_original.toLowerCase().includes('encuesta externa')) {
                        origen_display = 'Correo';
                    } else if (origen_original.toLowerCase() === 'origen desconocido') {
                        origen_display = 'Otros';
                    }
                    
                    bodyData.push([
                        origen_display,
                        row.total_estudiantes || 0,
                        row.total_encuestas || 0,
                        row.ingreso_promedio ? 'S/ ' + parseFloat(row.ingreso_promedio).toFixed(2) : '0.00',
                        (parseFloat(row.porcentaje_total) || 0).toFixed(2) + '%',
                        row.primera_encuesta || 'N/A'
                    ]);
                });
            } else if (chartType === 'respuesta_programa') {
                bodyData = data.map(row => [
                    row.programa || '',
                    row.total_egresados || 0,
                    row.total_respondieron || 0,
                    (parseFloat(row.porcentaje_respuesta) || 0).toFixed(2) + '%'
                ]);
            } else {
                bodyData = data.map(row => Object.values(row).map(v => 
                    v !== null && v !== undefined ? v.toString() : ''
                ));
            }
            
            if (bodyData.length > 0) {
                try {
                    if (currentY > doc.internal.pageSize.getHeight() - 50) {
                        doc.addPage();
                        currentY = 40;
                    }
                    
                    doc.autoTable({
                        head: [chartColumns[chartType]],
                        body: bodyData,
                        startY: currentY,
                        theme: "striped",
                        styles: { 
                            fontSize: 9, 
                            halign: "center",
                            cellPadding: 5,
                            font: "helvetica",
                            textColor: [50, 50, 50],
                            lineWidth: 0.1,
                            lineColor: [230, 230, 230]
                        },
                        headStyles: { 
                            fillColor: [26, 35, 126], 
                            textColor: [255, 255, 255], 
                            fontStyle: "bold",
                            cellPadding: 6,
                            fontSize: 10,
                            lineWidth: 0.1
                        },
                        alternateRowStyles: { fillColor: [248, 249, 250] },
                        margin: { left: margin, right: margin },
                        tableLineWidth: 0.1,
                        tableLineColor: [230, 230, 230]
                    });
                    
                    currentY = doc.lastAutoTable.finalY + 20;
                } catch(e) {
                    console.log(`Error al agregar tabla ${chartType}:`, e);
                    currentY += 20;
                }
            }
        }
        
        const pageCount = doc.internal.getNumberOfPages();
        for(let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setTextColor(100, 100, 100);
            const height = doc.internal.pageSize.getHeight();
            
            doc.setDrawColor(200, 200, 200);
            doc.line(margin, height - 20, width - margin, height - 20);
            
            doc.text(`Página ${i} de ${pageCount}`, width/2, height - 15, { align: "center" });
            doc.text(`Generado: ${fechaHora}`, width - margin, height - 15, { align: "right" });
            doc.text("Sistema de Seguimiento de Egresados", margin, height - 15, { align: "left" });
        }
        
        const fileName = `reporte_general_${new Date().toISOString().split('T')[0]}.pdf`;
        doc.save(fileName);
        
        console.log("PDF generado exitosamente");
        
    } catch(error) {
        console.error("Error al generar PDF:", error);
        alert("Error al generar el PDF. Por favor, verifica la consola para más detalles.");
    }
});

// =========================
// EXPORTAR TODO A EXCEL
// =========================
document.getElementById('btnGeneralExcel').addEventListener('click', function() {
    const stats = calcularEstadisticas();
    let html = `
        <html>
        <head>
            <title>Reporte General - Seguimiento de Egresados</title>
            <style>
                body { font-family: Arial, sans-serif; }
                h1 { color: #1a237e; }
                h2 { color: #3949ab; border-bottom: 2px solid #3949ab; padding-bottom: 5px; }
                table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
                th { background-color: #1a237e; color: white; padding: 10px; }
                td { border: 1px solid #ddd; padding: 8px; }
                .stats { background-color: #f5f5f5; padding: 15px; margin-bottom: 20px; border-radius: 5px; }
                .stat-item { display: inline-block; margin-right: 30px; }
                .stat-value { font-size: 24px; font-weight: bold; color: #1a237e; }
                .stat-label { font-size: 14px; color: #666; }
                .summary-stats { display: flex; gap: 20px; margin-bottom: 20px; }
                .summary-card { flex: 1; padding: 15px; border-radius: 5px; color: white; }
                .summary-card.llamada { background: linear-gradient(135deg, #2196f3 0%, #0d47a1 100%); }
                .summary-card.correo { background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); }
            </style>
        </head>
        <body>
            <h1>REPORTE GENERAL - SEGUIMIENTO DE EGRESADOS</h1>
            <p>Fecha de generación: ${new Date().toLocaleString('es-ES')}</p>
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-value">${stats.totalCarreras}</div>
                    <div class="stat-label">Total Carreras</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${stats.totalEstudiantes}</div>
                    <div class="stat-label">Total Estudiantes</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${stats.totalEmpresas}</div>
                    <div class="stat-label">Total Empresas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${stats.totalEncuestas}</div>
                    <div class="stat-label">Total Encuestas</div>
                </div>
            </div>
            
            <div class="summary-stats">
                <div class="summary-card llamada">
                    <h3>Por Llamada</h3>
                    <p>${stats.totalEncuestasLlamada} encuestas</p>
                    <p>${stats.totalEstudiantesLlamada} estudiantes</p>
                </div>
                <div class="summary-card correo">
                    <h3>Por Correo</h3>
                    <p>${stats.totalEncuestasCorreo} encuestas</p>
                    <p>${stats.totalEstudiantesCorreo} estudiantes</p>
                </div>
            </div>
    `;
    
    Object.keys(chartData).forEach(chartType => {
        const data = chartData[chartType];
        if (!data || (Array.isArray(data) && data.length === 0)) return;
        
        html += `<h2>${chartTitles[chartType]}</h2>`;
        html += `<table border='1'>`;
        html += `<tr>`;
        chartColumns[chartType].forEach(c => html += `<th>${c}</th>`);
        html += `</tr>`;
        
        if (chartType === 'trabaja' || chartType === 'area') {
            data.forEach(row => {
                html += `<tr>`;
                html += `<td>${row.respuesta || ''}</td>`;
                html += `<td>${row.total || 0}</td>`;
                html += `</tr>`;
            });
        } else if (chartType === 'egresados_encuesta') {
            if (data && data.length > 0) {
                const row = data[0];
                const total = parseInt(row.total_egresados) || 0;
                const respondieron = parseInt(row.total_respondieron) || 0;
                const noRespondieron = total - respondieron;
                const porcentaje = total > 0 ? ((respondieron / total) * 100).toFixed(2) : 0;
                
                html += `<tr><td>Respondieron</td><td>${respondieron}</td><td>${porcentaje}%</td></tr>`;
                html += `<tr><td>No respondieron</td><td>${noRespondieron}</td><td>${(100 - parseFloat(porcentaje)).toFixed(2)}%</td></tr>`;
            }
        } else if (chartType === 'detalle_egresados') {
            data.forEach(row => {
                html += `<tr>`;
                html += `<td>${row.nombre_completo || ''}</td>`;
                html += `<td>${row.dni_est || ''}</td>`;
                html += `<td>${row.carrera || ''}</td>`;
                html += `<td>${row.turno || ''}</td>`;
                html += `<td>${row.estado_encuesta || ''}</td>`;
                html += `<td>${row.tipo_seguimiento || ''}</td>`;
                html += `<td>${row.fecha_seguimiento || ''}</td>`;
                html += `</tr>`;
            });
        } else if (chartType === 'cargo') {
            data.forEach(row => {
                html += `<tr>`;
                html += `<td>${row.cargo || ''}</td>`;
                html += `<td>${row.total || 0}</td>`;
                html += `</tr>`;
            });
        } else if (chartType === 'origen') {
            // Procesar datos de origen
            data.forEach(row => {
                const origen_original = row.origen_encuesta || '';
                let origen_display = origen_original;
                
                if (origen_original.toLowerCase() === 'encuesta interna (sistema)' || 
                    origen_original.toLowerCase().includes('encuesta interna')) {
                    origen_display = 'Llamada';
                } else if (origen_original.toLowerCase() === 'encuesta externa (encuesta.php)' || 
                          origen_original.toLowerCase().includes('encuesta externa')) {
                    origen_display = 'Correo';
                } else if (origen_original.toLowerCase() === 'origen desconocido') {
                    origen_display = 'Otros';
                }
                
                html += `<tr>`;
                html += `<td>${origen_display}</td>`;
                html += `<td>${row.total_estudiantes || 0}</td>`;
                html += `<td>${row.total_encuestas || 0}</td>`;
                html += `<td>S/ ${(parseFloat(row.ingreso_promedio) || 0).toFixed(2)}</td>`;
                html += `<td>${(parseFloat(row.porcentaje_total) || 0).toFixed(2)}%</td>`;
                html += `<td>${row.primera_encuesta || 'N/A'}</td>`;
                html += `</tr>`;
            });
        } else if (chartType === 'respuesta_programa') {
            data.forEach(row => {
                html += `<tr>`;
                html += `<td>${row.programa || ''}</td>`;
                html += `<td>${row.total_egresados || 0}</td>`;
                html += `<td>${row.total_respondieron || 0}</td>`;
                html += `<td>${(parseFloat(row.porcentaje_respuesta) || 0).toFixed(2)}%</td>`;
                html += `</tr>`;
            });
        } else {
            data.forEach(row => {
                html += `<tr>`;
                for (let key in row) {
                    if (row.hasOwnProperty(key)) html += `<td>${row[key] || ''}</td>`;
                }
                html += `</tr>`;
            });
        }
        
        html += `</table>`;
    });
    
    html += `</body></html>`;
    
    const a = document.createElement("a");
    a.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
    a.download = `reporte_general_${new Date().toISOString().split('T')[0]}.xls`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
});

// =========================
// EXPORTAR ORIGEN A EXCEL
// =========================
document.getElementById('btnExportOrigen').addEventListener('click', function() {
    exportarExcelIndividual('origen');
});

// =========================
// FILTRO DE REPORTES
// =========================
if (filtro) {
    filtro.addEventListener("change", () => {
        const selectedValue = filtro.value;
        const tableContainer = document.querySelector('.table-container');
        
        if (selectedValue === "") {
            chartCards.forEach(card => {
                card.style.display = "block";
                card.style.gridColumn = "auto";
            });
            if (tableContainer) tableContainer.style.display = "block";
            const grid = document.querySelector('.grid');
            if (grid) grid.style.justifyItems = 'stretch';
            AOS.refresh();
        } else {
            chartCards.forEach(card => {
                if (card.dataset.report === selectedValue) {
                    card.style.display = "block";
                    card.style.gridColumn = "1 / -1";
                    const grid = document.querySelector('.grid');
                    if (grid) grid.style.justifyItems = 'center';
                    
                    const chartContainer = card.querySelector('.chart-container');
                    if (chartContainer) {
                        chartContainer.style.width = '100%';
                        chartContainer.style.maxWidth = '800px';
                        chartContainer.style.margin = '0 auto';
                    }
                } else {
                    card.style.display = "none";
                }
            });
            
            if (tableContainer) {
                if (selectedValue === 'origen') {
                    tableContainer.style.display = "block";
                } else {
                    tableContainer.style.display = "none";
                }
            }
            
            AOS.refresh();
        }
    });
}

// =========================
// INICIALIZAR LA PÁGINA
// =========================
function initializePage() {
    console.log("=== INICIALIZANDO PÁGINA ===");
    
    // Calcular estadísticas
    calcularEstadisticas();
    
    // Crear gráficos
    setTimeout(() => {
        console.log("=== CREANDO GRÁFICOS ===");
        createCharts();
        
        // Configurar filtro
        if (filtro) {
            filtro.value = "";
            console.log("Filtro inicializado");
        }
        
        // Refrescar animaciones
        setTimeout(() => {
            AOS.refresh();
        }, 500);
        
        console.log("=== PÁGINA INICIALIZADA CORRECTAMENTE ===");
    }, 200);
}

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializePage);
} else {
    initializePage();
}
</script>

<style>
/* ESTILOS ADICIONALES PARA LA NUEVA FUNCIONALIDAD */

.summary-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin: 20px 0 30px 0;
}

.summary-stat-card {
    background: white;
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
    transition: transform 0.3s ease;
}

.summary-stat-card:hover {
    transform: translateY(-5px);
}

.summary-stat-card h6 {
    font-size: 14px;
    margin-bottom: 8px;
    color: #666;
    font-weight: 600;
}

.summary-stat-card h3 {
    font-size: 24px;
    margin-bottom: 5px;
    color: #2c3e50;
    font-weight: 700;
}

.summary-stat-card small {
    font-size: 12px;
    color: #888;
}

.bg-info { 
    background: linear-gradient(135deg, #2196f3 0%, #0d47a1 100%); 
    color: white; 
}

.bg-info h6,
.bg-info h3,
.bg-info small {
    color: white !important;
}

.bg-warning { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
}

.bg-warning h6,
.bg-warning h3,
.bg-warning small {
    color: white !important;
}

/* TABLA DE ORIGEN */
.table-container {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    margin: 30px 0;
}

.table-title {
    background: linear-gradient(135deg, #673ab7 0%, #512da8 100%);
    color: white;
    padding: 20px;
    margin: 0;
    font-size: 1.3rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.table-responsive {
    overflow-x: auto;
    padding: 20px;
}

#origenTable {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.95rem;
}

#origenTable thead {
    background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
}

#origenTable th {
    padding: 15px;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
}

#origenTable td {
    padding: 12px 15px;
    border-bottom: 1px solid #e9ecef;
    color: #6c757d;
}

#origenTable tbody tr:hover {
    background-color: #f8f9fa;
}

/* BADGES DE ORIGEN */
.origen-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.origen-llamada {
    background: linear-gradient(135deg, #4caf50 0%, #2e7d32 100%);
    color: white;
}

.origen-correo {
    background: linear-gradient(135deg, #2196f3 0%, #0d47a1 100%);
    color: white;
}

.origen-sin-especificar {
    background: linear-gradient(135deg, #757575 0%, #424242 100%);
    color: white;
}

/* BOTÓN DE EXPORTAR ORIGEN */
.general-btn-origen {
    background: linear-gradient(135deg, #2196f3 0%, #0d47a1 100%);
    color: white;
}

.general-btn-origen:hover {
    background: linear-gradient(135deg, #0d47a1 0%, #002171 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(33, 150, 243, 0.3);
}

/* ESTILOS RESPONSIVE */
@media (max-width: 768px) {
    .summary-stats {
        grid-template-columns: 1fr;
    }
    
    .table-responsive {
        padding: 10px;
    }
    
    #origenTable th,
    #origenTable td {
        padding: 8px 10px;
        font-size: 0.85rem;
    }
    
    .origen-badge {
        font-size: 0.75rem;
        padding: 3px 8px;
    }
}
</style>

</body>
</html>