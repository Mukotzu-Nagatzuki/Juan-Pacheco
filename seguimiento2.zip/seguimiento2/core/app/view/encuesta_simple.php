<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encuesta de Situación Laboral</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .form-control,
        .btn {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .btn {
            cursor: pointer;
            margin-top: 10px;
            font-size: 16px;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
            border: none;
            width: calc(50% - 5px);
            display: inline-block;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Encuesta de Situación Laboral</h2>

    <form action="index.php?action=guardar_encuesta" method="POST">

        <div class="form-group">
            <label for="estudiante" class="form-label">ID del Estudiante</label>
            <input type="number" name="estudiante" id="estudiante" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="empresa" class="form-label">ID de la Empresa</label>
            <input type="number" name="empresa" id="empresa" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="trabaja" class="form-label">¿Estás trabajando actualmente?</label>
            <select name="trabaja" id="trabaja" class="form-control" required>
                <option value="">Seleccione...</option>
                <option value="1">Sí</option>
                <option value="0">No</option>
            </select>
        </div>

        <div class="form-group">
            <label for="labora_programa_estudios" class="form-label">¿Trabajas en el área de tu carrera?</label>
            <select name="labora_programa_estudios" id="labora_programa_estudios" class="form-control" required>
                <option value="">Seleccione...</option>
                <option value="1">Sí</option>
                <option value="0">No</option>
            </select>
        </div>

        <div class="form-group">
            <label for="cargo_actual" class="form-label">Cargo actual</label>
            <input type="text" name="cargo_actual" id="cargo_actual" class="form-control" placeholder="Ej: Analista de Sistemas">
        </div>

        <div class="form-group">
            <label for="condicion_laboral" class="form-label">Condición laboral</label>
            <select name="condicion_laboral" id="condicion_laboral" class="form-control" required>
                <option value="">Seleccione...</option>
                <option value="1">Dependiente</option>
                <option value="2">Independiente</option>
                <option value="3">Prácticas</option>
            </select>
        </div>

        <div class="form-group">
            <label for="ingreso_bruto_mensual" class="form-label">Ingreso Bruto Mensual</label>
            <input type="number" step="0.01" name="ingreso_bruto_mensual" id="ingreso_bruto_mensual" class="form-control" placeholder="Ej: 1500.00" required>
        </div>

        <div class="form-group">
            <label for="satisfaccion_trabajo" class="form-label">Nivel de satisfacción con tu trabajo</label>
            <select name="satisfaccion_trabajo" id="satisfaccion_trabajo" class="form-control" required>
                <option value="">Seleccione...</option>
                <option value="Muy satisfecho">Muy satisfecho</option>
                <option value="Satisfecho">Satisfecho</option>
                <option value="Neutral">Neutral</option>
                <option value="Insatisfecho">Insatisfecho</option>
                <option value="Muy insatisfecho">Muy insatisfecho</option>
            </select>
        </div>

        <div class="form-group">
            <label for="fecha_inicio" class="form-label">Fecha de inicio en el trabajo</label>
            <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Enviar Encuesta</button>
        <button type="button" class="btn btn-success" id="btnCompartir">Compartir</button>
    </form>
</div>

<script>
    // Compartir el enlace por WhatsApp
    const btnCompartir = document.getElementById('btnCompartir');
    btnCompartir.addEventListener('click', () => {
        const url = window.location.href;
        const message = `Hola👋, completa esta Encuesta de Situación Laboral por favor:\n${url}`;
        const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, "_blank");
    });
</script>

</body>
</html>

