<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../assets/css/actividades.css">
    <title>Configuración de Encuesta Externa</title>
</head>
<body>
    <div class="admin-content-wrapper">
        <div class="admin-content-header">
            <div class="admin-header-title py-4">
                <h1 class="display-6 fw-bold">Configuración de Encuesta Externa para Egresados</h1>
                <p class="lead mb-0">Controla el acceso al formulario de encuesta externa mediante fechas</p>
            </div>
        </div>

        <div class="container-fluid">
            <!-- Mostrar mensajes de sesión -->
            <?php
            if (isset($_SESSION['message'])): ?>
                <div class="alert-session alert-success-session">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['message']; ?>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert-session alert-error-session">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; ?>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <!-- Información importante -->
            <div class="info-box">
                <h5><i class="fas fa-info-circle"></i> ¿Cómo funciona?</h5>
                <p>Este módulo controla exclusivamente el <strong>formulario de encuesta externa</strong> que ven los egresados.</p>
                <p><strong>Flujo de funcionamiento:</strong></p>
                <ol>
                    <li>Creas una actividad con fechas específicas</li>
                    <li>Cuando la actividad está <strong>ACTIVA</strong> y la fecha actual está dentro del rango, los egresados pueden acceder a la encuesta</li>
                    <li>Cuando la actividad está <strong>INACTIVA</strong> o la fecha está fuera del rango, los egresados NO pueden acceder</li>
                </ol>
                <p><strong>URL de la encuesta externa:</strong></p>
                <div class="url-enlace">
                    https://seguimiento.mallfers.com/encuesta.php
                </div>
            </div>

            <!-- Estado actual de la encuesta -->
            <?php
            require_once "core/app/model/ActividadesData.php";
            $encuestaHabilitada = ActividadesData::isEncuestaHabilitada();
            $actividadActual = ActividadesData::getEncuestaActividadInfo();
            ?>
            
            <div class="<?php echo $encuestaHabilitada ? 'encuesta-habilitada' : 'encuesta-deshabilitada'; ?>">
                <h4>
                    <i class="fas <?php echo $encuestaHabilitada ? 'fa-check-circle text-success' : 'fa-times-circle text-danger'; ?>"></i>
                    Estado Actual de la Encuesta Externa: 
                    <span class="<?php echo $encuestaHabilitada ? 'text-success' : 'text-danger'; ?>">
                        <?php echo $encuestaHabilitada ? 'HABILITADA' : 'DESHABILITADA'; ?>
                    </span>
                </h4>
                
                <?php if ($encuestaHabilitada && $actividadActual): ?>
                    <p><strong>Actividad Activa:</strong> <?php echo htmlspecialchars($actividadActual->titulo); ?></p>
                    <p><strong>Período:</strong> 
                        <?php echo date('d/m/Y', strtotime($actividadActual->fecha_inicio)); ?> 
                        al 
                        <?php echo date('d/m/Y', strtotime($actividadActual->fecha_fin)); ?>
                    </p>
                    <p><strong>Días restantes:</strong> 
                        <?php 
                        $fechaFin = new DateTime($actividadActual->fecha_fin);
                        $hoy = new DateTime();
                        $diferencia = $hoy->diff($fechaFin);
                        echo $diferencia->days . ' días';
                        ?>
                    </p>
                <?php else: ?>
                    <p>No hay actividades activas en este momento. La encuesta externa está deshabilitada.</p>
                    <p>Para habilitar la encuesta, crea una nueva actividad o activa una existente con fechas válidas.</p>
                <?php endif; ?>
            </div>

            <!-- Formulario para crear nueva actividad de control de encuesta -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-plus-circle"></i> CREAR CONFIGURACIÓN DE ENCUESTA
                    </h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-warning-custom alert-custom">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <strong>Importante:</strong> Esta sección controla SOLO el acceso a la encuesta externa.
                    </div>
                    
                    <!-- ✅ NUEVA ALERTA DE RESTRICCIÓN DE FECHAS -->
                    <div class="alert alert-warning-custom alert-custom mt-3">
                        <i class="fas fa-calendar-times"></i> 
                        <strong>Restricción de fechas:</strong> 
                        <ul class="mb-0 mt-2">
                            <li>No se permiten actividades con exactamente las mismas fechas de inicio y fin</li>
                            <li>No se permiten actividades que se solapen con fechas existentes</li>
                            <li>Las fechas deben ser únicas y no superponerse con otras configuraciones</li>
                        </ul>
                    </div>
                    
                    <form action="index.php?action=actividades" method="POST" id="formActividad">
                        <input type="hidden" name="operation" value="create">
                        
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label for="titulo" class="form-label">Nombre de la Configuración *</label>
                                <input type="text" class="form-control" id="titulo" name="titulo" required 
                                    placeholder="Ej: Período de Encuesta Egresados 2024-2">
                                <small class="text-muted">Nombre descriptivo para identificar este período de encuesta</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="estado" class="form-label">Estado *</label>
                                <select class="form-control" id="estado" name="estado" required>
                                    <option value="1">Activar encuesta</option>
                                    <option value="0">Desactivar encuesta</option>
                                </select>
                                <small class="text-muted">"Activar" permite el acceso, "Desactivar" bloquea el acceso</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="fecha_inicio" class="form-label">Fecha de Inicio *</label>
                                <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio" 
                                    required>
                                <small class="text-muted">Fecha desde la que los egresados podrán acceder</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="fecha_fin" class="form-label">Fecha de Fin *</label>
                                <input type="date" class="form-control" id="fecha_fin" name="fecha_fin" 
                                    required>
                                <small class="text-muted">Fecha límite para completar la encuesta</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="descripcion" class="form-label">Instrucciones para egresados (Opcional)</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" 
                                        rows="3" placeholder="Ej: Complete la encuesta antes de la fecha límite para mantener sus datos actualizados..."></textarea>
                                <small class="text-muted">Este texto se puede mostrar en mensajes informativos</small>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-calendar-plus"></i> Crear Configuración
                                </button>
                                <button type="reset" class="btn btn-secondary">
                                    <i class="fas fa-redo"></i> Limpiar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Lista de configuraciones existentes -->
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-history"></i> CONFIGURACIÓN DE ENCUESTA PROGRAMADA
                    </h5>
                </div>
                <div class="card-body">
                    <?php
                    $actividades = ActividadesData::getAll();
                    
                    if (empty($actividades)): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No hay configuraciones de encuesta programadas.
                        </div>
                    <?php else: ?>
                        <div class="alert alert-success-custom alert-custom">
                            <i class="fas fa-lightbulb"></i> 
                            <strong>Recordatorio:</strong> Solo una actividad puede estar activa a la vez. Si activas una, las demás se desactivarán automáticamente.
                        </div>
                        
                        <div class="row">
                            <?php foreach ($actividades as $actividad): 
                                $fechaInicio = new DateTime($actividad->fecha_inicio);
                                $fechaFin = new DateTime($actividad->fecha_fin);
                                $hoy = new DateTime();
                                
                                // Determinar el estado visual
                                $claseEstado = '';
                                $textoEstado = '';
                                
                                if ($actividad->estado == 0) {
                                    $claseEstado = 'actividad-inactiva';
                                    $textoEstado = 'Desactivada';
                                    $claseBadge = 'status-inactiva';
                                } elseif ($hoy < $fechaInicio) {
                                    $claseEstado = 'actividad-futura';
                                    $textoEstado = 'Programada';
                                    $claseBadge = 'status-futura';
                                } elseif ($hoy > $fechaFin) {
                                    $claseEstado = 'actividad-finalizada';
                                    $textoEstado = 'Finalizada';
                                    $claseBadge = 'status-finalizada';
                                } else {
                                    $claseEstado = 'actividad-activa';
                                    $textoEstado = 'Activa';
                                    $claseBadge = 'status-activa';
                                }
                            ?>
                            <div class="col-md-6">
                                <div class="actividad-card <?php echo $claseEstado; ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h5><?php echo htmlspecialchars($actividad->titulo); ?></h5>
                                        <span class="status-badge <?php echo $claseBadge; ?>">
                                            <?php echo $textoEstado; ?>
                                        </span>
                                    </div>
                                    
                                    <?php if ($actividad->descripcion): ?>
                                        <p class="text-muted"><small><?php echo htmlspecialchars($actividad->descripcion); ?></small></p>
                                    <?php endif; ?>
                                    
                                    <div class="row mt-3">
                                        <div class="col-6">
                                            <small class="text-muted">Inicio:</small><br>
                                            <strong><?php echo date('d/m/Y', strtotime($actividad->fecha_inicio)); ?></strong>
                                        </div>
                                        <div class="col-6">
                                            <small class="text-muted">Fin:</small><br>
                                            <strong><?php echo date('d/m/Y', strtotime($actividad->fecha_fin)); ?></strong>
                                        </div>
                                    </div>
                                    
                                    <?php if ($hoy >= $fechaInicio && $hoy <= $fechaFin): ?>
                                        <div class="mt-3">
                                            <?php 
                                            $diasRestantes = $fechaFin->diff($hoy)->days;
                                            $totalDias = $fechaInicio->diff($fechaFin)->days;
                                            $porcentaje = $totalDias > 0 ? min(100, (($totalDias - $diasRestantes) / $totalDias) * 100) : 0;
                                            ?>
                                            
                                            <!-- Barra de progreso opcional (sin porcentaje en texto) -->
                                            <div class="progress mb-2" style="height: 6px;">
                                                <div class="progress-bar bg-success" role="progressbar" 
                                                    style="width: <?php echo $porcentaje; ?>%" 
                                                    aria-valuenow="<?php echo $porcentaje; ?>" 
                                                    aria-valuemin="0" 
                                                    aria-valuemax="100">
                                                </div>
                                            </div>
                                            
                                            <!-- Solo días restantes -->
                                            <small class="text-muted d-block text-center">
                                                <i class="fas fa-calendar-day me-1"></i>
                                                <strong><?php echo $diasRestantes; ?> días restantes</strong>
                                            </small>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="mt-3 d-flex gap-2">
                                        <!-- Formulario para activar/desactivar -->
                                        <form action="index.php?action=actividades" method="POST" style="display: inline;">
                                            <input type="hidden" name="operation" value="toggle">
                                            <input type="hidden" name="id" value="<?php echo $actividad->id; ?>">
                                            <button type="submit" class="btn btn-sm <?php echo $actividad->estado ? 'btn-warning' : 'btn-success'; ?>">
                                                <i class="fas <?php echo $actividad->estado ? 'fa-pause' : 'fa-play'; ?>"></i>
                                                <?php echo $actividad->estado ? 'Desactivar' : 'Activar'; ?>
                                            </button>
                                        </form>
                                        
                                        <!-- Formulario para eliminar -->
                                        <form action="index.php?action=actividades" method="POST" style="display: inline;" 
                                              onsubmit="return confirm('¿Está seguro de eliminar esta configuración de encuesta?');">
                                            <input type="hidden" name="operation" value="delete">
                                            <input type="hidden" name="id" value="<?php echo $actividad->id; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i> Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="../../../assets/js/actividades.js"></script>
</body>
</html>