<?php
// ============================================
// PARTE 1: LÓGICA PHP (CONTROLADOR)
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

// 1. CONEXIÓN A LA BASE DE DATOS
$host = "50.31.174.34";
$user = "wxwdrnht_wxwdrnht_integrado_db";
$pass = "integrado_db2025.";
$dbname = "wxwdrnht_integrado_db";

$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    // Si hay error de conexión, mostrar datos de prueba
    $estadisticas = [
        'total_estudiantes' => 1254,
        'total_empresas' => 11,
        'total_programas' => 10,
        'empleados_activos' => 16
    ];
    
    $ultimosEstudiantes = [];
    $distribucionProgramas = [];
    $situacionLaboral = [];
    
    echo "<div style='background:#ffcccc;padding:10px;margin:10px;'>
          <strong>⚠️ Error de conexión:</strong> " . $conn->connect_error . "<br>
          <strong>⚠️ Mostrando datos de prueba</strong>
          </div>";
} else {
    // 2. OBTENER ESTADÍSTICAS
    $estadisticas = [
        'total_estudiantes' => 0,
        'total_empresas' => 0,
        'total_programas' => 0,
        'empleados_activos' => 0
    ];
    
    // Contar estudiantes
    $sql = "SELECT COUNT(*) as total FROM estudiante";
    $result = $conn->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        $estadisticas['total_estudiantes'] = $row['total'];
    }
    
    // Contar empresas
    $sql = "SELECT COUNT(*) as total FROM empresa";
    $result = $conn->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        $estadisticas['total_empresas'] = $row['total'];
    }
    
    // Contar programas
    $sql = "SELECT COUNT(*) as total FROM prog_estudios";
    $result = $conn->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        $estadisticas['total_programas'] = $row['total'];
    }
    
    // Contar situaciones laborales
    $sql = "SELECT COUNT(*) as total FROM situacion_laboral";
    $result = $conn->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        $estadisticas['empleados_activos'] = $row['total'];
    }
    
    // 3. OBTENER ÚLTIMOS ESTUDIANTES
    $ultimosEstudiantes = [];
    $sql = "SELECT dni_est, ap_est, am_est, nom_est, mailp_est, cel_est 
            FROM estudiante 
            ORDER BY id DESC 
            LIMIT 5";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $ultimosEstudiantes[] = (object)$row;
        }
    }
    
    // 4. DISTRIBUCIÓN POR PROGRAMAS
    $distribucionProgramas = [];
    $sql = "SELECT 
        p.nom_progest as programa,
        COUNT(m.id) as total_estudiantes
    FROM prog_estudios p
    LEFT JOIN matricula m ON m.prog_estudios = p.id
    GROUP BY p.id, p.nom_progest
    ORDER BY total_estudiantes DESC";
    
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $distribucionProgramas[] = (object)$row;
        }
    }
    
    // 5. SITUACIÓN LABORAL
    $situacionLaboral = [];
    $sql = "SELECT 
        p.nom_progest as programa,
        COUNT(DISTINCT m.estudiante) as total_egresados,
        COUNT(DISTINCT sl.id) as empleados
    FROM prog_estudios p
    LEFT JOIN matricula m ON m.prog_estudios = p.id
    LEFT JOIN situacion_laboral sl ON sl.estudiante = m.estudiante
    GROUP BY p.id, p.nom_progest
    ORDER BY p.nom_progest";
    
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $programa = (object)$row;
            $programa->total_egresados = (int)$programa->total_egresados;
            $programa->empleados = (int)$programa->empleados;
            
            if ($programa->total_egresados > 0) {
                $programa->tasa_empleo = round(($programa->empleados * 100.0 / $programa->total_egresados), 2);
            } else {
                $programa->tasa_empleo = 0;
            }
            
            $situacionLaboral[] = $programa;
        }
    }
    
    // Cerrar conexión
    $conn->close();
}

// DEBUG: Verificar datos (puedes eliminar esto después)
echo "<!-- 
DEBUG INFO:
Estudiantes: " . $estadisticas['total_estudiantes'] . "
Empresas: " . $estadisticas['total_empresas'] . "
Programas: " . $estadisticas['total_programas'] . "
Situaciones: " . $estadisticas['empleados_activos'] . "
-->";

// ============================================
// PARTE 2: HTML (VISTA)
// ============================================
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Egresados</title>
    <link rel="stylesheet" href="assets/css/inicio.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header del Dashboard -->
        <header class="dashboard-header">
            <h1 class="page-title">SISTEMA DE SEGUIMIENTO DE EGRESADOS</h1>
        </header>

        <!-- Tarjetas de Estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-icon-wrapper">
                        <i class="fa-solid fa-graduation-cap stat-icon"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo number_format($estadisticas['total_estudiantes'] ?? 0); ?></div>
                        <div class="stat-label">Estudiantes Registrados</div>
                        <div class="stat-trend">
                            <i class="fa-solid fa-arrow-up"></i>
                            <span>12% vs último mes</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-icon-wrapper">
                        <i class="fa-solid fa-building stat-icon"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo $estadisticas['total_empresas'] ?? 0; ?></div>
                        <div class="stat-label">Empresas Colaboradoras</div>
                        <div class="stat-trend">
                            <i class="fa-solid fa-plus"></i>
                            <span>2 nuevas este mes</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-icon-wrapper">
                        <i class="fa-solid fa-briefcase stat-icon"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo $estadisticas['empleados_activos'] ?? 0; ?></div>
                        <div class="stat-label">Situaciones Laborales</div>
                        <div class="stat-trend">
                            <i class="fa-solid fa-arrow-up"></i>
                            <span>8% de empleabilidad</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-icon-wrapper">
                        <i class="fa-solid fa-book-open stat-icon"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo $estadisticas['total_programas'] ?? 0; ?></div>
                        <div class="stat-label">Programas Académicos</div>
                        <div class="stat-trend">
                            <i class="fa-solid fa-chart-line"></i>
                            <span>Todos activos</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Layout Principal -->
        <div class="dashboard-layout">
            <!-- Columna Izquierda -->
            <div class="dashboard-column">
                <!-- Últimos Estudiantes Registrados -->
                <section class="dashboard-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fa-solid fa-user-graduate"></i>
                            Últimos Estudiantes Registrados
                        </h2>
                        <div class="section-actions">
                            <a href="index.php?action=egresado" class="badge info">
                                <i class="fa-solid fa-plus"></i> Nuevo
                            </a>
                        </div>
                    </div>
                    
                    <?php if (!empty($ultimosEstudiantes) && is_array($ultimosEstudiantes)): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>DNI</th>
                                    <th>Nombre Completo</th>
                                    <th>Contacto</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ultimosEstudiantes as $estudiante): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($estudiante->dni_est ?? 'N/A'); ?></strong></td>
                                    <td>
                                        <?php 
                                            $nombreCompleto = trim(($estudiante->ap_est ?? '') . ' ' . ($estudiante->am_est ?? '') . ' ' . ($estudiante->nom_est ?? ''));
                                            echo htmlspecialchars($nombreCompleto ?: 'N/A');
                                        ?>
                                    </td>
                                    <td>
                                        <div><?php echo htmlspecialchars($estudiante->mailp_est ?? 'N/A'); ?></div>
                                        <small><?php echo htmlspecialchars($estudiante->cel_est ?? 'Sin celular'); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge success">
                                            <i class="fa-solid fa-check"></i> Activo
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fa-solid fa-users-slash"></i>
                            <h3>No hay estudiantes registrados</h3>
                            <p>Comienza agregando nuevos estudiantes al sistema</p>
                        </div>
                    <?php endif; ?>
                </section>

                <!-- Distribución por Programas -->
                <section class="dashboard-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fa-solid fa-chart-pie"></i>
                            Distribución por Programas
                        </h2>
                        <div class="section-actions">
                            <span class="badge info">
                                <i class="fa-solid fa-chart-bar"></i> Gráfico
                            </span>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="programasChart"></canvas>
                    </div>
                </section>
            </div>

            <!-- Columna Derecha -->
            <div class="dashboard-column">
                <!-- Situación Laboral -->
                <section class="dashboard-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fa-solid fa-chart-line"></i>
                            Indicadores de Empleabilidad
                        </h2>
                        <div class="section-actions">
                            <a href="index.php?action=reportes" class="badge info">
                                <i class="fa-solid fa-download"></i> Exportar
                            </a>
                        </div>
                    </div>
                    
                    <?php if (!empty($situacionLaboral) && is_array($situacionLaboral)): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Programa</th>
                                    <th>Egresados</th>
                                    <th>Empleados</th>
                                    <th>Tasa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($situacionLaboral as $programa): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($programa->programa ?? 'N/A'); ?></strong></td>
                                    <td><?php echo $programa->total_egresados ?? 0; ?></td>
                                    <td><?php echo $programa->empleados ?? 0; ?></td>
                                    <td>
                                        <?php 
                                            $tasaEmpleo = $programa->tasa_empleo ?? 0;
                                            $badgeClass = 'info';
                                            if ($tasaEmpleo >= 80) $badgeClass = 'success';
                                            elseif ($tasaEmpleo >= 50) $badgeClass = 'warning';
                                            else $badgeClass = 'danger';
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?>">
                                            <i class="fa-solid fa-percentage"></i>
                                            <?php echo number_format($tasaEmpleo, 1); ?>%
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fa-solid fa-chart-line"></i>
                            <h3>Sin datos de empleabilidad</h3>
                            <p>Registra situaciones laborales para ver estadísticas</p>
                        </div>
                    <?php endif; ?>
                </section>

                <!-- Acciones Rápidas -->
                <section class="dashboard-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fa-solid fa-bolt"></i>
                            Acciones Rápidas
                        </h2>
                        <div class="section-actions">
                            <span class="badge info">
                                <i class="fa-solid fa-star"></i> Acceso Directo
                            </span>
                        </div>
                    </div>
                    
                    <div class="quick-actions-grid">
                        <a href="index.php?action=egresado" class="action-card">
                            <div class="action-icon">
                                <i class="fa-solid fa-user-plus"></i>
                            </div>
                            <div class="action-info">
                                <div class="action-title">Nuevo Estudiante</div>
                                <div class="action-desc">Registrar nuevo egresado</div>
                            </div>
                        </a>
                        
                        <a href="index.php?action=empresas" class="action-card">
                            <div class="action-icon">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div class="action-info">
                                <div class="action-title">Empresas</div>
                                <div class="action-desc">Gestión de colaboradores</div>
                            </div>
                        </a>
                        
                        <a href="index.php?action=situacion" class="action-card">
                            <div class="action-icon">
                                <i class="fa-solid fa-briefcase"></i>
                            </div>
                            <div class="action-info">
                                <div class="action-title">Situación Laboral</div>
                                <div class="action-desc">Actualizar empleabilidad</div>
                            </div>
                        </a>
                        
                        <a href="index.php?action=reportes" class="action-card">
                            <div class="action-icon">
                                <i class="fa-solid fa-chart-bar"></i>
                            </div>
                            <div class="action-info">
                                <div class="action-title">Reportes</div>
                                <div class="action-desc">Generar informes PDF/Excel</div>
                            </div>
                        </a>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- Scripts para gráficos -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const programasCtx = document.getElementById('programasChart');
            if (programasCtx) {
                const programasLabels = <?php 
                    if (!empty($distribucionProgramas) && is_array($distribucionProgramas)) {
                        $labels = array();
                        foreach ($distribucionProgramas as $programa) {
                            $labels[] = "'" . addslashes($programa->programa ?? 'Sin nombre') . "'";
                        }
                        echo '[' . implode(',', $labels) . ']';
                    } else {
                        echo "['Sin datos disponibles']";
                    }
                ?>;
                
                const programasData = <?php 
                    if (!empty($distribucionProgramas) && is_array($distribucionProgramas)) {
                        $data = array();
                        foreach ($distribucionProgramas as $programa) {
                            $data[] = $programa->total_estudiantes ?? 0;
                        }
                        echo '[' . implode(',', $data) . ']';
                    } else {
                        echo '[1]';
                    }
                ?>;

                // Colores institucionales para el gráfico
                const backgroundColors = [
                    '#0d47a1', '#1565c0', '#1976d2', '#2196f3', '#64b5f6',
                    '#90caf9', '#bbdefb', '#e3f2fd', '#0a2a5a', '#1e88e5'
                ];

                new Chart(programasCtx, {
                    type: 'doughnut',
                    data: {
                        labels: programasLabels,
                        datasets: [{
                            data: programasData,
                            backgroundColor: backgroundColors,
                            borderWidth: 2,
                            borderColor: '#ffffff',
                            hoverOffset: 15
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true,
                                    pointStyle: 'circle',
                                    font: {
                                        size: 11,
                                        family: "'Segoe UI', sans-serif"
                                    },
                                    color: '#0a2a5a'
                                }
                            },
                            tooltip: {
                                backgroundColor: 'rgba(13, 71, 161, 0.9)',
                                titleFont: {
                                    size: 13,
                                    family: "'Segoe UI', sans-serif"
                                },
                                bodyFont: {
                                    size: 12,
                                    family: "'Segoe UI', sans-serif"
                                },
                                padding: 12,
                                cornerRadius: 6,
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.parsed;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: ${value} estudiantes (${percentage}%)`;
                                    }
                                }
                            }
                        },
                        cutout: '60%',
                        animation: {
                            animateScale: true,
                            animateRotate: true
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>