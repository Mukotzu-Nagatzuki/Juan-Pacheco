<!-- ✅ CONTENIDO DE LA VISTA DE USUARIOS -->
<div class="admin-content-wrapper">
    <div class="admin-content-header">
        <div class="admin-header-title">
            <h1>LISTA DE USUARIOS</h1>
            <p>Gestión de todos los usuarios del sistema</p>
        </div>
    </div>

    <div class="content-body">
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <button type="button" class="admin-btn-primary" id="openCreateModal">
                            <i class='bx bx-user-plus me-2'></i>
                            Crear Nuevo Usuario
                        </button>
                    </div>
                    
                    <!-- Buscador de usuarios -->
                    <div class="admin-search-box">
                        <div class="search-input-group">
                            <i class='bx bx-search search-icon'></i>
                            <input type="text" id="searchUsers" class="admin-form-input search-input" 
                                   placeholder="Buscar por usuario, ID o tipo...">
                            <button type="button" id="clearSearch" class="clear-search-btn" style="display: none;">
                                <i class='bx bx-x'></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="admin-card-body">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="admin-alert admin-alert-success auto-hide-alert" role="alert">
                        <i class='bx bx-check-circle me-2'></i>
                        <?php echo htmlspecialchars($_SESSION['message']); ?>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="admin-alert admin-alert-error auto-hide-alert" role="alert">
                        <i class='bx bx-error-circle me-2'></i>
                        <?php echo htmlspecialchars($_SESSION['error']); ?>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <div class="admin-table-responsive">
                    <table class="admin-table" id="usersTable">
                        <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">Usuario</th>
                                <th class="text-center">Tipo</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Fecha de Creación</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="usersTableBody">
                            <?php if ($users && count($users) > 0): ?>
                                <?php foreach($users as $user): ?>
                                <tr class="user-row" 
                                    data-id="<?php echo $user->id; ?>"
                                    data-usuario="<?php echo htmlspecialchars($user->usuario); ?>"
                                    data-tipo="<?php echo $user->tipo; ?>"
                                    data-tipo-text="<?php 
                                        switch($user->tipo) {
                                            case 1: echo 'Empleado'; break;
                                            case 2: echo 'Estudiante'; break;
                                            case 3: echo 'Empresa'; break;
                                            default: echo 'Sin tipo';
                                        }
                                    ?>">
                                    <td class="text-center align-middle"><?php echo $user->id; ?></td>
                                    <td class="text-center align-middle user-usuario"><?php echo htmlspecialchars($user->usuario); ?></td>
                                    <td class="text-center align-middle user-tipo">
                                        <?php 
                                            switch($user->tipo) {
                                                case 1: echo 'Empleado'; break;
                                                case 2: echo 'Estudiante'; break;
                                                case 3: echo 'Empresa'; break;
                                                default: echo 'Sin tipo';
                                            }
                                        ?>
                                    </td>
                                    <td class="text-center align-middle">
                                        <span class="admin-badge admin-badge-success">Activo</span>
                                    </td>
                                    <td class="text-center align-middle user-fecha">
                                        <?php 
                                            if (isset($user->created_at)) {
                                                echo date('d/m/Y H:i', strtotime($user->created_at));
                                            } else {
                                                echo date('d/m/Y H:i');
                                            }
                                        ?>
                                    </td>
                                    <td class="text-center align-middle">
                                        <div class="admin-btn-group">
                                            <button class="admin-btn admin-btn-warning edit-user-btn" 
                                                    data-user-id="<?php echo $user->id; ?>"
                                                    data-user-usuario="<?php echo htmlspecialchars($user->usuario); ?>"
                                                    data-user-tipo="<?php echo $user->tipo; ?>">
                                                <i class='bx bx-edit me-1'></i> Editar
                                            </button>
                                            <a href="index.php?action=eliminar_usuario&id=<?php echo $user->id; ?>" 
                                               class="admin-btn admin-btn-danger"
                                               onclick="return confirm('¿Está seguro de eliminar al usuario <?php echo htmlspecialchars($user->usuario); ?>?')">
                                                <i class='bx bx-trash me-1'></i> Eliminar
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr id="noDataRow">
                                    <td colspan="6" class="admin-text-center admin-text-muted py-5">
                                        <i class='bx bx-user-x display-4 d-block mb-3'></i>
                                        <p class="h5">No hay usuarios registrados</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <!-- Mensaje cuando no hay resultados en búsqueda -->
                    <div id="noResults" class="admin-text-center admin-text-muted py-5" style="display: none;">
                        <i class='bx bx-search-alt display-4 d-block mb-3'></i>
                        <p class="h5">No se encontraron resultados</p>
                        <p class="text-muted">Intente con otros términos de búsqueda</p>
                    </div>
                </div>

                <!-- Contador de resultados y paginación -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div class="text-muted small" id="resultCount">
                        Mostrando <?php echo count($users); ?> usuarios
                    </div>
                    
                    <!-- Controles de paginación -->
                    <div class="admin-pagination" id="paginationControls">
                        <div class="d-flex align-items-center gap-3">
                            <div class="admin-pagination-info small text-muted">
                                Página <span id="currentPage">1</span> de <span id="totalPages">1</span>
                            </div>
                            <div class="admin-pagination-buttons">
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="firstPage" title="Primera página">
                                    <i class='bx bx-chevrons-left'></i>
                                </button>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="prevPage" title="Página anterior">
                                    <i class='bx bx-chevron-left'></i>
                                </button>
                                <div class="admin-page-numbers" id="pageNumbers">
                                    <!-- Los números de página se generarán aquí -->
                                </div>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="nextPage" title="Página siguiente">
                                    <i class='bx bx-chevron-right'></i>
                                </button>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="lastPage" title="Última página">
                                    <i class='bx bx-chevrons-right'></i>
                                </button>
                            </div>
                            <div class="admin-pagination-select">
                                <select class="admin-form-input small" id="itemsPerPage" style="padding: 5px 10px; height: 32px;">
                                    <option value="5">5 por página</option>
                                    <option value="10" selected>10 por página</option>
                                    <option value="20">20 por página</option>
                                    <option value="50">50 por página</option>
                                    <option value="100">100 por página</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ✅ MODAL CREAR/EDITAR USUARIO -->
<div class="admin-modal" id="userModal">
    <div class="admin-modal-dialog">
        <div class="admin-modal-content">
            <div class="admin-modal-header">
                <h5 class="admin-modal-title" id="modalTitle">Crear Nuevo Usuario</h5>
                <button type="button" class="admin-modal-close" data-dismiss="modal">
                    <i class='bx bx-x'></i>
                </button>
            </div>

            <form id="userForm" action="index.php?action=usuario" method="POST" class="admin-form">
                <div class="admin-modal-body">
                    <input type="hidden" id="userId" name="id">
                    <div class="admin-form-grid">
                        <div class="admin-form-group">
                            <label for="modalUsuario" class="admin-form-label">Usuario *</label>
                            <input type="text" id="modalUsuario" name="usuario" class="admin-form-input" required>
                            <div class="admin-form-error" id="usuarioError"></div>
                        </div>
                        <div class="admin-form-group" id="passwordField">
                            <label for="modalPassword" class="admin-form-label">Contraseña <span id="passwordRequired">*</span></label>
                            <div class="admin-password-container">
                                <input type="password" id="modalPassword" name="password" class="admin-form-input">
                                <button type="button" class="admin-password-toggle" id="togglePassword">
                                    <i class='bx bx-hide'></i>
                                </button>
                            </div>
                            <div class="admin-form-help">Mínimo 6 caracteres</div>
                            <div class="admin-form-error" id="passwordError"></div>
                        </div>
                        <div class="admin-form-group">
                            <label for="modalTipo" class="admin-form-label">Tipo de Usuario *</label>
                            <select id="modalTipo" name="tipo" class="admin-form-input" required>
                                <option value="">Seleccione un tipo</option>
                                <option value="1">Empleado</option>
                                <option value="2">Estudiante</option>
                                <option value="3">Empresa</option>
                            </select>
                            <div class="admin-form-error" id="tipoError"></div>
                        </div>
                    </div>
                </div>

                <div class="admin-modal-footer">
                    <button type="button" class="admin-btn-secondary" data-dismiss="modal">
                        <i class='bx bx-x'></i> Cancelar
                    </button>
                    <button type="button" class="admin-btn-primary" id="saveUserBtn">
                        <i class='bx bx-save'></i> Guardar Usuario
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('Script de usuarios con paginación cargado');
    
    // ========== PAGINACIÓN CLIENTE-SIDE ==========
    class PaginationUsers {
        constructor() {
            this.currentPage = 1;
            this.itemsPerPage = parseInt(document.getElementById('itemsPerPage')?.value || 10);
            this.filteredItems = [];
            this.allItems = [];
            this.searchTerm = '';
            this.initPagination();
        }

        initPagination() {
            // Obtener todos los elementos de la tabla
            this.allItems = Array.from(document.querySelectorAll('#usersTableBody tr.user-row'));
            this.filteredItems = [...this.allItems];
            
            // Configurar eventos de paginación
            this.setupPaginationEvents();
            
            // Inicializar paginación
            this.updatePagination();
            this.handleInitialState();
        }

        setupPaginationEvents() {
            // Eventos de botones de paginación
            document.getElementById('firstPage')?.addEventListener('click', () => this.goToPage(1));
            document.getElementById('prevPage')?.addEventListener('click', () => this.goToPage(this.currentPage - 1));
            document.getElementById('nextPage')?.addEventListener('click', () => this.goToPage(this.currentPage + 1));
            document.getElementById('lastPage')?.addEventListener('click', () => this.goToPage(this.getTotalPages()));
            
            // Evento para cambiar items por página
            const itemsPerPageSelect = document.getElementById('itemsPerPage');
            if (itemsPerPageSelect) {
                itemsPerPageSelect.value = this.itemsPerPage.toString();
                itemsPerPageSelect.addEventListener('change', (e) => {
                    this.itemsPerPage = parseInt(e.target.value);
                    this.currentPage = 1;
                    this.updatePagination();
                });
            }
            
            // Configurar búsqueda en tiempo real
            const searchInput = document.getElementById('searchUsers');
            const clearSearchBtn = document.getElementById('clearSearch');
            
            if (searchInput) {
                let searchTimeout;
                searchInput.addEventListener('input', () => {
                    clearTimeout(searchTimeout);
                    searchTimeout = setTimeout(() => {
                        this.searchTerm = searchInput.value.trim().toLowerCase();
                        this.filterItems();
                        if (clearSearchBtn) {
                            clearSearchBtn.style.display = this.searchTerm ? 'flex' : 'none';
                        }
                    }, 300);
                });
                
                // Limpiar búsqueda con Escape
                searchInput.addEventListener('keyup', (e) => {
                    if (e.key === 'Escape') {
                        searchInput.value = '';
                        this.searchTerm = '';
                        this.filterItems();
                        if (clearSearchBtn) {
                            clearSearchBtn.style.display = 'none';
                        }
                    }
                });
                
                // Prevenir envío del formulario con Enter
                searchInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        this.searchTerm = searchInput.value.trim().toLowerCase();
                        this.filterItems();
                    }
                });
            }
            
            if (clearSearchBtn) {
                clearSearchBtn.addEventListener('click', () => {
                    const searchInput = document.getElementById('searchUsers');
                    if (searchInput) {
                        searchInput.value = '';
                        this.searchTerm = '';
                        this.filterItems();
                        clearSearchBtn.style.display = 'none';
                        searchInput.focus();
                    }
                });
                
                // Mostrar/ocultar botón según si hay texto
                clearSearchBtn.style.display = searchInput?.value.trim() ? 'flex' : 'none';
            }
            
            // Auto-hide alerts
            this.autoHideAlerts();
        }

        getTotalPages() {
            return Math.ceil(this.filteredItems.length / this.itemsPerPage) || 1;
        }

        goToPage(page) {
            const totalPages = this.getTotalPages();
            
            if (page < 1) page = 1;
            if (page > totalPages) page = totalPages;
            
            this.currentPage = page;
            this.updatePagination();
        }

        filterItems() {
            this.currentPage = 1;
            
            if (!this.searchTerm) {
                this.filteredItems = [...this.allItems];
            } else {
                this.filteredItems = this.allItems.filter(row => {
                    // Obtener texto de todas las celdas relevantes para búsqueda
                    const usuario = row.querySelector('.user-usuario')?.textContent.toLowerCase() || '';
                    const id = row.querySelector('td:first-child')?.textContent.toLowerCase() || '';
                    const tipo = row.querySelector('.user-tipo')?.textContent.toLowerCase() || '';
                    
                    // Buscar en todos los campos
                    return usuario.includes(this.searchTerm) ||
                           id.includes(this.searchTerm) ||
                           tipo.includes(this.searchTerm);
                });
            }
            
            this.updatePagination();
            this.highlightSearchResults();
        }

        updatePagination() {
            const totalPages = this.getTotalPages();
            const startIndex = (this.currentPage - 1) * this.itemsPerPage;
            const endIndex = startIndex + this.itemsPerPage;
            
            // Ocultar todas las filas
            this.allItems.forEach(row => row.style.display = 'none');
            
            // Mostrar solo las filas de la página actual
            this.filteredItems.slice(startIndex, endIndex).forEach(row => {
                if (row) row.style.display = '';
            });
            
            // Manejar estados de visibilidad
            this.handleVisibility();
            
            // Actualizar controles de paginación
            this.updatePaginationControls(totalPages);
            this.updatePaginationInfo(totalPages);
            this.updateResultCount();
        }

        updatePaginationControls(totalPages) {
            const pageNumbersContainer = document.getElementById('pageNumbers');
            if (!pageNumbersContainer) return;
            
            pageNumbersContainer.innerHTML = '';
            
            // Mostrar máximo 5 números de página
            let startPage = Math.max(1, this.currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            // Botón para primera página si es necesario
            if (startPage > 1) {
                const firstPageBtn = document.createElement('button');
                firstPageBtn.className = 'admin-page-number';
                firstPageBtn.textContent = '1';
                firstPageBtn.addEventListener('click', () => this.goToPage(1));
                pageNumbersContainer.appendChild(firstPageBtn);
                
                if (startPage > 2) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
            }
            
            // Números de página
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `admin-page-number ${i === this.currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.addEventListener('click', () => this.goToPage(i));
                pageNumbersContainer.appendChild(pageBtn);
            }
            
            // Botón para última página si es necesario
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
                
                const lastPageBtn = document.createElement('button');
                lastPageBtn.className = 'admin-page-number';
                lastPageBtn.textContent = totalPages;
                lastPageBtn.addEventListener('click', () => this.goToPage(totalPages));
                pageNumbersContainer.appendChild(lastPageBtn);
            }
            
            // Actualizar estado de botones
            const firstBtn = document.getElementById('firstPage');
            const prevBtn = document.getElementById('prevPage');
            const nextBtn = document.getElementById('nextPage');
            const lastBtn = document.getElementById('lastPage');
            
            if (firstBtn) firstBtn.disabled = this.currentPage === 1;
            if (prevBtn) prevBtn.disabled = this.currentPage === 1;
            if (nextBtn) nextBtn.disabled = this.currentPage === totalPages || totalPages === 0;
            if (lastBtn) lastBtn.disabled = this.currentPage === totalPages || totalPages === 0;
            
            // Mostrar/ocultar controles de paginación
            const paginationControls = document.getElementById('paginationControls');
            if (paginationControls) {
                paginationControls.style.display = this.filteredItems.length > 0 ? '' : 'none';
            }
        }

        updatePaginationInfo(totalPages) {
            const currentPageSpan = document.getElementById('currentPage');
            const totalPagesSpan = document.getElementById('totalPages');
            
            if (currentPageSpan) currentPageSpan.textContent = this.currentPage;
            if (totalPagesSpan) totalPagesSpan.textContent = totalPages;
        }

        updateResultCount() {
            const resultCount = document.getElementById('resultCount');
            if (!resultCount) return;
            
            const totalItems = this.filteredItems.length;
            const startIndex = (this.currentPage - 1) * this.itemsPerPage + 1;
            const endIndex = Math.min(startIndex + this.itemsPerPage - 1, totalItems);
            
            if (totalItems === 0) {
                if (this.searchTerm) {
                    resultCount.textContent = `No se encontraron resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = 'No hay usuarios registrados';
                }
            } else if (totalItems <= this.itemsPerPage) {
                if (this.searchTerm) {
                    resultCount.textContent = `Mostrando ${totalItems} resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = `Mostrando ${totalItems} usuarios`;
                }
            } else {
                if (this.searchTerm) {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} usuarios`;
                }
            }
        }

        handleVisibility() {
            const noResults = document.getElementById('noResults');
            const noDataRow = document.getElementById('noDataRow');
            const tableBody = document.getElementById('usersTableBody');
            
            if (this.filteredItems.length === 0) {
                // Mostrar mensaje de no resultados
                if (noResults) {
                    noResults.style.display = 'block';
                }
                if (tableBody) {
                    tableBody.style.display = 'none';
                }
                // Ocultar fila de no datos original
                if (noDataRow) {
                    noDataRow.style.display = 'none';
                }
            } else {
                // Ocultar mensaje de no resultados
                if (noResults) {
                    noResults.style.display = 'none';
                }
                if (tableBody) {
                    tableBody.style.display = '';
                }
                // Ocultar fila de no datos original
                if (noDataRow) {
                    noDataRow.style.display = 'none';
                }
            }
        }

        handleInitialState() {
            const noDataRow = document.getElementById('noDataRow');
            const paginationControls = document.getElementById('paginationControls');
            
            // Si hay mensaje de no datos, ocultar paginación
            if (noDataRow && noDataRow.style.display !== 'none') {
                if (paginationControls) {
                    paginationControls.style.display = 'none';
                }
            }
        }

        highlightSearchResults() {
            if (!this.searchTerm) {
                // Remover resaltado si no hay búsqueda
                const cells = document.querySelectorAll('.user-row td');
                cells.forEach(cell => {
                    if (cell.hasAttribute('data-original-text')) {
                        cell.innerHTML = cell.getAttribute('data-original-text');
                    }
                });
                return;
            }
            
            // Resaltar términos de búsqueda
            this.filteredItems.forEach(row => {
                const cells = row.querySelectorAll('td');
                cells.forEach(cell => {
                    // Guardar el texto original si no está guardado
                    if (!cell.hasAttribute('data-original-text')) {
                        cell.setAttribute('data-original-text', cell.innerHTML);
                    }
                    
                    const originalHTML = cell.getAttribute('data-original-text');
                    const textContent = cell.textContent || '';
                    
                    // Resaltar solo si hay coincidencia en esta celda específica
                    if (textContent.toLowerCase().includes(this.searchTerm)) {
                        const highlightedText = textContent.replace(
                            new RegExp(this.searchTerm, 'gi'),
                            match => `<span class="highlight">${match}</span>`
                        );
                        cell.innerHTML = highlightedText;
                    } else {
                        cell.innerHTML = originalHTML;
                    }
                });
            });
        }

        autoHideAlerts() {
            const alerts = document.querySelectorAll('.auto-hide-alert');
            
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transition = 'opacity 0.5s ease';
                    
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 500);
                }, 3000);
            });
        }

        refresh() {
            this.allItems = Array.from(document.querySelectorAll('#usersTableBody tr.user-row'));
            this.filterItems();
        }
    }

    // Instanciar paginación
    let pagination = null;

    // ========== FUNCIONALIDAD DEL MODAL ==========
    const modal = document.getElementById('userModal');
    const openCreateModal = document.getElementById('openCreateModal');
    const modalTitle = document.getElementById('modalTitle');
    const userForm = document.getElementById('userForm');
    const userId = document.getElementById('userId');
    const modalUsuario = document.getElementById('modalUsuario');
    const modalPassword = document.getElementById('modalPassword');
    const modalTipo = document.getElementById('modalTipo');
    const saveUserBtn = document.getElementById('saveUserBtn');
    const passwordRequired = document.getElementById('passwordRequired');

    // Elementos de error
    const usuarioError = document.getElementById('usuarioError');
    const passwordError = document.getElementById('passwordError');
    const tipoError = document.getElementById('tipoError');

    // Función para mostrar errores
    function showError(element, message) {
        element.textContent = message;
    }

    // Función para limpiar errores
    function clearErrors() {
        showError(usuarioError, '');
        showError(passwordError, '');
        showError(tipoError, '');
    }

    // Función para abrir modal con animación
    function openModal() {
        modal.style.display = 'flex';
        // Pequeño delay para activar la transición CSS
        setTimeout(() => {
            modal.classList.add('show');
        }, 10);
        document.body.style.overflow = 'hidden';
        
        // Enfocar el primer campo después de la animación
        setTimeout(() => {
            modalUsuario.focus();
        }, 350);
    }

    // Función para cerrar modal con animación
    function closeModalFunc() {
        modal.classList.remove('show');
        clearErrors();
        
        // Esperar a que termine la animación antes de ocultar completamente
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }, 300);
    }

    // Abrir modal para crear
    openCreateModal.addEventListener('click', function(e) {
        e.preventDefault();
        console.log('Abriendo modal para crear usuario');
        
        modalTitle.textContent = 'Crear Nuevo Usuario';
        userForm.reset();
        userId.value = '';
        clearErrors();
        
        // Hacer campo de contraseña obligatorio para crear
        modalPassword.required = true;
        passwordRequired.textContent = '*';
        passwordRequired.className = '';
        modalPassword.placeholder = '';
        
        openModal();
    });

    // Abrir modal para editar usando event delegation
    document.addEventListener('click', function(e) {
        const editBtn = e.target.closest('.edit-user-btn');
        if (editBtn) {
            e.preventDefault();
            console.log('Abriendo modal para editar usuario');
            
            const userData = {
                id: editBtn.getAttribute('data-user-id'),
                usuario: editBtn.getAttribute('data-user-usuario'),
                tipo: editBtn.getAttribute('data-user-tipo')
            };
            
            modalTitle.textContent = 'Editar Usuario';
            userId.value = userData.id;
            modalUsuario.value = userData.usuario;
            modalTipo.value = userData.tipo;
            clearErrors();
            
            // Hacer campo de contraseña opcional para editar
            modalPassword.required = false;
            passwordRequired.textContent = '(opcional)';
            passwordRequired.className = 'optional-field';
            modalPassword.value = '';
            modalPassword.placeholder = 'Dejar vacío para mantener contraseña actual';
            
            openModal();
        }
    });

    // Cerrar modal al hacer clic en botones de cierre
    document.addEventListener('click', function(e) {
        if (e.target.closest('.admin-modal-close') || e.target.closest('[data-dismiss="modal"]')) {
            closeModalFunc();
        }
    });

    // Cerrar modal al hacer clic fuera
    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModalFunc();
        }
    });

    // Cerrar modal con ESC
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && modal.classList.contains('show')) {
            closeModalFunc();
        }
    });

    // Validación del formulario
    function validateForm() {
        let isValid = true;
        const isEdit = userId.value !== '';
        
        // Limpiar errores previos
        clearErrors();
        
        // Validar usuario
        if (!modalUsuario.value.trim()) {
            showError(usuarioError, 'El nombre de usuario es requerido');
            isValid = false;
        }
        
        // Validar tipo
        if (!modalTipo.value) {
            showError(tipoError, 'El tipo de usuario es requerido');
            isValid = false;
        }
        
        // Validar contraseña
        if (!isEdit) {
            // Validación para crear usuario
            if (!modalPassword.value.trim()) {
                showError(passwordError, 'La contraseña es requerida para crear un usuario');
                isValid = false;
            } else if (modalPassword.value.length < 6) {
                showError(passwordError, 'La contraseña debe tener al menos 6 caracteres');
                isValid = false;
            }
        } else {
            // Validación para editar usuario
            if (modalPassword.value && modalPassword.value.length < 6) {
                showError(passwordError, 'La contraseña debe tener al menos 6 caracteres');
                isValid = false;
            }
        }
        
        return isValid;
    }

    // Envío del formulario
    saveUserBtn.addEventListener('click', function() {
        console.log('Validando formulario...');
        
        if (!validateForm()) {
            return;
        }
        
        console.log('Formulario válido, enviando...');
        
        // Mostrar loading en el botón
        const originalText = saveUserBtn.innerHTML;
        
        saveUserBtn.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Guardando...';
        saveUserBtn.disabled = true;
        
        // Pequeña demora para mostrar el loading y luego enviar
        setTimeout(() => {
            userForm.submit();
        }, 500);
    });

    // Toggle visibilidad de contraseña
    document.getElementById('togglePassword').addEventListener('click', function() {
        const type = modalPassword.getAttribute('type') === 'password' ? 'text' : 'password';
        modalPassword.setAttribute('type', type);
        this.innerHTML = type === 'password' ? '<i class="bx bx-hide"></i>' : '<i class="bx bx-show"></i>';
    });

    // Validación en tiempo real
    modalUsuario.addEventListener('input', function() {
        if (this.value.trim()) {
            showError(usuarioError, '');
        }
    });

    modalPassword.addEventListener('input', function() {
        if (this.value.length >= 6 || (!this.value && userId.value)) {
            showError(passwordError, '');
        }
    });

    modalTipo.addEventListener('change', function() {
        if (this.value) {
            showError(tipoError, '');
        }
    });

    // Prevenir envío del formulario con Enter
    userForm.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            saveUserBtn.click();
        }
    });

    // ========== INICIALIZACIÓN ==========

    function inicializarTodo() {
        // Inicializar paginación
        if (typeof PaginationUsers === 'function') {
            pagination = new PaginationUsers();
        }
        
        // Observar cambios en la tabla para actualizar paginación
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && pagination) {
                    setTimeout(() => {
                        pagination.refresh();
                    }, 200);
                }
            });
        });
        
        const tableBody = document.getElementById('usersTableBody');
        if (tableBody) {
            observer.observe(tableBody, { childList: true, subtree: true });
        }
    }

    // Esperar un poco para asegurar que todo esté cargado
    setTimeout(inicializarTodo, 100);

    // Debug: mostrar información de elementos
    console.log('Elementos cargados:', {
        modal: !!modal,
        openCreateModal: !!openCreateModal,
        userForm: !!userForm,
        tableRows: document.querySelectorAll('#usersTableBody tr').length
    });
});

// Función global para abrir modal desde cualquier lugar (backup)
function abrirModalCrearUsuario() {
    const modal = document.getElementById('userModal');
    const openCreateModal = document.getElementById('openCreateModal');
    if (modal && openCreateModal) {
        openCreateModal.click();
    }
}
</script>