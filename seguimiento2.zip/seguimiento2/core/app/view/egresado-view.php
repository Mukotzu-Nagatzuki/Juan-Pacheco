<div class="admin-content-wrapper">
    <div class="admin-content-header">
        <div class="admin-header-title py-4">
            <h1 class="display-6 fw-bold">LISTA DE ESTUDIANTES</h1>
            <p class="lead mb-0">Edite los estudiantes que pasanran como egresados</p>
        </div>
    </div>

    <div class="content-body">
        <div class="admin-card shadow-sm border-0">
            <div class="admin-card-header">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <button type="button" class="admin-btn-primary" id="openCreateModal">
                            <i class='bx bx-user-plus me-2'></i>
                            Registrar Nuevo Estudiante Egresado
                        </button>
                    </div>
                    
                    <!-- Buscador -->
                    <div class="admin-search-box">
                        <div class="search-input-group">
                            <i class='bx bx-search search-icon'></i>
                            <input type="text" id="searchEgresados" class="admin-form-input search-input" 
                                   placeholder="Buscar por DNI, nombres, apellidos o correo...">
                            <button type="button" id="clearSearch" class="clear-search-btn" style="display: none;">
                                <i class='bx bx-x'></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="admin-card-body">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="admin-alert admin-alert-success" role="alert">
                        <i class='bx bx-check-circle me-2'></i>
                        <?php echo htmlspecialchars($_SESSION['message']); ?>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="admin-alert admin-alert-error" role="alert">
                        <i class='bx bx-error-circle me-2'></i>
                        <?php echo htmlspecialchars($_SESSION['error']); ?>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <!-- NOTA: Se eliminó la barra de acciones masivas -->

                <div class="admin-table-responsive">
                    <table class="admin-table admin-table-striped admin-table-hover admin-table-bordered mb-0" id="egresadosTable">
                        <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">DNI</th>
                                <th class="text-center">Apellidos y Nombres</th>
                                <th class="text-center">Tipo</th>
                                <th class="text-center">Correo</th>
                                <th class="text-center">Teléfono</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="egresadosTableBody">
                            <?php if ($egresados && count($egresados) > 0): ?>
                                <?php foreach($egresados as $egresado): 
                                    // CORRECCIÓN: Determinar si es egresado o estudiante basado en estado (1=egresado, 0=estudiante)
                                    $esEgresado = ($egresado->estado == 1 || $egresado->tipo_estado === 'egresado');
                                    $tipo = $esEgresado ? 'egresado' : 'estudiante';
                                    $tipoTexto = $esEgresado ? 'Egresado' : 'Estudiante';
                                    $tipoClass = $esEgresado ? 'success' : 'info';
                                ?>
                                    <tr class="egresado-row" data-tipo="<?php echo $tipo; ?>" data-id="<?php echo $egresado->id; ?>">
                                        <td class="text-center align-middle"><?php echo $egresado->id; ?></td>
                                        <td class="text-center align-middle egresado-dni"><?php echo htmlspecialchars($egresado->dni_est); ?></td>
                                        <td class="text-center align-middle egresado-nombre">
                                            <?php echo htmlspecialchars($egresado->ap_est . " " . $egresado->am_est . ", " . $egresado->nom_est); ?>
                                        </td>
                                        <td class="text-center align-middle">
                                            <span class="admin-badge admin-badge-<?php echo $tipoClass; ?>" id="badge-<?php echo $egresado->id; ?>">
                                                <?php echo $tipoTexto; ?>
                                            </span>
                                        </td>
                                        <td class="text-center align-middle egresado-correo"><?php echo htmlspecialchars($egresado->mailp_est); ?></td>
                                        <td class="text-center align-middle egresado-telefono"><?php echo htmlspecialchars($egresado->cel_est); ?></td>
                                        <td class="text-center align-middle">
                                            <div class="admin-btn-group">
                                                <button type="button" class="admin-btn admin-btn-warning edit-egresado-btn" 
                                                        data-egresado-id="<?php echo $egresado->id; ?>"
                                                        data-dni="<?php echo htmlspecialchars($egresado->dni_est); ?>"
                                                        data-apellido-paterno="<?php echo htmlspecialchars($egresado->ap_est); ?>"
                                                        data-apellido-materno="<?php echo htmlspecialchars($egresado->am_est); ?>"
                                                        data-nombres="<?php echo htmlspecialchars($egresado->nom_est); ?>"
                                                        data-correo="<?php echo htmlspecialchars($egresado->mailp_est); ?>"
                                                        data-telefono="<?php echo htmlspecialchars($egresado->cel_est); ?>"
                                                        data-ubigeo="<?php echo htmlspecialchars($egresado->ubigeodir_est); ?>"
                                                        data-estado="<?php echo $tipo; ?>">
                                                    <i class='bx bx-edit me-1'></i> Editar
                                                </button>
                                                
                                                <!-- NOTA: Se eliminó el botón de cambiar estado -->
                                                
                                                <a href="index.php?action=eliminar_egresado&id=<?php echo $egresado->id; ?>" 
                                                class="admin-btn admin-btn-danger"
                                                onclick="return confirm('¿Está seguro de eliminar al egresado <?php echo htmlspecialchars($egresado->nom_est); ?>?')">
                                                    <i class='bx bx-trash me-1'></i> Eliminar
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="admin-text-center admin-text-muted py-5">
                                        <i class='bx bx-user-x display-4 d-block mb-3'></i>
                                        <p class="h5">No hay egresados registrados</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <!-- Mensaje cuando no hay resultados -->
                    <div id="noResults" class="admin-text-center admin-text-muted py-5" style="display: none;">
                        <i class='bx bx-search-alt display-4 d-block mb-3'></i>
                        <p class="h5">No se encontraron resultados</p>
                        <p class="text-muted">Intente con otros términos de búsqueda</p>
                    </div>
                </div>
                
                <!-- Contador de resultados y paginación -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div class="text-muted small" id="resultCount">
                        Mostrando <?php echo count($egresados); ?> egresados
                    </div>
                    
                    <!-- Controles de paginación - AGREGADO AQUÍ -->
                    <div class="admin-pagination" id="paginationControls">
                        <div class="d-flex align-items-center gap-3">
                            <div class="admin-pagination-info small text-muted">
                                Página <span id="currentPage">1</span> de <span id="totalPages">1</span>
                            </div>
                            <div class="admin-pagination-buttons">
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="firstPage" title="Primera página">
                                    <i class='bx bx-chevrons-left'></i>
                                </button>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="prevPage" title="Página anterior">
                                    <i class='bx bx-chevron-left'></i>
                                </button>
                                <div class="admin-page-numbers" id="pageNumbers">
                                    <!-- Los números de página se generarán aquí -->
                                </div>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="nextPage" title="Página siguiente">
                                    <i class='bx bx-chevron-right'></i>
                                </button>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="lastPage" title="Última página">
                                    <i class='bx bx-chevrons-right'></i>
                                </button>
                            </div>
                            <div class="admin-pagination-select">
                                <select class="admin-form-input small" id="itemsPerPage" style="padding: 5px 10px; height: 32px;">
                                    <option value="5">5 por página</option>
                                    <option value="10" selected>10 por página</option>
                                    <option value="20">20 por página</option>
                                    <option value="50">50 por página</option>
                                    <option value="100">100 por página</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Crear / Editar Egresado -->
<div class="admin-modal" id="egresadoModal">
    <div class="admin-modal-dialog">
        <div class="admin-modal-content">
            <div class="admin-modal-header">
                <h5 class="admin-modal-title" id="modalTitle">Registrar Nuevo Estudiante Egresado</h5>
                <button type="button" class="admin-modal-close" data-dismiss="modal">
                    <i class='bx bx-x'></i>
                </button>
            </div>
            <div class="admin-modal-body">
                <form id="egresadoForm" class="admin-form" method="POST" action="index.php?action=egresado">
                    <input type="hidden" id="id_egresado" name="id_egresado">
                    <input type="hidden" name="actions" value="1">

                    <div class="admin-form-grid">
                        <div class="admin-form-group">
                            <label class="admin-form-label">Tipo *</label>
                            <select name="estado" id="estado" class="admin-form-input" required>
                                <option value="estudiante">Estudiante</option>
                                <option value="egresado">Egresado</option>
                            </select>
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">DNI *</label>
                            <div class="dni-input-group">
                                <input type="text" name="dni" id="dni_input" maxlength="8" class="admin-form-input" required 
                                       pattern="[0-9]{8}" title="El DNI debe tener 8 dígitos">
                                <div class="admin-form-error" id="dniError" style="display: none;"></div>
                            </div>
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Apellido Paterno *</label>
                            <input type="text" name="apellido_paterno" id="apellido_paterno" class="admin-form-input" required>
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Apellido Materno *</label>
                            <input type="text" name="apellido_materno" id="apellido_materno" class="admin-form-input" required>
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Nombres *</label>
                            <input type="text" name="nombres" id="nombres" class="admin-form-input" required>
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Correo *</label>
                            <input type="email" name="correo" id="correo" class="admin-form-input" required>
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Teléfono *</label>
                            <input type="text" name="numero_telefonico" id="numero_telefonico" maxlength="9" class="admin-form-input" required
                                   pattern="[0-9]{9}" title="El teléfono debe tener 9 dígitos">
                        </div>

                        <!-- Campos de Ubigeo -->
                        <div class="admin-form-group">
                            <label class="admin-form-label">Departamento</label>
                            <select name="departamento" id="departamento" class="admin-form-input">
                                <option value="">Seleccione departamento</option>
                                <?php foreach($departamentos as $departamento): ?>
                                    <option value="<?php echo $departamento->id; ?>">
                                        <?php echo htmlspecialchars($departamento->departamento); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="departamento_nombre" id="departamento_nombre">
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Provincia</label>
                            <select name="provincia" id="provincia" class="admin-form-input" disabled>
                                <option value="">Seleccione provincia</option>
                            </select>
                            <input type="hidden" name="provincia_nombre" id="provincia_nombre">
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Distrito</label>
                            <select name="distrito" id="distrito" class="admin-form-input" disabled>
                                <option value="">Seleccione distrito</option>
                            </select>
                            <input type="hidden" name="distrito_nombre" id="distrito_nombre">
                        </div>
                    </div>
                </form>
            </div>
            <div class="admin-modal-footer">
                <button type="button" class="admin-btn-secondary" data-dismiss="modal">
                    <i class='bx bx-x'></i> Cancelar
                </button>
                <button type="button" class="admin-btn-primary" id="submitEgresadoForm">
                    <i class='bx bx-save'></i> Guardar Egresado
                </button>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/egresado.js"></script>