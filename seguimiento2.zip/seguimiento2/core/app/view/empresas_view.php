<div class="admin-content-wrapper">
    <div class="admin-content-header">
        <div class="admin-header-title py-4">
            <h1 class="display-6 fw-bold">GESTIÓN DE EMPRESAS</h1>
            <p class="lead mb-0">Administración de todas las empresas registradas en el sistema</p>
        </div>
    </div>

    <div class="content-body">
        <div class="admin-card shadow-sm border-0">
            <div class="admin-card-header">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <button type="button" class="admin-btn-primary" id="openCreateModal">
                            <i class='bx bx-building me-2'></i>
                            Registrar Nueva Empresa
                        </button>
                    </div>
                    <div class="col-md-6">
                        <!-- FORMULARIO DE BÚSQUEDA -->
                        <form method="GET" action="index.php" class="d-flex gap-2" id="searchForm">
                            <input type="hidden" name="action" value="empresas">
                            <div class="flex-grow-1">
                                <input type="text" name="busqueda" id="searchEmpresas" class="admin-form-input"
                                    placeholder="Buscar empresas..."
                                    value="<?php echo htmlspecialchars($_GET['busqueda'] ?? ''); ?>">
                            </div>
                            <button type="submit" class="admin-btn-primary">
                                <i class='bx bx-search'></i> Buscar
                            </button>
                            <?php if (isset($_GET['busqueda']) && !empty($_GET['busqueda'])): ?>
                                <button type="button" class="admin-btn-secondary clear-search-btn">
                                    <i class='bx bx-x'></i> Limpiar
                                </button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>

            <div class="admin-card-body">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="admin-alert admin-alert-success auto-hide-alert" role="alert">
                        <i class='bx bx-check-circle me-2'></i>
                        <?php echo htmlspecialchars($_SESSION['message']); ?>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="admin-alert admin-alert-error auto-hide-alert" role="alert">
                        <i class='bx bx-error-circle me-2'></i>
                        <?php echo htmlspecialchars($_SESSION['error']); ?>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <!-- Mostrar información de búsqueda -->
                <?php if (isset($_GET['busqueda']) && !empty($_GET['busqueda'])): ?>
                    <div class="admin-alert admin-alert-info auto-hide-alert" role="alert">
                        <i class='bx bx-info-circle me-2'></i>
                        Mostrando resultados para: "<strong><?php echo htmlspecialchars($_GET['busqueda']); ?></strong>"
                        <?php if (isset($_GET['criterio']) && $_GET['criterio'] != 'todas'): ?>
                            en <strong><?php echo htmlspecialchars($_GET['criterio']); ?></strong>
                        <?php endif; ?>
                        <span class="badge badge-primary ms-2">
                            <?php echo count($empresas); ?> resultado(s)
                        </span>
                    </div>
                <?php endif; ?>

                <div class="admin-table-responsive">
                    <table class="admin-table admin-table-striped admin-table-hover admin-table-bordered mb-0" id="empresasTable">
                        <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">RUC</th>
                                <th class="text-center">Razón Social</th>
                                <th class="text-center">Nombre Comercial</th>
                                <th class="text-center">Sector</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">Teléfono</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Condición SUNAT</th>
                                <th class="text-center">Validado</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <!-- En la tabla, agrega verificaciones para valores nulos -->
                        <tbody id="empresasTableBody">
                            <?php if (!empty($empresas) && is_array($empresas)): ?>
                                <?php foreach ($empresas as $empresa): ?>
                                    <?php if (is_object($empresa)): ?>
                                        <tr class="empresa-row" data-id="<?php echo $empresa->id ?? ''; ?>">
                                            <td class="text-center align-middle"><?php echo $empresa->id ?? ''; ?></td>
                                            <td class="text-center align-middle empresa-ruc">
                                                <?php echo htmlspecialchars($empresa->ruc ?? ''); ?></td>
                                            <td class="text-center align-middle empresa-razon-social">
                                                <?php echo htmlspecialchars($empresa->razon_social ?? ''); ?></td>
                                            <td class="text-center align-middle empresa-nombre-comercial">
                                                <?php echo htmlspecialchars($empresa->nombre_comercial ?? ''); ?></td>
                                            <td class="text-center align-middle empresa-sector">
                                                <span
                                                    class="badge badge-sector"><?php echo htmlspecialchars($empresa->sector ?? ''); ?></span>
                                            </td>
                                            <td class="text-center align-middle empresa-email">
                                                <?php echo htmlspecialchars($empresa->email ?? ''); ?></td>
                                            <td class="text-center align-middle empresa-telefono">
                                                <?php echo htmlspecialchars($empresa->telefono ?? ''); ?></td>
                                            <td class="text-center align-middle empresa-estado">
                                                <span
                                                    class="badge badge-<?php echo ($empresa->estado ?? '') === 'ACTIVO' ? 'success' : 'warning'; ?>">
                                                    <?php echo htmlspecialchars($empresa->estado ?? ''); ?>
                                                </span>
                                            </td>
                                            <td class="text-center align-middle empresa-condicion-sunat">
                                                <span
                                                    class="badge badge-info"><?php echo htmlspecialchars($empresa->condicion_sunat ?? ''); ?></span>
                                            </td>
                                            <td class="text-center align-middle empresa-validado">
                                                <span
                                                    class="badge badge-<?php echo ($empresa->validado ?? 0) ? 'success' : 'secondary'; ?>">
                                                    <?php echo ($empresa->validado ?? 0) ? 'Sí' : 'No'; ?>
                                                </span>
                                            </td>
                                            <td class="text-center align-middle">
                                                <div class="admin-btn-group">
                                                    <button type="button" class="admin-btn admin-btn-warning edit-empresa-btn"
                                                        data-empresa-id="<?php echo $empresa->id ?? ''; ?>"
                                                        data-ruc="<?php echo htmlspecialchars($empresa->ruc ?? ''); ?>"
                                                        data-razon-social="<?php echo htmlspecialchars($empresa->razon_social ?? ''); ?>"
                                                        data-nombre-comercial="<?php echo htmlspecialchars($empresa->nombre_comercial ?? ''); ?>"
                                                        data-sector="<?php echo htmlspecialchars($empresa->sector ?? ''); ?>"
                                                        data-email="<?php echo htmlspecialchars($empresa->email ?? ''); ?>"
                                                        data-telefono="<?php echo htmlspecialchars($empresa->telefono ?? ''); ?>"
                                                        data-direccion-fiscal="<?php echo htmlspecialchars($empresa->direccion_fiscal ?? ''); ?>"
                                                        data-departamento="<?php echo htmlspecialchars($empresa->departamento ?? ''); ?>"
                                                        data-provincia="<?php echo htmlspecialchars($empresa->provincia ?? ''); ?>"
                                                        data-distrito="<?php echo htmlspecialchars($empresa->distrito ?? ''); ?>"
                                                        data-ubigeo="<?php echo htmlspecialchars($empresa->ubigeo ?? ''); ?>"
                                                        data-estado="<?php echo htmlspecialchars($empresa->estado ?? ''); ?>"
                                                        data-condicion-sunat="<?php echo htmlspecialchars($empresa->condicion_sunat ?? ''); ?>"
                                                        data-validado="<?php echo $empresa->validado ?? 0; ?>"
                                                        data-registro-manual="<?php echo $empresa->registro_manual ?? 0; ?>">
                                                        <i class='bx bx-edit me-1'></i> Editar
                                                    </button>
                                                    <a href="index.php?action=eliminar_empresa&id=<?php echo $empresa->id ?? ''; ?>"
                                                        class="admin-btn admin-btn-danger"
                                                        onclick="return confirm('¿Está seguro de eliminar la empresa <?php echo htmlspecialchars($empresa->razon_social ?? ''); ?>?')">
                                                        <i class='bx bx-trash me-1'></i> Eliminar
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr id="noResultsRow">
                                    <td colspan="11" class="admin-text-center admin-text-muted py-5">
                                        <i class='bx bx-building-house display-4 d-block mb-3'></i>
                                        <p class="h5">
                                            <?php if (isset($_GET['busqueda']) && !empty($_GET['busqueda'])): ?>
                                                No se encontraron empresas que coincidan con tu búsqueda
                                            <?php else: ?>
                                                No hay empresas registradas
                                            <?php endif; ?>
                                        </p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <!-- Mensaje cuando no hay resultados en búsqueda -->
                    <div id="noResultsSearch" class="admin-text-center admin-text-muted py-5" style="display: none;">
                        <i class='bx bx-search-alt display-4 d-block mb-3'></i>
                        <p class="h5">No se encontraron resultados</p>
                        <p class="text-muted">Intente con otros términos de búsqueda</p>
                    </div>
                </div>
                
                <!-- Contador de resultados y paginación -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div class="text-muted small" id="resultCount">
                        Mostrando <?php echo count($empresas); ?> empresas
                    </div>
                    
                    <!-- Controles de paginación -->
                    <div class="admin-pagination" id="paginationControls">
                        <div class="d-flex align-items-center gap-3">
                            <div class="admin-pagination-info small text-muted">
                                Página <span id="currentPage">1</span> de <span id="totalPages">1</span>
                            </div>
                            <div class="admin-pagination-buttons">
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="firstPage" title="Primera página">
                                    <i class='bx bx-chevrons-left'></i>
                                </button>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="prevPage" title="Página anterior">
                                    <i class='bx bx-chevron-left'></i>
                                </button>
                                <div class="admin-page-numbers" id="pageNumbers">
                                    <!-- Los números de página se generarán aquí -->
                                </div>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="nextPage" title="Página siguiente">
                                    <i class='bx bx-chevron-right'></i>
                                </button>
                                <button type="button" class="admin-btn-secondary admin-pagination-btn" id="lastPage" title="Última página">
                                    <i class='bx bx-chevrons-right'></i>
                                </button>
                            </div>
                            <div class="admin-pagination-select">
                                <select class="admin-form-input small" id="itemsPerPage" style="padding: 5px 10px; height: 32px;">
                                    <option value="5">5 por página</option>
                                    <option value="10" selected>10 por página</option>
                                    <option value="20">20 por página</option>
                                    <option value="50">50 por página</option>
                                    <option value="100">100 por página</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Crear / Editar Empresa -->
<!-- Modal Crear / Editar Empresa -->
<div class="admin-modal" id="empresaModal">
    <div class="admin-modal-dialog admin-modal-lg">
        <div class="admin-modal-content">
            <div class="admin-modal-header">
                <h5 class="admin-modal-title" id="modalTitle">Registrar Nueva Empresa</h5>
                <button type="button" class="admin-modal-close" data-dismiss="modal">
                    <i class='bx bx-x'></i>
                </button>
            </div>
            <div class="admin-modal-body">
                <form id="empresaForm" class="admin-form" method="POST" action="index.php?action=guardar_empresa">
                    <input type="hidden" id="id_empresa" name="id_empresa">
                    <input type="hidden" name="actions" value="1">

                    <div class="admin-form-grid">
                        <!-- Columna 1 -->
                        <div class="form-column">
                            <div class="admin-form-group">
                                <label class="admin-form-label">RUC *</label>
                                <input type="text" name="ruc" maxlength="11" class="admin-form-input" required
                                    pattern="[0-9]{11}" title="El RUC debe tener 11 dígitos" id="rucInput">
                                <div id="rucValidationMessage" class="admin-validation-message"></div>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Razón Social *</label>
                                <input type="text" name="razon_social" class="admin-form-input" required 
                                    id="razonSocialInput" oninput="this.value = this.value.toUpperCase()">
                                <div id="razonSocialValidationMessage" class="admin-validation-message"></div>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Nombre Comercial</label>
                                <input type="text" name="nombre_comercial" class="admin-form-input" 
                                    id="nombreComercialInput" oninput="this.value = this.value.toUpperCase()">
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Sector</label>
                                <select name="sector" class="admin-form-input">
                                    <option value="">Seleccione...</option>
                                    <option value="Tecnología">Tecnología</option>
                                    <option value="Educación">Educación</option>
                                    <option value="Salud">Salud</option>
                                    <option value="Comercio">Comercio</option>
                                    <option value="Industria">Industria</option>
                                    <option value="Servicios">Servicios</option>
                                    <option value="Construcción">Construcción</option>
                                    <option value="Finanzas">Finanzas</option>
                                    <option value="Agricultura">Agricultura</option>
                                    <option value="Mineria">Minería</option>
                                    <option value="Transporte">Transporte</option>
                                    <option value="Turismo">Turismo</option>
                                    <option value="Otro">Otro</option>
                                </select>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Email</label>
                                <input type="email" name="email" class="admin-form-input">
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Teléfono *</label>
                                <input type="text" name="telefono" class="admin-form-input" maxlength="9" minlength="9"
                                    pattern="[0-9]{9}" title="El teléfono debe contener exactamente 9 números" required
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0,9);">
                            </div>
                        </div>

                        <!-- Columna 2 -->
                        <div class="form-column">
                            <div class="admin-form-group">
                                <label class="admin-form-label">Estado SUNAT</label>
                                <select name="estado" class="admin-form-input">
                                    <option value="">Seleccione...</option>
                                    <option value="ACTIVO">ACTIVO</option>
                                    <option value="INACTIVO">INACTIVO</option>
                                    <option value="BAJA">BAJA</option>
                                    <option value="SUSPENDIDO">SUSPENDIDO</option>
                                </select>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Condición SUNAT</label>
                                <select name="condicion_sunat" class="admin-form-input">
                                    <option value="">Seleccione...</option>
                                    <option value="HABIDO">HABIDO</option>
                                    <option value="NO HABIDO">NO HABIDO</option>
                                    <option value="PENDIENTE">PENDIENTE</option>
                                </select>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Validado</label>
                                <select name="validado" class="admin-form-input">
                                    <option value="0">No</option>
                                    <option value="1">Sí</option>
                                </select>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Registro Manual</label>
                                <select name="registro_manual" class="admin-form-input">
                                    <option value="0">No</option>
                                    <option value="1">Sí</option>
                                </select>
                            </div>

                            <div class="admin-form-group">
                                <label class="admin-form-label">Ubigeo</label>
                                <input type="text" name="ubigeo" maxlength="6" class="admin-form-input" 
                                    pattern="[0-9]{6}" title="El código de ubigeo debe tener 6 dígitos"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0,6)">
                            </div>
                        </div>
                    </div>

                    <!-- Campos de dirección (ancho completo) -->
                    <div class="admin-form-group full-width">
                        <label class="admin-form-label">Dirección Fiscal</label>
                        <div class="input-group">
                            <textarea name="direccion_fiscal" class="admin-form-input" rows="3" id="direccionFiscalTextarea"></textarea>
                        </div>
                    </div>

                    <div class="admin-form-grid">
                        <div class="admin-form-group">
                            <label class="admin-form-label">Departamento *</label>
                            <select name="departamento_id" id="departamento_id" class="admin-form-input" required>
                                <option value="">Seleccione Departamento</option>
                                <?php foreach ($departamentos as $dep): ?>
                                    <option value="<?php echo $dep->id; ?>">
                                        <?php echo htmlspecialchars($dep->departamento); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="departamento" id="departamento_nombre">
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Provincia *</label>
                            <select name="provincia_id" id="provincia_id" class="admin-form-input" required disabled>
                                <option value="">Seleccione Provincia</option>
                            </select>
                            <input type="hidden" name="provincia" id="provincia_nombre">
                        </div>

                        <div class="admin-form-group">
                            <label class="admin-form-label">Distrito *</label>
                            <select name="distrito_id" id="distrito_id" class="admin-form-input" required disabled>
                                <option value="">Seleccione Distrito</option>
                            </select>
                            <input type="hidden" name="distrito" id="distrito_nombre">
                            <input type="hidden" name="ubigeo" id="ubigeo_code">
                        </div>
                    </div>
                </form>
            </div>
            <div class="admin-modal-footer">
                <button type="button" class="admin-btn-secondary" data-dismiss="modal">
                    <i class='bx bx-x'></i> Cancelar
                </button>
                <button type="button" class="admin-btn-primary" id="submitEmpresaForm">
                    <i class='bx bx-save'></i> Guardar Empresa
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ===================== SCRIPT DEL MODAL ===================== -->
<script src="assets/js/empresa.js"></script>

<script>


function clearValidationMessage(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.style.display = 'none';
        element.innerHTML = '';
    }
}
    // Función para ocultar alertas automáticamente después de 3 segundos
    function autoHideAlerts() {
        const alerts = document.querySelectorAll('.admin-alert-success, .admin-alert-error, .admin-alert-info');
        
        alerts.forEach(alert => {
            // Configurar tiempo de espera de 3 segundos (3000ms)
            setTimeout(() => {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s ease';
                
                // Después de la animación, ocultar completamente
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 500);
            }, 3000); // 3000ms = 3 segundos
        });
    }

    // BLOQUEAR cierre del modal cuando se hace clic fuera
    document.addEventListener("click", function (event) {
        const modal = document.getElementById("empresaModal");
        const dialog = document.querySelector("#empresaModal .admin-modal-dialog");

        // Si el modal NO está visible → no hacer nada
        if (!modal.classList.contains("show")) return;

        // Verificar si el clic NO fue dentro del contenido
        if (!dialog.contains(event.target) && !event.target.closest("[data-dismiss='modal']")) {
            event.stopPropagation(); // Bloquea cierre por clic afuera
        }
    });

    // FORZAR que solo se cierre con botones autorizados
    document.querySelectorAll("[data-dismiss='modal']").forEach(btn => {
        btn.addEventListener("click", () => {
            document.getElementById("empresaModal").classList.remove("show");
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        // Ejecutar auto-hide de alertas
        autoHideAlerts();
        
        // Botón para limpiar búsqueda - usando clase en lugar de ID
        const clearSearchBtns = document.querySelectorAll('.clear-search-btn');

        clearSearchBtns.forEach(btn => {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation(); // Esto evita que el evento se propague
                console.log('Limpiando búsqueda...');
                window.location.href = 'index.php?action=empresas';
            });
        });

        // Si usas event delegation (por si hay elementos dinámicos)
        document.addEventListener('click', function (e) {
            if (e.target.closest('.clear-search-btn')) {
                e.preventDefault();
                e.stopPropagation();
                window.location.href = 'index.php?action=empresas';
            }
        });
    });
</script>