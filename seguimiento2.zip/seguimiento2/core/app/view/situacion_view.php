<div class="container-fluid mt-4 px-4">
    <div class="admin-content-header">
        <div class="admin-header-title py-4">
            <h1 class="display-6 fw-bold">SITUACIÓN LABORAL</h1>
            <p class="lead mb-0">Gestión de todos los registros de la encuesta</p>
        </div>
    </div>
    <br>
    
    <!-- Mostrar mensajes -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="admin-alert admin-alert-success auto-hide-alert" id="successAlert">
            <?= $_SESSION['message'];
            unset($_SESSION['message']); ?>
        </div>
    <?php elseif (isset($_SESSION['error'])): ?>
        <div class="admin-alert admin-alert-error auto-hide-alert" id="errorAlert">
            <?= $_SESSION['error'];
            unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <!-- Información de actividad activa actual -->
    <?php if (isset($actividad_actual) && $actividad_actual): ?>
    <div class="alert alert-info mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-1"><i class='bx bx-calendar-event'></i> Actividad Activa Actual</h5>
                <p class="mb-0">
                    <strong><?= htmlspecialchars($actividad_actual->titulo) ?></strong><br>
                    <?= date('d/m/Y', strtotime($actividad_actual->fecha_inicio)) ?> 
                    al 
                    <?= date('d/m/Y', strtotime($actividad_actual->fecha_fin)) ?>
                    | Encuestas realizadas en este período se asignarán automáticamente a esta actividad
                </p>
            </div>
            <span class="badge bg-success fs-6">ACTIVA</span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Tabla de situaciones laborales -->
    <div class="card">
        <div class="card-header admin-card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Todas las Situaciones Laborales Registradas</h5>
                
                <!-- BUSCADOR SIN BOTÓN × -->
                <div class="admin-search-box">
                    <div class="search-input-group">
                        <i class='bx bx-search search-icon'></i>
                        <input type="text" id="searchSituaciones" class="admin-form-input search-input" 
                               placeholder="Buscar por DNI exacto, nombre o actividad...">
                        <!-- ELIMINADO EL BOTÓN × -->
                    </div>
                </div>
            </div>
            <br>
        </div>
        <div class="card-body">
            <!-- Mensaje cuando no hay resultados en búsqueda client-side -->
            <div id="noResults" class="admin-text-center admin-text-muted py-5" style="display: none;">
                <i class='bx bx-search-alt display-4 d-block mb-3'></i>
                <p class="h5">No se encontraron resultados</p>
                <p class="text-muted">Intente con otros términos de búsqueda</p>
            </div>
            
            <?php if ($situaciones && count($situaciones) > 0): ?>
                <div class="admin-table-responsive">
                    <table class="admin-table table-striped table-bordered table-hover mb-0" id="situacionesTable">
                        <thead class="table-dark">
                            <tr>
                                <th style="min-width: 50px;">#</th>
                                <th style="min-width: 200px;">Egresado</th>
                                <th style="min-width: 120px;">DNI</th>
                                <th style="min-width: 100px;">Trabaja</th>
                                <th style="min-width: 120px;">En su área</th>
                                <th style="min-width: 150px;">Cargo</th>
                                <th style="min-width: 130px;">Condición</th>
                                <th style="min-width: 120px;">Ingreso</th>
                                <th style="min-width: 140px;">Satisfacción</th>
                                <th style="min-width: 120px;">Fecha Inicio</th>
                                <!-- NUEVA COLUMNA: FECHA FIN -->
                                <th style="min-width: 120px;">Fecha Fin</th>
                                <!-- NUEVA COLUMNA: ACTIVIDAD -->
                                <th style="min-width: 180px;">Actividad Asignada</th>
                            </tr>
                        </thead>
                        <tbody id="situacionesTableBody">
                            <?php foreach ($situaciones as $index => $sit): ?>
                                <tr class="situacion-row" 
                                    data-id="<?= $sit->id_situacion ?? '' ?>"
                                    data-nombre="<?= htmlspecialchars($sit->estudiante_nombre_completo ?? '') ?>"
                                    data-dni="<?= htmlspecialchars($sit->estudiante_dni ?? '') ?>"
                                    data-cargo="<?= htmlspecialchars($sit->cargo_actual ?? '') ?>"
                                    data-condicion="<?= $sit->condicion_laboral ?? '' ?>"
                                    data-ingreso="<?= $sit->ingreso_bruto_mensual ?? '' ?>"
                                    data-satisfaccion="<?= htmlspecialchars($sit->satisfaccion_trabajo ?? '') ?>"
                                    data-fecha-fin="<?= $sit->fecha_fin ?? '' ?>"
                                    data-actividad="<?= htmlspecialchars($sit->actividad_titulo ?? '') ?>">
                                    <td class="text-center align-middle"><?= $index + 1 ?></td>
                                    <td class="align-middle situacion-nombre"><?= htmlspecialchars($sit->estudiante_nombre_completo ?? '') ?></td>
                                    <td class="text-center align-middle situacion-dni"><?= htmlspecialchars($sit->estudiante_dni ?? '') ?></td>
                                    <td class="text-center align-middle">
                                        <span class="admin-badge <?= ($sit->trabaja == 1) ? 'admin-badge-success' : 'bg-danger' ?>">
                                            <?= ($sit->trabaja == 1) ? 'Sí' : 'No' ?>
                                        </span>
                                    </td>
                                    <td class="text-center align-middle">
                                        <span class="admin-badge <?= ($sit->labora_programa_estudios == 1) ? 'admin-badge-success' : 'bg-warning' ?>">
                                            <?= ($sit->labora_programa_estudios == 1) ? 'Sí' : 'No' ?>
                                        </span>
                                    </td>
                                    <td class="align-middle situacion-cargo"><?= htmlspecialchars($sit->cargo_actual ?? '') ?></td>
                                    <td class="text-center align-middle situacion-condicion">
                                        <?php
                                        $condiciones = [
                                            1 => 'Dependiente',
                                            2 => 'Independiente',
                                            3 => 'Prácticas',
                                            4 => 'Por Contrato'
                                        ];
                                        echo $condiciones[$sit->condicion_laboral ?? 0] ?? 'Desconocido';
                                        ?>
                                    </td>
                                    <td class="text-center align-middle situacion-ingreso">S/ <?= number_format($sit->ingreso_bruto_mensual ?? 0, 2) ?></td>
                                    <td class="text-center align-middle situacion-satisfaccion">
                                        <?php
                                        $satisfaccion_classes = [
                                            'Muy satisfecho' => 'bg-success',
                                            'Satisfecho' => 'bg-primary',
                                            'Neutral' => 'bg-secondary',
                                            'Insatisfecho' => 'bg-warning',
                                            'Muy insatisfecho' => 'bg-danger'
                                        ];
                                        $satisfaccion = $sit->satisfaccion_trabajo ?? 'Neutral';
                                        $clase = $satisfaccion_classes[$satisfaccion] ?? 'bg-secondary';
                                        ?>
                                        <span class="admin-badge <?= $clase ?>">
                                            <?= htmlspecialchars($satisfaccion) ?>
                                        </span>
                                    </td>
                                    <td class="text-center align-middle situacion-fecha-inicio">
                                        <?= !empty($sit->fecha_inicio) ? date('d/m/Y', strtotime($sit->fecha_inicio)) : 'No especificada' ?>
                                    </td>
                                    <!-- NUEVA CELDA: FECHA FIN -->
                                    <td class="text-center align-middle situacion-fecha-fin">
                                        <?php
                                        $fecha_fin = $sit->fecha_fin ?? '';
                                        if (!empty($fecha_fin)) {
                                            echo date('d/m/Y', strtotime($fecha_fin));
                                        } elseif ($sit->trabaja == 1) {
                                            echo '<span class="admin-badge bg-success">Trabajo Actual</span>';
                                        } else {
                                            echo '<span class="text-muted">No aplica</span>';
                                        }
                                        ?>
                                    </td>
                                    <!-- NUEVA CELDA: ACTIVIDAD -->
                                    <td class="text-center align-middle situacion-actividad">
                                        <?php
                                        $actividad_titulo = $sit->actividad_titulo ?? null;
                                        $actividad_fecha_inicio = $sit->actividad_fecha_inicio ?? null;
                                        $actividad_fecha_fin = $sit->actividad_fecha_fin ?? null;
                                        $actividad_id = $sit->actividad ?? null;
                                        
                                        if ($actividad_titulo && $actividad_titulo !== 'No asignada') {
                                            // Mostrar información de la actividad con tooltip
                                            $tooltip_text = htmlspecialchars($actividad_titulo) . "\n" .
                                                        "Inicio: " . date('d/m/Y', strtotime($actividad_fecha_inicio)) . "\n" .
                                                        "Fin: " . date('d/m/Y', strtotime($actividad_fecha_fin));
                                            
                                            echo '<div class="actividad-asignada" data-bs-toggle="tooltip" data-bs-title="' . $tooltip_text . '">';
                                            echo '<span class="admin-badge ' . 
                                                (($actividad_actual && $actividad_actual->id == $actividad_id) ? 'bg-success' : 'bg-info') . '">';
                                            echo '<i class="bx bx-calendar-check me-1"></i>';
                                            echo htmlspecialchars(mb_strimwidth($actividad_titulo, 0, 25, '...'));
                                            echo '</span>';
                                            
                                            // Si es la actividad actual, mostrar indicador
                                            if ($actividad_actual && $actividad_actual->id == $actividad_id) {
                                                echo '<small class="d-block text-success mt-1"><i class="bx bx-time"></i> Actividad vigente</small>';
                                            }
                                            echo '</div>';
                                        } else {
                                            echo '<span class="text-muted">';
                                            echo '<i class="bx bx-calendar-x"></i> No asignada';
                                            if ($actividad_id) {
                                                echo ' <small class="text-danger">(ID: ' . $actividad_id . ')</small>';
                                            }
                                            echo '</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info text-center admin-alert" id="noDataMessage">
                    No hay situaciones laborales registradas aún.
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Contador de resultados y paginación -->
        <div class="d-flex justify-content-between align-items-center mt-3 px-4">
            <div class="text-muted small" id="resultCount">
                Mostrando <?= count($situaciones ?? []) ?> registros
            </div>
            
            <!-- Controles de paginación -->
            <div class="admin-pagination" id="paginationControls">
                <div class="d-flex align-items-center gap-3">
                    <div class="admin-pagination-info small text-muted">
                        Página <span id="currentPage">1</span> de <span id="totalPages">1</span>
                    </div>
                    <div class="admin-pagination-buttons">
                        <button type="button" class="admin-btn-secondary admin-pagination-btn" id="firstPage" title="Primera página">
                            <i class='bx bx-chevrons-left'></i>
                        </button>
                        <button type="button" class="admin-btn-secondary admin-pagination-btn" id="prevPage" title="Página anterior">
                            <i class='bx bx-chevron-left'></i>
                        </button>
                        <div class="admin-page-numbers" id="pageNumbers">
                            <!-- Los números de página se generarán aquí -->
                        </div>
                        <button type="button" class="admin-btn-secondary admin-pagination-btn" id="nextPage" title="Página siguiente">
                            <i class='bx bx-chevron-right'></i>
                        </button>
                        <button type="button" class="admin-btn-secondary admin-pagination-btn" id="lastPage" title="Última página">
                            <i class='bx bx-chevrons-right'></i>
                        </button>
                    </div>
                    <div class="admin-pagination-select">
                        <select class="admin-form-input small" id="itemsPerPage" style="padding: 5px 10px; height: 32px;">
                            <option value="5">5 por página</option>
                            <option value="10" selected>10 por página</option>
                            <option value="20">20 por página</option>
                            <option value="50">50 por página</option>
                            <option value="100">100 por página</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card-footer admin-card-footer">
            <strong>Total de registros:</strong> <span id="totalRecords"><?= count($situaciones ?? []) ?></span>
        </div>
    </div>
</div>

<!-- JavaScript para paginación y búsqueda -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    console.log("=== SITUACIÓN LABORAL JS CARGADO ===");
    
    // ========== PAGINACIÓN CLIENTE-SIDE ==========
    class PaginationSituaciones {
        constructor() {
            this.currentPage = 1;
            this.itemsPerPage = parseInt(document.getElementById('itemsPerPage')?.value || 10);
            this.filteredItems = [];
            this.allItems = [];
            this.searchTerm = '';
            this.initPagination();
        }

        initPagination() {
            // Obtener todos los elementos de la tabla
            this.allItems = Array.from(document.querySelectorAll('#situacionesTableBody tr.situacion-row'));
            this.filteredItems = [...this.allItems];
            
            // Configurar eventos de paginación
            this.setupPaginationEvents();
            
            // Inicializar paginación
            this.updatePagination();
            this.handleInitialState();
        }

        setupPaginationEvents() {
            // Eventos de botones de paginación
            document.getElementById('firstPage')?.addEventListener('click', () => this.goToPage(1));
            document.getElementById('prevPage')?.addEventListener('click', () => this.goToPage(this.currentPage - 1));
            document.getElementById('nextPage')?.addEventListener('click', () => this.goToPage(this.currentPage + 1));
            document.getElementById('lastPage')?.addEventListener('click', () => this.goToPage(this.getTotalPages()));
            
            // Evento para cambiar items por página
            const itemsPerPageSelect = document.getElementById('itemsPerPage');
            if (itemsPerPageSelect) {
                itemsPerPageSelect.value = this.itemsPerPage.toString();
                itemsPerPageSelect.addEventListener('change', (e) => {
                    this.itemsPerPage = parseInt(e.target.value);
                    this.currentPage = 1;
                    this.updatePagination();
                });
            }
            
            // Configurar búsqueda en tiempo real SIN BOTÓN ×
            const searchInput = document.getElementById('searchSituaciones');
            
            if (searchInput) {
                // Buscar inmediatamente al escribir
                searchInput.addEventListener('input', () => {
                    this.searchTerm = searchInput.value.trim();
                    this.filterItems();
                    
                    // Actualizar indicador visual del tipo de búsqueda
                    this.updateSearchTypeIndicator();
                });
                
                // Manejar tecla Escape para limpiar
                searchInput.addEventListener('keyup', (e) => {
                    if (e.key === 'Escape') {
                        searchInput.value = '';
                        this.searchTerm = '';
                        this.filterItems();
                        this.updateSearchTypeIndicator();
                    }
                });
                
                // Limpiar automáticamente cuando se borra todo
                searchInput.addEventListener('blur', () => {
                    if (searchInput.value.trim() === '') {
                        this.searchTerm = '';
                        this.filterItems();
                        this.updateSearchTypeIndicator();
                    }
                });
                
                // Inicializar indicador visual
                this.updateSearchTypeIndicator();
            }
            
            // Auto-hide alerts
            this.autoHideAlerts();
            
            // Inicializar tooltips de Bootstrap
            this.initTooltips();
        }

        updateSearchTypeIndicator() {
            const searchInput = document.getElementById('searchSituaciones');
            if (!searchInput) return;
            
            const cleanSearchTerm = this.searchTerm.replace(/\s+/g, '');
            
            // Remover clases anteriores
            searchInput.classList.remove('dni-search', 'text-search');
            
            if (cleanSearchTerm === '') {
                searchInput.placeholder = "Buscar por DNI exacto, nombre o actividad...";
            } else if (/^\d+$/.test(cleanSearchTerm)) {
                // Solo números = búsqueda de DNI exacto
                searchInput.classList.add('dni-search');
                searchInput.placeholder = "Buscando por DNI exacto...";
            } else {
                // Con letras = búsqueda de texto en nombre/actividad
                searchInput.classList.add('text-search');
                searchInput.placeholder = "Buscando en nombre/actividad...";
            }
        }

        initTooltips() {
            // Inicializar tooltips si Bootstrap está disponible
            if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
                const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
                const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => {
                    return new bootstrap.Tooltip(tooltipTriggerEl, {
                        delay: {show: 100, hide: 100}
                    });
                });
            } else {
                // Fallback simple si no hay Bootstrap
                const tooltipElements = document.querySelectorAll('[data-bs-toggle="tooltip"]');
                tooltipElements.forEach(el => {
                    el.addEventListener('mouseenter', function(e) {
                        const title = this.getAttribute('data-bs-title');
                        if (title) {
                            const tooltip = document.createElement('div');
                            tooltip.className = 'custom-tooltip';
                            tooltip.textContent = title.replace(/\\n/g, '\n');
                            tooltip.style.position = 'absolute';
                            tooltip.style.background = 'rgba(0,0,0,0.8)';
                            tooltip.style.color = 'white';
                            tooltip.style.padding = '5px 10px';
                            tooltip.style.borderRadius = '4px';
                            tooltip.style.zIndex = '1000';
                            tooltip.style.maxWidth = '300px';
                            tooltip.style.whiteSpace = 'pre-line';
                            
                            document.body.appendChild(tooltip);
                            const rect = this.getBoundingClientRect();
                            tooltip.style.top = (rect.top - tooltip.offsetHeight - 5) + 'px';
                            tooltip.style.left = (rect.left + rect.width/2 - tooltip.offsetWidth/2) + 'px';
                            
                            this._tooltip = tooltip;
                        }
                    });
                    
                    el.addEventListener('mouseleave', function(e) {
                        if (this._tooltip) {
                            document.body.removeChild(this._tooltip);
                            delete this._tooltip;
                        }
                    });
                });
            }
        }

        getTotalPages() {
            const total = Math.ceil(this.filteredItems.length / this.itemsPerPage);
            console.log(`Calculando total páginas: ${this.filteredItems.length} / ${this.itemsPerPage} = ${total}`);
            return total > 0 ? total : 1;
        }

        goToPage(page) {
            const totalPages = this.getTotalPages();
            
            if (page < 1) page = 1;
            if (page > totalPages) page = totalPages;
            
            this.currentPage = page;
            this.updatePagination();
        }

        filterItems() {
            this.currentPage = 1;
            
            if (!this.searchTerm) {
                this.filteredItems = [...this.allItems];
            } else {
                // Limpiar el término de búsqueda (eliminar espacios)
                const cleanSearchTerm = this.searchTerm.replace(/\s+/g, '');
                
                this.filteredItems = this.allItems.filter(row => {
                    // Obtener datos específicos de la fila
                    const nombre = row.querySelector('.situacion-nombre')?.textContent.toLowerCase() || '';
                    const dni = row.querySelector('.situacion-dni')?.textContent.toLowerCase() || '';
                    const actividad = row.querySelector('.situacion-actividad')?.textContent.toLowerCase() || '';
                    
                    // Limpiar el DNI de espacios
                    const cleanDni = dni.replace(/\s+/g, '');
                    
                    // DETERMINAR EL TIPO DE BÚSQUEDA:
                    // 1. Si el término es solo números => BÚSQUEDA EXACTA DE DNI
                    // 2. Si contiene letras => BÚSQUEDA PARCIAL EN NOMBRE/ACTIVIDAD
                    
                    if (/^\d+$/.test(cleanSearchTerm)) {
                        // SOLO NUMEROS: Búsqueda EXACTA del DNI (comparación completa)
                        return cleanDni === cleanSearchTerm;
                    } else {
                        // CONTIENE LETRAS: Búsqueda parcial en nombre y actividad
                        const cleanSearchTermLower = cleanSearchTerm.toLowerCase();
                        return nombre.includes(cleanSearchTermLower) ||
                               actividad.includes(cleanSearchTermLower);
                    }
                });
            }
            
            this.updatePagination();
            this.highlightSearchResults();
        }

        updatePagination() {
            const totalPages = this.getTotalPages();
            const startIndex = (this.currentPage - 1) * this.itemsPerPage;
            const endIndex = startIndex + this.itemsPerPage;
            
            // Ocultar todas las filas
            this.allItems.forEach(row => row.style.display = 'none');
            
            // Mostrar solo las filas de la página actual
            this.filteredItems.slice(startIndex, endIndex).forEach(row => {
                if (row) row.style.display = '';
            });
            
            // Manejar estados de visibilidad
            this.handleVisibility();
            
            // Actualizar controles de paginación
            this.updatePaginationControls(totalPages);
            this.updatePaginationInfo(totalPages);
            this.updateResultCount();
        }

        updatePaginationControls(totalPages) {
            const pageNumbersContainer = document.getElementById('pageNumbers');
            if (!pageNumbersContainer) return;
            
            pageNumbersContainer.innerHTML = '';
            
            // Mostrar máximo 5 números de página
            let startPage = Math.max(1, this.currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            // Botón para primera página si es necesario
            if (startPage > 1) {
                const firstPageBtn = document.createElement('button');
                firstPageBtn.className = 'admin-page-number';
                firstPageBtn.textContent = '1';
                firstPageBtn.addEventListener('click', () => this.goToPage(1));
                pageNumbersContainer.appendChild(firstPageBtn);
                
                if (startPage > 2) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
            }
            
            // Números de página
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `admin-page-number ${i === this.currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.addEventListener('click', () => this.goToPage(i));
                pageNumbersContainer.appendChild(pageBtn);
            }
            
            // Botón para última página si es necesario
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
                
                const lastPageBtn = document.createElement('button');
                lastPageBtn.className = 'admin-page-number';
                lastPageBtn.textContent = totalPages;
                lastPageBtn.addEventListener('click', () => this.goToPage(totalPages));
                pageNumbersContainer.appendChild(lastPageBtn);
            }
            
            // Actualizar estado de botones - SOLO deshabilitar si realmente no hay más páginas
            const firstBtn = document.getElementById('firstPage');
            const prevBtn = document.getElementById('prevPage');
            const nextBtn = document.getElementById('nextPage');
            const lastBtn = document.getElementById('lastPage');
            
            if (firstBtn) {
                firstBtn.disabled = this.currentPage === 1;
                firstBtn.style.opacity = this.currentPage === 1 ? '0.5' : '1';
                firstBtn.style.cursor = this.currentPage === 1 ? 'not-allowed' : 'pointer';
            }
            
            if (prevBtn) {
                prevBtn.disabled = this.currentPage === 1;
                prevBtn.style.opacity = this.currentPage === 1 ? '0.5' : '1';
                prevBtn.style.cursor = this.currentPage === 1 ? 'not-allowed' : 'pointer';
            }
            
            if (nextBtn) {
                // IMPORTANTE: Solo deshabilitar si estamos en la última página
                nextBtn.disabled = this.currentPage === totalPages;
                nextBtn.style.opacity = this.currentPage === totalPages ? '0.5' : '1';
                nextBtn.style.cursor = this.currentPage === totalPages ? 'not-allowed' : 'pointer';
            }
            
            if (lastBtn) {
                // IMPORTANTE: Solo deshabilitar si estamos en la última página
                lastBtn.disabled = this.currentPage === totalPages;
                lastBtn.style.opacity = this.currentPage === totalPages ? '0.5' : '1';
                lastBtn.style.cursor = this.currentPage === totalPages ? 'not-allowed' : 'pointer';
            }
            
            // Mostrar/ocultar controles de paginación - CORREGIDO
            const paginationControls = document.getElementById('paginationControls');
            if (paginationControls) {
                // Mostrar paginación SIEMPRE que haya resultados (aunque sea 1 página)
                paginationControls.style.display = this.filteredItems.length > 0 ? 'flex' : 'none';
            }
        }

        // AGREGAR este método para debuggear (opcional, para verificar que todo funciona):

        debugPagination() {
            console.log('=== DEBUG PAGINACIÓN ===');
            console.log('Página actual:', this.currentPage);
            console.log('Total páginas:', this.getTotalPages());
            console.log('Items por página:', this.itemsPerPage);
            console.log('Total items:', this.filteredItems.length);
            console.log('Término búsqueda:', this.searchTerm);
            console.log('=== FIN DEBUG ===');
        }

        // Luego, en el método updatePagination(), agregar después de actualizar los controles:
        updatePagination() {
            const totalPages = this.getTotalPages();
            const startIndex = (this.currentPage - 1) * this.itemsPerPage;
            const endIndex = startIndex + this.itemsPerPage;
            
            // DEBUG: Verificar que los cálculos son correctos
            console.log(`Página ${this.currentPage} de ${totalPages}`);
            console.log(`Mostrando items ${startIndex + 1} a ${endIndex} de ${this.filteredItems.length}`);
            
            // Ocultar todas las filas
            this.allItems.forEach(row => row.style.display = 'none');
            
            // Mostrar solo las filas de la página actual
            const itemsToShow = this.filteredItems.slice(startIndex, endIndex);
            console.log(`Items a mostrar: ${itemsToShow.length}`);
            
            itemsToShow.forEach(row => {
                if (row) row.style.display = '';
            });
            
            // Manejar estados de visibilidad
            this.handleVisibility();
            
            // Actualizar controles de paginación
            this.updatePaginationControls(totalPages);
            this.updatePaginationInfo(totalPages);
            this.updateResultCount();
            
            // DEBUG opcional
            this.debugPagination();
        }


        updatePaginationInfo(totalPages) {
            const currentPageSpan = document.getElementById('currentPage');
            const totalPagesSpan = document.getElementById('totalPages');
            
            if (currentPageSpan) currentPageSpan.textContent = this.currentPage;
            if (totalPagesSpan) totalPagesSpan.textContent = totalPages;
        }

        updateResultCount() {
            const resultCount = document.getElementById('resultCount');
            const totalRecords = document.getElementById('totalRecords');
            
            if (!resultCount) return;
            
            const totalItems = this.filteredItems.length;
            const startIndex = (this.currentPage - 1) * this.itemsPerPage + 1;
            const endIndex = Math.min(startIndex + this.itemsPerPage - 1, totalItems);
            
            // Actualizar contador de registros
            if (totalRecords) {
                totalRecords.textContent = totalItems;
            }
            
            if (totalItems === 0) {
                if (this.searchTerm) {
                    // Mostrar mensaje específico según el tipo de búsqueda
                    const cleanSearchTerm = this.searchTerm.replace(/\s+/g, '');
                    if (/^\d+$/.test(cleanSearchTerm)) {
                        resultCount.textContent = `No se encontró ningún registro con DNI: ${this.searchTerm}`;
                    } else {
                        resultCount.textContent = `No se encontraron resultados para "${this.searchTerm}"`;
                    }
                } else {
                    resultCount.textContent = 'No hay registros';
                }
            } else if (totalItems <= this.itemsPerPage) {
                if (this.searchTerm) {
                    const cleanSearchTerm = this.searchTerm.replace(/\s+/g, '');
                    if (/^\d+$/.test(cleanSearchTerm)) {
                        resultCount.textContent = `Mostrando ${totalItems} registro(s) con DNI: ${this.searchTerm}`;
                    } else {
                        resultCount.textContent = `Mostrando ${totalItems} resultados para "${this.searchTerm}"`;
                    }
                } else {
                    resultCount.textContent = `Mostrando ${totalItems} registros`;
                }
            } else {
                if (this.searchTerm) {
                    const cleanSearchTerm = this.searchTerm.replace(/\s+/g, '');
                    if (/^\d+$/.test(cleanSearchTerm)) {
                        resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} registros con DNI: ${this.searchTerm}`;
                    } else {
                        resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} resultados para "${this.searchTerm}"`;
                    }
                } else {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} registros`;
                }
            }
        }

        handleVisibility() {
            const noResults = document.getElementById('noResults');
            const noDataMessage = document.getElementById('noDataMessage');
            const tableBody = document.getElementById('situacionesTableBody');
            
            if (this.filteredItems.length === 0) {
                // Mostrar mensaje de no resultados
                if (noResults) {
                    noResults.style.display = 'block';
                }
                if (tableBody) {
                    tableBody.style.display = 'none';
                }
                // Ocultar mensaje de no datos original
                if (noDataMessage) {
                    noDataMessage.style.display = 'none';
                }
            } else {
                // Ocultar mensaje de no resultados
                if (noResults) {
                    noResults.style.display = 'none';
                }
                if (tableBody) {
                    tableBody.style.display = '';
                }
                // Ocultar mensaje de no datos original si existe
                if (noDataMessage) {
                    noDataMessage.style.display = 'none';
                }
            }
        }

        handleInitialState() {
            const noDataMessage = document.getElementById('noDataMessage');
            const paginationControls = document.getElementById('paginationControls');
            
            // Si hay mensaje de no datos, ocultar paginación
            if (noDataMessage && noDataMessage.style.display !== 'none') {
                if (paginationControls) {
                    paginationControls.style.display = 'none';
                }
            }
        }

        highlightSearchResults() {
            if (!this.searchTerm) {
                // Remover resaltado si no hay búsqueda
                const cells = document.querySelectorAll('.situacion-row td');
                cells.forEach(cell => {
                    if (cell.hasAttribute('data-original-text')) {
                        cell.innerHTML = cell.getAttribute('data-original-text');
                    }
                });
                return;
            }
            
            // Determinar si es búsqueda de texto (no DNI)
            const cleanSearchTerm = this.searchTerm.replace(/\s+/g, '');
            const isTextSearch = !/^\d+$/.test(cleanSearchTerm);
            const searchTermLower = cleanSearchTerm.toLowerCase();
            
            if (isTextSearch) {
                // Solo resaltar en búsqueda de texto (nombre/actividad)
                this.filteredItems.forEach(row => {
                    const nombreCell = row.querySelector('.situacion-nombre');
                    const actividadCell = row.querySelector('.situacion-actividad');
                    
                    const cellsToHighlight = [nombreCell, actividadCell].filter(cell => cell);
                    
                    cellsToHighlight.forEach(cell => {
                        if (!cell.hasAttribute('data-original-text')) {
                            cell.setAttribute('data-original-text', cell.innerHTML);
                        }
                        
                        const originalHTML = cell.getAttribute('data-original-text');
                        const textContent = cell.textContent || '';
                        
                        if (textContent.toLowerCase().includes(searchTermLower)) {
                            const highlightedText = textContent.replace(
                                new RegExp(searchTermLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'),
                                match => `<span class="highlight">${match}</span>`
                            );
                            cell.innerHTML = highlightedText;
                        } else {
                            cell.innerHTML = originalHTML;
                        }
                    });
                });
            } else {
                // Para búsqueda de DNI, no resaltar (ya que es coincidencia exacta)
                const cells = document.querySelectorAll('.situacion-row td');
                cells.forEach(cell => {
                    if (cell.hasAttribute('data-original-text')) {
                        cell.innerHTML = cell.getAttribute('data-original-text');
                    }
                });
            }
        }

        autoHideAlerts() {
            const alerts = document.querySelectorAll('.auto-hide-alert');
            
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transition = 'opacity 0.5s ease';
                    
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 500);
                }, 3000);
            });
        }

        refresh() {
            this.allItems = Array.from(document.querySelectorAll('#situacionesTableBody tr.situacion-row'));
            this.filterItems();
        }
    }

    // Instanciar paginación
    let pagination = null;
    
    // Inicializar todo cuando el DOM esté listo
    function inicializarTodo() {
        if (typeof PaginationSituaciones === 'function') {
            pagination = new PaginationSituaciones();
        }
        
        // Observar cambios en la tabla
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && pagination) {
                    setTimeout(() => {
                        pagination.refresh();
                    }, 200);
                }
            });
        });
        
        const tableBody = document.getElementById('situacionesTableBody');
        if (tableBody) {
            observer.observe(tableBody, { childList: true, subtree: true });
        }
    }

    // Esperar un poco para asegurar que todo esté cargado
    setTimeout(inicializarTodo, 100);

    console.log("=== SITUACIÓN LABORAL JS INICIALIZADO CORRECTAMENTE ===");
});
</script>

<!-- Estilos adicionales para tooltips y búsqueda -->
<style>
.custom-tooltip {
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 8px 12px;
    border-radius: 4px;
    z-index: 1000;
    font-size: 12px;
    max-width: 300px;
    white-space: pre-line;
    pointer-events: none;
}

.actividad-asignada {
    cursor: help;
}

.highlight {
    background-color: #ffeb3b;
    padding: 2px 0;
    border-radius: 3px;
    font-weight: bold;
    color: #000;
}

/* Estilos para indicadores visuales de tipo de búsqueda */
.search-input.dni-search {
    border-color: #0d6efd !important;
    background-color: rgba(13, 110, 253, 0.05);
    box-shadow: 0 0 0 1px rgba(13, 110, 253, 0.1);
}

.search-input.text-search {
    border-color: #198754 !important;
    background-color: rgba(25, 135, 84, 0.05);
    box-shadow: 0 0 0 1px rgba(25, 135, 84, 0.1);
}

.search-input::placeholder {
    color: #6c757d;
    font-size: 0.9em;
    transition: color 0.3s ease;
}

.search-input.dni-search::placeholder {
    color: #0d6efd;
    font-weight: 500;
}

.search-input.text-search::placeholder {
    color: #198754;
    font-weight: 500;
}
</style>