<div class="container-fluid px-4">
    <h1 class="mt-4">Historial Laboral de Egresados</h1>

    <!-- Mensajes -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['warning'])): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['warning']; unset($_SESSION['warning']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Tarjeta simple -->
    <div class="row">
        <div class="col-md-12">
            <div class="admin-card bg-primary text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Total de Historiales Registrados</h5>
                            <h2 class="mt-2"><?php echo count($historiales); ?></h2>
                        </div>
                        <i class="fas fa-history fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Barra de búsqueda -->
    <div class="admin-card mb-4">
        <div class="card-header admin-card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <i class="fas fa-search me-1"></i>
                    Buscar Historial Laboral
                </div>
                <a href="?page=historial" class="admin-btn admin-btn-secondary">
                    <i class="fas fa-redo me-1"></i> Mostrar Todos
                </a>
            </div>
        </div>
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <input type="hidden" name="page" value="historial">
                <div class="col-md-3">
                    <select name="criterio" class="admin-form-input">
                        <option value="todas" <?php echo ($criterio == 'todas') ? 'selected' : ''; ?>>Todos los campos</option>
                        <option value="tiempo_primer_empleo" <?php echo ($criterio == 'tiempo_primer_empleo') ? 'selected' : ''; ?>>Tiempo primer empleo</option>
                        <option value="razon_desempleo" <?php echo ($criterio == 'razon_desempleo') ? 'selected' : ''; ?>>Razón desempleo</option>
                        <option value="fecha_inicio" <?php echo ($criterio == 'fecha_inicio') ? 'selected' : ''; ?>>Fecha inicio</option>
                    </select>
                </div>
                <div class="col-md-7">
                    <input type="text" name="busqueda" class="admin-form-input" placeholder="Buscar..." value="<?php echo htmlspecialchars($busqueda); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="admin-btn admin-btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Buscar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Botón agregar -->
    <div class="mb-3">
        <button type="button" class="admin-btn admin-btn-primary" onclick="openModal('agregarModal')">
            <i class="fas fa-plus me-1"></i> Nuevo Historial
        </button>
        
        <?php if (isset($historial_editar) && $historial_editar): ?>
        <button type="button" class="admin-btn admin-btn-warning" onclick="openModal('editarModal')">
            <i class="fas fa-edit me-1"></i> Editar Historial #<?php echo $historial_editar->id; ?>
        </button>
        <?php endif; ?>
    </div>

    <!-- Tabla principal -->
    <div class="admin-card mb-4">
        <div class="card-header admin-card-header">
            <i class="fas fa-table me-1"></i>
            Registros de Historial Laboral (<?php echo count($historiales); ?> registros)
        </div>
        <div class="card-body">
            <?php if (count($historiales) > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover admin-table">
                    <thead class="admin-table-header">
                        <tr>
                            <th>ID</th>
                            <th>Situación</th>
                            <th>Tiempo para Primer Empleo</th>
                            <th>Razón de Desempleo</th>
                            <th>Fecha Inicio</th>
                            <th>Fecha Fin</th>
                            <th>Fecha Registro</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($historiales as $historial): 
                            // Determinar color para tiempo
                            $tiempo_color = 'secondary';
                            if (strpos($historial->tiempo_primer_empleo, 'Menos') !== false) {
                                $tiempo_color = 'success';
                            } elseif (strpos($historial->tiempo_primer_empleo, '1-3') !== false) {
                                $tiempo_color = 'info';
                            } elseif (strpos($historial->tiempo_primer_empleo, '3-6') !== false) {
                                $tiempo_color = 'warning';
                            } elseif (strpos($historial->tiempo_primer_empleo, '6-12') !== false) {
                                $tiempo_color = 'warning';
                            } elseif (strpos($historial->tiempo_primer_empleo, 'Más') !== false) {
                                $tiempo_color = 'danger';
                            } elseif (strpos($historial->tiempo_primer_empleo, 'Aún') !== false) {
                                $tiempo_color = 'danger';
                            }
                        ?>
                        <tr>
                            <td><?php echo $historial->id; ?></td>
                            <td>
                                <span class="admin-badge bg-info">
                                    Situación #<?php echo $historial->situacion; ?>
                                </span>
                            </td>
                            <td>
                                <span class="admin-badge bg-<?php echo $tiempo_color; ?>">
                                    <?php echo $historial->tiempo_primer_empleo; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($historial->razon_desempleo): ?>
                                    <span class="admin-badge bg-warning">
                                        <?php echo $historial->razon_desempleo; ?>
                                    </span>
                                <?php else: ?>
                                    <span class="admin-badge bg-secondary">No aplica</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d/m/Y', strtotime($historial->fecha_inicio)); ?></td>
                            <td>
                                <?php if ($historial->fecha_fin): ?>
                                    <?php echo date('d/m/Y', strtotime($historial->fecha_fin)); ?>
                                <?php else: ?>
                                    <span class="admin-badge bg-success">Actual</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d/m/Y H:i', strtotime($historial->fecha_registro)); ?></td>
                            <td>
                                <div class="admin-btn-group">
                                    <a href="?page=historial&editar=<?php echo $historial->id; ?><?php echo !empty($busqueda) ? '&busqueda=' . urlencode($busqueda) . '&criterio=' . urlencode($criterio) : ''; ?>" 
                                       class="admin-btn admin-btn-warning" title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?page=historial&ver=<?php echo $historial->id; ?><?php echo !empty($busqueda) ? '&busqueda=' . urlencode($busqueda) . '&criterio=' . urlencode($criterio) : ''; ?>" 
                                       class="admin-btn admin-btn-info" title="Ver detalles">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="?page=historial&eliminar=<?php echo $historial->id; ?><?php echo !empty($busqueda) ? '&busqueda=' . urlencode($busqueda) . '&criterio=' . urlencode($criterio) : ''; ?>" 
                                       class="admin-btn admin-btn-danger"
                                       onclick="return confirm('¿Está seguro de eliminar este historial?')"
                                       title="Eliminar">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="admin-empty-state text-center py-5">
                <i class="fas fa-info-circle fa-3x mb-3 text-muted"></i>
                <h4 class="text-muted">No hay registros de historial laboral</h4>
                <p class="text-muted mb-0">Comience agregando un nuevo historial laboral.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal para agregar -->
<div id="agregarModal" class="admin-modal">
    <div class="admin-modal-dialog">
        <div class="admin-modal-content">
            <form method="POST" action="">
                <div class="admin-modal-header">
                    <h5 class="admin-modal-title">
                        <i class="fas fa-plus-circle me-2"></i> Nuevo Historial Laboral
                    </h5>
                    <button type="button" class="admin-modal-close" onclick="closeModal('agregarModal')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="admin-modal-body">
                    <?php if (empty($situaciones)): ?>
                    <div class="admin-alert admin-alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Error:</strong> No hay situaciones laborales registradas. 
                        Debes crear situaciones laborales primero antes de agregar historiales.
                    </div>
                    <?php else: ?>
                    <div class="admin-form-grid">
                        <div class="admin-form-group">
                            <label for="situacion" class="admin-form-label">Situación Laboral *</label>
                            <select class="admin-form-input" id="situacion" name="situacion" required>
                                <option value="">Seleccionar situación...</option>
                                <?php foreach($situaciones as $situacion): ?>
                                    <option value="<?php echo $situacion->id; ?>">
                                        Situación #<?php echo $situacion->id; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="tiempo_primer_empleo" class="admin-form-label">Tiempo para Primer Empleo *</label>
                            <select class="admin-form-input" id="tiempo_primer_empleo" name="tiempo_primer_empleo" required>
                                <option value="">Seleccionar tiempo...</option>
                                <option value="Menos de 1 mes">Menos de 1 mes</option>
                                <option value="1-3 meses">1-3 meses</option>
                                <option value="3-6 meses">3-6 meses</option>
                                <option value="6-12 meses">6-12 meses</option>
                                <option value="Más de 1 año">Más de 1 año</option>
                                <option value="Aún no consigue empleo">Aún no consigue empleo</option>
                            </select>
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="razon_desempleo" class="admin-form-label">Razón de Desempleo (si aplica)</label>
                            <select class="admin-form-input" id="razon_desempleo" name="razon_desempleo">
                                <option value="">Seleccionar razón...</option>
                                <option value="No hay ofertas en mi área">No hay ofertas en mi área</option>
                                <option value="Falta de experiencia">Falta de experiencia</option>
                                <option value="Salario muy bajo">Salario muy bajo</option>
                                <option value="Continúo estudiando">Continúo estudiando</option>
                                <option value="Embarazo/maternidad">Embarazo/maternidad</option>
                                <option value="Problemas de salud">Problemas de salud</option>
                                <option value="Responsabilidades familiares">Responsabilidades familiares</option>
                                <option value="No busca empleo actualmente">No busca empleo actualmente</option>
                                <option value="Otra">Otra razón</option>
                            </select>
                        </div>
                        
                        <div class="admin-form-group" id="otra_razon_container" style="display:none;">
                            <label for="otra_razon" class="admin-form-label">Especificar otra razón</label>
                            <input type="text" class="admin-form-input" id="otra_razon" name="otra_razon">
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="fecha_inicio" class="admin-form-label">Fecha Inicio *</label>
                            <input type="date" class="admin-form-input" id="fecha_inicio" name="fecha_inicio" required 
                                   max="<?php echo date('Y-m-d'); ?>">
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="fecha_fin" class="admin-form-label">Fecha Fin (opcional)</label>
                            <input type="date" class="admin-form-input" id="fecha_fin" name="fecha_fin"
                                   max="<?php echo date('Y-m-d'); ?>">
                            <div class="admin-form-text">Dejar vacío si sigue trabajando actualmente</div>
                        </div>
                    </div>
                    
                    <div class="admin-alert admin-alert-info mt-3">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Nota:</strong> Este historial nos ayuda a entender las trayectorias laborales de nuestros egresados.
                    </div>
                    <?php endif; ?>
                </div>
                <div class="admin-modal-footer">
                    <button type="button" class="admin-btn admin-btn-secondary" onclick="closeModal('agregarModal')">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </button>
                    <?php if (!empty($situaciones)): ?>
                    <button type="submit" name="agregar_historial" class="admin-btn admin-btn-primary">
                        <i class="fas fa-save me-1"></i> Guardar Historial
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para editar -->
<?php if (isset($historial_editar) && $historial_editar): ?>
<div id="editarModal" class="admin-modal <?php echo ($historial_editar) ? 'show' : ''; ?>">
    <div class="admin-modal-dialog">
        <div class="admin-modal-content">
            <form method="POST" action="">
                <input type="hidden" name="id" value="<?php echo $historial_editar->id; ?>">
                <div class="admin-modal-header">
                    <h5 class="admin-modal-title">
                        <i class="fas fa-edit me-2"></i> Editar Historial #<?php echo $historial_editar->id; ?>
                    </h5>
                    <button type="button" class="admin-modal-close" onclick="closeModal('editarModal')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="admin-modal-body">
                    <?php if (empty($situaciones)): ?>
                    <div class="admin-alert admin-alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Error:</strong> No hay situaciones laborales registradas.
                    </div>
                    <?php else: ?>
                    <div class="admin-form-grid">
                        <div class="admin-form-group">
                            <label for="edit_situacion" class="admin-form-label">Situación Laboral *</label>
                            <select class="admin-form-input" id="edit_situacion" name="situacion" required>
                                <option value="">Seleccionar situación...</option>
                                <?php foreach($situaciones as $situacion): ?>
                                    <option value="<?php echo $situacion->id; ?>" 
                                        <?php echo ($historial_editar->situacion == $situacion->id) ? 'selected' : ''; ?>>
                                        Situación #<?php echo $situacion->id; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="edit_tiempo_primer_empleo" class="admin-form-label">Tiempo para Primer Empleo *</label>
                            <select class="admin-form-input" id="edit_tiempo_primer_empleo" name="tiempo_primer_empleo" required>
                                <option value="">Seleccionar tiempo...</option>
                                <option value="Menos de 1 mes" <?php echo ($historial_editar->tiempo_primer_empleo == 'Menos de 1 mes') ? 'selected' : ''; ?>>Menos de 1 mes</option>
                                <option value="1-3 meses" <?php echo ($historial_editar->tiempo_primer_empleo == '1-3 meses') ? 'selected' : ''; ?>>1-3 meses</option>
                                <option value="3-6 meses" <?php echo ($historial_editar->tiempo_primer_empleo == '3-6 meses') ? 'selected' : ''; ?>>3-6 meses</option>
                                <option value="6-12 meses" <?php echo ($historial_editar->tiempo_primer_empleo == '6-12 meses') ? 'selected' : ''; ?>>6-12 meses</option>
                                <option value="Más de 1 año" <?php echo ($historial_editar->tiempo_primer_empleo == 'Más de 1 año') ? 'selected' : ''; ?>>Más de 1 año</option>
                                <option value="Aún no consigue empleo" <?php echo ($historial_editar->tiempo_primer_empleo == 'Aún no consigue empleo') ? 'selected' : ''; ?>>Aún no consigue empleo</option>
                            </select>
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="edit_razon_desempleo" class="admin-form-label">Razón de Desempleo</label>
                            <select class="admin-form-input" id="edit_razon_desempleo" name="razon_desempleo">
                                <option value="">Seleccionar razón...</option>
                                <?php 
                                $razones_predeterminadas = [
                                    'No hay ofertas en mi área',
                                    'Falta de experiencia',
                                    'Salario muy bajo',
                                    'Continúo estudiando',
                                    'Embarazo/maternidad',
                                    'Problemas de salud',
                                    'Responsabilidades familiares',
                                    'No busca empleo actualmente'
                                ];
                                
                                $es_otra_razon = $historial_editar->razon_desempleo && !in_array($historial_editar->razon_desempleo, $razones_predeterminadas);
                                ?>
                                <option value="No hay ofertas en mi área" <?php echo ($historial_editar->razon_desempleo == 'No hay ofertas en mi área') ? 'selected' : ''; ?>>No hay ofertas en mi área</option>
                                <option value="Falta de experiencia" <?php echo ($historial_editar->razon_desempleo == 'Falta de experiencia') ? 'selected' : ''; ?>>Falta de experiencia</option>
                                <option value="Salario muy bajo" <?php echo ($historial_editar->razon_desempleo == 'Salario muy bajo') ? 'selected' : ''; ?>>Salario muy bajo</option>
                                <option value="Continúo estudiando" <?php echo ($historial_editar->razon_desempleo == 'Continúo estudiando') ? 'selected' : ''; ?>>Continúo estudiando</option>
                                <option value="Embarazo/maternidad" <?php echo ($historial_editar->razon_desempleo == 'Embarazo/maternidad') ? 'selected' : ''; ?>>Embarazo/maternidad</option>
                                <option value="Problemas de salud" <?php echo ($historial_editar->razon_desempleo == 'Problemas de salud') ? 'selected' : ''; ?>>Problemas de salud</option>
                                <option value="Responsabilidades familiares" <?php echo ($historial_editar->razon_desempleo == 'Responsabilidades familiares') ? 'selected' : ''; ?>>Responsabilidades familiares</option>
                                <option value="No busca empleo actualmente" <?php echo ($historial_editar->razon_desempleo == 'No busca empleo actualmente') ? 'selected' : ''; ?>>No busca empleo actualmente</option>
                                <option value="Otra" <?php echo $es_otra_razon ? 'selected' : ''; ?>>Otra razón</option>
                            </select>
                        </div>
                        
                        <div class="admin-form-group" id="edit_otra_razon_container" style="<?php echo $es_otra_razon ? 'display:block;' : 'display:none;'; ?>">
                            <label for="edit_otra_razon" class="admin-form-label">Especificar otra razón</label>
                            <input type="text" class="admin-form-input" id="edit_otra_razon" name="otra_razon" 
                                   value="<?php echo $es_otra_razon ? htmlspecialchars($historial_editar->razon_desempleo) : ''; ?>">
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="edit_fecha_inicio" class="admin-form-label">Fecha Inicio *</label>
                            <input type="date" class="admin-form-input" id="edit_fecha_inicio" name="fecha_inicio" 
                                   value="<?php echo $historial_editar->fecha_inicio; ?>" required 
                                   max="<?php echo date('Y-m-d'); ?>">
                        </div>
                        
                        <div class="admin-form-group">
                            <label for="edit_fecha_fin" class="admin-form-label">Fecha Fin</label>
                            <input type="date" class="admin-form-input" id="edit_fecha_fin" name="fecha_fin"
                                   value="<?php echo $historial_editar->fecha_fin; ?>" 
                                   max="<?php echo date('Y-m-d'); ?>">
                            <div class="admin-form-text">Dejar vacío si sigue trabajando actualmente</div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="admin-modal-footer">
                    <button type="button" class="admin-btn admin-btn-secondary" onclick="closeModal('editarModal')">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </button>
                    <?php if (!empty($situaciones)): ?>
                    <button type="submit" name="actualizar_historial" class="admin-btn admin-btn-warning">
                        <i class="fas fa-sync-alt me-1"></i> Actualizar
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Modal para ver detalles -->
<?php if (isset($historial_detalle) && $historial_detalle): ?>
<div id="detalleModal" class="admin-modal <?php echo ($historial_detalle) ? 'show' : ''; ?>">
    <div class="admin-modal-dialog">
        <div class="admin-modal-content">
            <div class="admin-modal-header">
                <h5 class="admin-modal-title">
                    <i class="fas fa-eye me-2"></i> Detalles del Historial #<?php echo $historial_detalle->id; ?>
                </h5>
                <button type="button" class="admin-modal-close" onclick="closeModal('detalleModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="admin-modal-body">
                <div class="admin-detail-grid">
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">ID:</div>
                        <div class="admin-detail-value"><?php echo $historial_detalle->id; ?></div>
                    </div>
                    
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">Situación:</div>
                        <div class="admin-detail-value">
                            <span class="admin-badge bg-info">
                                Situación #<?php echo $historial_detalle->situacion; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">Tiempo primer empleo:</div>
                        <div class="admin-detail-value">
                            <?php
                            $tiempo_color = 'primary';
                            if (strpos($historial_detalle->tiempo_primer_empleo, 'Menos') !== false) {
                                $tiempo_color = 'success';
                            } elseif (strpos($historial_detalle->tiempo_primer_empleo, '1-3') !== false) {
                                $tiempo_color = 'info';
                            } elseif (strpos($historial_detalle->tiempo_primer_empleo, '3-6') !== false) {
                                $tiempo_color = 'warning';
                            } elseif (strpos($historial_detalle->tiempo_primer_empleo, '6-12') !== false) {
                                $tiempo_color = 'warning';
                            } elseif (strpos($historial_detalle->tiempo_primer_empleo, 'Más') !== false) {
                                $tiempo_color = 'danger';
                            } elseif (strpos($historial_detalle->tiempo_primer_empleo, 'Aún') !== false) {
                                $tiempo_color = 'danger';
                            }
                            ?>
                            <span class="admin-badge bg-<?php echo $tiempo_color; ?>">
                                <?php echo $historial_detalle->tiempo_primer_empleo; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">Razón desempleo:</div>
                        <div class="admin-detail-value">
                            <?php if ($historial_detalle->razon_desempleo): ?>
                                <span class="admin-badge bg-warning">
                                    <?php echo $historial_detalle->razon_desempleo; ?>
                                </span>
                            <?php else: ?>
                                <span class="admin-badge bg-secondary">No aplica</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">Fecha inicio:</div>
                        <div class="admin-detail-value"><?php echo date('d/m/Y', strtotime($historial_detalle->fecha_inicio)); ?></div>
                    </div>
                    
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">Fecha fin:</div>
                        <div class="admin-detail-value">
                            <?php if ($historial_detalle->fecha_fin): ?>
                                <?php echo date('d/m/Y', strtotime($historial_detalle->fecha_fin)); ?>
                            <?php else: ?>
                                <span class="admin-badge bg-success">Actualmente trabajando</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="admin-detail-group">
                        <div class="admin-detail-label">Fecha registro:</div>
                        <div class="admin-detail-value"><?php echo date('d/m/Y H:i:s', strtotime($historial_detalle->fecha_registro)); ?></div>
                    </div>
                </div>
            </div>
            <div class="admin-modal-footer">
                <button type="button" class="admin-btn admin-btn-secondary" onclick="closeModal('detalleModal')">
                    <i class="fas fa-times me-1"></i> Cerrar
                </button>
                <a href="?page=historial&editar=<?php echo $historial_detalle->id; ?><?php echo !empty($busqueda) ? '&busqueda=' . urlencode($busqueda) . '&criterio=' . urlencode($criterio) : ''; ?>" class="admin-btn admin-btn-warning">
                    <i class="fas fa-edit me-1"></i> Editar
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Funciones para abrir/cerrar modales
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

// Mostrar campo para otra razón
document.getElementById('razon_desempleo')?.addEventListener('change', function() {
    const otraContainer = document.getElementById('otra_razon_container');
    if (this.value === 'Otra') {
        otraContainer.style.display = 'block';
        document.getElementById('otra_razon').required = true;
    } else {
        otraContainer.style.display = 'none';
        document.getElementById('otra_razon').required = false;
        document.getElementById('otra_razon').value = '';
    }
});

// Para el formulario de edición
document.getElementById('edit_razon_desempleo')?.addEventListener('change', function() {
    const otraContainer = document.getElementById('edit_otra_razon_container');
    if (this.value === 'Otra') {
        otraContainer.style.display = 'block';
        document.getElementById('edit_otra_razon').required = true;
    } else {
        otraContainer.style.display = 'none';
        document.getElementById('edit_otra_razon').required = false;
    }
});

// Cerrar modal al hacer clic fuera
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('admin-modal')) {
        closeModal(event.target.id);
    }
});

// Cerrar con tecla Escape
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modals = document.querySelectorAll('.admin-modal.show');
        modals.forEach(modal => {
            closeModal(modal.id);
        });
    }
});

// Si hay un modal de edición o detalles activo, abrirlo automáticamente
document.addEventListener('DOMContentLoaded', function() {
    <?php if (isset($historial_editar) && $historial_editar): ?>
    openModal('editarModal');
    <?php endif; ?>
    
    <?php if (isset($historial_detalle) && $historial_detalle): ?>
    openModal('detalleModal');
    <?php endif; ?>
    
    // Configurar campos de fecha con límite de hoy
    const fechaHoy = new Date().toISOString().split('T')[0];
    document.getElementById('fecha_inicio')?.setAttribute('max', fechaHoy);
    document.getElementById('fecha_fin')?.setAttribute('max', fechaHoy);
    document.getElementById('edit_fecha_inicio')?.setAttribute('max', fechaHoy);
    document.getElementById('edit_fecha_fin')?.setAttribute('max', fechaHoy);
});
</script>