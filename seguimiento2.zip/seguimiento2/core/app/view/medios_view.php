<div class="container-fluid mt-4 px-4">
    <div class="admin-content-header">
        <div class="admin-header-title py-4">
            <h1 class="display-6 fw-bold">Reporte General del Sistema</h1>
            <p class="lead mb-0">Generar reportes </p>
        </div>
    </div>
    <br>

    <!-- Formulario para agregar medio -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Agregar Nuevo Medio</h5>
        </div>
        <div class="card-body">
            <form method="POST" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="nombre_medio" class="form-control" 
                           placeholder="Ej: Bolsa de trabajo del instituto" required>
                </div>
                <div class="col-md-4">
                    <button type="submit" name="agregar_medio" class="btn btn-success w-100">
                        Agregar Medio
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Lista de medios -->
    <div class="card">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">Medios de Consecución Registrados</h5>
        </div>
        <div class="card-body">
            <?php if ($medios && count($medios) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Medio de Consecución</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($medios as $index => $medio): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($medio->nombre_medio) ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm">Editar</button>
                                        <button class="btn btn-danger btn-sm">Eliminar</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info text-center">
                    No hay medios de consecución registrados.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>