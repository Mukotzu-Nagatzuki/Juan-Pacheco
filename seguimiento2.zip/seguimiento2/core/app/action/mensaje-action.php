<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'correo/vendor/autoload.php';
require_once 'core/app/model/EgresadoData.php';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'giseniavalerocainicela@gmail.com';
    $mail->Password = 'woyuzpndyqshvkai';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('giseniavalerocainicela@gmail.com', 'Seguimiento');

    $egresados = EgresadoData::getAll();
    $correos_enviados = 0;
    $correos_lista = array();
    
    echo "<div style='font-family: Arial, sans-serif; padding: 15px; max-width: 800px; margin: 0 auto;'>";
    echo "<div style='background: linear-gradient(90deg, #0d47a1, #1976d2); padding: 15px; color: white;'>";
    echo "<h2 style='margin: 0;'>Envío de Correos a Egresados</h2>";
    echo "</div>";
    
    foreach ($egresados as $egresado) {
        if ($egresado->estado == 1) {
            $correo = '';
            $nombre_egresado = $egresado->nombre_est ?? 'Desconocido';
            $dni = $egresado->dni_est ?? 'N/A';
            
            if (!empty($egresado->mailp_est) && filter_var($egresado->mailp_est, FILTER_VALIDATE_EMAIL)) {
                $correo = trim($egresado->mailp_est);
                $tipo_correo = 'Personal';
            } elseif (!empty($egresado->maili_est) && filter_var($egresado->maili_est, FILTER_VALIDATE_EMAIL)) {
                $correo = trim($egresado->maili_est);
                $tipo_correo = 'Institucional';
            }
            
            if (!empty($correo)) {
                $mail->addBCC($correo);
                $correos_enviados++;
                
                $correos_lista[] = array(
                    'nombre' => $nombre_egresado,
                    'dni' => $dni,
                    'correo' => $correo,
                    'tipo' => $tipo_correo
                );
                
                echo "<div style='background: #f0f7ff; padding: 8px; margin: 3px 0; border-left: 3px solid #0d47a1;'>";
                echo "<strong># $correos_enviados</strong> - ";
                echo "<strong>$nombre_egresado</strong> (DNI: $dni)<br>";
                echo "Correo $tipo_correo: <strong>$correo</strong>";
                echo "</div>";
            } else {
                echo "<div style='background: #fff3e0; padding: 8px; margin: 3px 0; border-left: 3px solid #ff9800;'>";
                echo "<strong>Sin correo</strong> - ";
                echo "<strong>$nombre_egresado</strong> (DNI: $dni)";
                echo "</div>";
            }
        }
    }
    
    if ($correos_enviados == 0) {
        throw new Exception("No se encontraron egresados con correo válido.");
    }
    
    echo "<div style='background: #e8f5e9; padding: 10px; margin: 10px 0;'>";
    echo "<h3>Resumen de Destinatarios</h3>";
    echo "Egresados con estado = 1: " . count(array_filter($egresados, function($e) { return $e->estado == 1; })) . "<br>";
    echo "Correos válidos: <strong>$correos_enviados</strong>";
    echo "</div>";
    
    // Contenido del correo
    $mail->isHTML(true);
    $mail->Subject = 'Encuesta de IESTP Andres Avelino Cáceres Dorregaray';
    
    $mail->Body = '
    <div style="font-family: Arial, sans-serif; background:#f8f9fa;">
        <div style="max-width:600px; margin:0 auto; background:white; border-radius:5px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
            
            <!-- Encabezado -->
            <div style="background: linear-gradient(90deg, #0d47a1, #1976d2); padding:20px; color:white;">
                <div style="text-align:center;">
                    <div style="width: 80px; height: 80px; background: white; border-radius:50%; margin:0 auto 10px; padding:10px;">
                        <img src="https://institutoaacd.com/wp-content/uploads/2025/04/ANDRES-AVELINO-scaled.png" 
                             alt="Logo" 
                             style="width:100%; height:100%; object-fit:contain; display:block;">
                    </div>
                    <h2 style="margin:5px 0; font-size:22px;">Encuesta de Egresados</h2>
                    <p style="margin:0; font-size:14px;">IESTP Andrés Avelino Cáceres Dorregaray</p>
                </div>
            </div>
            
            <!-- Cuerpo -->
            <div style="padding:20px;">
                <p>Estimado(a) egresado(a),</p>
                
                <p>
                    Reciba un cordial saludo. Le invitamos atentamente a completar la siguiente 
                    <strong style="color:#0d47a1;">Encuesta de Egresados</strong>, con el propósito de mejorar nuestros servicios 
                    educativos y fortalecer el vínculo con nuestros estudiantes.
                </p>
                
                <div style="text-align:center; margin:20px 0;">
                    <a href="https://seguimiento.mallfers.com/encuesta.php" 
                       style="background: linear-gradient(90deg, #0d47a1, #1976d2); color:white; padding:12px 24px; 
                              border-radius:5px; text-decoration:none; font-weight:bold; display:inline-block;">
                        Completar encuesta
                    </a>
                </div>
                
                <p style="color:#666; font-size:14px;">
                    Su participación es muy valiosa para nosotros y solo le tomará unos minutos. 
                    ¡Gracias por contribuir al crecimiento institucional!
                </p>
            </div>
            
            <!-- Pie -->
            <div style="background:#f5f5f5; padding:10px; text-align:center; font-size:12px; color:#777;">
                © ' . date("Y") . ' IESTP Andrés Avelino Cáceres Dorregaray<br>
                Este es un mensaje automático, por favor no responder.
            </div>
            
        </div>
    </div>
    ';
    
    $mail->AltBody = "Encuesta de Egresados - IESTP Andrés Avelino Cáceres Dorregaray\n\nEstimado(a) egresado(a),\n\nLe invitamos a completar nuestra encuesta de egresados para mejorar nuestros servicios educativos.\n\nEnlace: https://seguimiento.mallfers.com/encuesta.php\n\n¡Gracias por su participación!\n\nIESTP Andrés Avelino Cáceres Dorregaray";
    
    echo "<div style='text-align:center; margin:15px 0;'>";
    echo "<div style='background: #0d47a1; color:white; padding:8px 16px; border-radius:3px; display:inline-block;'>";
    echo "<strong>Enviando correos...</strong>";
    echo "</div>";
    echo "</div>";
    
    $mail->send();
    
    echo "<div style='background: #e8f5e9; padding:15px; text-align:center;'>";
    echo "<h3>CORREOS ENVIADOS EXITOSAMENTE</h3>";
    echo "<p>Se enviaron correos a <strong>$correos_enviados</strong> egresados.</p>";
    echo "</div>";
    
    echo "<div style='background:#f9f9f9; padding:10px; margin:10px 0;'>";
    echo "<h4>Destinatarios:</h4>";
    echo "<div style='max-height:200px; overflow-y:auto;'>";
    echo "<table style='width:100%; border-collapse:collapse;'>";
    echo "<tr style='background:#0d47a1; color:white;'>";
    echo "<th style='padding:5px;'>#</th>";
    echo "<th style='padding:5px;'>Nombre</th>";
    echo "<th style='padding:5px;'>DNI</th>";
    echo "<th style='padding:5px;'>Correo</th>";
    echo "<th style='padding:5px;'>Tipo</th>";
    echo "</tr>";
    
    foreach ($correos_lista as $index => $destinatario) {
        $bg_color = $index % 2 == 0 ? '#fff' : '#f9f9f9';
        echo "<tr style='background:$bg_color;'>";
        echo "<td style='padding:5px; border-bottom:1px solid #ddd;'>" . ($index + 1) . "</td>";
        echo "<td style='padding:5px; border-bottom:1px solid #ddd;'>" . htmlspecialchars($destinatario['nombre']) . "</td>";
        echo "<td style='padding:5px; border-bottom:1px solid #ddd;'>" . $destinatario['dni'] . "</td>";
        echo "<td style='padding:5px; border-bottom:1px solid #ddd;'>" . htmlspecialchars($destinatario['correo']) . "</td>";
        echo "<td style='padding:5px; border-bottom:1px solid #ddd;'>" . $destinatario['tipo'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    echo "</div>";
    
    echo "<div style='text-align:center;'>";
    echo "<a href='javascript:history.back()' style='background:#0d47a1; color:white; padding:8px 16px; text-decoration:none; border-radius:3px; display:inline-block;'>Volver</a>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #ffebee; padding:15px; color:#c62828;'>";
    echo "<h3>Error al enviar correos</h3>";
    echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    if (isset($mail)) {
        echo "<p><strong>Detalles:</strong> " . htmlspecialchars($mail->ErrorInfo) . "</p>";
    }
    echo "<br><a href='javascript:history.back()' style='background:#c62828; color:white; padding:8px 16px; text-decoration:none; border-radius:3px;'>Volver</a>";
    echo "</div>";
}

echo "</div>";
?>