<?php
// core/app/action/send-encuesta-action.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar si hay una sesión de administrador
if (!isset($_SESSION['admin_id'])) {
    echo "Error: No autorizado. Inicie sesión como administrador.";
    exit();
}

// Incluir modelos necesarios
require_once __DIR__ . "/../model/EgresadoData.php";
require_once __DIR__ . "/../model/EstudianteData.php";

// Manejar diferentes acciones
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'send_encuesta_email') {
        $modo = $_POST['modo'] ?? '';
        
        if ($modo == 'todos') {
            // Enviar a todos los egresados
            $resultado = enviarEncuestaATodos();
            echo $resultado['message'];
        } elseif ($modo == 'especifico' && isset($_POST['dni_est'])) {
            // Enviar a un egresado específico
            $dni = $_POST['dni_est'];
            $resultado = enviarEncuestaAEgresado($dni);
            echo $resultado['message'];
        } else {
            echo "Error: Parámetros inválidos";
        }
        exit();
    }
    
    // Acción para el botón de envío masivo (antiguo)
    if ($action == 'send_mass_email') {
        $resultado = enviarEncuestaATodos();
        echo $resultado['message'];
        exit();
    }
}

// Función para enviar encuesta a todos los egresados
function enviarEncuestaATodos() {
    // Obtener todos los egresados
    $egresados = EgresadoData::getAll();
    
    if (empty($egresados)) {
        return ['success' => false, 'message' => 'No hay egresados registrados'];
    }
    
    $enviados = 0;
    $errores = 0;
    $total = 0;
    
    foreach ($egresados as $egresado) {
        // Solo procesar egresados activos y con correo
        if ($egresado->estado == 1 && !empty($egresado->mailp_est)) {
            $total++;
            $nombre_completo = trim($egresado->ap_est . ' ' . $egresado->am_est . ', ' . $egresado->nom_est);
            
            $result = enviarCorreoIndividual($egresado->mailp_est, $nombre_completo);
            if ($result['success']) {
                $enviados++;
            } else {
                $errores++;
                error_log("Error enviando a " . $egresado->mailp_est . ": " . $result['error']);
            }
            
            // Pequeña pausa para no saturar el servidor SMTP
            usleep(100000); // 0.1 segundo
        }
    }
    
    if ($total == 0) {
        return ['success' => false, 'message' => 'No hay egresados con correo electrónico registrado'];
    }
    
    return [
        'success' => true,
        'message' => "✅ Se enviaron $enviados correos de $total egresados. Errores: $errores"
    ];
}

// Función para enviar encuesta a un egresado específico
function enviarEncuestaAEgresado($dni) {
    $estudiante = EstudianteData::getByDni($dni);
    
    if (!$estudiante) {
        return ['success' => false, 'message' => '❌ Egresado no encontrado'];
    }
    
    if (empty($estudiante->mailp_est) && empty($estudiante->correo)) {
        return ['success' => false, 'message' => '❌ El egresado no tiene correo registrado'];
    }
    
    $correo = !empty($estudiante->mailp_est) ? $estudiante->mailp_est : $estudiante->correo;
    $nombre_completo = trim($estudiante->ap_est . ' ' . $estudiante->am_est . ', ' . $estudiante->nom_est);
    
    $result = enviarCorreoIndividual($correo, $nombre_completo);
    
    if ($result['success']) {
        return ['success' => true, 'message' => "✅ Correo enviado exitosamente a $nombre_completo"];
    } else {
        return ['success' => false, 'message' => "❌ Error: " . $result['error']];
    }
}

// Función para enviar correo individual
function enviarCorreoIndividual($correoDestino, $nombreEstudiante) {
    // RUTA CORREGIDA según tu estructura: desde core/app/action hasta core/vendor
    $vendorPath = __DIR__ . '/../../../vendor/autoload.php';
    
    if (!file_exists($vendorPath)) {
        return ['success' => false, 'error' => 'No se encontró PHPMailer. Verifique la ruta: ' . $vendorPath];
    }
    
    require $vendorPath;
    
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer(true);

    try {
        // Configuración SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'giseniavalerocainicela@gmail.com';
        $mail->Password = 'woyu zpnd yqsh vkai';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';
        $mail->SMTPDebug = 0; // Cambiar a 2 para debug

        // Remitente y destinatario
        $mail->setFrom('giseniavalerocainicela@gmail.com', 'Seguimiento de Egresados - IESTP');
        $mail->addAddress($correoDestino, $nombreEstudiante);

        // Contenido del mensaje
        $mail->isHTML(true);
        $mail->Subject = 'Encuesta de Egresados - IESTP Andres Avelino Cáceres Dorregaray';

        $mail->Body = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; background-color:#f4f4f4; padding: 20px; margin:0;">
            <div style="max-width:600px; margin:0 auto; background:white; border-radius:12px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,0.1);">

                <!-- Encabezado -->
                <div style="background:#1a73e8; padding:20px; text-align:center; color:white;">
                    <h2 style="margin:0; font-size:24px;">Encuesta de Egresados</h2>
                    <p style="margin:5px 0 0; font-size:14px;">IESTP Andrés Avelino Cáceres Dorregaray</p>
                </div>

                <!-- Cuerpo -->
                <div style="padding: 30px; color:#333; font-size:16px; line-height:1.6;">
                    <p>Estimado(a) <strong>' . htmlspecialchars($nombreEstudiante) . '</strong>,</p>

                    <p>
                        Reciba un cordial saludo. Le invitamos atentamente a completar la siguiente 
                        <strong>Encuesta de Egresados</strong>, con el propósito de mejorar nuestros servicios 
                        educativos y fortalecer el vínculo con nuestros estudiantes.
                    </p>

                    <div style="text-align:center; margin:30px 0;">
                        <a href="https://seguimiento.mallfers.com/encuesta.php" 
                           style="
                               display:inline-block;
                               background:#1a73e8;
                               color:white;
                               padding:14px 26px;
                               border-radius:8px;
                               text-decoration:none;
                               font-size:18px;
                               font-weight:bold;
                               box-shadow:0 3px 6px rgba(0,0,0,0.2);
                               transition:0.3s;
                           "
                           onmouseover="this.style.backgroundColor=\'#0d5bb5\'; this.style.boxShadow=\'0 5px 10px rgba(0,0,0,0.3)\';"
                           onmouseout="this.style.backgroundColor=\'#1a73e8\'; this.style.boxShadow=\'0 3px 6px rgba(0,0,0,0.2)\';">
                            📋 Completar encuesta
                        </a>
                    </div>

                    <p style="font-size:14px; color:#555;">
                        <strong>Importante:</strong> Su participación es muy valiosa para nosotros y solo le tomará unos minutos.
                        ¡Gracias por contribuir al crecimiento institucional!
                    </p>
                    
                    <div style="background:#f8f9fa; border-left:4px solid #1a73e8; padding:12px; margin-top:20px;">
                        <p style="margin:0; font-size:13px; color:#666;">
                            <strong>Enlace directo:</strong> https://seguimiento.mallfers.com/encuesta.php
                        </p>
                    </div>
                </div>

                <!-- Pie -->
                <div style="background:#f0f0f0; padding:15px; text-align:center; font-size:13px; color:#666;">
                    © ' . date("Y") . ' IESTP Andrés Avelino Cáceres Dorregaray<br>
                    <small>Este es un mensaje automático, por favor no responder.</small>
                </div>

            </div>
        </body>
        </html>
        ';
        
        // También agregar versión de texto plano
        $mail->AltBody = "Estimado(a) $nombreEstudiante,\n\nLe invitamos a completar la Encuesta de Egresados del IESTP Andrés Avelino Cáceres Dorregaray.\n\nEnlace: https://seguimiento.mallfers.com/encuesta.php\n\nGracias por su participación.";

        // Enviar el correo
        if ($mail->send()) {
            return ['success' => true, 'message' => 'Correo enviado exitosamente'];
        } else {
            return ['success' => false, 'error' => 'No se pudo enviar el mensaje.'];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error PHPMailer: ' . $mail->ErrorInfo];
    }
}

// Obtener lista de egresados en JSON (para el select)
if (isset($_GET['action']) && $_GET['action'] == 'get_egresados_json') {
    header('Content-Type: application/json');
    
    try {
        $egresados = EgresadoData::getAll();
        
        $lista_egresados = [];
        foreach ($egresados as $egresado) {
            if ($egresado->estado == 1) { // Solo egresados
                $lista_egresados[] = [
                    'dni_est' => $egresado->dni_est,
                    'nombre_completo' => trim($egresado->ap_est . ' ' . $egresado->am_est . ', ' . $egresado->nom_est),
                    'mailp_est' => $egresado->mailp_est
                ];
            }
        }
        
        echo json_encode([
            'success' => true,
            'egresados' => $lista_egresados,
            'total' => count($lista_egresados)
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error al cargar egresados: ' . $e->getMessage()
        ]);
    }
    exit();
}

// Si se accede directamente sin parámetros
echo "Acceso no autorizado";
?>