<?php
require_once "core/app/model/MedioConsecucionData.php";

// Procesar formularios
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['agregar_medio'])) {
        $medio = new MedioConsecucionData();
        $medio->nombre_medio = trim($_POST['nombre_medio']);
        $result = $medio->add();
        
        if ($result[0]) {
            $_SESSION['message'] = "Medio de consecución agregado correctamente";
        } else {
            $_SESSION['error'] = "Error al agregar: " . $result[1];
        }
    }
}

// Obtener todos los medios
$medios = MedioConsecucionData::getAll();

ob_start();
include(__DIR__ . "/../view/medios_view.php");
$content = ob_get_clean();
include(__DIR__ . "/../layouts/layout.php");
?>