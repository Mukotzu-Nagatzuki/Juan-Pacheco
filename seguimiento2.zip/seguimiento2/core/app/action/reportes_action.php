<?php
require_once "core/app/model/ReportesModel.php";

class ReportesController {
    private $model;
    private $db;

    public function __construct($database) {
        $this->db = $database;
        $this->model = new ReportesModel($database);
    }

    public function index() {
        // Obtener datos para filtros
        $programas = $this->model->getProgramasEstudios();
        $empresas = $this->model->getEmpresas();
        $tipos_seguimiento = $this->model->getTiposSeguimiento();
        $condiciones_laborales = $this->model->getCondicionesLaborales();
        $sectores = $this->model->getSectoresEmpresas();

        // Determinar qué reporte mostrar
        $tipo_reporte = $_GET['tipo'] ?? 'situacion_laboral';

        // Procesar filtros
        $filtros = $this->getFiltros();

        // Obtener datos del reporte seleccionado
        $datos_reporte = [];
        $titulo_reporte = '';

        switch ($tipo_reporte) {
            case 'situacion_laboral':
                $datos_reporte = $this->model->getSituacionLaboralCompleta($filtros);
                $titulo_reporte = 'Situación Laboral de Egresados';
                break;
            case 'seguimiento':
                $datos_reporte = $this->model->getSeguimientoEgresados($filtros);
                $titulo_reporte = 'Seguimiento de Egresados';
                break;
            case 'historial_laboral':
                $datos_reporte = $this->model->getHistorialLaboralDetallado($filtros);
                $titulo_reporte = 'Historial Laboral Detallado';
                break;
            case 'estadisticas':
                $datos_reporte = $this->model->getEstadisticasEmpleabilidad($filtros);
                $titulo_reporte = 'Estadísticas de Empleabilidad';
                break;
            case 'empleados':
                $datos_reporte = $this->model->getEmpleadosSeguimiento($filtros);
                $titulo_reporte = 'Empleados y Seguimiento';
                break;
            case 'empresas':
                $datos_reporte = $this->model->getEmpresasContratantes($filtros);
                $titulo_reporte = 'Empresas Contratantes';
                break;
        }

        // Cargar vista
        require 'views/reportes/index.php';
    }

    public function exportar() {
        $tipo_reporte = $_GET['tipo'] ?? 'situacion_laboral';
        $formato = $_GET['formato'] ?? 'excel';

        $filtros = $this->getFiltros();

        // Obtener datos
        switch ($tipo_reporte) {
            case 'situacion_laboral':
                $datos = $this->model->getSituacionLaboralCompleta($filtros);
                $titulo = 'Situacion_Laboral_Egresados';
                break;
            case 'seguimiento':
                $datos = $this->model->getSeguimientoEgresados($filtros);
                $titulo = 'Seguimiento_Egresados';
                break;
            case 'historial_laboral':
                $datos = $this->model->getHistorialLaboralDetallado($filtros);
                $titulo = 'Historial_Laboral';
                break;
            case 'estadisticas':
                $datos = $this->model->getEstadisticasEmpleabilidad($filtros);
                $titulo = 'Estadisticas_Empleabilidad';
                break;
            case 'empleados':
                $datos = $this->model->getEmpleadosSeguimiento($filtros);
                $titulo = 'Empleados_Seguimiento';
                break;
            case 'empresas':
                $datos = $this->model->getEmpresasContratantes($filtros);
                $titulo = 'Empresas_Contratantes';
                break;
        }

        // Exportar según formato
        if ($formato === 'excel') {
            $this->exportarExcel($datos, $titulo);
        } else {
            $this->exportarPDF($datos, $titulo);
        }
    }

    private function getFiltros() {
        $filtros = [];
        
        if (!empty($_GET['programa_estudio'])) {
            $filtros['programa_estudio'] = $_GET['programa_estudio'];
        }
        if (!empty($_GET['empresa'])) {
            $filtros['empresa'] = $_GET['empresa'];
        }
        if (!empty($_GET['tipo_seguimiento'])) {
            $filtros['tipo_seguimiento'] = $_GET['tipo_seguimiento'];
        }
        if (!empty($_GET['condicion_laboral'])) {
            $filtros['condicion_laboral'] = $_GET['condicion_laboral'];
        }
        if (!empty($_GET['trabaja'])) {
            $filtros['trabaja'] = $_GET['trabaja'];
        }
        if (!empty($_GET['sector'])) {
            $filtros['sector'] = $_GET['sector'];
        }
        if (!empty($_GET['fecha_desde'])) {
            $filtros['fecha_desde'] = $_GET['fecha_desde'];
        }
        if (!empty($_GET['fecha_hasta'])) {
            $filtros['fecha_hasta'] = $_GET['fecha_hasta'];
        }

        return $filtros;
    }

    private function exportarExcel($datos, $titulo) {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $titulo . '_' . date('Y-m-d') . '.xls"');
        header('Cache-Control: max-age=0');

        echo '<table border="1">';
        if (!empty($datos)) {
            // Encabezados
            echo '<tr>';
            foreach (array_keys((array)$datos[0]) as $columna) {
                echo '<th>' . ucfirst(str_replace('_', ' ', $columna)) . '</th>';
            }
            echo '</tr>';

            // Datos
            foreach ($datos as $fila) {
                echo '<tr>';
                foreach ($fila as $valor) {
                    echo '<td>' . $valor . '</td>';
                }
                echo '</tr>';
            }
        }
        echo '</table>';
        exit;
    }

    private function exportarPDF($datos, $titulo) {
        // Aquí implementarías la generación de PDF
        // Por simplicidad, redirigimos a Excel
        $this->exportarExcel($datos, $titulo);
    }
}
?>