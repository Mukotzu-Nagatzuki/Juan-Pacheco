<?php 
// core/app/action/encuesta-action.php

require_once "core/app/model/EncuestaData.php";
require_once "core/app/model/EgresadoData.php";
require_once "core/app/model/EmpresaData.php";
require_once "core/app/model/ActividadesData.php";

// ========== MANEJAR PETICIONES AJAX PARA VERIFICAR EMPRESA ==========
if (isset($_GET['check_empresa']) && isset($_GET['ruc'])) {
    header('Content-Type: application/json');
    $ruc = isset($_GET['ruc']) ? trim($_GET['ruc']) : '';
    
    try {
        $empresa = EmpresaData::getByRuc($ruc);
        if ($empresa) {
            echo json_encode([
                'success' => true,
                'exists' => true,
                'razon_social' => $empresa->razon_social ?? $empresa->nombre ?? 'Empresa registrada',
                'nombre' => $empresa->nombre ?? 'Sin nombre'
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'exists' => false
            ]);
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error al verificar empresa: ' . $e->getMessage()
        ]);
    }
    exit();
}

// Manejar el envío del formulario desde POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $encuesta = new EncuestaData();
        
        // Obtener datos del formulario
        $dni = trim($_POST['dni_est'] ?? '');
        $trabaja = intval($_POST['trabaja'] ?? 0);
        
        // ========== VALIDACIONES BÁSICAS (SIEMPRE REQUERIDAS) ==========
        
        // DNI siempre requerido
        if (empty($dni) || strlen($dni) != 8 || !is_numeric($dni)) {
            throw new Exception("El DNI debe tener exactamente 8 dígitos numéricos");
        }

        // Campo "¿Trabaja?" siempre requerido
        if (!in_array($trabaja, [0, 1])) {
            throw new Exception("Debe seleccionar si trabaja o no");
        }

        // Buscar estudiante
        $estudiante = EgresadoData::getEstudianteByDni($dni);
        if (!$estudiante) {
            throw new Exception("No se encontró un egresado con el DNI: $dni");
        }
        $encuesta->estudiante = $estudiante->id;

        // ========== VALOR COMÚN ==========
        $encuesta->trabaja = $trabaja;
        
        // ========== AGREGAR TIPO DE ENCUESTA ==========
        // ENCUESTA INTERNA (LLAMADA/SISTEMA) = 0
        $encuesta->tipo = 0;

        // ========== MANEJO CONDICIONAL SEGÚN SI TRABAJA O NO ==========
        if ($trabaja == 1) {
            // Si trabaja = Sí, obtener y validar todos los campos
            $ruc = trim($_POST['ruc_empresa'] ?? '');
            $labora_programa_estudios = isset($_POST['labora_programa_estudios']) && $_POST['labora_programa_estudios'] !== '' 
                ? intval($_POST['labora_programa_estudios']) 
                : null;
            $cargo_actual = isset($_POST['cargo_actual']) && $_POST['cargo_actual'] !== '' 
                ? trim($_POST['cargo_actual']) 
                : null;
            $condicion_laboral = isset($_POST['condicion_laboral']) && $_POST['condicion_laboral'] !== ''
                ? intval($_POST['condicion_laboral'])
                : null;
            $ingreso_bruto_mensual = isset($_POST['ingreso_bruto_mensual']) && $_POST['ingreso_bruto_mensual'] !== ''
                ? floatval($_POST['ingreso_bruto_mensual'])
                : null;
            $satisfaccion_trabajo = isset($_POST['satisfaccion_trabajo']) && $_POST['satisfaccion_trabajo'] !== ''
                ? trim($_POST['satisfaccion_trabajo'])
                : null;
            $fecha_inicio = isset($_POST['fecha_inicio']) && $_POST['fecha_inicio'] !== ''
                ? trim($_POST['fecha_inicio'])
                : null;
            $fecha_fin = isset($_POST['fecha_fin']) && $_POST['fecha_fin'] !== ''
                ? trim($_POST['fecha_fin'])
                : null;

            // ========== VALIDACIONES CAMPOS LABORALES (SOLO SI TRABAJA) ==========
            
            // RUC requerido cuando se trabaja
            if (empty($ruc) || strlen($ruc) != 11 || !is_numeric($ruc)) {
                throw new Exception("El RUC debe tener exactamente 11 dígitos numéricos");
            }

            // Cargo actual requerido cuando se trabaja
            if (empty($cargo_actual)) {
                throw new Exception("El cargo actual es requerido cuando se trabaja");
            }

            if (strlen($cargo_actual) < 2) {
                throw new Exception("El cargo debe tener al menos 2 caracteres");
            }

            if (strlen($cargo_actual) > 100) {
                throw new Exception("El cargo no puede tener más de 100 caracteres");
            }

            // Ingreso requerido y válido cuando se trabaja
            if ($ingreso_bruto_mensual === null || $ingreso_bruto_mensual <= 0) {
                throw new Exception("El ingreso bruto mensual debe ser mayor a 0 cuando se trabaja");
            }

            if ($ingreso_bruto_mensual > 999999.99) {
                throw new Exception("El ingreso no puede ser mayor a 999,999.99");
            }

            // Fecha inicio requerida cuando se trabaja
            if (empty($fecha_inicio)) {
                throw new Exception("La fecha de inicio es requerida cuando se trabaja");
            }

            // Validar que fecha_inicio no sea futura
            $fechaInicioObj = new DateTime($fecha_inicio);
            $hoy = new DateTime();
            if ($fechaInicioObj > $hoy) {
                throw new Exception("La fecha de inicio no puede ser futura");
            }

            // Validar que fecha_fin no sea anterior a fecha_inicio (si se proporciona)
            if (!empty($fecha_fin)) {
                $fechaFinObj = new DateTime($fecha_fin);
                if ($fechaFinObj < $fechaInicioObj) {
                    throw new Exception("La fecha de fin no puede ser anterior a la fecha de inicio");
                }
            }

            // ========== MANEJAR EMPRESA (SOLO SI TRABAJA) ==========
            $empresa = EmpresaData::getByRuc($ruc);
            
            if (!$empresa) {
                // Crear nueva empresa automáticamente con datos básicos
                $nuevaEmpresa = new EmpresaData();
                $nuevaEmpresa->ruc = $ruc;
                $nuevaEmpresa->razon_social = "Empresa RUC " . $ruc;
                $nuevaEmpresa->nombre_comercial = "Empresa RUC " . $ruc;
                $nuevaEmpresa->direccion_fiscal = "Por definir";
                $nuevaEmpresa->telefono = "000000000";
                $nuevaEmpresa->email = "contacto@empresa.com";
                $nuevaEmpresa->estado = 'ACTIVO';
                $nuevaEmpresa->validado = 0;
                $nuevaEmpresa->registro_manual = 1;
                
                $resultEmpresa = $nuevaEmpresa->add();
                
                if ($resultEmpresa[0]) {
                    usleep(300000); // Pequeña pausa para asegurar la creación
                    $empresa = EmpresaData::getByRuc($ruc);
                }
            }
            
            $encuesta->empresa = $empresa ? $empresa->id : null;
            
            // Asignar valores laborales (pueden ser NULL si no se proporcionan)
            $encuesta->labora_programa_estudios = $labora_programa_estudios;
            $encuesta->cargo_actual = $cargo_actual;
            $encuesta->condicion_laboral = $condicion_laboral;
            $encuesta->ingreso_bruto_mensual = $ingreso_bruto_mensual;
            $encuesta->satisfaccion_trabajo = $satisfaccion_trabajo;
            $encuesta->fecha_inicio = $fecha_inicio;
            $encuesta->fecha_fin = !empty($fecha_fin) ? $fecha_fin : null;
            
        } else {
            // Si trabaja = No, establecer valores NULL
            $encuesta->empresa = null;
            $encuesta->labora_programa_estudios = null;
            $encuesta->cargo_actual = null;
            $encuesta->condicion_laboral = null;
            $encuesta->ingreso_bruto_mensual = null;
            $encuesta->satisfaccion_trabajo = null;
            $encuesta->fecha_inicio = null;
            $encuesta->fecha_fin = null;
        }

        // Obtener y asignar actividad (si existe)
        $actividadActual = ActividadesData::getActividadActivaActual();
        $encuesta->actividad = $actividadActual ? $actividadActual->id : null;

        // ========== GUARDAR ENCUESTA ==========
        $result = $encuesta->add();
        
        if ($result[0]) {
            $_SESSION['message'] = "✅ Encuesta registrada correctamente (Tipo: Llamada/Sistema).";
            
            // Guardar en sesión para mostrar en el view
            $_SESSION['last_encuesta'] = [
                'dni' => $dni,
                'trabaja' => $trabaja == 1 ? 'Sí' : 'No',
                'cargo' => $cargo_actual ?? 'No aplica',
                'tipo' => 'Llamada/Sistema (Interna)'
            ];
            
        } else {
            $_SESSION['error'] = "❌ Error en la consulta: " . $result[1];
        }
        
    } catch (Exception $e) {
        $_SESSION['error'] = "❌ " . $e->getMessage();
        
        // Guardar datos del formulario en sesión para repoblar
        $_SESSION['form_data'] = $_POST;
    }

    header("Location: index.php?action=encuesta");
    exit();
}

// Obtener todas las encuestas para mostrar
$encuestas = EncuestaData::getAllWithDetails();

// Estado de la encuesta
$encuestaHabilitada = ActividadesData::isEncuestaHabilitada();
$actividadActual = ActividadesData::getEncuestaActividadInfo();

// Recuperar datos del formulario si hubo error
$formData = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_data']);

// Recuperar última encuesta exitosa
$lastEncuesta = $_SESSION['last_encuesta'] ?? null;
if ($lastEncuesta) {
    unset($_SESSION['last_encuesta']);
}

// Vista
ob_start();
include(__DIR__ . "/../view/encuesta_view.php");
$content = ob_get_clean();

include(__DIR__ . "/../layouts/layout.php");