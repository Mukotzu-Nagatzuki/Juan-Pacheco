<?php 
// core/app/action/empresa-action.php

require_once "core/app/model/EmpresaData.php";
require_once "core/app/model/UbDepartamentoData.php";
require_once "core/app/model/UbProvinciaData.php";
require_once "core/app/model/UbDistritoData.php";

// Manejar peticiones AJAX para ubigeo primero
if (isset($_GET['get_provincias']) || isset($_GET['get_distritos'])) {
    header('Content-Type: application/json');
    
    if (isset($_GET['get_provincias']) && isset($_GET['departamento_id'])) {
        $departamento_id = intval($_GET['departamento_id']);
        $provincias = UbProvinciaData::getByDepartamento($departamento_id);
        
        $html = '<option value="">Seleccione Provincia</option>';
        foreach ($provincias as $provincia) {
            $html .= '<option value="' . $provincia->id . '">' . htmlspecialchars($provincia->provincia) . '</option>';
        }
        
        echo json_encode([
            'success' => true,
            'html' => $html
        ]);
        exit;
    }
    
    if (isset($_GET['get_distritos']) && isset($_GET['provincia_id'])) {
        $provincia_id = intval($_GET['provincia_id']);
        $distritos = UbDistritoData::getByProvincia($provincia_id);
        
        $html = '<option value="">Seleccione Distrito</option>';
        foreach ($distritos as $distrito) {
            $html .= '<option value="' . $distrito->id . '">' . htmlspecialchars($distrito->distrito) . '</option>';
        }
        
        echo json_encode([
            'success' => true,
            'html' => $html
        ]);
        exit;
    }
    
    echo json_encode(['success' => false, 'message' => 'Parámetros inválidos']);
    exit;
}

// Manejar eliminación desde GET
if (isset($_GET['action']) && $_GET['action'] == 'eliminar_empresa' && isset($_GET['id'])) {
    $result = EmpresaData::delete($_GET['id']);
    if ($result[0]) {
        $_SESSION['message'] = "Empresa eliminada correctamente";
    } else {
        $_SESSION['error'] = "Error al eliminar la empresa: " . $result[1];
    }
    header("Location: index.php?action=empresas");
    exit();
}

// Manejar operaciones desde POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['actions'])) {
    $actions = $_POST['actions'];
    
    if ($actions == 1) { // Crear nueva empresa
        try {
            $empresa = new EmpresaData();
            $empresa->ruc = trim($_POST['ruc']);
            $empresa->razon_social = trim($_POST['razon_social']);
            $empresa->nombre_comercial = trim($_POST['nombre_comercial']);
            $empresa->direccion_fiscal = trim($_POST['direccion_fiscal']);
            $empresa->telefono = trim($_POST['telefono']);
            $empresa->email = trim($_POST['email']);
            $empresa->sector = trim($_POST['sector']);
            $empresa->validado = intval($_POST['validado']);
            $empresa->registro_manual = intval($_POST['registro_manual']);
            $empresa->estado = trim($_POST['estado']);
            $empresa->condicion_sunat = trim($_POST['condicion_sunat']);
            $empresa->ubigeo = trim($_POST['ubigeo']);
            
            // IMPORTANTE: Usar los nombres desde los campos hidden
            $empresa->departamento = trim($_POST['departamento']);
            $empresa->provincia = trim($_POST['provincia']);
            $empresa->distrito = trim($_POST['distrito']);
            
            // Verificar si ya existe una empresa con el mismo RUC
            if (EmpresaData::existsByRuc($empresa->ruc)) {
                $_SESSION['error'] = "Ya existe una empresa registrada con el RUC: " . $empresa->ruc;
            } else {
                $result = $empresa->add();
                if ($result[0]) {
                    $_SESSION['message'] = "Empresa registrada correctamente";
                } else {
                    $_SESSION['error'] = "Error al registrar la empresa: " . $result[1];
                }
            }
        } catch (Exception $e) {
            $_SESSION['error'] = "Error: " . $e->getMessage();
        }
        header("Location: index.php?action=empresas");
        exit();
    }

    if ($actions == 2) { // Actualizar empresa existente
        try {
            $empresa = new EmpresaData();
            $empresa->id = intval($_POST['id_empresa']);
            $empresa->ruc = trim($_POST['ruc']);
            $empresa->razon_social = trim($_POST['razon_social']);
            $empresa->nombre_comercial = trim($_POST['nombre_comercial']);
            $empresa->direccion_fiscal = trim($_POST['direccion_fiscal']);
            $empresa->telefono = trim($_POST['telefono']);
            $empresa->email = trim($_POST['email']);
            $empresa->sector = trim($_POST['sector']);
            $empresa->validado = intval($_POST['validado']);
            $empresa->registro_manual = intval($_POST['registro_manual']);
            $empresa->estado = trim($_POST['estado']);
            $empresa->condicion_sunat = trim($_POST['condicion_sunat']);
            $empresa->ubigeo = trim($_POST['ubigeo']);
            
            // IMPORTANTE: Usar los nombres desde los campos hidden
            $empresa->departamento = trim($_POST['departamento']);
            $empresa->provincia = trim($_POST['provincia']);
            $empresa->distrito = trim($_POST['distrito']);
            
            $result = $empresa->update();
            if ($result[0]) {
                $_SESSION['message'] = "Empresa actualizada correctamente";
            } else {
                $_SESSION['error'] = "Error al actualizar la empresa: " . $result[1];
            }
        } catch (Exception $e) {
            $_SESSION['error'] = "Error: " . $e->getMessage();
        }
        header("Location: index.php?action=empresas");
        exit();
    }
}

// Cargar datos para la vista
$busqueda = $_GET['busqueda'] ?? '';
$criterio = $_GET['criterio'] ?? 'todas';

if (!empty($busqueda)) {
    $empresas = EmpresaData::search($busqueda, $criterio);
} else {
    $empresas = EmpresaData::getAll();
}

// Cargar datos de ubigeo para los selects
$departamentos = UbDepartamentoData::getAll();

// Capturar la vista
ob_start();
include(__DIR__ . "/../view/empresas_view.php");
$content = ob_get_clean();

// Incluir el layout principal
include(__DIR__ . "/../layouts/layout.php");
?>