<?php 
// core/app/action/situacion-action.php

require_once "core/app/model/SituacionlaboralData.php"; // AÑADIR ESTA LÍNEA
require_once "core/app/model/EncuestaData.php";
require_once "core/app/model/EgresadoData.php";
require_once "core/app/model/EmpresaData.php";
require_once "core/app/model/ActividadesData.php";

// Manejar el envío del formulario desde POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $encuesta = new EncuestaData();
        $dni = trim($_POST['dni_est'] ?? '');
        $ruc = trim($_POST['ruc_empresa'] ?? '');
        $trabaja = intval($_POST['trabaja'] ?? 0);
        $labora_programa_estudios = intval($_POST['labora_programa_estudios'] ?? 0);
        $cargo_actual = trim($_POST['cargo_actual'] ?? '');
        $condicion_laboral = intval($_POST['condicion_laboral'] ?? 0);
        $ingreso_bruto_mensual = floatval($_POST['ingreso_bruto_mensual'] ?? 0);
        $satisfaccion_trabajo = trim($_POST['satisfaccion_trabajo'] ?? '');
        $fecha_inicio = trim($_POST['fecha_inicio'] ?? '');
        $fecha_fin = trim($_POST['fecha_fin'] ?? ''); // NUEVO: obtener fecha_fin

        // Validaciones básicas
        if (empty($dni) || strlen($dni) != 8 || !is_numeric($dni)) {
            throw new Exception("El DNI debe tener exactamente 8 dígitos numéricos");
        }

        if (empty($ruc) || strlen($ruc) != 11 || !is_numeric($ruc)) {
            throw new Exception("El RUC debe tener exactamente 11 dígitos numéricos");
        }

        if (empty($cargo_actual)) {
            throw new Exception("El cargo actual es requerido");
        }

        if ($ingreso_bruto_mensual <= 0) {
            throw new Exception("El ingreso bruto mensual debe ser mayor a 0");
        }

        if (empty($fecha_inicio)) {
            throw new Exception("La fecha de inicio es requerida");
        }

        // Buscar estudiante
        $estudiante = EgresadoData::getEstudianteByDni($dni);
        if (!$estudiante) {
            throw new Exception("No se encontró un egresado con el DNI: $dni");
        }
        $encuesta->estudiante = $estudiante->id;

        // Buscar empresa
        $empresa = EmpresaData::getByRuc($ruc);
        
        if (!$empresa) {
            // Crear nueva empresa automáticamente
            $nuevaEmpresa = new EmpresaData();
            $nuevaEmpresa->ruc = $ruc;
            $nuevaEmpresa->nombre = "Empresa - " . $ruc;
            $nuevaEmpresa->direccion = "Por definir";
            $nuevaEmpresa->telefono = "000000000";
            $nuevaEmpresa->email = "contacto@empresa.com";
            
            $resultEmpresa = $nuevaEmpresa->add();
            
            if ($resultEmpresa[0]) {
                usleep(300000);
                $empresa = EmpresaData::getByRuc($ruc);
            }
        }
        
        $encuesta->empresa = $empresa ? $empresa->id : null;

        // Asignar valores
        $encuesta->trabaja = $trabaja;
        $encuesta->labora_programa_estudios = $labora_programa_estudios;
        $encuesta->cargo_actual = $cargo_actual;
        $encuesta->condicion_laboral = $condicion_laboral;
        $encuesta->ingreso_bruto_mensual = $ingreso_bruto_mensual;
        $encuesta->satisfaccion_trabajo = $satisfaccion_trabajo;
        $encuesta->fecha_inicio = $fecha_inicio;
        
        // Asignar fecha_fin - puede ser NULL
        if (!empty($fecha_fin)) {
            $encuesta->fecha_fin = $fecha_fin;
        }

        // Guardar
        $result = $encuesta->add();
        
        if ($result[0]) {
            $_SESSION['message'] = "✅ Encuesta registrada correctamente.";
        } else {
            $_SESSION['error'] = "Error al registrar: " . $result[1];
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "❌ " . $e->getMessage();
    }

    header("Location: index.php?action=situacion");
    exit();
}

// Obtener todas las situaciones laborales - USAR LA CLASE CORRECTA
$situaciones = SituacionlaboralData::getAllWithDetails();

// SOLUCIÓN DE EMERGENCIA: Agregar datos de actividad manualmente
$actividadesMap = [];
$todasActividades = ActividadesData::getAll();
foreach ($todasActividades as $act) {
    $actividadesMap[$act->id] = $act;
}

// Asignar nombres de actividad a cada situación
foreach ($situaciones as $sit) {
    if (!empty($sit->actividad) && isset($actividadesMap[$sit->actividad])) {
        $actividad = $actividadesMap[$sit->actividad];
        $sit->actividad_titulo = $actividad->titulo;
        $sit->actividad_fecha_inicio = $actividad->fecha_inicio;
        $sit->actividad_fecha_fin = $actividad->fecha_fin;
    } elseif (!empty($sit->actividad)) {
        // Si hay ID pero no está en el mapa, buscar directamente
        $actividad = ActividadesData::getById($sit->actividad);
        if ($actividad) {
            $sit->actividad_titulo = $actividad->titulo;
            $sit->actividad_fecha_inicio = $actividad->fecha_inicio;
            $sit->actividad_fecha_fin = $actividad->fecha_fin;
        } else {
            $sit->actividad_titulo = 'No asignada';
            $sit->actividad_fecha_inicio = null;
            $sit->actividad_fecha_fin = null;
        }
    } else {
        $sit->actividad_titulo = 'No asignada';
        $sit->actividad_fecha_inicio = null;
        $sit->actividad_fecha_fin = null;
    }
}

// Obtener información de actividades para mostrar
$actividades_activas = ActividadesData::getActivas();
$actividad_actual = ActividadesData::getActividadActivaActual();

if (isset($_GET['debug']) && $_GET['debug'] == 1) {
    echo "<pre>";
    echo "=== DEPURACIÓN DE DATOS (DESPUÉS DE CORRECCIÓN) ===\n";
    echo "Total de situaciones: " . count($situaciones) . "\n";
    
    if (count($situaciones) > 0) {
        echo "\nPrimer registro:\n";
        echo "ID: " . ($situaciones[0]->id ?? 'NULL') . "\n";
        echo "actividad (ID en BD): " . ($situaciones[0]->actividad ?? 'NULL') . "\n";
        echo "actividad_titulo: " . ($situaciones[0]->actividad_titulo ?? 'NULL') . "\n";
        echo "actividad_fecha_inicio: " . ($situaciones[0]->actividad_fecha_inicio ?? 'NULL') . "\n";
        echo "actividad_fecha_fin: " . ($situaciones[0]->actividad_fecha_fin ?? 'NULL') . "\n";
        
        echo "\n=== VERIFICAR CLASE ===\n";
        echo "Clase del objeto: " . get_class($situaciones[0]) . "\n";
        
        // Verificar las propiedades del objeto
        echo "\n=== PROPIEDADES DEL OBJETO ===\n";
        $props = get_object_vars($situaciones[0]);
        foreach ($props as $key => $value) {
            echo "$key: " . ($value ?? 'NULL') . "\n";
        }
    }
    
    echo "\n=== INFORMACIÓN DE ACTIVIDAD ACTUAL ===\n";
    if ($actividad_actual) {
        echo "ID: " . $actividad_actual->id . "\n";
        echo "Título: " . $actividad_actual->titulo . "\n";
        echo "Fecha inicio: " . $actividad_actual->fecha_inicio . "\n";
        echo "Fecha fin: " . $actividad_actual->fecha_fin . "\n";
    } else {
        echo "NO HAY ACTIVIDAD ACTIVA\n";
    }
    
    echo "\n=== MAPA DE ACTIVIDADES ===\n";
    echo "Total actividades en mapa: " . count($actividadesMap) . "\n";
    echo "¿Existe actividad ID 15 en mapa? " . (isset($actividadesMap[15]) ? 'Sí - Título: ' . $actividadesMap[15]->titulo : 'No') . "\n";
    
    echo "</pre>";
    exit();
}

// Para la vista
ob_start();
include(__DIR__ . "/../view/situacion_view.php");
$content = ob_get_clean();

include(__DIR__ . "/../layouts/layout.php");
?>