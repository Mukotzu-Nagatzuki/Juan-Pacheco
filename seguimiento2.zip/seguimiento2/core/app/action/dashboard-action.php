<?php
// core/app/action/dashboard-action.php

// Incluir modelos
require_once "core/app/model/EgresadoData.php";
require_once "core/app/model/EmpresaData.php";
require_once "core/app/model/SituacionlaboralData.php";
require_once "core/app/model/ProgramaData.php";
require_once "core/app/model/DashboardData.php"; // Nuevo modelo

error_reporting(E_ALL);
ini_set('display_errors', 1);

error_log("🚀 INICIANDO DASHBOARD ACTION");

try {
    // Obtener estadísticas
    $stats = DashboardData::getStats();
    
    $estadisticas = [
        'total_estudiantes' => $stats->total_estudiantes ?? 0,
        'total_empresas' => $stats->total_empresas ?? 0,
        'total_programas' => $stats->total_programas ?? 0,
        'empleados_activos' => $stats->empleados_activos ?? 0
    ];
    
    // Obtener otros datos
    $ultimosEgresados = DashboardData::getUltimosEstudiantes();
    $distribucionProgramas = DashboardData::getDistribucionProgramas();
    $situacionLaboral = DashboardData::getSituacionLaboral();
    
    error_log("✅ Datos obtenidos correctamente");
    
} catch (Exception $e) {
    error_log("❌ Error en dashboard: " . $e->getMessage());
    
    // Datos de prueba en caso de error
    $estadisticas = [
        'total_estudiantes' => 0,
        'total_empresas' => 0,
        'total_programas' => 0,
        'empleados_activos' => 0
    ];
    
    $ultimosEgresados = [];
    $distribucionProgramas = [];
    $situacionLaboral = [];
}

// Incluir la vista directamente
include(__DIR__ . "/../view/dashboard_view.php");

error_log("🏁 FINALIZANDO DASHBOARD ACTION");
?>