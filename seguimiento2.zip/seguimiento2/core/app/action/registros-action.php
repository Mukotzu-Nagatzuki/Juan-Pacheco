<?php
$users = UserData::getAll();
ob_start();
include(__DIR__ . "/../view/usuario-register-view.php");
$content = ob_get_clean();
include(__DIR__ . "/../layouts/layout.php");
?>
