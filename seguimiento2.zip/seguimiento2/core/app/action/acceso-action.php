<?php
if(isset($_POST["usuario"]) && isset($_POST["password"])){
    $user_var = $_POST["usuario"];
    $password_var = $_POST["password"];

    $sql = "SELECT id, usuario, password FROM usuarios WHERE usuario=:usuario";
    $params = [":usuario" =>$user_var];
    $result = Executor::doit($sql,$params);
    
    $login_success = false;
    
    if($result[0]->rowCount() > 0){
        while($row = $result[0]->fetch(PDO::FETCH_ASSOC)){
            if(password_verify($password_var, $row['password'])) {
                $_SESSION['userid'] = $row['id'];
                $_SESSION['username'] = $row['usuario'];
                $login_success = true;
                break;
            }
        }
    }
    
    if($login_success){
        // Redirigir al index.php de tu aplicación (mismo directorio que action)
        header("Location: index.php");
        exit;
    } else {
        // Credenciales incorrectas
        $_SESSION['error'] = "Usuario o contraseña incorrectos";
        header("Location: index.php");
        exit;
    }
    
} else {
    header("Location: index.php");
    exit;
}
?>