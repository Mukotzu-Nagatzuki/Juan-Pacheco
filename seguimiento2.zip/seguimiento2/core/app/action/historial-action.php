<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once "core/app/model/HistoriallaboralData.php";
require_once "core/app/model/SituacionlaboralData.php";

// ============================================
// ACCIONES POST (AGREGAR / ACTUALIZAR)
// ============================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // ----- AGREGAR -----
    if (isset($_POST['agregar_historial'])) {
        $historial = new HistoriallaboralData();
        $historial->situacion = intval($_POST['situacion']);
        $historial->tiempo_primer_empleo = trim($_POST['tiempo_primer_empleo']);

        $razon = trim($_POST['razon_desempleo']);
        $historial->razon_desempleo = ($razon == 'Otra' && !empty($_POST['otra_razon']))
            ? trim($_POST['otra_razon'])
            : $razon;

        $historial->fecha_inicio = $_POST['fecha_inicio'];
        $historial->fecha_fin = !empty($_POST['fecha_fin']) ? $_POST['fecha_fin'] : null;

        $ok = $historial->add(); // esto devuelve true | false

        if ($ok) {
            $_SESSION['message'] = "Historial laboral agregado correctamente";
        } else {
            $_SESSION['error'] = "Error al agregar registro";
        }

        header("Location: index.php?page=historial");
        exit();
    }

    // ----- ACTUALIZAR -----
    if (isset($_POST['actualizar_historial'])) {
        $historial = new HistoriallaboralData();
        $historial->id = intval($_POST['id']);
        $historial->situacion = intval($_POST['situacion']);
        $historial->tiempo_primer_empleo = trim($_POST['tiempo_primer_empleo']);

        $razon = trim($_POST['razon_desempleo']);
        $historial->razon_desempleo = ($razon == 'Otra' && !empty($_POST['otra_razon']))
            ? trim($_POST['otra_razon'])
            : $razon;

        $historial->fecha_inicio = $_POST['fecha_inicio'];
        $historial->fecha_fin = !empty($_POST['fecha_fin']) ? $_POST['fecha_fin'] : null;

        $ok = $historial->update();

        if ($ok) {
            $_SESSION['message'] = "Historial actualizado correctamente";
        } else {
            $_SESSION['error'] = "Error al actualizar";
        }

        header("Location: index.php?page=historial");
        exit();
    }
}

// ============================================
// ACCIONES GET (VER - EDITAR - ELIMINAR)
// ============================================

// ----- ELIMINAR -----
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);

    $existe = HistoriallaboralData::getById($id);

    if ($existe) {
        $ok = HistoriallaboralData::delete($id);

        if ($ok) {
            $_SESSION['message'] = "Historial eliminado correctamente";
        } else {
            $_SESSION['error'] = "Error al eliminar";
        }
    } else {
        $_SESSION['error'] = "El historial no existe";
    }

    header("Location: index.php?page=historial");
    exit();
}

// ----- EDITAR -----
$historial_editar = null;

if (isset($_GET['editar'])) {
    $id = intval($_GET['editar']);
    $historial_editar = HistoriallaboralData::getById($id);

    if (!$historial_editar) {
        $_SESSION['error'] = "Historial no encontrado";
        header("Location: index.php?page=historial");
        exit();
    }
}

// ----- VER -----
$historial_detalle = null;

if (isset($_GET['ver'])) {
    $id = intval($_GET['ver']);
    $historial_detalle = HistoriallaboralData::getById($id);

    if (!$historial_detalle) {
        $_SESSION['error'] = "Historial no encontrado";
        header("Location: index.php?page=historial");
        exit();
    }
}

// ----- BUSCAR -----
$busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
$criterio = isset($_GET['criterio']) ? $_GET['criterio'] : 'todas';

$historiales = !empty($busqueda)
    ? HistoriallaboralData::search($busqueda, $criterio)
    : HistoriallaboralData::getAll();

// ----- SITUACIONES LABORALES -----
try {
    $situaciones = Executor::doit("SELECT * FROM situacion_laboral");
    $situaciones = $situaciones[0] ? Model::many($situaciones[0], new stdClass()) : [];

    if (empty($situaciones)) {
        $_SESSION['warning'] = "Debes crear situaciones laborales primero.";
    }

} catch (Exception $e) {
    $_SESSION['error'] = "Error al cargar situaciones laborales";
    $situaciones = [];
}

// ----- CARGAR VISTA -----
ob_start();
include("core/app/view/historial_view.php");
$content = ob_get_clean();

include("core/app/layouts/layout.php");
?>
