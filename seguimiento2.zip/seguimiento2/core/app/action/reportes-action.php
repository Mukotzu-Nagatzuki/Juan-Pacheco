<?php
require_once __DIR__."/../model/ReportesData.php";

// Obtener datos del reporte
$empresas_sector = ReportesData::empresasPorSector();
$empresas_validado = ReportesData::empresasValidadas();
$estudiantes_programa = ReportesData::estudiantesPorPrograma();
$estudiantes_turno = ReportesData::estudiantesPorTurno();
$seguimientos_tipo = ReportesData::seguimientosPorTipo();
$seguimientos_programa = ReportesData::seguimientosPorPrograma();
$situacion_laboral = ReportesData::situacionLaboral();
$ingreso_promedio = ReportesData::ingresoPromedioPorPrograma();

$encuesta_trabaja = ReportesData::encuestaTrabaja();
$encuesta_area = ReportesData::encuestaArea();
$encuesta_condicion = ReportesData::encuestaCondicion();
$encuesta_cargo = ReportesData::encuestaCargoFrecuente();

// Obtener datos de los nuevos reportes
$egresados_encuesta = ReportesData::egresadosConEncuesta();
$tipo_seguimiento = ReportesData::tipoSeguimientoEncuestaSimple();
$detalle_egresados = ReportesData::detalleEgresadosEncuesta();
$respuesta_programa = ReportesData::respuestaPorPrograma();
$distribucion_egresados = ReportesData::distribucionEgresadosEncuesta();
$estadisticas_seguimiento = ReportesData::estadisticasSeguimiento();

// ============================================
// NUEVOS REPORTES: ORIGEN DE ENCUESTAS
// ============================================
$origen_encuestas = ReportesData::origenEncuestas();
$detalle_origen = ReportesData::detalleEncuestasPorOrigen();
$estadisticas_origen_programa = ReportesData::estadisticasRespuestaPorOrigenPrograma();
$comparativa_origen = ReportesData::comparativaResultadosPorOrigen();

// Obtener total de egresados
$total_egresados = ReportesData::totalEgresados();

// ==============================
// EXPORTAR EXCEL - REPORTE GENERAL
// ==============================
if (isset($_POST['export_excel'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=reporte_general_" . date('Y-m-d') . ".xls");
    
    echo "<html>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<style>";
    echo "td, th { border: 1px solid #ddd; padding: 8px; }";
    echo "th { background-color: #4CAF50; color: white; }";
    echo ".titulo { font-size: 18px; font-weight: bold; text-align: center; }";
    echo ".subtitulo { background-color: #f2f2f2; font-weight: bold; }";
    echo ".llamada { background-color: #e8f5e9; }";
    echo ".correo { background-color: #e3f2fd; }";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    
    echo "<table>";
    
    // Título general
    echo "<tr><td colspan='5' class='titulo'>REPORTE GENERAL DEL SISTEMA</td></tr>";
    echo "<tr><td colspan='5'>Fecha de generación: " . date('d/m/Y H:i:s') . "</td></tr>";
    echo "<tr><td colspan='5'></td></tr>";
    
    // Resumen general
    echo "<tr><td colspan='5' class='subtitulo'>RESUMEN GENERAL</td></tr>";
    if (!empty($total_egresados)) {
        echo "<tr><td>Total Egresados:</td><td colspan='4'>" . $total_egresados . "</td></tr>";
    }
    
    // Mostrar encuestas por tipo (CORREGIDO: 0=Llamada, 1=Correo)
    if (!empty($origen_encuestas)) {
        $total_encuestas_llamada = 0;
        $total_encuestas_correo = 0;
        $total_estudiantes_llamada = 0;
        $total_estudiantes_correo = 0;
        $ingreso_llamada = 0;
        $ingreso_correo = 0;
        
        foreach ($origen_encuestas as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres para exportación
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            if (strpos($origen, 'Llamada') !== false) {
                $total_encuestas_llamada = $row['total_encuestas'] ?? 0;
                $total_estudiantes_llamada = $row['total_estudiantes'] ?? 0;
                $ingreso_llamada = $row['ingreso_promedio'] ?? 0;
            } elseif (strpos($origen, 'Correo') !== false) {
                $total_encuestas_correo = $row['total_encuestas'] ?? 0;
                $total_estudiantes_correo = $row['total_estudiantes'] ?? 0;
                $ingreso_correo = $row['ingreso_promedio'] ?? 0;
            }
        }
        
        echo "<tr><td>Encuestas por Llamada (tipo=0):</td><td colspan='4'>" . $total_encuestas_llamada . " (Estudiantes: " . $total_estudiantes_llamada . ")</td></tr>";
        echo "<tr><td>Encuestas por Correo (tipo=1):</td><td colspan='4'>" . $total_encuestas_correo . " (Estudiantes: " . $total_estudiantes_correo . ")</td></tr>";
        echo "<tr><td>Total Encuestas:</td><td colspan='4'>" . ($total_encuestas_llamada + $total_encuestas_correo) . "</td></tr>";
        echo "<tr><td>Ingreso Promedio Llamada:</td><td colspan='4'>S/ " . number_format($ingreso_llamada, 2) . "</td></tr>";
        echo "<tr><td>Ingreso Promedio Correo:</td><td colspan='4'>S/ " . number_format($ingreso_correo, 2) . "</td></tr>";
    }
    echo "<tr><td colspan='5'></td></tr>";
    
    // Empresas por sector
    if (!empty($empresas_sector)) {
        echo "<tr><td colspan='5' class='subtitulo'>EMPRESAS POR SECTOR</td></tr>";
        echo "<tr><th>Sector</th><th>Total Empresas</th><th colspan='3'>Porcentaje</th></tr>";
        $total_empresas = array_sum(array_column($empresas_sector, 'total'));
        foreach ($empresas_sector as $row) {
            $sector = $row['sector'] ?? 'No especificado';
            $porcentaje = !empty($total_empresas) ? round(($row['total'] / $total_empresas) * 100, 2) : 0;
            echo "<tr><td>" . htmlspecialchars($sector) . "</td><td>" . $row['total'] . "</td><td colspan='3'>" . $porcentaje . "%</td></tr>";
        }
        echo "<tr><td colspan='5'></td></tr>";
    }
    
    // Estudiantes por programa
    if (!empty($estudiantes_programa)) {
        echo "<tr><td colspan='5' class='subtitulo'>ESTUDIANTES POR PROGRAMA</td></tr>";
        echo "<tr><th>Programa</th><th>Total Estudiantes</th><th colspan='3'>Porcentaje</th></tr>";
        $total_estudiantes = array_sum(array_column($estudiantes_programa, 'total_estudiantes'));
        foreach ($estudiantes_programa as $row) {
            $programa = $row['nom_progest'] ?? 'No especificado';
            $porcentaje = !empty($total_estudiantes) ? round(($row['total_estudiantes'] / $total_estudiantes) * 100, 2) : 0;
            echo "<tr><td>" . htmlspecialchars($programa) . "</td><td>" . $row['total_estudiantes'] . "</td><td colspan='3'>" . $porcentaje . "%</td></tr>";
        }
        echo "<tr><td colspan='5'></td></tr>";
    }
    
    // Encuesta: ¿Trabajan? por tipo (CORREGIDO para Llamada/Correo)
    if (!empty($encuesta_trabaja)) {
        echo "<tr><td colspan='5' class='subtitulo'>ENCUESTA: ¿TRABAJAN ACTUALMENTE? (POR TIPO)</td></tr>";
        echo "<tr><th>Tipo</th><th>Situación</th><th>Total</th><th colspan='2'>Porcentaje</th></tr>";
        
        // Agrupar por tipo
        $por_tipo = [];
        foreach ($encuesta_trabaja as $row) {
            $tipo = $row['origen'] ?? ''; // 'origen' contiene 'Llamada' o 'Correo'
            
            // Transformar nombres
            if (strtolower($tipo) === 'desconocido' || stripos($tipo, 'desconocido') !== false) {
                $tipo = 'Correo';
            } elseif (strtolower($tipo) === 'encuesta interna' || stripos($tipo, 'encuesta interna') !== false) {
                $tipo = 'Llamada';
            }
            
            if (!isset($por_tipo[$tipo])) {
                $por_tipo[$tipo] = ['Sí' => 0, 'No' => 0, 'total' => 0];
            }
            if (($row['trabaja'] ?? '') == 'Sí') {
                $por_tipo[$tipo]['Sí'] = $row['total'] ?? 0;
            } elseif (($row['trabaja'] ?? '') == 'No') {
                $por_tipo[$tipo]['No'] = $row['total'] ?? 0;
            }
            $por_tipo[$tipo]['total'] += $row['total'] ?? 0;
        }
        
        foreach ($por_tipo as $tipo => $datos) {
            $porcentaje_si = $datos['total'] > 0 ? round(($datos['Sí'] / $datos['total']) * 100, 2) : 0;
            $porcentaje_no = $datos['total'] > 0 ? round(($datos['No'] / $datos['total']) * 100, 2) : 0;
            
            echo "<tr class='" . (strpos($tipo, 'Llamada') !== false ? 'llamada' : 'correo') . "'>";
            echo "<td rowspan='2'>" . htmlspecialchars($tipo) . "</td>";
            echo "<td>Sí</td><td>" . $datos['Sí'] . "</td><td colspan='2'>" . $porcentaje_si . "%</td></tr>";
            echo "<tr class='" . (strpos($tipo, 'Llamada') !== false ? 'llamada' : 'correo') . "'>";
            echo "<td>No</td><td>" . $datos['No'] . "</td><td colspan='2'>" . $porcentaje_no . "%</td></tr>";
        }
        echo "<tr><td colspan='5'></td></tr>";
    }
    
    // ORIGEN DE ENCUESTAS (CORREGIDO para Llamada/Correo)
    if (!empty($origen_encuestas)) {
        echo "<tr><td colspan='5' class='subtitulo'>ESTADÍSTICAS POR TIPO DE ENCUESTA</td></tr>";
        echo "<tr><th>Tipo</th><th>Estudiantes</th><th>Encuestas</th><th>Ingreso Promedio</th><th>% del Total</th></tr>";
        foreach ($origen_encuestas as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $clase = '';
            if (strpos($origen, 'Llamada') !== false) {
                $clase = 'llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $clase = 'correo';
            }
            
            echo "<tr class='" . $clase . "'>";
            echo "<td>" . htmlspecialchars($origen) . "</td>";
            echo "<td>" . ($row['total_estudiantes'] ?? 0) . "</td>";
            echo "<td>" . ($row['total_encuestas'] ?? 0) . "</td>";
            echo "<td>S/ " . (isset($row['ingreso_promedio']) ? number_format($row['ingreso_promedio'], 2) : '0.00') . "</td>";
            echo "<td>" . ($row['porcentaje_total'] ?? 0) . "%</td>";
            echo "</tr>";
        }
    }
    
    // COMPARATIVA POR ORIGEN (CORREGIDO para Llamada/Correo)
    if (!empty($comparativa_origen)) {
        echo "<tr><td colspan='5'></td></tr>";
        echo "<tr><td colspan='5' class='subtitulo'>COMPARATIVA DE RESULTADOS POR TIPO</td></tr>";
        echo "<tr><th>Tipo</th><th>Estudiantes</th><th>Ingreso Promedio</th><th>% Trabaja</th><th>% Trabaja en Carrera</th></tr>";
        foreach ($comparativa_origen as $row) {
            $origen = $row['origen'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $clase = '';
            if (strpos($origen, 'Llamada') !== false) {
                $clase = 'llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $clase = 'correo';
            }
            
            echo "<tr class='" . $clase . "'>";
            echo "<td>" . htmlspecialchars($origen) . "</td>";
            echo "<td>" . ($row['total_estudiantes'] ?? 0) . "</td>";
            echo "<td>S/ " . (isset($row['ingreso_promedio']) ? number_format($row['ingreso_promedio'], 2) : '0.00') . "</td>";
            echo "<td>" . ($row['porcentaje_trabaja'] ?? 0) . "%</td>";
            echo "<td>" . ($row['porcentaje_trabaja_carrera'] ?? 0) . "%</td>";
            echo "</tr>";
        }
    }
    
    // CONDICIÓN LABORAL
    if (!empty($encuesta_condicion)) {
        echo "<tr><td colspan='5'></td></tr>";
        echo "<tr><td colspan='5' class='subtitulo'>CONDICIÓN LABORAL</td></tr>";
        echo "<tr><th>Condición</th><th>Total</th><th colspan='3'>Porcentaje</th></tr>";
        $total_condicion = array_sum(array_column($encuesta_condicion, 'total'));
        foreach ($encuesta_condicion as $row) {
            $condicion = $row['condicion_laboral'] ?? 'No especificado';
            $porcentaje = !empty($total_condicion) ? round(($row['total'] / $total_condicion) * 100, 2) : 0;
            echo "<tr><td>" . htmlspecialchars($condicion) . "</td><td>" . $row['total'] . "</td><td colspan='3'>" . $porcentaje . "%</td></tr>";
        }
    }
    
    echo "</table>";
    echo "</body></html>";
    exit;
}

// ==============================
// EXPORTAR EXCEL - ORIGEN DE ENCUESTAS
// ==============================
if (isset($_POST['export_excel_origen'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=reporte_tipo_encuestas_" . date('Y-m-d') . ".xls");
    
    echo "<html>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<style>";
    echo "td, th { border: 1px solid #ddd; padding: 8px; }";
    echo "th { background-color: #2196F3; color: white; }";
    echo ".titulo { font-size: 18px; font-weight: bold; text-align: center; }";
    echo ".subtitulo { background-color: #2196F3; color: white; font-weight: bold; }";
    echo ".llamada { background-color: #e8f5e9; }";
    echo ".correo { background-color: #e3f2fd; }";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    
    echo "<table>";
    
    // Título
    echo "<tr><td colspan='9' class='titulo'>REPORTE DE TIPO DE ENCUESTAS (LLAMADA/CORREO)</td></tr>";
    echo "<tr><td colspan='9'>Fecha: " . date('d/m/Y H:i:s') . "</td></tr>";
    echo "<tr><td colspan='9'></td></tr>";
    
    // Resumen por tipo
    if (!empty($origen_encuestas)) {
        echo "<tr><th colspan='9' class='subtitulo'>RESUMEN POR TIPO DE ENCUESTA</th></tr>";
        echo "<tr>";
        echo "<th>Tipo (0=Llamada, 1=Correo)</th>";
        echo "<th>Total Estudiantes</th>";
        echo "<th>Total Encuestas</th>";
        echo "<th>Ingreso Promedio</th>";
        echo "<th>% Trabaja</th>";
        echo "<th>% Trabaja en Carrera</th>";
        echo "<th>Primera Encuesta</th>";
        echo "<th>% del Total</th>";
        echo "</tr>";
        
        foreach ($origen_encuestas as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $tipo_numero = '';
            $clase = '';
            if (strpos($origen, 'Llamada') !== false) {
                $tipo_numero = '0 = Llamada';
                $clase = 'llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $tipo_numero = '1 = Correo';
                $clase = 'correo';
            } else {
                $tipo_numero = 'N/A';
            }
            
            // Buscar datos de comparativa
            $comparativa = [];
            foreach ($comparativa_origen as $comp) {
                $comp_origen = $comp['origen'] ?? '';
                
                // Transformar nombres para comparar
                if (strtolower($comp_origen) === 'desconocido' || stripos($comp_origen, 'desconocido') !== false) {
                    $comp_origen = 'Correo';
                } elseif (strtolower($comp_origen) === 'encuesta interna' || stripos($comp_origen, 'encuesta interna') !== false) {
                    $comp_origen = 'Llamada';
                }
                
                if ($comp_origen == $origen) {
                    $comparativa = $comp;
                    break;
                }
            }
            
            echo "<tr class='" . $clase . "'>";
            echo "<td>" . $tipo_numero . " - " . htmlspecialchars($origen) . "</td>";
            echo "<td align='center'>" . ($row['total_estudiantes'] ?? 0) . "</td>";
            echo "<td align='center'>" . ($row['total_encuestas'] ?? 0) . "</td>";
            echo "<td align='right'>S/ " . (isset($row['ingreso_promedio']) ? number_format($row['ingreso_promedio'], 2) : '0.00') . "</td>";
            
            if (!empty($comparativa)) {
                echo "<td align='center'>" . ($comparativa['porcentaje_trabaja'] ?? '0.00') . "%</td>";
                echo "<td align='center'>" . ($comparativa['porcentaje_trabaja_carrera'] ?? '0.00') . "%</td>";
            } else {
                echo "<td align='center'>0.00%</td>";
                echo "<td align='center'>0.00%</td>";
            }
            
            echo "<td>" . ($row['primera_encuesta'] ?? 'N/A') . "</td>";
            echo "<td align='center'>" . ($row['porcentaje_total'] ?? 0) . "%</td>";
            echo "</tr>";
        }
        echo "<tr><td colspan='9'></td></tr>";
    }
    
    // Detalle de encuestas por tipo
    if (!empty($detalle_origen)) {
        echo "<tr><th colspan='10' class='subtitulo'>DETALLE DE ENCUESTAS POR TIPO</th></tr>";
        echo "<tr>";
        echo "<th>#</th>";
        echo "<th>Estudiante</th>";
        echo "<th>DNI</th>";
        echo "<th>Carrera</th>";
        echo "<th>Fecha Encuesta</th>";
        echo "<th>Tipo (0/1)</th>";
        echo "<th>Tipo Descripción</th>";
        echo "<th>Cargo Actual</th>";
        echo "<th>Ingreso Bruto</th>";
        echo "<th>Trabaja</th>";
        echo "</tr>";
        
        $contador = 1;
        foreach ($detalle_origen as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $tipo_numero = '';
            $clase = '';
            if (strpos($origen, 'Llamada') !== false) {
                $tipo_numero = '0';
                $clase = 'llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $tipo_numero = '1';
                $clase = 'correo';
            }
            
            echo "<tr class='" . $clase . "'>";
            echo "<td align='center'>" . $contador++ . "</td>";
            echo "<td>" . htmlspecialchars($row['nombre_completo'] ?? '') . "</td>";
            echo "<td>" . ($row['dni_est'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['carrera'] ?? '') . "</td>";
            echo "<td>" . ($row['fecha_encuesta'] ?? '') . "</td>";
            echo "<td align='center'>" . $tipo_numero . "</td>";
            echo "<td>" . htmlspecialchars($origen) . "</td>";
            echo "<td>" . htmlspecialchars($row['cargo_actual'] ?? '') . "</td>";
            echo "<td align='right'>S/ " . (isset($row['ingreso_bruto_mensual']) ? number_format($row['ingreso_bruto_mensual'], 2) : '0.00') . "</td>";
            echo "<td align='center'>" . ($row['trabaja_actualmente'] ?? '') . "</td>";
            echo "</tr>";
        }
    }
    
    // Estadísticas por programa y tipo
    if (!empty($estadisticas_origen_programa)) {
        echo "<tr><td colspan='10'></td></tr>";
        echo "<tr><th colspan='8' class='subtitulo'>ESTADÍSTICAS POR PROGRAMA Y TIPO</th></tr>";
        echo "<tr>";
        echo "<th>Programa</th>";
        echo "<th>Tipo (0/1)</th>";
        echo "<th>Tipo Descripción</th>";
        echo "<th>Estudiantes</th>";
        echo "<th>Encuestas</th>";
        echo "<th>% Trabaja</th>";
        echo "<th>% en Carrera</th>";
        echo "<th>Ingreso Promedio</th>";
        echo "</tr>";
        
        foreach ($estadisticas_origen_programa as $row) {
            $origen = $row['origen'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $tipo_numero = '';
            $clase = '';
            if (strpos($origen, 'Llamada') !== false) {
                $tipo_numero = '0';
                $clase = 'llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $tipo_numero = '1';
                $clase = 'correo';
            }
            
            echo "<tr class='" . $clase . "'>";
            echo "<td>" . htmlspecialchars($row['programa'] ?? '') . "</td>";
            echo "<td align='center'>" . $tipo_numero . "</td>";
            echo "<td>" . htmlspecialchars($origen) . "</td>";
            echo "<td align='center'>" . ($row['total_estudiantes'] ?? 0) . "</td>";
            echo "<td align='center'>" . ($row['total_encuestas'] ?? 0) . "</td>";
            echo "<td align='center'>" . ($row['porcentaje_trabaja'] ?? 0) . "%</td>";
            echo "<td align='center'>" . ($row['porcentaje_carrera'] ?? 0) . "%</td>";
            echo "<td align='right'>S/ " . number_format($row['ingreso_promedio'] ?? 0, 2) . "</td>";
            echo "</tr>";
        }
    }
    
    echo "</table>";
    
    // Resumen final con estadísticas
    echo "<div style='margin-top: 30px; padding: 15px; border: 1px solid #ddd; background-color: #f9f9f9;'>";
    echo "<h3>RESUMEN ESTADÍSTICO</h3>";
    
    if (!empty($origen_encuestas)) {
        $total_encuestas_llamada = 0;
        $total_encuestas_correo = 0;
        $total_estudiantes_llamada = 0;
        $total_estudiantes_correo = 0;
        $ingreso_llamada = 0;
        $ingreso_correo = 0;
        
        foreach ($origen_encuestas as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            if (strpos($origen, 'Llamada') !== false) {
                $total_encuestas_llamada = $row['total_encuestas'] ?? 0;
                $total_estudiantes_llamada = $row['total_estudiantes'] ?? 0;
                $ingreso_llamada = $row['ingreso_promedio'] ?? 0;
            } elseif (strpos($origen, 'Correo') !== false) {
                $total_encuestas_correo = $row['total_encuestas'] ?? 0;
                $total_estudiantes_correo = $row['total_estudiantes'] ?? 0;
                $ingreso_correo = $row['ingreso_promedio'] ?? 0;
            }
        }
        
        $total_encuestas = $total_encuestas_llamada + $total_encuestas_correo;
        $total_estudiantes = $total_estudiantes_llamada + $total_estudiantes_correo;
        
        echo "<p><strong>Total Encuestas por Llamada (tipo=0):</strong> " . $total_encuestas_llamada . " (" . ($total_encuestas > 0 ? round(($total_encuestas_llamada / $total_encuestas) * 100, 2) : 0) . "%)</p>";
        echo "<p><strong>Total Encuestas por Correo (tipo=1):</strong> " . $total_encuestas_correo . " (" . ($total_encuestas > 0 ? round(($total_encuestas_correo / $total_encuestas) * 100, 2) : 0) . "%)</p>";
        echo "<p><strong>Total General de Encuestas:</strong> " . $total_encuestas . "</p>";
        echo "<p><strong>Estudiantes por Llamada:</strong> " . $total_estudiantes_llamada . "</p>";
        echo "<p><strong>Estudiantes por Correo:</strong> " . $total_estudiantes_correo . "</p>";
        echo "<p><strong>Ingreso Promedio Llamada:</strong> S/ " . number_format($ingreso_llamada, 2) . "</p>";
        echo "<p><strong>Ingreso Promedio Correo:</strong> S/ " . number_format($ingreso_correo, 2) . "</p>";
    }
    
    if (!empty($comparativa_origen)) {
        echo "<h4>Comparativa de Resultados:</h4>";
        foreach ($comparativa_origen as $row) {
            $origen = $row['origen'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            echo "<p><strong>" . htmlspecialchars($origen) . ":</strong> " . ($row['porcentaje_trabaja'] ?? 0) . "% trabaja, " . ($row['porcentaje_trabaja_carrera'] ?? 0) . "% trabaja en su carrera</p>";
        }
    }
    
    echo "<p><strong>Generado:</strong> " . date('d/m/Y H:i:s') . "</p>";
    echo "</div>";
    
    echo "</body></html>";
    exit;
}

// ==============================
// EXPORTAR PDF - REPORTE GENERAL
// ==============================
if (isset($_POST['export_pdf'])) {
    require_once __DIR__."/../../vendor/autoload.php";
    
    $mpdf = new \Mpdf\Mpdf();
    
    $html = "<h2 style='text-align: center;'>Reporte General del Sistema</h2>";
    $html .= "<p style='text-align: center;'>Fecha: " . date('d/m/Y H:i:s') . "</p>";
    
    // Resumen general
    $html .= "<h3>Resumen General</h3>";
    if (!empty($total_egresados)) {
        $html .= "<p><strong>Total Egresados:</strong> " . $total_egresados . "</p>";
    }
    
    // Mostrar encuestas por tipo (CORREGIDO para Llamada/Correo)
    if (!empty($origen_encuestas)) {
        $total_encuestas_llamada = 0;
        $total_encuestas_correo = 0;
        
        foreach ($origen_encuestas as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            if (strpos($origen, 'Llamada') !== false) {
                $total_encuestas_llamada = $row['total_encuestas'] ?? 0;
            } elseif (strpos($origen, 'Correo') !== false) {
                $total_encuestas_correo = $row['total_encuestas'] ?? 0;
            }
        }
        
        $html .= "<p><strong>Encuestas por Llamada (tipo=0):</strong> " . $total_encuestas_llamada . "</p>";
        $html .= "<p><strong>Encuestas por Correo (tipo=1):</strong> " . $total_encuestas_correo . "</p>";
        $html .= "<p><strong>Total Encuestas:</strong> " . ($total_encuestas_llamada + $total_encuestas_correo) . "</p>";
    }
    
    // Empresas por sector
    if (!empty($empresas_sector)) {
        $html .= "<h3>Empresas por Sector</h3>";
        $html .= "<table border='1' style='width:100%; border-collapse: collapse; margin-bottom: 20px;'>";
        $html .= "<tr style='background-color: #4CAF50; color: white;'><th>Sector</th><th>Total Empresas</th></tr>";
        foreach ($empresas_sector as $row) {
            $html .= "<tr><td>" . htmlspecialchars($row['sector'] ?? 'No especificado') . "</td><td>" . ($row['total'] ?? 0) . "</td></tr>";
        }
        $html .= "</table>";
    }
    
    // Estudiantes por programa
    if (!empty($estudiantes_programa)) {
        $html .= "<h3>Estudiantes por Programa</h3>";
        $html .= "<table border='1' style='width:100%; border-collapse: collapse; margin-bottom: 20px;'>";
        $html .= "<tr style='background-color: #2196F3; color: white;'><th>Programa</th><th>Total Estudiantes</th></tr>";
        foreach ($estudiantes_programa as $row) {
            $html .= "<tr><td>" . htmlspecialchars($row['nom_progest'] ?? 'No especificado') . "</td><td>" . ($row['total_estudiantes'] ?? 0) . "</td></tr>";
        }
        $html .= "</table>";
    }
    
    // Tipo de encuestas (CORREGIDO para Llamada/Correo)
    if (!empty($origen_encuestas)) {
        $html .= "<h3>Estadísticas por Tipo de Encuesta</h3>";
        $html .= "<table border='1' style='width:100%; border-collapse: collapse; margin-bottom: 20px;'>";
        $html .= "<tr style='background-color: #FF9800; color: white;'>";
        $html .= "<th>Tipo (0=Llamada, 1=Correo)</th><th>Estudiantes</th><th>Encuestas</th><th>Ingreso Promedio</th>";
        $html .= "</tr>";
        foreach ($origen_encuestas as $row) {
            $origen = $row['origen_encuesta'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $tipo_numero = '';
            if (strpos($origen, 'Llamada') !== false) {
                $tipo_numero = '0 = Llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $tipo_numero = '1 = Correo';
            }
            
            $html .= "<tr>";
            $html .= "<td>" . $tipo_numero . " - " . htmlspecialchars($origen) . "</td>";
            $html .= "<td>" . ($row['total_estudiantes'] ?? 0) . "</td>";
            $html .= "<td>" . ($row['total_encuestas'] ?? 0) . "</td>";
            $html .= "<td>S/ " . (isset($row['ingreso_promedio']) ? number_format($row['ingreso_promedio'], 2) : '0.00') . "</td>";
            $html .= "</tr>";
        }
        $html .= "</table>";
    }
    
    // Comparativa por tipo (CORREGIDO para Llamada/Correo)
    if (!empty($comparativa_origen)) {
        $html .= "<h3>Comparativa por Tipo de Encuesta</h3>";
        $html .= "<table border='1' style='width:100%; border-collapse: collapse;'>";
        $html .= "<tr style='background-color: #9C27B0; color: white;'>";
        $html .= "<th>Tipo</th><th>Estudiantes</th><th>Ingreso Promedio</th><th>% Trabaja</th><th>% Trabaja en Carrera</th>";
        $html .= "</tr>";
        foreach ($comparativa_origen as $row) {
            $origen = $row['origen'] ?? '';
            
            // Transformar nombres
            if (strtolower($origen) === 'desconocido' || stripos($origen, 'desconocido') !== false) {
                $origen = 'Correo';
            } elseif (strtolower($origen) === 'encuesta interna' || stripos($origen, 'encuesta interna') !== false) {
                $origen = 'Llamada';
            }
            
            $tipo_numero = '';
            if (strpos($origen, 'Llamada') !== false) {
                $tipo_numero = '0 = Llamada';
            } elseif (strpos($origen, 'Correo') !== false) {
                $tipo_numero = '1 = Correo';
            }
            
            $html .= "<tr>";
            $html .= "<td>" . $tipo_numero . " - " . htmlspecialchars($origen) . "</td>";
            $html .= "<td>" . ($row['total_estudiantes'] ?? 0) . "</td>";
            $html .= "<td>S/ " . (isset($row['ingreso_promedio']) ? number_format($row['ingreso_promedio'], 2) : '0.00') . "</td>";
            $html .= "<td>" . ($row['porcentaje_trabaja'] ?? 0) . "%</td>";
            $html .= "<td>" . ($row['porcentaje_trabaja_carrera'] ?? 0) . "%</td>";
            $html .= "</tr>";
        }
        $html .= "</table>";
    }
    
    $mpdf->WriteHTML($html);
    $mpdf->Output("reporte_general_" . date('Y-m-d') . ".pdf", "D");
    exit;
}

// ==============================
// TABLA Y DATOS PARA GRÁFICO DE ORIGEN
// ==============================
// Prepara datos para el gráfico de origen
$grafico_origen_labels = [];
$grafico_origen_data = [];
$grafico_origen_colores = [];

if (!empty($origen_encuestas)) {
    $totalEncuestasGrafica = 0;
    
    foreach ($origen_encuestas as $row):
        $origen_original = $row['origen_encuesta'] ?? '';
        $origen_display = $origen_original;
        
        // Transformar nombres según lo solicitado
        if (strtolower($origen_original) === 'desconocido' || stripos($origen_original, 'desconocido') !== false) {
            $origen_display = 'Correo';
        } elseif (strtolower($origen_original) === 'encuesta interna' || stripos($origen_original, 'encuesta interna') !== false) {
            $origen_display = 'Llamada';
        }
        
        $totalEncuestasGrafica += $row['total_encuestas'] ?? 0;
    endforeach;
    
    // Agrupar datos por origen (Llamada, Correo, Otros)
    $agrupados = [];
    foreach ($origen_encuestas as $row) {
        $origen_original = $row['origen_encuesta'] ?? '';
        $origen_display = $origen_original;
        
        // Transformar nombres según lo solicitado
        if (strtolower($origen_original) === 'desconocido' || stripos($origen_original, 'desconocido') !== false) {
            $origen_display = 'Correo';
        } elseif (strtolower($origen_original) === 'encuesta interna' || stripos($origen_original, 'encuesta interna') !== false) {
            $origen_display = 'Llamada';
        }
        
        $origen = $origen_display;
        if (strpos($origen, 'Llamada') !== false) {
            $key = 'Llamada';
        } elseif (strpos($origen, 'Correo') !== false) {
            $key = 'Correo';
        } else {
            $key = 'Otros';
        }
        
        if (!isset($agrupados[$key])) {
            $agrupados[$key] = [
                'encuestas' => 0,
                'estudiantes' => 0
            ];
        }
        $agrupados[$key]['encuestas'] += $row['total_encuestas'] ?? 0;
        $agrupados[$key]['estudiantes'] += $row['total_estudiantes'] ?? 0;
    }
    
    // Preparar datos para gráfico
    foreach ($agrupados as $key => $valor) {
        if ($valor['encuestas'] > 0) {
            $grafico_origen_labels[] = $key;
            $grafico_origen_data[] = $valor['encuestas'];
            
            // Asignar colores según tipo
            if ($key === 'Llamada') {
                $grafico_origen_colores[] = 'rgba(76, 175, 80, 0.7)';
            } elseif ($key === 'Correo') {
                $grafico_origen_colores[] = 'rgba(33, 150, 243, 0.7)';
            } else {
                $grafico_origen_colores[] = 'rgba(158, 158, 158, 0.7)';
            }
        }
    }
}

// ==============================
// VISTA NORMAL
// ==============================
// Pasar las nuevas variables a la vista
ob_start();
include(__DIR__ . "/../view/reportes_view.php");
$content = ob_get_clean();

// Layout principal
include(__DIR__ . "/../layouts/layout.php");