<?php
// core/app/action/ubigeo-action.php

require_once "core/app/model/UbDepartamentoData.php";
require_once "core/app/model/UbProvinciaData.php";
require_once "core/app/model/UbDistritoData.php";

header('Content-Type: application/json');

if (isset($_GET['get_provincias']) && isset($_GET['departamento_id'])) {
    $departamento_id = intval($_GET['departamento_id']);
    $provincias = UbProvinciaData::getByDepartamento($departamento_id);
    
    $html = '<option value="">Seleccione Provincia</option>';
    foreach ($provincias as $provincia) {
        $html .= '<option value="' . $provincia->id . '">' . htmlspecialchars($provincia->provincia) . '</option>';
    }
    
    echo json_encode([
        'success' => true,
        'html' => $html
    ]);
    exit;
}

if (isset($_GET['get_distritos']) && isset($_GET['provincia_id'])) {
    $provincia_id = intval($_GET['provincia_id']);
    $distritos = UbDistritoData::getByProvincia($provincia_id);
    
    $html = '<option value="">Seleccione Distrito</option>';
    foreach ($distritos as $distrito) {
        $html .= '<option value="' . $distrito->id . '">' . htmlspecialchars($distrito->distrito) . '</option>';
    }
    
    echo json_encode([
        'success' => true,
        'html' => $html
    ]);
    exit;
}

if (isset($_GET['get_ubigeo_completo']) && isset($_GET['distrito_id'])) {
    $distrito_id = intval($_GET['distrito_id']);
    $distrito = UbDistritoData::getById($distrito_id);
    
    if ($distrito) {
        $provincia = UbProvinciaData::getById($distrito->ubprovincia);
        if ($provincia) {
            $departamento = UbDepartamentoData::getById($provincia->ubdepartamento);
            
            echo json_encode([
                'success' => true,
                'departamento_id' => $departamento->id,
                'provincia_id' => $provincia->id,
                'distrito_id' => $distrito->id
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Provincia no encontrada']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Distrito no encontrado']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Parámetros inválidos']);
?>