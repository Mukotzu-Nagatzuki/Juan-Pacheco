<?php
// core/app/action/usuario-action.php

// DIFERENCIAR ENTRE CREAR Y EDITAR
if (isset($_POST['usuario']) && isset($_POST['tipo'])) {
    
    // SI TIENE ID → ES EDICIÓN
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        try {
            // ACTUALIZAR USUARIO EXISTENTE
            $user = UserData::getById($_POST['id']);
            if (!$user) {
                throw new Exception("Usuario no encontrado");
            }
            
            $user->usuario = $_POST['usuario'];
            $user->tipo = $_POST['tipo'];
            
            // Verificar si el username ya existe (excluyendo el usuario actual)
            $existingUser = UserData::getByUsername($_POST['usuario']);
            if ($existingUser && $existingUser->id != $_POST['id']) {
                $_SESSION['error'] = "El nombre de usuario ya está en uso por otro usuario";
                header("Location: index.php?action=registros");
                exit;
            }
            
            // SI HAY CONTRASEÑA NUEVA
            if (!empty($_POST['password'])) {
                if (strlen($_POST['password']) < 6) {
                    $_SESSION['error'] = "La contraseña debe tener al menos 6 caracteres";
                    header("Location: index.php?action=registros");
                    exit;
                }
                $user->password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $user->update();
                $user->update_passwd();
            } else {
                // NO HAY CONTRASEÑA NUEVA
                $user->update();
            }
            
            $_SESSION['message'] = "Usuario actualizado exitosamente";
            header("Location: index.php?action=registros");
            exit;
            
        } catch (Exception $e) {
            $_SESSION['error'] = "Error al actualizar usuario: " . $e->getMessage();
            header("Location: index.php?action=registros");
            exit;
        }
        
    } else {
        // NO TIENE ID → ES CREACIÓN
        try {
            // CREAR NUEVO USUARIO
            $user = new UserData();
            $user->usuario = $_POST['usuario'];
            $user->tipo = $_POST['tipo'];
            
            // Verificar contraseña para creación
            if (!isset($_POST['password']) || empty($_POST['password'])) {
                $_SESSION['error'] = "La contraseña es requerida para crear un usuario";
                header("Location: index.php?action=registros");
                exit;
            }
            
            if (strlen($_POST['password']) < 6) {
                $_SESSION['error'] = "La contraseña debe tener al menos 6 caracteres";
                header("Location: index.php?action=registros");
                exit;
            }
            
            $user->password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            
            // Verificar si el usuario ya existe
            $existingUser = UserData::getByUsername($_POST['usuario']);
            if ($existingUser) {
                $_SESSION['error'] = "El nombre de usuario ya está en uso";
                header("Location: index.php?action=registros");
                exit;
            }
            
            $result = $user->add();
            if ($result) {
                $_SESSION['message'] = "Usuario creado exitosamente";
            } else {
                throw new Exception("Error al crear usuario en la base de datos");
            }
            
            header("Location: index.php?action=registros");
            exit;
            
        } catch (Exception $e) {
            $_SESSION['error'] = "Error al crear usuario: " . $e->getMessage();
            header("Location: index.php?action=registros");
            exit;
        }
    }
}

// Eliminar usuario
if (isset($_GET['action']) && $_GET['action'] == 'eliminar_usuario' && isset($_GET['id'])) {
    try {
        // Prevenir eliminación del usuario actual
        if ($_GET['id'] == $_SESSION['userid']) {
            $_SESSION['error'] = "No puede eliminar su propio usuario";
        } else {
            $result = UserData::delById($_GET['id']);
            if ($result) {
                $_SESSION['message'] = "Usuario eliminado exitosamente";
            } else {
                throw new Exception("Error al eliminar usuario");
            }
        }
        header("Location: index.php?action=registros");
        exit;
    } catch (Exception $e) {
        $_SESSION['error'] = "Error al eliminar usuario: " . $e->getMessage();
        header("Location: index.php?action=registros");
        exit;
    }
}

// SI ES UNA PETICIÓN GET (mostrar lista de usuarios)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Verificar si la acción es registros o no hay acción específica
        if (!isset($_GET['action']) || $_GET['action'] == 'registros') {
            // Cargar todos los usuarios para la lista
            $users = UserData::getAll();
            
            ob_start();
            // Asegúrate de que esta ruta sea correcta
            $viewPath = __DIR__ . "/../view/usuarios-view.php";
            if (!file_exists($viewPath)) {
                throw new Exception("Vista no encontrada: " . $viewPath);
            }
            include($viewPath);
            $content = ob_get_clean();
            
            // Incluir el layout completo pasando el contenido
            $layoutPath = __DIR__ . "/../layouts/layout.php";
            if (!file_exists($layoutPath)) {
                throw new Exception("Layout no encontrado: " . $layoutPath);
            }
            include($layoutPath);
            exit;
        }
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}