<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once "core/app/model/ActividadesData.php";

// Manejar las acciones POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $operation = $_POST['operation'] ?? '';
    
    switch($operation) {
        case 'create':
            // Crear nueva actividad
            if (isset($_POST['titulo']) && isset($_POST['fecha_inicio']) && isset($_POST['fecha_fin'])) {
                try {
                    $actividad = new ActividadesData();
                    $actividad->titulo = trim($_POST['titulo']);
                    $actividad->descripcion = trim($_POST['descripcion'] ?? '');
                    $actividad->fecha_inicio = trim($_POST['fecha_inicio']);
                    $actividad->fecha_fin = trim($_POST['fecha_fin']);
                    $actividad->estado = intval($_POST['estado'] ?? 1);
                    
                    // Validaciones básicas
                    if (empty($actividad->titulo)) {
                        throw new Exception("El título es requerido");
                    }
                    
                    if ($actividad->fecha_fin < $actividad->fecha_inicio) {
                        throw new Exception("La fecha de fin no puede ser anterior a la fecha de inicio");
                    }
                    
                    // ✅ VALIDACIÓN 1: Verificar si existe actividad con exactamente las mismas fechas
                    if (ActividadesData::existeActividadConMismasFechas($actividad->fecha_inicio, $actividad->fecha_fin)) {
                        $actividadDuplicada = ActividadesData::getActividadConMismasFechas($actividad->fecha_inicio, $actividad->fecha_fin);
                        throw new Exception("❌ Ya existe una actividad programada con exactamente las mismas fechas:\n" .
                                           "Actividad: " . htmlspecialchars($actividadDuplicada->titulo) . "\n" .
                                           "Período: " . date('d/m/Y', strtotime($actividadDuplicada->fecha_inicio)) . 
                                           " al " . date('d/m/Y', strtotime($actividadDuplicada->fecha_fin)));
                    }
                    
                    // ✅ VALIDACIÓN 2: Verificar solapamiento de rangos de fechas
                    if (ActividadesData::existeSolapamientoDeFechas($actividad->fecha_inicio, $actividad->fecha_fin)) {
                        $actividadSolapada = ActividadesData::getActividadSolapada($actividad->fecha_inicio, $actividad->fecha_fin);
                        throw new Exception("❌ Ya existe una actividad programada que se solapa con estas fechas:\n" .
                                           "Actividad: " . htmlspecialchars($actividadSolapada->titulo) . "\n" .
                                           "Período: " . date('d/m/Y', strtotime($actividadSolapada->fecha_inicio)) . 
                                           " al " . date('d/m/Y', strtotime($actividadSolapada->fecha_fin)));
                    }
                    
                    $result = $actividad->add();
                    
                    if ($result[0]) {
                        $_SESSION['message'] = "✅ Configuración de encuesta creada correctamente";
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['error'] = "Error al crear configuración: " . $result[1];
                        $_SESSION['error_type'] = 'error';
                    }
                    
                } catch (Exception $e) {
                    $_SESSION['error'] = $e->getMessage();
                    $_SESSION['error_type'] = 'error';
                }
            }
            break;
            
        case 'toggle':
            // Activar/Desactivar actividad
            if (isset($_POST['id'])) {
                $id = intval($_POST['id']);
                $result = ActividadesData::toggleEstado($id);
                
                if ($result[0]) {
                    $_SESSION['message'] = "✅ Estado de configuración actualizado";
                    $_SESSION['message_type'] = 'success';
                } else {
                    $_SESSION['error'] = "Error al actualizar estado";
                    $_SESSION['error_type'] = 'error';
                }
            }
            break;
            
        case 'delete':
            // Eliminar actividad
            if (isset($_POST['id'])) {
                $id = intval($_POST['id']);
                $result = ActividadesData::deleteById($id);
                
                if ($result[0]) {
                    $_SESSION['message'] = "✅ Configuración eliminada correctamente";
                    $_SESSION['message_type'] = 'success';
                } else {
                    $_SESSION['error'] = "Error al eliminar configuración";
                    $_SESSION['error_type'] = 'error';
                }
            }
            break;
    }
    
    // Redirigir de vuelta a la página de actividades
    header("Location: index.php?action=actividades");
    exit();
}

// Si es GET, mostrar la vista
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // ----- CARGAR VISTA -----
    ob_start();
    include("core/app/view/actividades_view.php");
    $content = ob_get_clean();
    
    include("core/app/layouts/layout.php");
}
?>