<?php 
require_once "core/app/model/EgresadoData.php";

$actions = $_POST['actions'];

if ($actions == 1) {
    $egresado = new EgresadoData();
    $egresado->dni_est = $_POST['dni'];
    $egresado->ap_est = $_POST['apellido_paterno'];
    $egresado->am_est = $_POST['apellido_materno'];
    $egresado->nom_est = $_POST['nombres'];
    $egresado->cel_est = $_POST['numero_telefonico'];
    $egresado->mailp_est = $_POST['correo'];
    $egresado->maili_est = $_POST['correo'];
    
    // Para ubigeo, necesitaríamos mapear distrito y región a ubigeodir_est
    // Por ahora lo dejamos vacío o habría que crear una función para convertir
    $egresado->ubigeodir_est = '';
    
    $egresado->add();
    header("Location: index.php?action=egresado");
}

if ($actions == 2) {
    $egresado = new EgresadoData();
    $egresado->id = $_POST['id_egresado'];
    $egresado->dni_est = $_POST['dni'];
    $egresado->ap_est = $_POST['apellido_paterno'];
    $egresado->am_est = $_POST['apellido_materno'];
    $egresado->nom_est = $_POST['nombres'];
    $egresado->cel_est = $_POST['numero_telefonico'];
    $egresado->mailp_est = $_POST['correo'];
    $egresado->maili_est = $_POST['correo'];
    $egresado->ubigeodir_est = '';
    
    $egresado->update();
    header("Location: index.php?action=egresado");
}

if ($actions == 3) {
    EgresadoData::delete($_POST['id_egresado']);
    header("Location: index.php?action=egresado");
}
?>