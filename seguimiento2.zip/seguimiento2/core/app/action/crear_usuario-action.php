<?php
// ============================================
// 🧩 Acción: Crear nuevo usuario (desde modal)
// ============================================

require_once(__DIR__ . '/../model/UserData.php');
require_once(__DIR__ . '/../../config/Executor.php'); // si usas Executor
require_once(__DIR__ . '/../../config/Model.php');    // si usas Model

header('Content-Type: application/json; charset=utf-8');

// Validar campos
if (
    empty($_POST['usuario']) ||
    empty($_POST['password']) ||
    empty($_POST['tipo'])
) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan campos obligatorios.']);
    exit;
}

try {
    $user = new UserData();
    $user->usuario = $_POST['usuario'];
    $user->password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $user->tipo = intval($_POST['tipo']);
    $user->estuempleado = 0; // si no estás usando ese campo por ahora
    $user->token = bin2hex(random_bytes(8));

    $result = $user->add();

    if ($result) {
        echo json_encode(['status' => 'ok', 'message' => 'Usuario creado correctamente']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo crear el usuario']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error interno: ' . $e->getMessage()]);
}
