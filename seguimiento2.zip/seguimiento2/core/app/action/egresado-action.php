<?php 
// core/app/action/egresado-action.php

require_once "core/app/model/EgresadoData.php";
require_once "core/app/model/ProgramaData.php";
require_once "core/app/model/CondicionAcademicaData.php";
require_once "core/app/model/UbigeoData.php";

// DEBUG: Mostrar información sobre la base de datos
error_log("=== EGRESADO ACTION INICIADO ===");

require_once "core/app/model/EgresadoData.php";
require_once "core/app/model/ProgramaData.php";
require_once "core/app/model/CondicionAcademicaData.php";
require_once "core/app/model/UbigeoData.php";

// ========== MANEJO DE PETICIONES AJAX PARA UBIGEO ==========

if (isset($_GET['get_provincias']) || isset($_GET['get_distritos']) || isset($_GET['get_ubigeo_completo'])) {
    require_once "core/app/model/UbDepartamentoData.php";
    require_once "core/app/model/UbProvinciaData.php";
    require_once "core/app/model/UbDistritoData.php";
    
    header('Content-Type: application/json');
    
    if (isset($_GET['get_provincias']) && isset($_GET['departamento_id'])) {
        $departamento_id = intval($_GET['departamento_id']);
        $provincias = UbProvinciaData::getByDepartamento($departamento_id);
        
        $html = '<option value="">Seleccione Provincia</option>';
        foreach ($provincias as $provincia) {
            $html .= '<option value="' . $provincia->id . '">' . htmlspecialchars($provincia->provincia) . '</option>';
        }
        
        echo json_encode(array(
            'success' => true,
            'html' => $html
        ));
        exit;
    }
    
    if (isset($_GET['get_distritos']) && isset($_GET['provincia_id'])) {
        $provincia_id = intval($_GET['provincia_id']);
        $distritos = UbDistritoData::getByProvincia($provincia_id);
        
        $html = '<option value="">Seleccione Distrito</option>';
        foreach ($distritos as $distrito) {
            $html .= '<option value="' . $distrito->id . '">' . htmlspecialchars($distrito->distrito) . '</option>';
        }
        
        echo json_encode(array(
            'success' => true,
            'html' => $html
        ));
        exit;
    }
    
    if (isset($_GET['get_ubigeo_completo']) && isset($_GET['distrito_id'])) {
        $distrito_id = intval($_GET['distrito_id']);
        $distrito = UbDistritoData::getById($distrito_id);
        
        if ($distrito) {
            $provincia = UbProvinciaData::getById($distrito->ubprovincia);
            if ($provincia) {
                $departamento = UbDepartamentoData::getById($provincia->ubdepartamento);
                
                echo json_encode(array(
                    'success' => true,
                    'departamento_id' => $departamento->id,
                    'provincia_id' => $provincia->id,
                    'distrito_id' => $distrito->id
                ));
            } else {
                echo json_encode(array('success' => false, 'message' => 'Provincia no encontrada'));
            }
        } else {
            echo json_encode(array('success' => false, 'message' => 'Distrito no encontrado'));
        }
        exit;
    }
    
    echo json_encode(array('success' => false, 'message' => 'Parámetros inválidos'));
    exit;
}

// ========== MANEJO DE ELIMINACIÓN ==========

if (isset($_GET['action']) && $_GET['action'] == 'buscar_estudiante' && isset($_GET['dni'])) {
    $dni = trim($_GET['dni']);
    $estudiante = EgresadoData::getEstudianteByDni($dni);
    
    if ($estudiante) {
        // Verificar si se está editando (tiene parámetro edit_id)
        $edit_id = isset($_GET['edit_id']) ? intval($_GET['edit_id']) : 0;
        
        // Si estamos editando y el ID coincide, no es un duplicado
        if ($edit_id > 0 && $estudiante->id == $edit_id) {
            $response = array('success' => false, 'message' => 'Es el mismo registro', 'is_self' => true);
        } else {
            // Es un duplicado real
            $response = array(
                'success' => true,
                'is_duplicate' => true,
                'data' => array(
                    'id' => $estudiante->id,
                    'dni' => $estudiante->dni_est,
                    'nombres' => $estudiante->nom_est . ' ' . $estudiante->ap_est . ' ' . $estudiante->am_est
                )
            );
        }
    } else {
        $response = array('success' => false, 'is_duplicate' => false, 'message' => 'DNI disponible');
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}
// ========== MANEJO DE BÚSQUEDA Y AUTOCOMPLETADO ==========

if (isset($_GET['action']) && $_GET['action'] == 'buscar_estudiante' && isset($_GET['dni'])) {
    $estudiante = EgresadoData::getEstudianteByDni($_GET['dni']);
    if ($estudiante) {
        $ubigeoData = null;
        if (!empty($estudiante->ubigeodir_est)) {
            $ubigeoData = UbigeoData::getUbigeoCompleto($estudiante->ubigeodir_est);
        }
        
        if ($ubigeoData) {
            $response = array(
                'success' => true,
                'data' => array(
                    'id_estudiante' => $estudiante->id,
                    'apellido_paterno' => $estudiante->ap_est,
                    'apellido_materno' => $estudiante->am_est,
                    'nombres' => $estudiante->nom_est,
                    'correo' => $estudiante->mailp_est,
                    'numero_telefonico' => $estudiante->cel_est,
                    'estado' => $estudiante->tipo_estado,
                    'ubigeo_distrito' => $estudiante->ubigeodir_est,
                    'departamento_id' => $ubigeoData->departamento_id,
                    'provincia_id' => $ubigeoData->provincia_id,
                    'distrito_id' => $ubigeoData->distrito_id
                )
            );
        } else {
            $response = array(
                'success' => true,
                'data' => array(
                    'id_estudiante' => $estudiante->id,
                    'apellido_paterno' => $estudiante->ap_est,
                    'apellido_materno' => $estudiante->am_est,
                    'nombres' => $estudiante->nom_est,
                    'correo' => $estudiante->mailp_est,
                    'numero_telefonico' => $estudiante->cel_est,
                    'estado' => $estudiante->tipo_estado,
                    'ubigeo_distrito' => '',
                    'departamento_id' => '',
                    'provincia_id' => '',
                    'distrito_id' => ''
                )
            );
        }
    } else {
        $response = array('success' => false, 'message' => 'Estudiante no encontrado');
    }
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// ========== MANEJO DE OPERACIONES PRINCIPALES ==========

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['actions'])) {
    $actions = $_POST['actions'];
    
    if ($actions == 1) {
        $dni = trim($_POST['dni'] ?? '');
        $apellidoPaterno = trim($_POST['apellido_paterno'] ?? '');
        $apellidoMaterno = trim($_POST['apellido_materno'] ?? '');
        $nombres = trim($_POST['nombres'] ?? '');
        $correo = trim($_POST['correo'] ?? '');
        $telefono = trim($_POST['numero_telefonico'] ?? '');
        $estado = trim($_POST['estado'] ?? 'estudiante');
        
        if (empty($dni) || empty($apellidoPaterno) || empty($nombres) || empty($correo)) {
            $_SESSION['error'] = "Todos los campos obligatorios deben ser completados";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (!preg_match('/^\d{8}$/', $dni)) {
            $_SESSION['error'] = "El DNI debe tener 8 dígitos";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (!empty($telefono) && !preg_match('/^\d{9}$/', $telefono)) {
            $_SESSION['error'] = "El teléfono debe tener 9 dígitos";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = "El correo electrónico no es válido";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        $existente = EgresadoData::getEstudianteByDni($dni);
        if ($existente) {
            $_SESSION['error'] = "Ya existe un estudiante/egresado con este DNI";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        $egresado = new EgresadoData();
        $egresado->dni_est = $dni;
        $egresado->ap_est = $apellidoPaterno;
        $egresado->am_est = $apellidoMaterno;
        $egresado->nom_est = $nombres;
        $egresado->mailp_est = $correo;
        $egresado->maili_est = $correo;
        $egresado->cel_est = $telefono;
        $egresado->estado = $estado;
        $egresado->ubigeodir_est = !empty($_POST['distrito']) ? $_POST['distrito'] : '';
        
        $result = $egresado->add();
        if ($result[0]) {
            $_SESSION['message'] = ($estado == 'egresado' ? 'Egresado' : 'Estudiante') . " registrado correctamente";
        } else {
            $_SESSION['error'] = "Error al registrar: " . $result[1];
        }
        header("Location: index.php?action=egresado");
        exit();
    }

    if ($actions == 2) {
        $id = intval($_POST['id_egresado'] ?? 0);
        $dni = trim($_POST['dni'] ?? '');
        $apellidoPaterno = trim($_POST['apellido_paterno'] ?? '');
        $apellidoMaterno = trim($_POST['apellido_materno'] ?? '');
        $nombres = trim($_POST['nombres'] ?? '');
        $correo = trim($_POST['correo'] ?? '');
        $telefono = trim($_POST['numero_telefonico'] ?? '');
        $estado = trim($_POST['estado'] ?? 'estudiante');
        
        if ($id <= 0) {
            $_SESSION['error'] = "ID de egresado no válido";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (empty($dni) || empty($apellidoPaterno) || empty($nombres) || empty($correo)) {
            $_SESSION['error'] = "Todos los campos obligatorios deben ser completados";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (!preg_match('/^\d{8}$/', $dni)) {
            $_SESSION['error'] = "El DNI debe tener 8 dígitos";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (!empty($telefono) && !preg_match('/^\d{9}$/', $telefono)) {
            $_SESSION['error'] = "El teléfono debe tener 9 dígitos";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = "El correo electrónico no es válido";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        $existente = EgresadoData::getEstudianteByDni($dni);
        if ($existente && $existente->id != $id) {
            $_SESSION['error'] = "Ya existe otro estudiante/egresado con este DNI";
            header("Location: index.php?action=egresado");
            exit();
        }
        
        $egresado = new EgresadoData();
        $egresado->id = $id;
        $egresado->dni_est = $dni;
        $egresado->ap_est = $apellidoPaterno;
        $egresado->am_est = $apellidoMaterno;
        $egresado->nom_est = $nombres;
        $egresado->mailp_est = $correo;
        $egresado->maili_est = $correo;
        $egresado->cel_est = $telefono;
        $egresado->estado = $estado;
        $egresado->ubigeodir_est = !empty($_POST['distrito']) ? $_POST['distrito'] : '';
        
        $result = $egresado->update();
        if ($result[0]) {
            $_SESSION['message'] = ($estado == 'egresado' ? 'Egresado' : 'Estudiante') . " actualizado correctamente";
        } else {
            $_SESSION['error'] = "Error al actualizar: " . $result[1];
        }
        header("Location: index.php?action=egresado");
        exit();
    }
}

// ========== OBTENER DATOS PARA LA VISTA ==========

$egresados = EgresadoData::getAll();
$programas = ProgramaData::getAll();
$condiciones = CondicionAcademicaData::getAll();
$departamentos = UbigeoData::getDepartamentos();

ob_start();
include(__DIR__ . "/../view/egresado-view.php");
$content = ob_get_clean();

include(__DIR__ . "/../layouts/layout.php");
?>