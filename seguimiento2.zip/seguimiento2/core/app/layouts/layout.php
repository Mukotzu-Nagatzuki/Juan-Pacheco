<?php
// Verificar si la sesión ya está activa antes de iniciarla
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Función para obtener iniciales del nombre
function obtenerIniciales($nombre) {
    $palabras = explode(' ', $nombre);
    $iniciales = '';
    
    if (count($palabras) >= 2) {
        $iniciales = strtoupper(substr($palabras[0], 0, 1) . substr($palabras[1], 0, 1));
    } else {
        $iniciales = strtoupper(substr($nombre, 0, 2));
    }
    
    return $iniciales;
}

// Verificar si el usuario está logueado
if (isset($_SESSION['userid'])) {
    // Obtener iniciales del usuario
    $nombreUsuario = $_SESSION['username'] ?? 'Usuario';
    $iniciales = obtenerIniciales($nombreUsuario);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SIBE</title>
    <link rel="stylesheet" href="assets/css/dashboard.css">
    
    <!-- Boxicons con múltiples fuentes de respaldo -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/admin.css">
    <link rel="stylesheet" href="assets/css/egresado.css">
    <link rel="stylesheet" href="assets/css/empresas.css">
    <link rel="stylesheet" href="assets/css/usuario.css">
    <link rel="stylesheet" href="assets/css/encuesta.css">
    <link rel="stylesheet" href="assets/css/historial.css">
    <style>
        /* Estilos de respaldo para iconos */
        .icon-fallback::before {
            content: "□";
            font-family: Arial, sans-serif;
            margin-right: 8px;
        }
        
        /* Asegurar que los iconos tengan estilo consistente */
        .bx {
            font-size: 1.2em;
            min-width: 24px;
            display: inline-block;
        }
    </style>
</head>

<body class="dashboard-body">
    <!-- Sidebar -->
    <?php
    $current_page = isset($_GET['action']) ? $_GET['action'] : 'dashboard';
    ?>
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="institution-section">
                <div class="institution-info">
                    <div class="institution-logo-name">
                        <img src="assets/img/inst.png" alt="Logo" class="header-logo" />
                        <span class="institution-name">IESTP AACD</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="sidebar-content">
            <ul class="menu-list">
                <li class="menu-item">
                    <a href="index.php" class="menu-link <?php echo $current_page == 'dashboard' ? 'active' : ''; ?>"
                        data-tooltip="Dashboard">
                        <i class="bx bx-home"></i>
                        <span class="menu-label">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=registros"
                        class="menu-link <?php echo $current_page == 'registros' ? 'active' : ''; ?>"
                        data-tooltip="registros">
                        <i class="bx bx-folder"></i>
                        <span class="menu-label">Gestión de Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=egresado"
                        class="menu-link <?php echo $current_page == 'egresado' ? 'active' : ''; ?>"
                        data-tooltip="egresado">
                        <i class="bx bx-user-pin"></i>
                        <span class="menu-label">Registro de Egresados</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=empresas"
                        class="menu-link <?php echo $current_page == 'empresas' ? 'active' : ''; ?>"
                        data-tooltip="empresas">
                        <i class="bx bx-building"></i>
                        <span class="menu-label">Empresas</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=situacion"
                        class="menu-link <?php echo $current_page == 'situacion' ? 'active' : ''; ?>"
                        data-tooltip="situacion-laboral">
                        <i class="bx bx-briefcase"></i>
                        <span class="menu-label">Situación Laboral</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=encuesta"
                        class="menu-link <?php echo $current_page == 'encuesta' ? 'active' : ''; ?>"
                        data-tooltip="encuesta">
                        <i class="bx bx-list-check"></i>
                        <span class="menu-label">Encuesta</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=actividades"
                        class="menu-link <?php echo $current_page == 'actividades' ? 'active' : ''; ?>"
                        data-tooltip="actividades-laboral">
                        <i class="bx bx-network-chart"></i>
                        <span class="menu-label">Actividades</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?action=reportes"
                        class="menu-link <?php echo $current_page == 'reportes' ? 'active' : ''; ?>"
                        data-tooltip="reportes">
                        <i class="bx bx-bar-chart-alt"></i>
                        <span class="menu-label">Reportes</span>
                    </a>
                </li>

            </ul>
        </div>

        <div class="sidebar-footer">
            <a href="salir.php" class="logout-btn">
                <div class="logout-label">
                    <i class="bx bx-log-out"></i>
                    <span class="logout-text">Cerrar Sesión</span>
                </div>
            </a>
        </div>
    </aside>

    <!-- Header -->
    <header class="main-header">
        <div class="header-content">
            <div class="header-left">
                <button class="header-toggle">
                    <i class="bx bx-menu"></i>
                </button>
                <h1 class="header-title">Sistema de bienestar y empleabilidad</h1>
            </div>
            <div class="user-profile">
                <div class="user-avatar">
                    <span class="avatar-initials"><?php echo $iniciales; ?></span>
                </div>
                <div class="user-details">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role">Administrador</span>
                </div>
                <i class='bx bx-chevron-down profile-arrow'></i>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <?php
        // Aquí se incluirá el contenido específico de cada página
        if (isset($content)) {
            echo $content;
        } else {
            // Por defecto, cargar el dashboard
            include 'core/app/view/dashboard_view.php';
        }
        ?>
        
        <!-- Sección de prueba de iconos (puedes eliminar esto después) -->
        <div style="display: none;" id="icon-test">
            <h4>Prueba de iconos:</h4>
            <i class='bx bx-home'></i> Home<br>
            <i class='bx bx-folder'></i> Folder<br>
            <i class='bx bx-user-pin'></i> User<br>
            <i class='bx bx-building'></i> Building<br>
            <i class='bx bx-log-out'></i> Logout
        </div>
    </main>

    <script src="assets/js/dashboard.js"></script>
    <script>
        // Verificar si los iconos están cargados
        document.addEventListener('DOMContentLoaded', function() {
            // Verificar si los iconos de Boxicons están cargados
            setTimeout(function() {
                const testIcon = document.querySelector('.bx');
                if (testIcon && getComputedStyle(testIcon).fontFamily.indexOf('boxicons') === -1) {
                    console.warn('Boxicons no se cargaron correctamente');
                    
                    // Mostrar mensaje de advertencia en consola
                    console.log('Intentando cargar Boxicons desde CDN alternativo...');
                    
                    // Crear link alternativo
                    const link = document.createElement('link');
                    link.rel = 'stylesheet';
                    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.4/css/boxicons.min.css';
                    document.head.appendChild(link);
                } else {
                    console.log('Boxicons cargados correctamente');
                }
            }, 1000);

            // Toggle del sidebar desde el header
            const headerToggle = document.querySelector('.header-toggle');
            const sidebar = document.querySelector('.sidebar');
            
            if (headerToggle && sidebar) {
                headerToggle.addEventListener('click', function() {
                    sidebar.classList.toggle('collapsed');
                });
            }
        });
    </script>
</body>

</html>
<?php
} else {
    // Usuario no logueado - mostrar login
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SIBE</title>
    <link rel="stylesheet" href="assets/css/login.css">
    
    <!-- Boxicons con múltiples fuentes de respaldo -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <style>
        /* Estilos de respaldo para iconos en login */
        .bx {
            font-size: 1.2em;
            min-width: 20px;
            display: inline-block;
        }
        
        .icon-fallback::before {
            content: "□";
            font-family: Arial, sans-serif;
            margin-right: 8px;
        }
    </style>
</head>

<body class="login-body">
    <div class="login-container">
        <div class="login-card">
            <!-- Header con Logo -->
            <div class="login-header">
                <div class="logo-section">
                    <div class="logo-text">
                        <h1>SISTEMA DE <br> SEGUIMIENTO DE EGRESADOS</h1>
                    </div>
                </div>
            </div>
            <!-- Formulario -->
            <div class="form-section">
                <div class="form-header">
                    <p>Ingresa tus credenciales para continuar</p>
                </div>

                <form action="index.php?action=acceso" method="POST" id="loginForm" class="login-form">
                    <div class="input-group">
                        <div class="input-container">
                            <i class='bx bxs-user'></i>
                            <input type="text" id="usuario" placeholder=" " name="usuario" required
                                value="<?php echo isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : ''; ?>">
                            <label for="usuario">Usuario</label>
                        </div>
                    </div>

                    <div class="input-group">
                        <div class="input-container">
                            <i class='bx bxs-lock-alt'></i>
                            <input type="password" id="password" placeholder=" " name="password" required>
                            <label for="contrasena">Contraseña</label>
                            <i id="togglePassword" class='bx bx-hide password-toggle'></i>
                        </div>
                    </div>

                    <button type="submit" class="login-btn">
                        <i class='bx bx-log-in-circle'></i>
                        <span class="btn-text">Ingresar al Sistema</span>
                        <i class='bx bx-chevron-right'></i>
                    </button>
                </form>

                <?php if (isset($_SESSION['error']) && !empty($_SESSION['error'])): ?>
                    <div id="error-message" class="error-global" data-auto-hide="true">
                        <i class='bx bx-error-circle'></i>
                        <span><?php echo htmlspecialchars($_SESSION['error']); ?></span>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
            </div>

            <!-- Footer -->
            <div class="login-footer">
                <p>&copy; 2025-LUMINID</p>
            </div>
        </div>

        <!-- Lado derecho con mensaje elegante -->
        <div class="welcome-section">
            <div class="welcome-content">
                <!-- Logo y nombre de institución -->
                <div class="institution-header">
                    <div class="institution-logo">
                        <img src="assets/img/inst.png" alt="Logo ESTP AACD" class="institution-logo-img">
                    </div>
                    <div class="institution-name">
                        <h2 class="institution-title">IESTP"ANDRES AVELINO CASERES DORREGARAY"</h2>
                    </div>
                </div>
                
                <!-- Título principal -->
                <h1 class="welcome-title">
                    TRANSFORMANDO FUTUROS A TRAVÉS DE LA EDUCACIÓN
                </h1>
                
                <p class="welcome-subtitle">
                    Seguimiento del egresado
                </p>
                <div class="welcome-divider"></div>
                <p class="welcome-description">
                    Gestiona el seguimiento de egresados y optimiza los procesos
                    de bienestar estudiantil con nuestra plataforma especializada.
                </p>
                
                <!-- Información adicional -->
                <div class="additional-info">
                    <div class="info-item">
                        <i class='bx bx-shield-quarter'></i>
                        <span>Plataforma segura y confiable</span>
                    </div>
                    <div class="info-item">
                        <i class='bx bx-trending-up'></i>
                        <span>Reportes en tiempo real</span>
                    </div>
                    <div class="info-item">
                        <i class='bx bx-group'></i>
                        <span>Gestión integral de egresados</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/login.js"></script>
    <script>
        // Verificación de iconos en login
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const icons = document.querySelectorAll('.bx');
                if (icons.length > 0) {
                    const firstIcon = icons[0];
                    const style = getComputedStyle(firstIcon);
                    if (style.fontFamily.indexOf('boxicons') === -1) {
                        console.warn('Boxicons no cargados en login - cargando alternativa');
                        
                        // Cargar CDN alternativo
                        const altLink = document.createElement('link');
                        altLink.rel = 'stylesheet';
                        altLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.4/css/boxicons.min.css';
                        document.head.appendChild(altLink);
                    }
                }
            }, 500);
        });
    </script>
</body>

</html>
<?php } ?>