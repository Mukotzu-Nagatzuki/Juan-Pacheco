<?php
/**
 * Funciones de seguridad para SIBE
 */

/**
 * Genera un token CSRF seguro
 */
function generarTokenCSRF() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifica un token CSRF
 */
function verificarTokenCSRF($token) {
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Valida si el usuario está autenticado y la sesión es segura
 */
function validarSesionSegura() {
    if (!isset($_SESSION['userid'])) {
        return false;
    }
    
    // Verificar timeout de sesión (30 minutos)
    if (isset($_SESSION['last_login']) && (time() - $_SESSION['last_login'] > 1800)) {
        session_destroy();
        return false;
    }
    
    // Verificar User-Agent (protección básica)
    if (isset($_SESSION['user_agent']) && $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
        session_destroy();
        return false;
    }
    
    // Actualizar último acceso
    $_SESSION['last_login'] = time();
    
    return true;
}

/**
 * Limpia entrada de usuario para prevenir XSS
 */
function limpiarEntrada($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/**
 * Verifica fortaleza de contraseña
 */
function validarFortalezaPassword($password) {
    if (strlen($password) < 8) {
        return "La contraseña debe tener al menos 8 caracteres";
    }
    
    if (!preg_match('/[A-Z]/', $password)) {
        return "La contraseña debe tener al menos una mayúscula";
    }
    
    if (!preg_match('/[a-z]/', $password)) {
        return "La contraseña debe tener al menos una minúscula";
    }
    
    if (!preg_match('/[0-9]/', $password)) {
        return "La contraseña debe tener al menos un número";
    }
    
    return true;
}
?>