<?php
// core/app/model/DashboardData.php

class DashboardData {
    
    // Obtener estadísticas del dashboard
    public static function getStats() {
        $sql = "SELECT 
            (SELECT COUNT(*) FROM estudiante) as total_estudiantes,
            (SELECT COUNT(*) FROM empresa) as total_empresas,
            (SELECT COUNT(*) FROM prog_estudios) as total_programas,
            (SELECT COUNT(*) FROM situacion_laboral) as empleados_activos";
        
        $query = Executor::doit($sql);
        return Model::one($query[0], new stdClass());
    }
    
    // Obtener últimos estudiantes
    public static function getUltimosEstudiantes($limit = 5) {
        $sql = "SELECT * FROM estudiante ORDER BY id DESC LIMIT {$limit}";
        $query = Executor::doit($sql);
        return Model::many($query[0], new EgresadoData());
    }
    
    // Obtener distribución por programas
    public static function getDistribucionProgramas() {
        $sql = "SELECT 
            p.nom_progest as programa,
            COUNT(m.id) as total_estudiantes
        FROM prog_estudios p
        LEFT JOIN matricula m ON m.prog_estudios = p.id
        GROUP BY p.id, p.nom_progest
        ORDER BY total_estudiantes DESC";
        
        $query = Executor::doit($sql);
        return Model::many($query[0], new stdClass());
    }
    
    // Obtener situación laboral
    public static function getSituacionLaboral() {
        $sql = "SELECT 
            p.nom_progest as programa,
            COUNT(DISTINCT m.estudiante) as total_egresados,
            COUNT(DISTINCT CASE WHEN sl.id IS NOT NULL THEN m.estudiante END) as empleados
        FROM prog_estudios p
        LEFT JOIN matricula m ON m.prog_estudios = p.id
        LEFT JOIN situacion_laboral sl ON sl.estudiante = m.estudiante
        GROUP BY p.id, p.nom_progest
        ORDER BY p.nom_progest";
        
        $query = Executor::doit($sql);
        $result = Model::many($query[0], new stdClass());
        
        // Calcular tasa de empleo
        foreach ($result as $programa) {
            $programa->total_egresados = (int)$programa->total_egresados;
            $programa->empleados = (int)$programa->empleados;
            $programa->tasa_empleo = $programa->total_egresados > 0 
                ? round(($programa->empleados * 100.0 / $programa->total_egresados), 2)
                : 0;
        }
        
        return $result;
    }
}
?>