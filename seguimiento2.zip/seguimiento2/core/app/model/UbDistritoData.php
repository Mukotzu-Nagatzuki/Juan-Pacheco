<?php
class UbDistritoData {
    public static $tablename = "ubdistrito";

    public $id;
    public $distrito;
    public $ubprovincia;

    public static function getByProvincia($provincia_id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE ubprovincia = $provincia_id ORDER BY distrito ASC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta UbDistritoData::getByProvincia: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new UbDistritoData());
    }

    public static function getById($id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new UbDistritoData());
    }
}
?>