<?php
// core/app/model/ReportesData.php
// Conversión estandarizada usando Executor::doit($sql)
// El primer valor retornado es siempre un PDOStatement
// Se usa fetchAll(PDO::FETCH_ASSOC) para evitar errores con fetch_array()

class ReportesData {

    // Ejecuta SQL y retorna los resultados en array asociativo
    private static function fetchAllAssocFromSql($sql) {
        $res = Executor::doit($sql);

        // Validar que exista PDOStatement
        if (!isset($res[0]) || !$res[0] instanceof PDOStatement) {
            return [];
        }

        $stmt = $res[0];
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // -------------------------------------------------------------
    // 1. Empresas por sector
    // -------------------------------------------------------------
    public static function empresasPorSector() {
        $sql = "
            SELECT IFNULL(sector,'(Sin sector)') AS sector,
                   COUNT(*) AS total
            FROM empresa
            GROUP BY sector
            ORDER BY total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 2. Empresas validadas
    // -------------------------------------------------------------
    public static function empresasValidadas() {
        $sql = "
            SELECT validado,
                   COUNT(*) AS total
            FROM empresa
            GROUP BY validado
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 3. Estudiantes por programa (INCLUYE todos los programas)
    // -------------------------------------------------------------
    public static function estudiantesPorPrograma() {
        $sql = "
            SELECT COALESCE(p.nom_progest,'(Sin programa)') AS nom_progest,
                   COUNT(m.estudiante) AS total_estudiantes
            FROM prog_estudios p
            LEFT JOIN matricula m ON m.prog_estudios = p.id
            GROUP BY p.nom_progest
            ORDER BY total_estudiantes DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 4. Estudiantes por turno (DIURNO / VESPERTINO)
    // -------------------------------------------------------------
    public static function estudiantesPorTurno() {
        $sql = "
            SELECT 
                CASE 
                    WHEN turno = 'D' THEN 'DIURNO'
                    WHEN turno = 'V' THEN 'VESPERTINO'
                    ELSE 'NO DEFINIDO'
                END AS turno,
                COUNT(*) AS total
            FROM matricula
            GROUP BY turno
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 5. Seguimientos por tipo
    // -------------------------------------------------------------
    public static function seguimientosPorTipo() {
        $sql = "
            SELECT COALESCE(t.nombre_tipo,'(Sin tipo)') AS nombre_tipo,
                   COUNT(s.id) AS total
            FROM seguimiento s
            LEFT JOIN tipo_seguimiento t ON s.tipo = t.id
            GROUP BY t.nombre_tipo
            ORDER BY total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 6. Seguimientos por programa
    // -------------------------------------------------------------
    public static function seguimientosPorPrograma() {
        $sql = "
            SELECT COALESCE(p.nom_progest,'(Sin programa)') AS nom_progest,
                   COUNT(s.id) AS total
            FROM seguimiento s
            LEFT JOIN matricula m ON s.estudiante = m.estudiante
            LEFT JOIN prog_estudios p ON m.prog_estudios = p.id
            GROUP BY p.nom_progest
            ORDER BY total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 7. Situación laboral
    // -------------------------------------------------------------
    public static function situacionLaboral() {
        $sql = "
            SELECT trabaja,
                   COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY trabaja
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 8. Ingreso promedio por programa
    // -------------------------------------------------------------
    public static function ingresoPromedioPorPrograma() {
        $sql = "
            SELECT COALESCE(p.nom_progest,'(Sin programa)') AS nom_progest,
                   AVG(sl.ingreso_bruto_mensual) AS ingreso_promedio,
                   COUNT(sl.id) AS total_registros
            FROM prog_estudios p
            LEFT JOIN matricula m ON m.prog_estudios = p.id
            LEFT JOIN situacion_laboral sl ON sl.estudiante = m.estudiante
            GROUP BY p.nom_progest
            ORDER BY ingreso_promedio DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 9. Trabajan actualmente (Sí / No)
    // -------------------------------------------------------------
    public static function encuestaTrabaja() {
        $sql = "
            SELECT 
                CASE 
                    WHEN trabaja = 1 THEN 'Sí'
                    WHEN trabaja = 0 THEN 'No'
                    ELSE 'Sin Respuesta'
                END AS trabaja,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY trabaja
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 10. Trabaja en su área de estudios
    // -------------------------------------------------------------
    public static function encuestaArea() {
        $sql = "
            SELECT 
                CASE 
                    WHEN labora_programa_estudios = 1 THEN 'Sí'
                    WHEN labora_programa_estudios = 0 THEN 'No'
                    ELSE 'Sin Respuesta'
                END AS labora_area,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY labora_programa_estudios
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 11. Condición laboral
    // -------------------------------------------------------------
    public static function encuestaCondicion() {
        $sql = "
            SELECT 
                CASE 
                    WHEN condicion_laboral = 1 THEN 'Dependiente'
                    WHEN condicion_laboral = 2 THEN 'Independiente'
                    WHEN condicion_laboral = 3 THEN 'Prácticas'
                    WHEN condicion_laboral = 4 THEN 'Por Contrato'
                    ELSE 'Sin Respuesta'
                END AS condicion,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY condicion_laboral
            ORDER BY total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 12. Cargos laborales más frecuentes
    // -------------------------------------------------------------
    public static function encuestaCargoFrecuente() {
        $sql = "
            SELECT cargo_actual AS cargo,
                   COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY cargo_actual
            HAVING cargo_actual IS NOT NULL AND cargo_actual != ''
            ORDER BY total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 13. Egresados que respondieron la encuesta
    // -------------------------------------------------------------
    public static function egresadosConEncuesta() {
        $sql = "
            SELECT 
                COUNT(DISTINCT sl.estudiante) AS total_respondieron,
                (SELECT COUNT(*) FROM estudiante WHERE estado = 1) AS total_egresados,
                CASE 
                    WHEN COUNT(DISTINCT sl.estudiante) > 0 
                    THEN ROUND((COUNT(DISTINCT sl.estudiante) * 100.0 / 
                        (SELECT COUNT(*) FROM estudiante WHERE estado = 1)), 2)
                    ELSE 0 
                END AS porcentaje
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON e.id = sl.estudiante AND e.estado = 1
            WHERE sl.estudiante IS NOT NULL
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 14. Tipo de seguimiento (correo/llamada)
    // -------------------------------------------------------------
    public static function tipoSeguimientoEncuestaSimple() {
        $sql = "
            SELECT 
                CASE 
                    WHEN s.tipo = 1 THEN 'Correo (Encuesta Externa)'
                    WHEN s.tipo = 2 THEN 'Llamada (Encuesta Interna)'
                    WHEN s.tipo IS NULL THEN 'Sin seguimiento'
                    ELSE CONCAT('Tipo ', s.tipo)
                END AS tipo_seguimiento,
                COUNT(DISTINCT s.estudiante) AS total_estudiantes,
                COUNT(*) AS total_seguimientos
            FROM estudiante e
            LEFT JOIN seguimiento s ON s.estudiante = e.id
            LEFT JOIN situacion_laboral sl ON sl.estudiante = e.id
            WHERE e.estado = 1
            GROUP BY s.tipo
            ORDER BY total_estudiantes DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 15. Detalle de egresados con/sin encuesta
    // -------------------------------------------------------------
    public static function detalleEgresadosEncuesta() {
        $sql = "
            SELECT 
                e.id,
                CONCAT(e.ap_est, ' ', e.am_est, ', ', e.nom_est) AS nombre_completo,
                e.dni_est,
                p.nom_progest AS carrera,
                CASE 
                    WHEN m.turno = 'D' THEN 'DIURNO'
                    WHEN m.turno = 'V' THEN 'VESPERTINO'
                    ELSE m.turno
                END AS turno,
                CASE 
                    WHEN sl.id IS NOT NULL THEN 'Sí respondió'
                    ELSE 'No respondió'
                END AS estado_encuesta,
                CASE 
                    WHEN s.tipo = 1 THEN 'Correo (Encuesta Externa)'
                    WHEN s.tipo = 2 THEN 'Llamada (Encuesta Interna)'
                    ELSE 'Sin seguimiento'
                END AS tipo_seguimiento,
                DATE_FORMAT(s.fecha, '%d/%m/%Y') AS fecha_seguimiento,
                DATE_FORMAT(sl.fecha_inicio, '%d/%m/%Y') AS fecha_encuesta,
                sl.cargo_actual,
                sl.ingreso_bruto_mensual,
                CASE 
                    WHEN sl.trabaja = 1 THEN 'Sí'
                    WHEN sl.trabaja = 0 THEN 'No'
                    ELSE 'No especificado'
                END AS trabaja_actualmente
            FROM estudiante e
            INNER JOIN matricula m ON m.estudiante = e.id
            INNER JOIN prog_estudios p ON p.id = m.prog_estudios
            LEFT JOIN situacion_laboral sl ON sl.estudiante = e.id
            LEFT JOIN (
                SELECT estudiante, tipo, MAX(fecha) as fecha 
                FROM seguimiento 
                GROUP BY estudiante, tipo
            ) s ON s.estudiante = e.id
            WHERE e.estado = 1 -- Solo egresados (estado = 1)
            ORDER BY estado_encuesta DESC, e.ap_est, e.am_est, e.nom_est
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 16. Porcentaje de respuesta por programa
    // -------------------------------------------------------------
    public static function respuestaPorPrograma() {
        $sql = "
            SELECT 
                p.nom_progest AS programa,
                COUNT(DISTINCT e.id) AS total_egresados,
                COUNT(DISTINCT sl.estudiante) AS total_respondieron,
                CASE 
                    WHEN COUNT(DISTINCT e.id) > 0 
                    THEN ROUND((COUNT(DISTINCT sl.estudiante) * 100.0 / COUNT(DISTINCT e.id)), 2)
                    ELSE 0 
                END AS porcentaje_respuesta
            FROM prog_estudios p
            LEFT JOIN matricula m ON m.prog_estudios = p.id
            LEFT JOIN estudiante e ON e.id = m.estudiante AND e.estado = 1
            LEFT JOIN situacion_laboral sl ON sl.estudiante = e.id
            GROUP BY p.nom_progest
            HAVING total_egresados > 0
            ORDER BY porcentaje_respuesta DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 17. Distribución de egresados por estado de encuesta
    // -------------------------------------------------------------
    public static function distribucionEgresadosEncuesta() {
        $sql = "
            SELECT 
                'Respondieron' AS estado,
                COUNT(DISTINCT sl.estudiante) AS cantidad
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON e.id = sl.estudiante AND e.estado = 1
            
            UNION ALL
            
            SELECT 
                'No respondieron' AS estado,
                (SELECT COUNT(*) FROM estudiante WHERE estado = 1) - 
                (SELECT COUNT(DISTINCT sl.estudiante) 
                FROM situacion_laboral sl 
                INNER JOIN estudiante e ON e.id = sl.estudiante AND e.estado = 1) AS cantidad
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // 18. Estadísticas de seguimiento por tipo
    // -------------------------------------------------------------
    public static function estadisticasSeguimiento() {
        $sql = "
            SELECT 
                ts.nombre_tipo AS tipo_seguimiento,
                COUNT(DISTINCT s.estudiante) AS total_estudiantes,
                COUNT(*) AS total_seguimientos,
                MIN(s.fecha) AS primera_fecha,
                MAX(s.fecha) AS ultima_fecha
            FROM seguimiento s
            INNER JOIN estudiante e ON e.id = s.estudiante AND e.estado = 1
            INNER JOIN tipo_seguimiento ts ON ts.id = s.tipo
            GROUP BY s.tipo, ts.nombre_tipo
            ORDER BY total_seguimientos DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // FUNCIONES PARA ORIGEN DE ENCUESTAS (AGREGADAS)
    // -------------------------------------------------------------

    // 19. Situación laboral (MODIFICADO - incluye tipo)
    public static function situacionLaboralPorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN tipo = 1 THEN 'Encuesta Externa'
                    WHEN tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen,
                trabaja,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY tipo, trabaja
            ORDER BY origen, trabaja
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 20. Ingreso promedio por programa (MODIFICADO - incluye tipo)
    public static function ingresoPromedioPorProgramaOrigen() {
        $sql = "
            SELECT 
                COALESCE(p.nom_progest,'(Sin programa)') AS nom_progest,
                CASE 
                    WHEN sl.tipo = 1 THEN 'Encuesta Externa'
                    WHEN sl.tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen,
                AVG(sl.ingreso_bruto_mensual) AS ingreso_promedio,
                COUNT(sl.id) AS total_registros
            FROM prog_estudios p
            LEFT JOIN matricula m ON m.prog_estudios = p.id
            LEFT JOIN situacion_laboral sl ON sl.estudiante = m.estudiante
            GROUP BY p.nom_progest, sl.tipo
            HAVING ingreso_promedio IS NOT NULL
            ORDER BY nom_progest, origen
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 21. Trabajan actualmente (Sí / No) (MODIFICADO - incluye tipo)
    public static function encuestaTrabajaPorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN tipo = 1 THEN 'Encuesta Externa'
                    WHEN tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen,
                CASE 
                    WHEN trabaja = 1 THEN 'Sí'
                    WHEN trabaja = 0 THEN 'No'
                    ELSE 'Sin Respuesta'
                END AS trabaja,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY tipo, trabaja
            ORDER BY origen, trabaja
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 22. Trabaja en su área de estudios (MODIFICADO - incluye tipo)
    public static function encuestaAreaPorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN tipo = 1 THEN 'Encuesta Externa'
                    WHEN tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen,
                CASE 
                    WHEN labora_programa_estudios = 1 THEN 'Sí'
                    WHEN labora_programa_estudios = 0 THEN 'No'
                    ELSE 'Sin Respuesta'
                END AS labora_area,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY tipo, labora_programa_estudios
            ORDER BY origen, labora_area
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 23. Condición laboral (MODIFICADO - incluye tipo)
    public static function encuestaCondicionPorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN tipo = 1 THEN 'Encuesta Externa'
                    WHEN tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen,
                CASE 
                    WHEN condicion_laboral = 1 THEN 'Dependiente'
                    WHEN condicion_laboral = 2 THEN 'Independiente'
                    WHEN condicion_laboral = 3 THEN 'Prácticas'
                    WHEN condicion_laboral = 4 THEN 'Por Contrato'
                    ELSE 'Sin Respuesta'
                END AS condicion,
                COUNT(*) AS total
            FROM situacion_laboral
            GROUP BY tipo, condicion_laboral
            ORDER BY origen, total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 24. Cargos laborales más frecuentes (MODIFICADO - incluye tipo)
    public static function encuestaCargoFrecuentePorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN tipo = 1 THEN 'Encuesta Externa'
                    WHEN tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen,
                cargo_actual AS cargo,
                COUNT(*) AS total
            FROM situacion_laboral
            WHERE cargo_actual IS NOT NULL AND cargo_actual != ''
            GROUP BY tipo, cargo_actual
            ORDER BY origen, total DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 25. Egresados que respondieron la encuesta (MODIFICADO)
    public static function egresadosConEncuestaPorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN sl.tipo = 1 THEN 'Encuesta Externa'
                    WHEN sl.tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen_encuesta,
                COUNT(DISTINCT sl.estudiante) AS total_respondieron,
                COUNT(sl.id) AS total_encuestas,
                ROUND((COUNT(DISTINCT sl.estudiante) * 100.0 / 
                    (SELECT COUNT(*) FROM estudiante WHERE estado = 1)), 2) AS porcentaje_egresados,
                ROUND((COUNT(sl.id) * 100.0 / 
                    (SELECT COUNT(*) FROM situacion_laboral)), 2) AS porcentaje_total_encuestas
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON e.id = sl.estudiante AND e.estado = 1
            WHERE sl.estudiante IS NOT NULL
            GROUP BY sl.tipo
            ORDER BY total_respondieron DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 26. Tipo de seguimiento (correo/llamada) (MODIFICADO)
    public static function tipoSeguimientoEncuestaSimplePorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN s.tipo = 1 THEN 'Correo (Encuesta Externa)'
                    WHEN s.tipo = 2 THEN 'Llamada (Encuesta Interna)'
                    WHEN s.tipo IS NULL THEN 'Sin seguimiento'
                    ELSE CONCAT('Tipo ', s.tipo)
                END AS tipo_seguimiento,
                CASE 
                    WHEN sl.tipo = 1 THEN 'Encuesta Externa'
                    WHEN sl.tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen_encuesta,
                COUNT(DISTINCT s.estudiante) AS total_estudiantes,
                COUNT(*) AS total_seguimientos
            FROM estudiante e
            LEFT JOIN seguimiento s ON s.estudiante = e.id
            LEFT JOIN situacion_laboral sl ON sl.estudiante = e.id
            WHERE e.estado = 1
            GROUP BY s.tipo, sl.tipo
            ORDER BY origen_encuesta, tipo_seguimiento
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 27. Detalle de egresados con/sin encuesta (MODIFICADO)
    public static function detalleEgresadosEncuestaPorOrigen() {
        $sql = "
            SELECT 
                e.id,
                CONCAT(e.ap_est, ' ', e.am_est, ', ', e.nom_est) AS nombre_completo,
                e.dni_est,
                p.nom_progest AS carrera,
                CASE 
                    WHEN m.turno = 'D' THEN 'DIURNO'
                    WHEN m.turno = 'V' THEN 'VESPERTINO'
                    ELSE m.turno
                END AS turno,
                CASE 
                    WHEN sl.id IS NOT NULL THEN 'Sí respondió'
                    ELSE 'No respondió'
                END AS estado_encuesta,
                CASE 
                    WHEN sl.tipo = 1 THEN 'Encuesta Externa'
                    WHEN sl.tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo definido'
                END AS origen_encuesta,
                CASE 
                    WHEN s.tipo = 1 THEN 'Correo (Encuesta Externa)'
                    WHEN s.tipo = 2 THEN 'Llamada (Encuesta Interna)'
                    ELSE 'Sin seguimiento'
                END AS tipo_seguimiento,
                DATE_FORMAT(s.fecha, '%d/%m/%Y') AS fecha_seguimiento,
                DATE_FORMAT(sl.fecha_inicio, '%d/%m/%Y') AS fecha_encuesta,
                sl.cargo_actual,
                sl.ingreso_bruto_mensual,
                CASE 
                    WHEN sl.trabaja = 1 THEN 'Sí'
                    WHEN sl.trabaja = 0 THEN 'No'
                    ELSE 'No especificado'
                END AS trabaja_actualmente
            FROM estudiante e
            INNER JOIN matricula m ON m.estudiante = e.id
            INNER JOIN prog_estudios p ON p.id = m.prog_estudios
            LEFT JOIN situacion_laboral sl ON sl.estudiante = e.id
            LEFT JOIN (
                SELECT estudiante, tipo, MAX(fecha) as fecha 
                FROM seguimiento 
                GROUP BY estudiante, tipo
            ) s ON s.estudiante = e.id
            WHERE e.estado = 1
            ORDER BY estado_encuesta DESC, origen_encuesta, e.ap_est, e.am_est, e.nom_est
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 28. Porcentaje de respuesta por programa (MODIFICADO)
    public static function respuestaPorProgramaPorOrigen() {
        $sql = "
            SELECT 
                p.nom_progest AS programa,
                COUNT(DISTINCT e.id) AS total_egresados,
                COUNT(DISTINCT sl.estudiante) AS total_respondieron,
                COUNT(DISTINCT CASE WHEN sl.tipo = 1 THEN sl.estudiante END) AS externas,
                COUNT(DISTINCT CASE WHEN sl.tipo = 0 THEN sl.estudiante END) AS internas,
                CASE 
                    WHEN COUNT(DISTINCT e.id) > 0 
                    THEN ROUND((COUNT(DISTINCT sl.estudiante) * 100.0 / COUNT(DISTINCT e.id)), 2)
                    ELSE 0 
                END AS porcentaje_respuesta,
                CASE 
                    WHEN COUNT(DISTINCT sl.estudiante) > 0 
                    THEN ROUND((COUNT(DISTINCT CASE WHEN sl.tipo = 1 THEN sl.estudiante END) * 100.0 / 
                           COUNT(DISTINCT sl.estudiante)), 2)
                    ELSE 0 
                END AS porcentaje_externas,
                CASE 
                    WHEN COUNT(DISTINCT sl.estudiante) > 0 
                    THEN ROUND((COUNT(DISTINCT CASE WHEN sl.tipo = 0 THEN sl.estudiante END) * 100.0 / 
                           COUNT(DISTINCT sl.estudiante)), 2)
                    ELSE 0 
                END AS porcentaje_internas
            FROM prog_estudios p
            LEFT JOIN matricula m ON m.prog_estudios = p.id
            LEFT JOIN estudiante e ON e.id = m.estudiante AND e.estado = 1
            LEFT JOIN situacion_laboral sl ON sl.estudiante = e.id
            GROUP BY p.nom_progest
            HAVING total_egresados > 0
            ORDER BY porcentaje_respuesta DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 29. Distribución de egresados por estado de encuesta (MODIFICADO)
    public static function distribucionEgresadosEncuestaPorOrigen() {
        $sql = "
            SELECT 
                CASE 
                    WHEN sl.tipo = 1 THEN 'Respondieron (Externa)'
                    WHEN sl.tipo = 0 THEN 'Respondieron (Interna)'
                    ELSE 'Sin tipo definido'
                END AS estado,
                COUNT(DISTINCT sl.estudiante) AS cantidad
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON e.id = sl.estudiante AND e.estado = 1
            GROUP BY sl.tipo
            
            UNION ALL
            
            SELECT 
                'No respondieron' AS estado,
                (SELECT COUNT(*) FROM estudiante WHERE estado = 1) - 
                (SELECT COUNT(DISTINCT sl.estudiante) 
                FROM situacion_laboral sl 
                INNER JOIN estudiante e ON e.id = sl.estudiante AND e.estado = 1) AS cantidad
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // -------------------------------------------------------------
    // NUEVOS MÉTODOS PARA ORIGEN DE ENCUESTAS
    // -------------------------------------------------------------

    // 30. ORIGEN DE ENCUESTAS (NUEVO)
    public static function origenEncuestas() {
        $sql = "
            SELECT 
                CASE 
                    WHEN sl.tipo = 1 THEN 'Encuesta Externa (encuesta.php)'
                    WHEN sl.tipo = 0 THEN 'Encuesta Interna (sistema)'
                    ELSE 'Origen desconocido'
                END AS origen_encuesta,
                COUNT(DISTINCT sl.estudiante) AS total_estudiantes,
                COUNT(sl.id) AS total_encuestas,
                ROUND(AVG(sl.ingreso_bruto_mensual), 2) AS ingreso_promedio,
                MIN(sl.fecha_inicio) AS primera_encuesta,
                MAX(sl.fecha_inicio) AS ultima_encuesta,
                ROUND((COUNT(sl.id) * 100.0 / (SELECT COUNT(*) FROM situacion_laboral)), 2) AS porcentaje_total
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id AND e.estado = 1
            GROUP BY sl.tipo
            ORDER BY total_encuestas DESC
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 31. DETALLE DE ENCUESTAS POR ORIGEN (NUEVO)
    public static function detalleEncuestasPorOrigen() {
        $sql = "
            SELECT 
                e.id,
                CONCAT(e.ap_est, ' ', e.am_est, ', ', e.nom_est) AS nombre_completo,
                e.dni_est,
                p.nom_progest AS carrera,
                DATE_FORMAT(sl.fecha_inicio, '%d/%m/%Y %H:%i') AS fecha_encuesta,
                CASE 
                    WHEN sl.tipo = 1 THEN 'Encuesta Externa (encuesta.php)'
                    WHEN sl.tipo = 0 THEN 'Encuesta Interna (sistema)'
                    ELSE 'Origen desconocido'
                END AS origen_encuesta,
                sl.cargo_actual,
                sl.ingreso_bruto_mensual,
                CASE 
                    WHEN sl.trabaja = 1 THEN 'Sí'
                    WHEN sl.trabaja = 0 THEN 'No'
                    ELSE 'No especificado'
                END AS trabaja_actualmente,
                cl.nombre_condicion AS condicion_laboral,
                emp.razon_social AS empresa,
                DATE_FORMAT(s.fecha, '%d/%m/%Y %H:%i') AS fecha_seguimiento,
                s.observaciones,
                ts.nombre_tipo AS tipo_seguimiento
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id AND e.estado = 1
            INNER JOIN matricula m ON e.id = m.estudiante
            INNER JOIN prog_estudios p ON m.prog_estudios = p.id
            LEFT JOIN condicion_laboral cl ON sl.condicion_laboral = cl.id
            LEFT JOIN empresa emp ON sl.empresa = emp.id
            LEFT JOIN seguimiento s ON sl.estudiante = s.estudiante
            LEFT JOIN tipo_seguimiento ts ON s.tipo = ts.id
            ORDER BY sl.fecha_inicio DESC, origen_encuesta, p.nom_progest
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 32. ESTADÍSTICAS DE RESPUESTA POR ORIGEN Y PROGRAMA (NUEVO)
    public static function estadisticasRespuestaPorOrigenPrograma() {
        $sql = "
            SELECT 
                p.nom_progest AS programa,
                COUNT(DISTINCT e.id) AS total_egresados,
                COUNT(DISTINCT sl.estudiante) AS total_respondieron,
                COUNT(DISTINCT CASE WHEN sl.tipo = 1 THEN sl.estudiante END) AS respuestas_externas,
                COUNT(DISTINCT CASE WHEN sl.tipo = 0 THEN sl.estudiante END) AS respuestas_internas,
                COUNT(DISTINCT CASE WHEN sl.tipo IS NULL THEN sl.estudiante END) AS respuestas_origen_desconocido,
                ROUND((COUNT(DISTINCT sl.estudiante) * 100.0 / NULLIF(COUNT(DISTINCT e.id), 0)), 2) AS porcentaje_respuesta_total,
                ROUND((COUNT(DISTINCT CASE WHEN sl.tipo = 1 THEN sl.estudiante END) * 100.0 / 
                       NULLIF(COUNT(DISTINCT sl.estudiante), 0)), 2) AS porcentaje_externas,
                ROUND((COUNT(DISTINCT CASE WHEN sl.tipo = 0 THEN sl.estudiante END) * 100.0 / 
                       NULLIF(COUNT(DISTINCT sl.estudiante), 0)), 2) AS porcentaje_internas
            FROM prog_estudios p
            LEFT JOIN matricula m ON p.id = m.prog_estudios
            LEFT JOIN estudiante e ON m.estudiante = e.id AND e.estado = 1
            LEFT JOIN situacion_laboral sl ON e.id = sl.estudiante
            GROUP BY p.nom_progest
            HAVING total_egresados > 0
            ORDER BY total_respondieron DESC, p.nom_progest
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 33. COMPARATIVA DE RESULTADOS POR ORIGEN (NUEVO)
    public static function comparativaResultadosPorOrigen() {
        $sql = "
            SELECT 
                'Encuesta Externa' AS origen,
                COUNT(DISTINCT sl.estudiante) AS total_estudiantes,
                ROUND(AVG(sl.ingreso_bruto_mensual), 2) AS ingreso_promedio,
                ROUND((COUNT(CASE WHEN sl.trabaja = 1 THEN 1 END) * 100.0 / COUNT(*)), 2) AS porcentaje_trabaja,
                ROUND((COUNT(CASE WHEN sl.labora_programa_estudios = 1 THEN 1 END) * 100.0 / COUNT(*)), 2) AS porcentaje_trabaja_carrera,
                COUNT(DISTINCT CASE WHEN sl.condicion_laboral = 1 THEN sl.estudiante END) AS dependientes,
                COUNT(DISTINCT CASE WHEN sl.condicion_laboral = 2 THEN sl.estudiante END) AS independientes
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id AND e.estado = 1
            WHERE sl.tipo = 1
            
            UNION ALL
            
            SELECT 
                'Encuesta Interna' AS origen,
                COUNT(DISTINCT sl.estudiante) AS total_estudiantes,
                ROUND(AVG(sl.ingreso_bruto_mensual), 2) AS ingreso_promedio,
                ROUND((COUNT(CASE WHEN sl.trabaja = 1 THEN 1 END) * 100.0 / COUNT(*)), 2) AS porcentaje_trabaja,
                ROUND((COUNT(CASE WHEN sl.labora_programa_estudios = 1 THEN 1 END) * 100.0 / COUNT(*)), 2) AS porcentaje_trabaja_carrera,
                COUNT(DISTINCT CASE WHEN sl.condicion_laboral = 1 THEN sl.estudiante END) AS dependientes,
                COUNT(DISTINCT CASE WHEN sl.condicion_laboral = 2 THEN sl.estudiante END) AS independientes
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id AND e.estado = 1
            WHERE sl.tipo = 0
            
            UNION ALL
            
            SELECT 
                'Origen desconocido' AS origen,
                COUNT(DISTINCT sl.estudiante) AS total_estudiantes,
                ROUND(AVG(sl.ingreso_bruto_mensual), 2) AS ingreso_promedio,
                ROUND((COUNT(CASE WHEN sl.trabaja = 1 THEN 1 END) * 100.0 / COUNT(*)), 2) AS porcentaje_trabaja,
                ROUND((COUNT(CASE WHEN sl.labora_programa_estudios = 1 THEN 1 END) * 100.0 / COUNT(*)), 2) AS porcentaje_trabaja_carrera,
                COUNT(DISTINCT CASE WHEN sl.condicion_laboral = 1 THEN sl.estudiante END) AS dependientes,
                COUNT(DISTINCT CASE WHEN sl.condicion_laboral = 2 THEN sl.estudiante END) AS independientes
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id AND e.estado = 1
            WHERE sl.tipo IS NULL
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 34. RESUMEN GENERAL DE ENCUESTAS POR TIPO (NUEVO)
    public static function resumenGeneralEncuestas() {
        $sql = "
            SELECT 
                'Total Encuestas' AS categoria,
                COUNT(*) AS valor
            FROM situacion_laboral
            
            UNION ALL
            
            SELECT 
                'Encuestas Externas',
                COUNT(*) 
            FROM situacion_laboral 
            WHERE tipo = 1
            
            UNION ALL
            
            SELECT 
                'Encuestas Internas',
                COUNT(*) 
            FROM situacion_laboral 
            WHERE tipo = 0
            
            UNION ALL
            
            SELECT 
                'Porcentaje Externas',
                ROUND((COUNT(CASE WHEN tipo = 1 THEN 1 END) * 100.0 / COUNT(*)), 2)
            FROM situacion_laboral
            
            UNION ALL
            
            SELECT 
                'Porcentaje Internas',
                ROUND((COUNT(CASE WHEN tipo = 0 THEN 1 END) * 100.0 / COUNT(*)), 2)
            FROM situacion_laboral
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    // 35. EVOLUCIÓN TEMPORAL POR TIPO DE ENCUESTA (NUEVO)
    public static function evolucionTemporalEncuestas() {
        $sql = "
            SELECT 
                DATE_FORMAT(fecha_inicio, '%Y-%m') AS mes,
                CASE 
                    WHEN tipo = 1 THEN 'Encuesta Externa'
                    WHEN tipo = 0 THEN 'Encuesta Interna'
                    ELSE 'Sin tipo'
                END AS origen,
                COUNT(*) AS total_encuestas,
                COUNT(DISTINCT estudiante) AS total_estudiantes,
                ROUND(AVG(ingreso_bruto_mensual), 2) AS ingreso_promedio
            FROM situacion_laboral
            WHERE fecha_inicio IS NOT NULL
            GROUP BY DATE_FORMAT(fecha_inicio, '%Y-%m'), tipo
            ORDER BY mes DESC, origen
        ";
        return self::fetchAllAssocFromSql($sql);
    }

    public static function totalEgresados() {
        $sql = "SELECT COUNT(*) as total FROM estudiante WHERE estado = 1";
        $res = Executor::doit($sql);
        
        // Verifica si hay resultado
        if (!isset($res[0]) || !$res[0] instanceof PDOStatement) {
            return 0;
        }
        
        $stmt = $res[0];
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verifica si fetch devolvió algo
        if (!$result) {
            return 0;
        }
        
        return $result['total'] ?? 0;
    }

    // -------------------------------------------------------------
    // MÉTODO PARA AGREGAR CAMPO TIPO A TABLA EXISTENTE (SQL)
    // -------------------------------------------------------------
    public static function agregarCampoTipo() {
        $sql = "ALTER TABLE situacion_laboral 
                ADD COLUMN tipo INT DEFAULT NULL COMMENT '1=Encuesta Externa, 0=Encuesta Interna'";
        $res = Executor::doit($sql);
        return isset($res[0]) && $res[0] instanceof PDOStatement;
    }
}