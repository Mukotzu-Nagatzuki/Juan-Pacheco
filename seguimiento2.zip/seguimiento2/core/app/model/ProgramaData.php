<?php
class ProgramaData {
    public static $tablename = "prog_estudios";

    public $id;
    public $nom_progest;
    public $perfilingre_progest;
    public $perfilegre_progest;
    public $id_progest;

    // Obtener todos los programas de estudio
    public static function getAll() {
        $sql = "SELECT * FROM " . self::$tablename . " ORDER BY nom_progest ASC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new ProgramaData());
    }

    // Obtener un programa por ID
    public static function getById($id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new ProgramaData());
    }

    // Registrar un nuevo programa
    public function add() {
        $sql = "INSERT INTO " . self::$tablename . " (nom_progest, perfilingre_progest, perfilegre_progest, id_progest) 
                VALUES (
                    \"$this->nom_progest\",
                    \"$this->perfilingre_progest\",
                    \"$this->perfilegre_progest\",
                    \"$this->id_progest\"
                )";
        return Executor::doit($sql);
    }

    // Actualizar programa existente
    public function update() {
        $sql = "UPDATE " . self::$tablename . " 
                SET nom_progest = \"$this->nom_progest\",
                    perfilingre_progest = \"$this->perfilingre_progest\",
                    perfilegre_progest = \"$this->perfilegre_progest\",
                    id_progest = \"$this->id_progest\"
                WHERE id = $this->id";
        return Executor::doit($sql);
    }

    // Eliminar un programa
    public static function delete($id) {
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = $id";
        return Executor::doit($sql);
    }
}
?>