<?php
// core/app/model/UbigeoData.php
class UbigeoData {
    public $id;
    public $departamento;
    public $provincia;
    public $distrito;
    public $departamento_id;
    public $provincia_id;
    public $distrito_id;
    
    // Obtener todos los departamentos
    public static function getDepartamentos() {
        $sql = "SELECT id, departamento FROM ubdepartamento ORDER BY departamento ASC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new UbigeoData());
    }

    // Obtener provincias por departamento
    public static function getProvinciasByDepartamento($departamento_id) {
        $sql = "SELECT id, provincia FROM ubprovincia 
                WHERE ubdepartamento = $departamento_id 
                ORDER BY provincia ASC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new UbigeoData());
    }

    // Obtener distritos por provincia
    public static function getDistritosByProvincia($provincia_id) {
        $sql = "SELECT id, distrito FROM ubdistrito 
                WHERE ubprovincia = $provincia_id 
                ORDER BY distrito ASC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new UbigeoData());
    }

    // Obtener datos completos de ubigeo por ID de distrito
    public static function getUbigeoCompleto($distrito_id) {
        $sql = "SELECT d.id as departamento_id, d.departamento,
                       p.id as provincia_id, p.provincia,
                       di.id as distrito_id, di.distrito
                FROM ubdistrito di
                JOIN ubprovincia p ON di.ubprovincia = p.id
                JOIN ubdepartamento d ON p.ubdepartamento = d.id
                WHERE di.id = $distrito_id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new UbigeoData());
    }
}
?>