<?php
class EgresadoData {
    public static $tablename = "estudiante";

    public $id;
    public $dni_est;
    public $ap_est;
    public $am_est;
    public $nom_est;
    public $cel_est;
    public $mailp_est;
    public $maili_est;
    public $ubigeodir_est;
    public $estado; // Aquí manejaremos 0=Estudiante, 1=Egresado

    // Obtener todos los egresados - CORREGIDO CON 0 Y 1
    public static function getAll() {
        $sql = "SELECT *, 
                CASE 
                    WHEN estado = 1 THEN 'egresado' 
                    ELSE 'estudiante' 
                END as tipo_estado 
                FROM " . self::$tablename . " ORDER BY ap_est, am_est, nom_est ASC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new EgresadoData());
    }

    // Obtener estudiante por DNI - CORREGIDO
    public static function getEstudianteByDni($dni) {
        $sql = "SELECT *, 
                CASE 
                    WHEN estado = 1 THEN 'egresado' 
                    ELSE 'estudiante' 
                END as tipo_estado 
                FROM " . self::$tablename . " WHERE dni_est = \"$dni\"";
        $query = Executor::doit($sql);
        return Model::one($query[0], new EgresadoData());
    }

    // Cambiar estado individual - CORREGIDO PARA 0 Y 1
    public static function cambiarEstado($id, $estado) {
        // Convertir 'estudiante' a 0 y 'egresado' a 1
        $estado_num = ($estado == 'egresado') ? 1 : 0;
        $sql = "UPDATE " . self::$tablename . " SET estado = $estado_num WHERE id = $id";
        
        error_log("DEBUG EgresadoData::cambiarEstado - SQL: $sql");
        
        $result = Executor::doit($sql);
        
        if (isset($result[0])) {
            if ($result[0] === true || (is_numeric($result[0]) && $result[0] > 0)) {
                return array(true, "Estado actualizado correctamente");
            } else {
                return array(false, "No se pudo actualizar el estado");
            }
        }
        
        return array(false, "Error desconocido al actualizar estado");
    }

    // Cambiar estado en masa - CORREGIDO PARA 0 Y 1
    public static function cambiarEstadoMasa($ids, $estado) {
        if (empty($ids) || !is_array($ids)) {
            return array(false, "No se proporcionaron IDs válidos");
        }
        
        $ids_str = implode(',', array_map('intval', $ids));
        $estado_num = ($estado == 'egresado') ? 1 : 0;
        $sql = "UPDATE " . self::$tablename . " SET estado = $estado_num WHERE id IN ($ids_str)";
        
        error_log("DEBUG EgresadoData::cambiarEstadoMasa - SQL: $sql");
        
        $result = Executor::doit($sql);
        
        if (isset($result[0])) {
            if ($result[0] === true || (is_numeric($result[0]) && $result[0] > 0)) {
                return array(true, count($ids) . " estados actualizados correctamente");
            } else {
                return array(false, "No se pudieron actualizar los estados");
            }
        }
        
        return array(false, "Error desconocido al actualizar estados en masa");
    }

    // Agregar nuevo egresado - CORREGIDO PARA 0 Y 1
    public function add() {
        // Convertir estado a número: 'egresado' = 1, 'estudiante' = 0
        $estado_num = ($this->estado == 'egresado') ? 1 : 0;
        
        $sql = "INSERT INTO " . self::$tablename . " 
                (dni_est, ap_est, am_est, nom_est, cel_est, mailp_est, maili_est, ubigeodir_est, estado) 
                VALUES (\"$this->dni_est\", \"$this->ap_est\", \"$this->am_est\", \"$this->nom_est\", 
                        \"$this->cel_est\", \"$this->mailp_est\", \"$this->maili_est\", 
                        \"$this->ubigeodir_est\", $estado_num)";
        return Executor::doit($sql);
    }

    // Actualizar egresado - CORREGIDO PARA 0 Y 1
    public function update() {
        // Convertir estado a número: 'egresado' = 1, 'estudiante' = 0
        $estado_num = ($this->estado == 'egresado') ? 1 : 0;
        
        $sql = "UPDATE " . self::$tablename . " 
                SET dni_est = \"$this->dni_est\", 
                    ap_est = \"$this->ap_est\", 
                    am_est = \"$this->am_est\", 
                    nom_est = \"$this->nom_est\", 
                    cel_est = \"$this->cel_est\", 
                    mailp_est = \"$this->mailp_est\", 
                    maili_est = \"$this->maili_est\", 
                    ubigeodir_est = \"$this->ubigeodir_est\",
                    estado = $estado_num
                WHERE id = $this->id";
        return Executor::doit($sql);
    }

    // Obtener egresado por ID - CORREGIDO
    public static function getById($id) {
        $sql = "SELECT *, 
                CASE 
                    WHEN estado = 1 THEN 'egresado' 
                    ELSE 'estudiante' 
                END as tipo_estado 
                FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new EgresadoData());
    }

    // En EgresadoData.php, modifica el método delete()
    public static function delete($id) {
        // Primero eliminar las matrículas asociadas
        $sql_matriculas = "DELETE FROM matricula WHERE estudiante = $id";
        $result_matriculas = Executor::doit($sql_matriculas);
        
        if (!$result_matriculas[0]) {
            return array(false, "Error al eliminar matrículas: " . $result_matriculas[1]);
        }
        
        // Luego eliminar el estudiante
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = $id";
        $result = Executor::doit($sql);
        
        if ($result[0]) {
            return array(true, "Egresado eliminado correctamente");
        } else {
            return array(false, "Error al eliminar el egresado: " . $result[1]);
        }
    }

    // Los demás métodos permanecen igual...
    public static function getUbigeoData($ubigeo) {
        $sql = "SELECT d.id as departamento_id, d.departamento,
                    p.id as provincia_id, p.provincia,
                    di.id as distrito_id, di.distrito
                FROM ubdistrito di
                JOIN ubprovincia p ON di.ubprovincia = p.id
                JOIN ubdepartamento d ON p.ubdepartamento = d.id
                WHERE di.id = \"$ubigeo\"";
        return Executor::doit($sql);
    }

    private static function tableExists($table) {
        $sql = "SELECT 1 FROM $table LIMIT 1";
        $query = Executor::doit($sql);
        return $query[0];
    }
    public static function getAllEgresados() {
    $sql = "SELECT 
                id_est as id,
                dni_est as dni,
                CONCAT(nom_est, ' ', ap_est, ' ', am_est) as nombre_completo,
                mailp_est as correo,
                cel_est as telefono,
                estado,
                tipo_estado
            FROM estudiantes 
            WHERE (estado = 1 OR tipo_estado = 'egresado' OR estado_est = 'egresado')
            AND mailp_est IS NOT NULL 
            AND mailp_est != ''
            AND TRIM(mailp_est) != ''
            ORDER BY ap_est, am_est, nom_est";
    
    $result = Model::executeQuery($sql);
    
    $estudiantes = [];
    if (count($result) > 0) {
        error_log("Se encontraron " . count($result) . " estudiantes egresados en la base de datos");
        foreach ($result as $row) {
            $est = new stdClass();
            $est->id = $row['id'];
            $est->dni_est = $row['dni'];
            $est->nombre_completo = $row['nombre_completo'];
            $est->mailp_est = trim($row['correo']);
            $est->cel_est = $row['telefono'];
            $est->estado = $row['estado'];
            $est->tipo_estado = $row['tipo_estado'];
            $estudiantes[] = $est;
            
            // Log para depuración
            error_log("Estudiante encontrado: DNI=" . $est->dni_est . ", Correo=" . $est->mailp_est);
        }
    } else {
        error_log("NO se encontraron estudiantes egresados en la base de datos");
    }
    
    return $estudiantes;
}
}
?>