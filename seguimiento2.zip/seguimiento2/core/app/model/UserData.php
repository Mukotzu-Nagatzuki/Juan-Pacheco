<?php
class UserData {
    public static $tablename = "usuarios";

    public $id;
    public $usuario;
    public $password;
    public $tipo;          // 1=Empleado, 2=Estudiante, 3=Empresa
    public $estuempleado;  // ID del estudiante o empleado relacionado
    public $token;

    // 🟢 INSERTAR NUEVO USUARIO
    public function add() {
        $sql = "INSERT INTO " . self::$tablename . " 
                (usuario, password, tipo, estuempleado, token) 
                VALUES (:usuario, :password, :tipo, :estuempleado, :token)";
        $params = [
            ':usuario' => $this->usuario,
            ':password' => $this->password,
            ':tipo' => $this->tipo,
            ':estuempleado' => $this->estuempleado,
            ':token' => $this->token
        ];
        return Executor::doit($sql, $params);
    }

    // 🟡 ACTUALIZAR USUARIO
    public function update() {
        $sql = "UPDATE " . self::$tablename . " 
                SET usuario = :usuario, tipo = :tipo, estuempleado = :estuempleado, token = :token 
                WHERE id = :id";
        $params = [
            ':usuario' => $this->usuario,
            ':tipo' => $this->tipo,
            ':estuempleado' => $this->estuempleado,
            ':token' => $this->token,
            ':id' => $this->id
        ];
        return Executor::doit($sql, $params);
    }

    // 🔵 ACTUALIZAR CONTRASEÑA
    public function update_passwd() {
        $sql = "UPDATE " . self::$tablename . " 
                SET password = :password 
                WHERE id = :id";
        $params = [
            ':password' => $this->password,
            ':id' => $this->id
        ];
        return Executor::doit($sql, $params);
    }

    // 🔍 OBTENER USUARIO POR NOMBRE
    public static function getByUsername($usuario) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE usuario = :usuario";
        $params = [':usuario' => $usuario];
        $query = Executor::doit($sql, $params);
        return Model::one($query[0], new UserData());
    }

    // 🔍 OBTENER USUARIO POR ID
    public static function getById($id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = :id";
        $params = [':id' => $id];
        $query = Executor::doit($sql, $params);
        return Model::one($query[0], new UserData());
    }

    // ❌ ELIMINAR USUARIO
    public static function delById($id) {
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = :id";
        $params = [':id' => $id];
        return Executor::doit($sql, $params);
    }

    // 📋 LISTAR TODOS LOS USUARIOS
    public static function getAll() {
        $sql = "SELECT * FROM " . self::$tablename . " ORDER BY usuario";
        $query = Executor::doit($sql);
        return Model::many($query[0], new UserData());
    }
}
?>