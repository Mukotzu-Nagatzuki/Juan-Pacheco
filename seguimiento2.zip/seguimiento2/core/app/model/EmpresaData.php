<?php
class EmpresaData
{
    public static $tablename = "empresa";

    public $id;
    public $ruc;
    public $razon_social;
    public $nombre_comercial;
    public $direccion_fiscal;
    public $telefono;
    public $email;
    public $sector;
    public $validado;
    public $registro_manual;
    public $estado;
    public $condicion_sunat;
    public $ubigeo;
    public $departamento;
    public $provincia;
    public $distrito;
    public $fecha_creacion;
    public $fecha_actualizacion;

    // Mostrar todas las empresas
    public static function getAll()
    {
        $sql = "SELECT * FROM " . self::$tablename . " ORDER BY fecha_creacion DESC";
        $query = Executor::doit($sql);

        // Verificar si hay error en la consulta
        if (!$query[0]) {
            error_log("Error en consulta getAll: " . $query[1]);
            return [];
        }

        return Model::many($query[0], new EmpresaData());
    }

    // Método de búsqueda
    public static function search($busqueda, $criterio = 'todas')
    {
        $busqueda = trim($busqueda);
        $sql = "SELECT * FROM " . self::$tablename . " WHERE ";

        switch ($criterio) {
            case 'ruc':
                $sql .= "ruc LIKE '%$busqueda%'";
                break;
            case 'sector':
                $sql .= "sector LIKE '%$busqueda%'";
                break;
            case 'nombre_comercial':
                $sql .= "nombre_comercial LIKE '%$busqueda%'";
                break;
            case 'razon_social':
                $sql .= "razon_social LIKE '%$busqueda%'";
                break;
            case 'todas':
            default:
                $sql .= "(ruc LIKE '%$busqueda%' OR 
                         razon_social LIKE '%$busqueda%' OR 
                         nombre_comercial LIKE '%$busqueda%' OR 
                         sector LIKE '%$busqueda%' OR
                         email LIKE '%$busqueda%' OR
                         departamento LIKE '%$busqueda%' OR
                         provincia LIKE '%$busqueda%' OR
                         distrito LIKE '%$busqueda%')";
                break;
        }

        $sql .= " ORDER BY fecha_creacion DESC";
        $query = Executor::doit($sql);

        if (!$query[0]) {
            error_log("Error en consulta search: " . $query[1]);
            return [];
        }

        return Model::many($query[0], new EmpresaData());
    }

    // Buscar por ID
    public static function getById($id)
    {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);

        if (!$query[0]) {
            error_log("Error en consulta getById: " . $query[1]);
            return null;
        }

        return Model::one($query[0], new EmpresaData());
    }

    // Verificar si existe empresa por RUC
    public static function existsByRuc($ruc)
    {
        $sql = "SELECT COUNT(*) as total FROM " . self::$tablename . " WHERE ruc = \"$ruc\"";
        $query = Executor::doit($sql);

        if (!$query[0]) {
            error_log("Error en consulta existsByRuc: " . $query[1]);
            return false;
        }

        $result = Model::one($query[0], new stdClass());
        return $result->total > 0;
    }



    public static function getByRuc($ruc)
    {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE $ruc = \"$ruc\"";
        $query = Executor::doit($sql);
        return Model::one($query[0], new EmpresaData());
    }

    // Registrar una nueva empresa
    public function add()
    {
        // ELIMINAR estas líneas - ya no necesitas convertir IDs a nombres
        // $this->departamento = self::getDepartamentoNombre($this->departamento);
        // $this->provincia = self::getProvinciaNombre($this->provincia);
        // $this->distrito = self::getDistritoNombre($this->distrito);

        $sql = "INSERT INTO " . self::$tablename . " 
                (ruc, razon_social, nombre_comercial, direccion_fiscal, telefono, email, sector, validado, registro_manual, estado, condicion_sunat, ubigeo, departamento, provincia, distrito, fecha_creacion) 
                VALUES (
                    \"$this->ruc\",
                    \"$this->razon_social\",
                    \"$this->nombre_comercial\",
                    \"$this->direccion_fiscal\",
                    \"$this->telefono\",
                    \"$this->email\",
                    \"$this->sector\",
                    \"$this->validado\",
                    \"$this->registro_manual\",
                    \"$this->estado\",
                    \"$this->condicion_sunat\",
                    \"$this->ubigeo\",
                    \"$this->departamento\",
                    \"$this->provincia\",
                    \"$this->distrito\",
                    NOW()
                )";
        return Executor::doit($sql);
    }

    // Actualizar empresa
    public function update()
    {
        // ELIMINAR estas líneas - ya no necesitas convertir IDs a nombres
        // $this->departamento = self::getDepartamentoNombre($this->departamento);
        // $this->provincia = self::getProvinciaNombre($this->provincia);
        // $this->distrito = self::getDistritoNombre($this->distrito);

        $sql = "UPDATE " . self::$tablename . " SET 
                ruc=\"$this->ruc\",
                razon_social=\"$this->razon_social\",
                nombre_comercial=\"$this->nombre_comercial\",
                direccion_fiscal=\"$this->direccion_fiscal\",
                telefono=\"$this->telefono\",
                email=\"$this->email\",
                sector=\"$this->sector\",
                validado=\"$this->validado\",
                registro_manual=\"$this->registro_manual\",
                estado=\"$this->estado\",
                condicion_sunat=\"$this->condicion_sunat\",
                ubigeo=\"$this->ubigeo\",
                departamento=\"$this->departamento\",
                provincia=\"$this->provincia\",
                distrito=\"$this->distrito\",
                fecha_actualizacion=NOW()
                WHERE id = $this->id";
        return Executor::doit($sql);
    }

    // Eliminar empresa
    public static function delete($id)
    {
        try {
            // PRIMERO: Obtener todas las situaciones laborales de esta empresa
            $sql_situaciones = "SELECT id FROM situacion_laboral WHERE empresa = $id";
            $query_situaciones = Executor::doit($sql_situaciones);

            if ($query_situaciones[0]) {
                $situaciones = Model::many($query_situaciones[0], new stdClass());

                // Eliminar todos los historiales relacionados con estas situaciones
                foreach ($situaciones as $situacion) {
                    $sql_historial = "DELETE FROM historial_laboral WHERE situacion = {$situacion->id}";
                    Executor::doit($sql_historial);
                }
            }

            // SEGUNDO: Eliminar las situaciones laborales
            $sql_situaciones_delete = "DELETE FROM situacion_laboral WHERE empresa = $id";
            Executor::doit($sql_situaciones_delete);

            // TERCERO: Finalmente eliminar la empresa
            $sql_empresa = "DELETE FROM " . self::$tablename . " WHERE id = $id";
            return Executor::doit($sql_empresa);

        } catch (Exception $e) {
            // Manejar el error
            return [false, $e->getMessage()];
        }
    }
}
?>