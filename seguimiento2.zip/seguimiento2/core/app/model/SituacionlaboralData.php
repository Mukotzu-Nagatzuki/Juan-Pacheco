<?php
class SituacionlaboralData {
    public static $tablename = "situacion_laboral";

    // Propiedades principales
    public $id;
    public $estudiante;
    public $empresa;
    public $trabaja;
    public $labora_programa_estudios;
    public $cargo_actual;
    public $condicion_laboral;
    public $ingreso_bruto_mensual;
    public $satisfaccion_trabajo;
    public $fecha_inicio;
    public $fecha_fin;
    public $tipo;
    public $actividad;
    
    // Propiedades para JOINs
    public $estudiante_dni;
    public $estudiante_nombre;
    public $estudiante_apellido;
    public $estudiante_am;
    public $estudiante_nombre_completo;
    
    public $empresa_nombre;
    public $empresa_ruc;
    
    // NUEVAS: Propiedades para actividad
    public $actividad_id;
    public $actividad_titulo;
    public $actividad_fecha_inicio;
    public $actividad_fecha_fin;

    // 🔍 Obtener situación laboral por DNI de estudiante
    public static function getByEstudianteDni($dni) {
        $sql = "
            SELECT 
                sl.id,
                sl.estudiante,
                sl.empresa,
                sl.trabaja,
                sl.labora_programa_estudios,
                sl.cargo_actual,
                sl.condicion_laboral,
                sl.ingreso_bruto_mensual,
                sl.satisfaccion_trabajo,
                sl.fecha_inicio,
                sl.fecha_fin,
                sl.tipo,
                sl.actividad,
                
                e.dni_est AS estudiante_dni,
                e.nom_est AS estudiante_nombre,
                e.ap_est AS estudiante_apellido,
                e.am_est AS estudiante_am,
                CONCAT(e.nom_est, ' ', e.ap_est, ' ', COALESCE(e.am_est, '')) AS estudiante_nombre_completo,
                
                em.nombre_comercial AS empresa_nombre,
                em.ruc AS empresa_ruc,
                
                a.id AS actividad_id,
                a.titulo AS actividad_titulo,
                a.fecha_inicio AS actividad_fecha_inicio,
                a.fecha_fin AS actividad_fecha_fin
                
            FROM situacion_laboral sl
            
            INNER JOIN estudiante e 
                ON sl.estudiante = e.id
                
            LEFT JOIN empresa em 
                ON sl.empresa = em.id
                
            LEFT JOIN actividades a 
                ON sl.actividad = a.id
                
            WHERE e.dni_est = :dni
            ORDER BY sl.id DESC
            LIMIT 1
        ";

        $params = [':dni' => $dni];
        $query = Executor::doit($sql, $params);
        return Model::one($query[0], new SituacionlaboralData());
    }

    // 📋 Obtener TODAS las situaciones laborales con detalles
    public static function getAllWithDetails() {
        $sql = "
            SELECT 
                sl.id,
                sl.estudiante,
                sl.empresa,
                sl.trabaja,
                sl.labora_programa_estudios,
                sl.cargo_actual,
                sl.condicion_laboral,
                sl.ingreso_bruto_mensual,
                sl.satisfaccion_trabajo,
                sl.fecha_inicio,
                sl.fecha_fin,
                sl.tipo,
                sl.actividad,
                
                e.dni_est AS estudiante_dni,
                e.nom_est AS estudiante_nombre,
                e.ap_est AS estudiante_apellido,
                e.am_est AS estudiante_am,
                CONCAT(e.nom_est, ' ', e.ap_est, ' ', COALESCE(e.am_est, '')) AS estudiante_nombre_completo,
                
                COALESCE(em.nombre_comercial, 'Sin empresa') AS empresa_nombre,
                COALESCE(em.ruc, '') AS empresa_ruc,
                
                a.id AS actividad_id,
                a.titulo AS actividad_titulo,
                a.fecha_inicio AS actividad_fecha_inicio,
                a.fecha_fin AS actividad_fecha_fin
                
            FROM situacion_laboral sl
            
            INNER JOIN estudiante e 
                ON sl.estudiante = e.id
                
            LEFT JOIN empresa em 
                ON sl.empresa = em.id
                
            LEFT JOIN actividades a 
                ON sl.actividad = a.id
                
            ORDER BY sl.id DESC
        ";

        $query = Executor::doit($sql);
        return Model::many($query[0], new SituacionlaboralData());
    }
    
    // 💾 Insertar nueva situación laboral CON ACTIVIDAD AUTOMÁTICA
    public static function add($data) {
        // Obtener la actividad activa actualmente
        require_once "ActividadesData.php";
        $actividad_actual = ActividadesData::getActividadActivaActual();
        
        // Si hay una actividad activa, asignarla automáticamente
        $actividad_id = $actividad_actual ? $actividad_actual->id : null;
        
        $sql = "INSERT INTO " . self::$tablename . " 
                (estudiante, empresa, trabaja, labora_programa_estudios, cargo_actual, 
                 condicion_laboral, ingreso_bruto_mensual, satisfaccion_trabajo, 
                 fecha_inicio, fecha_fin, tipo, actividad)
                VALUES 
                (:estudiante, :empresa, :trabaja, :labora_programa_estudios, :cargo_actual,
                 :condicion_laboral, :ingreso_bruto_mensual, :satisfaccion_trabajo,
                 :fecha_inicio, :fecha_fin, :tipo, :actividad)";
        
        $params = [
            ':estudiante' => $data['estudiante'] ?? null,
            ':empresa' => $data['empresa'] ?? null,
            ':trabaja' => $data['trabaja'] ?? 0,
            ':labora_programa_estudios' => $data['labora_programa_estudios'] ?? null,
            ':cargo_actual' => $data['cargo_actual'] ?? null,
            ':condicion_laboral' => $data['condicion_laboral'] ?? null,
            ':ingreso_bruto_mensual' => $data['ingreso_bruto_mensual'] ?? null,
            ':satisfaccion_trabajo' => $data['satisfaccion_trabajo'] ?? null,
            ':fecha_inicio' => $data['fecha_inicio'] ?? null,
            ':fecha_fin' => $data['fecha_fin'] ?? null,
            ':tipo' => $data['tipo'] ?? 0,
            ':actividad' => $actividad_id // Asignación automática
        ];
        
        Executor::doit($sql, $params);
        return true;
    }

    // ✏️ Actualizar situación laboral (mantener actividad original)
    public static function update($id, $data) {
        // Primero obtener la situación actual para mantener la actividad
        $situacion_actual = self::getById($id);
        $actividad_id = $situacion_actual ? $situacion_actual->actividad : null;
        
        $sql = "UPDATE " . self::$tablename . " SET 
                estudiante = :estudiante,
                empresa = :empresa,
                trabaja = :trabaja,
                labora_programa_estudios = :labora_programa_estudios,
                cargo_actual = :cargo_actual,
                condicion_laboral = :condicion_laboral,
                ingreso_bruto_mensual = :ingreso_bruto_mensual,
                satisfaccion_trabajo = :satisfaccion_trabajo,
                fecha_inicio = :fecha_inicio,
                fecha_fin = :fecha_fin,
                tipo = :tipo
                WHERE id = :id";
        
        $params = [
            ':id' => $id,
            ':estudiante' => $data['estudiante'] ?? null,
            ':empresa' => $data['empresa'] ?? null,
            ':trabaja' => $data['trabaja'] ?? 0,
            ':labora_programa_estudios' => $data['labora_programa_estudios'] ?? null,
            ':cargo_actual' => $data['cargo_actual'] ?? null,
            ':condicion_laboral' => $data['condicion_laboral'] ?? null,
            ':ingreso_bruto_mensual' => $data['ingreso_bruto_mensual'] ?? null,
            ':satisfaccion_trabajo' => $data['satisfaccion_trabajo'] ?? null,
            ':fecha_inicio' => $data['fecha_inicio'] ?? null,
            ':fecha_fin' => $data['fecha_fin'] ?? null,
            ':tipo' => $data['tipo'] ?? 0
        ];
        
        Executor::doit($sql, $params);
        return true;
    }

    // 🔍 Obtener situación por ID
    public static function getById($id) {
        $sql = "
            SELECT 
                sl.*,
                e.dni_est AS estudiante_dni,
                e.nom_est AS estudiante_nombre,
                e.ap_est AS estudiante_apellido,
                CONCAT(e.nom_est, ' ', e.ap_est, ' ', COALESCE(e.am_est, '')) AS estudiante_nombre_completo,
                em.nombre_comercial AS empresa_nombre,
                em.ruc AS empresa_ruc,
                a.titulo AS actividad_titulo,
                a.fecha_inicio AS actividad_fecha_inicio,
                a.fecha_fin AS actividad_fecha_fin
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id
            INNER JOIN empresa em ON sl.empresa = em.id
            LEFT JOIN actividades a ON sl.actividad = a.id
            WHERE sl.id = :id
        ";

        $params = [':id' => $id];
        $query = Executor::doit($sql, $params);
        return Model::one($query[0], new SituacionlaboralData());
    }

    // NUEVO: Obtener situaciones por actividad
    public static function getByActividad($actividad_id) {
        $sql = "
            SELECT 
                sl.*,
                e.dni_est AS estudiante_dni,
                e.nom_est AS estudiante_nombre,
                e.ap_est AS estudiante_apellido,
                CONCAT(e.nom_est, ' ', e.ap_est, ' ', COALESCE(e.am_est, '')) AS estudiante_nombre_completo,
                em.nombre_comercial AS empresa_nombre,
                em.ruc AS empresa_ruc,
                a.titulo AS actividad_titulo
            FROM situacion_laboral sl
            INNER JOIN estudiante e ON sl.estudiante = e.id
            INNER JOIN empresa em ON sl.empresa = em.id
            LEFT JOIN actividades a ON sl.actividad = a.id
            WHERE sl.actividad = :actividad_id
            ORDER BY sl.id DESC
        ";

        $params = [':actividad_id' => $actividad_id];
        $query = Executor::doit($sql, $params);
        return Model::many($query[0], new SituacionlaboralData());
    }

    // ❌ Eliminar situación laboral
    public static function delete($id) {
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = :id";
        $params = [':id' => $id];
        Executor::doit($sql, $params);
        return true;
    }

    // 📊 Obtener conteo total
    public static function getCount() {
        $sql = "SELECT COUNT(*) as total FROM " . self::$tablename;
        $query = Executor::doit($sql);
        $result = Model::one($query[0], new SituacionlaboralData());
        return $result->total ?? 0;
    }

    // 📊 Obtener conteo por actividad
    public static function getCountByActividad($actividad_id) {
        $sql = "SELECT COUNT(*) as total FROM " . self::$tablename . " WHERE actividad = :actividad_id";
        $params = [':actividad_id' => $actividad_id];
        $query = Executor::doit($sql, $params);
        $result = Model::one($query[0], new SituacionlaboralData());
        return $result->total ?? 0;
    }
}
?>