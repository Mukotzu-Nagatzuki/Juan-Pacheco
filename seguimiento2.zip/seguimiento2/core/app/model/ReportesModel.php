<?php
class ReportesModel {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    // REPORTE 1: Situación laboral completa de egresados
    public function getSituacionLaboralCompleta($filtros = []) {
        $where = "WHERE e.estado = 1";
        $params = [];

        if (!empty($filtros['programa_estudio'])) {
            $where .= " AND m.prog_estudios = ?";
            $params[] = $filtros['programa_estudio'];
        }

        if (!empty($filtros['condicion_laboral'])) {
            $where .= " AND sl.condicion_laboral = ?";
            $params[] = $filtros['condicion_laboral'];
        }

        if (!empty($filtros['trabaja'])) {
            $where .= " AND sl.trabaja = ?";
            $params[] = $filtros['trabaja'];
        }

        $sql = "SELECT 
                    e.id,
                    e.dni_est as dni,
                    CONCAT(e.nom_est, ' ', e.ap_est, ' ', e.am_est) as nombre_completo,
                    p.nom_progest as programa_estudio,
                    sl.trabaja,
                    CASE 
                        WHEN sl.trabaja = 1 THEN 'Trabaja'
                        ELSE 'No trabaja'
                    END as situacion_trabajo,
                    cl.nombre_condicion as condicion_laboral,
                    sl.labora_programa_estudios,
                    CASE 
                        WHEN sl.labora_programa_estudios = 1 THEN 'Sí'
                        WHEN sl.labora_programa_estudios = 0 THEN 'No'
                        ELSE 'No aplica'
                    END as trabaja_en_carrera,
                    sl.ingreso_bruto_mensual,
                    sl.satisfaccion_trabajo,
                    emp.razon_social as empresa,
                    emp.sector,
                    sl.fecha_inicio as fecha_inicio_laboral,
                    hl.tiempo_primer_empleo,
                    hl.razon_desempleo,
                    hl.fecha_inicio as fecha_inicio_historial,
                    hl.fecha_fin as fecha_fin_historial
                FROM estudiante e
                INNER JOIN matricula m ON e.id = m.estudiante
                INNER JOIN prog_estudios p ON m.prog_estudios = p.id
                LEFT JOIN situacion_laboral sl ON e.id = sl.estudiante
                LEFT JOIN condicion_laboral cl ON sl.condicion_laboral = cl.id
                LEFT JOIN empresa emp ON sl.empresa = emp.id
                LEFT JOIN historial_laboral hl ON sl.id = hl.situacion
                $where
                ORDER BY p.nom_progest, e.ap_est, e.am_est";

        return $this->db->query($sql, $params);
    }

    // REPORTE 2: Seguimiento de egresados
    public function getSeguimientoEgresados($filtros = []) {
        $where = "WHERE e.estado = 1";
        $params = [];

        if (!empty($filtros['programa_estudio'])) {
            $where .= " AND m.prog_estudios = ?";
            $params[] = $filtros['programa_estudio'];
        }

        if (!empty($filtros['tipo_seguimiento'])) {
            $where .= " AND s.tipo = ?";
            $params[] = $filtros['tipo_seguimiento'];
        }

        if (!empty($filtros['fecha_desde'])) {
            $where .= " AND s.fecha >= ?";
            $params[] = $filtros['fecha_desde'];
        }

        if (!empty($filtros['fecha_hasta'])) {
            $where .= " AND s.fecha <= ?";
            $params[] = $filtros['fecha_hasta'];
        }

        $sql = "SELECT 
                    e.id,
                    e.dni_est as dni,
                    CONCAT(e.nom_est, ' ', e.ap_est, ' ', e.am_est) as nombre_completo,
                    p.nom_progest as programa_estudio,
                    ts.nombre_tipo as tipo_seguimiento,
                    s.observaciones,
                    s.fecha as fecha_seguimiento,
                    CONCAT(emp.nom_est, ' ', emp.ap_est) as realizado_por,
                    sl.trabaja,
                    emp.cargo_emp as cargo_empleado
                FROM estudiante e
                INNER JOIN matricula m ON e.id = m.estudiante
                INNER JOIN prog_estudios p ON m.prog_estudios = p.id
                LEFT JOIN seguimiento s ON e.id = s.estudiante
                LEFT JOIN tipo_seguimiento ts ON s.tipo = ts.id
                LEFT JOIN empleado emp ON s.estudiante = emp.id
                LEFT JOIN situacion_laboral sl ON e.id = sl.estudiante
                $where
                ORDER BY s.fecha DESC, p.nom_progest, e.ap_est";

        return $this->db->query($sql, $params);
    }

    // REPORTE 3: Historial laboral detallado
    public function getHistorialLaboralDetallado($filtros = []) {
        $where = "WHERE e.estado = 1 AND hl.fecha_inicio IS NOT NULL";
        $params = [];

        if (!empty($filtros['programa_estudio'])) {
            $where .= " AND m.prog_estudios = ?";
            $params[] = $filtros['programa_estudio'];
        }

        if (!empty($filtros['empresa'])) {
            $where .= " AND sl.empresa = ?";
            $params[] = $filtros['empresa'];
        }

        $sql = "SELECT 
                    e.id,
                    e.dni_est as dni,
                    CONCAT(e.nom_est, ' ', e.ap_est, ' ', e.am_est) as nombre_egresado,
                    p.nom_progest as programa_estudio,
                    emp.razon_social as empresa,
                    emp.sector,
                    hl.tiempo_primer_empleo,
                    hl.razon_desempleo,
                    hl.fecha_inicio,
                    hl.fecha_fin,
                    hl.fecha_registro,
                    DATEDIFF(hl.fecha_fin, hl.fecha_inicio) as dias_trabajados,
                    sl.condicion_laboral,
                    cl.nombre_condicion as nombre_condicion_laboral,
                    sl.ingreso_bruto_mensual
                FROM historial_laboral hl
                JOIN situacion_laboral sl ON hl.situacion = sl.id
                JOIN estudiante e ON sl.estudiante = e.id
                JOIN matricula m ON e.id = m.estudiante
                JOIN prog_estudios p ON m.prog_estudios = p.id
                LEFT JOIN empresa emp ON sl.empresa = emp.id
                LEFT JOIN condicion_laboral cl ON sl.condicion_laboral = cl.id
                $where
                ORDER BY hl.fecha_inicio DESC, p.nom_progest";

        return $this->db->query($sql, $params);
    }

    // REPORTE 4: Estadísticas de empleabilidad por programa
    public function getEstadisticasEmpleabilidad($filtros = []) {
        $where = "WHERE e.estado = 1";
        $params = [];

        if (!empty($filtros['programa_estudio'])) {
            $where .= " AND m.prog_estudios = ?";
            $params[] = $filtros['programa_estudio'];
        }

        $sql = "SELECT 
                    p.id,
                    p.nom_progest as programa_estudio,
                    COUNT(DISTINCT e.id) as total_egresados,
                    COUNT(DISTINCT sl.id) as egresados_con_registro_laboral,
                    COUNT(DISTINCT CASE WHEN sl.trabaja = 1 THEN e.id END) as egresados_trabajando,
                    COUNT(DISTINCT CASE WHEN sl.trabaja = 0 THEN e.id END) as egresados_desempleados,
                    COUNT(DISTINCT CASE WHEN sl.trabaja IS NULL THEN e.id END) as sin_informacion,
                    ROUND((COUNT(DISTINCT CASE WHEN sl.trabaja = 1 THEN e.id END) * 100.0 / 
                          NULLIF(COUNT(DISTINCT sl.id), 0)), 2) as tasa_empleabilidad,
                    COUNT(DISTINCT CASE WHEN sl.labora_programa_estudios = 1 THEN e.id END) as trabaja_en_carrera,
                    ROUND(AVG(sl.ingreso_bruto_mensual), 2) as ingreso_promedio,
                    COUNT(DISTINCT ts.id) as total_seguimientos,
                    COUNT(DISTINCT emp.id) as empresas_contratantes
                FROM prog_estudios p
                LEFT JOIN matricula m ON p.id = m.prog_estudios
                LEFT JOIN estudiante e ON m.estudiante = e.id
                LEFT JOIN situacion_laboral sl ON e.id = sl.estudiante
                LEFT JOIN seguimiento s ON e.id = s.estudiante
                LEFT JOIN tipo_seguimiento ts ON s.tipo = ts.id
                LEFT JOIN empresa emp ON sl.empresa = emp.id
                $where
                GROUP BY p.id, p.nom_progest
                ORDER BY tasa_empleabilidad DESC";

        return $this->db->query($sql, $params);
    }

    // REPORTE 5: Empleados y su participación en seguimiento
    public function getEmpleadosSeguimiento($filtros = []) {
        $where = "WHERE emp.estado = 1";
        $params = [];

        if (!empty($filtros['cargo'])) {
            $where .= " AND emp.cargo_emp = ?";
            $params[] = $filtros['cargo'];
        }

        $sql = "SELECT 
                    emp.id,
                    emp.dni_emp as dni,
                    emp.apnom_emp as nombre_completo,
                    emp.cargo_emp as cargo,
                    p.nom_progest as programa_responsable,
                    COUNT(DISTINCT s.id) as total_seguimientos_realizados,
                    COUNT(DISTINCT e.id) as estudiantes_seguidos,
                    MIN(s.fecha) as primer_seguimiento,
                    MAX(s.fecha) as ultimo_seguimiento,
                    emp.cel_emp as telefono,
                    emp.mailp_emp as email
                FROM empleado emp
                LEFT JOIN prog_estudios p ON emp.prog_estudios = p.id
                LEFT JOIN seguimiento s ON emp.id = s.estudiante
                LEFT JOIN estudiante e ON s.estudiante = e.id
                $where
                GROUP BY emp.id, emp.dni_emp, emp.apnom_emp, emp.cargo_emp, p.nom_progest
                ORDER BY total_seguimientos_realizados DESC";

        return $this->db->query($sql, $params);
    }

    // REPORTE 6: Empresas que contratan egresados
    public function getEmpresasContratantes($filtros = []) {
        $where = "WHERE emp.estado = 'ACTIVO' OR emp.estado IS NOT NULL";
        $params = [];

        if (!empty($filtros['sector'])) {
            $where .= " AND emp.sector = ?";
            $params[] = $filtros['sector'];
        }

        if (!empty($filtros['validado'])) {
            $where .= " AND emp.validado = ?";
            $params[] = $filtros['validado'];
        }

        $sql = "SELECT 
                    emp.id,
                    emp.ruc,
                    emp.razon_social,
                    emp.nombre_comercial,
                    emp.sector,
                    emp.direccion_fiscal,
                    emp.telefono,
                    emp.email,
                    emp.validado,
                    emp.estado,
                    COUNT(DISTINCT sl.estudiante) as egresados_contratados,
                    COUNT(DISTINCT p.id) as programas_contratados,
                    ROUND(AVG(sl.ingreso_bruto_mensual), 2) as salario_promedio,
                    MIN(sl.fecha_inicio) as primera_contratacion,
                    MAX(sl.fecha_inicio) as ultima_contratacion
                FROM empresa emp
                LEFT JOIN situacion_laboral sl ON emp.id = sl.empresa
                LEFT JOIN estudiante e ON sl.estudiante = e.id
                LEFT JOIN matricula m ON e.id = m.estudiante
                LEFT JOIN prog_estudios p ON m.prog_estudios = p.id
                $where
                GROUP BY emp.id, emp.ruc, emp.razon_social, emp.nombre_comercial, emp.sector
                HAVING egresados_contratados > 0 OR egresados_contratados = 0
                ORDER BY egresados_contratados DESC";

        return $this->db->query($sql, $params);
    }

    // Métodos para obtener datos de filtros
    public function getProgramasEstudios() {
        $sql = "SELECT id, nom_progest as nombre FROM prog_estudios ORDER BY nom_progest";
        return $this->db->query($sql);
    }

    public function getEmpresas() {
        $sql = "SELECT id, razon_social as nombre FROM empresa WHERE estado = 'ACTIVO' ORDER BY razon_social";
        return $this->db->query($sql);
    }

    public function getTiposSeguimiento() {
        $sql = "SELECT id, nombre_tipo as nombre FROM tipo_seguimiento ORDER BY nombre_tipo";
        return $this->db->query($sql);
    }

    public function getCondicionesLaborales() {
        $sql = "SELECT id, nombre_condicion as nombre FROM condicion_laboral ORDER BY nombre_condicion";
        return $this->db->query($sql);
    }

    public function getSectoresEmpresas() {
        $sql = "SELECT DISTINCT sector as nombre FROM empresa WHERE sector IS NOT NULL AND sector != '' ORDER BY sector";
        return $this->db->query($sql);
    }

}
?>