<?php
class MedioConsecucionData {
    public $id;
    public $nombre_medio;

    public static function getAll() {
        $sql = "SELECT * FROM medio_consecucion ORDER BY nombre_medio";
        $query = Executor::doit($sql);
        return Model::many($query[0], new MedioConsecucionData());
    }

    public function add() {
        $sql = "INSERT INTO medio_consecucion (nombre_medio) VALUES (\"$this->nombre_medio\")";
        return Executor::doit($sql);
    }

    public static function getById($id) {
        $sql = "SELECT * FROM medio_consecucion WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new MedioConsecucionData());
    }
}
?>