<?php

class EncuestaData {
    public $id;
    public $estudiante;
    public $empresa;
    public $trabaja;
    public $tipo; // Campo nuevo: 0=Interna (sistema), 1=Externa (formulario)
    public $labora_programa_estudios;
    public $cargo_actual;
    public $condicion_laboral;
    public $ingreso_bruto_mensual;
    public $satisfaccion_trabajo;
    public $fecha_inicio;
    public $fecha_fin;
    public $actividad;

    // Obtener todas las encuestas laborales
    public static function getAll() {
        $sql = "SELECT * FROM situacion_laboral ORDER BY id DESC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new EncuestaData());
    }

    // Obtener todas las encuestas con detalles del estudiante
    public static function getAllWithDetails() {
        $sql = "SELECT sl.*, 
                       e.dni_est as estudiante_dni,
                       e.nom_est as estudiante_nombre,
                       e.ap_est as estudiante_apellido_paterno,
                       e.am_est as estudiante_apellido_materno,
                       CONCAT(e.nom_est, ' ', e.ap_est, ' ', e.am_est) as estudiante_nombre_completo,
                       CASE 
                            WHEN sl.tipo = 1 THEN 'Encuesta Externa'
                            WHEN sl.tipo = 0 THEN 'Encuesta Interna'
                            ELSE 'Sin tipo definido'
                       END as tipo_descripcion
                FROM situacion_laboral sl
                LEFT JOIN estudiante e ON sl.estudiante = e.id
                ORDER BY sl.id DESC";
        
        $query = Executor::doit($sql);
        return Model::many($query[0], new EncuestaData());
    }

    // Obtener una encuesta por su ID
    public static function getById($id) {
        $sql = "SELECT * FROM situacion_laboral WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new EncuestaData());
    }
    
    // Guardar nueva encuesta - MODIFICADO PARA INCLUIR TIPO
    public function add() {
        // Preparar empresa (puede ser NULL)
        $empresa_value = 'NULL';
        if ($this->empresa && $this->empresa != '') {
            $empresa_value = "\"$this->empresa\"";
        }
        
        // Preparar fecha_fin (puede ser NULL)
        $fecha_fin_value = 'NULL';
        if ($this->fecha_fin && $this->fecha_fin != '' && $this->fecha_fin != '0000-00-00') {
            $fecha_fin_value = "\"$this->fecha_fin\"";
        }
        
        // Preparar actividad (puede ser NULL)
        $actividad_value = 'NULL';
        if ($this->actividad && $this->actividad != '') {
            $actividad_value = "\"$this->actividad\"";
        }
        
        // Preparar tipo (si es NULL, usar NULL, sino usar el valor)
        $tipo_value = 'NULL';
        if ($this->tipo !== null && $this->tipo !== '') {
            $tipo_value = "\"$this->tipo\"";
        }
        
        // Preparar otros campos que pueden ser NULL si no trabaja
        $labora_programa_estudios_value = 'NULL';
        if ($this->labora_programa_estudios !== null && $this->labora_programa_estudios !== '') {
            $labora_programa_estudios_value = "\"$this->labora_programa_estudios\"";
        }
        
        $cargo_actual_value = 'NULL';
        if ($this->cargo_actual !== null && $this->cargo_actual !== '') {
            $cargo_actual_value = "\"$this->cargo_actual\"";
        }
        
        $condicion_laboral_value = 'NULL';
        if ($this->condicion_laboral !== null && $this->condicion_laboral !== '') {
            $condicion_laboral_value = "\"$this->condicion_laboral\"";
        }
        
        $ingreso_bruto_mensual_value = 'NULL';
        if ($this->ingreso_bruto_mensual !== null && $this->ingreso_bruto_mensual !== '') {
            $ingreso_bruto_mensual_value = "\"$this->ingreso_bruto_mensual\"";
        }
        
        $satisfaccion_trabajo_value = 'NULL';
        if ($this->satisfaccion_trabajo !== null && $this->satisfaccion_trabajo !== '') {
            $satisfaccion_trabajo_value = "\"$this->satisfaccion_trabajo\"";
        }
        
        $fecha_inicio_value = 'NULL';
        if ($this->fecha_inicio !== null && $this->fecha_inicio !== '') {
            $fecha_inicio_value = "\"$this->fecha_inicio\"";
        }
        
        $sql = "INSERT INTO situacion_laboral 
                (estudiante, empresa, trabaja, tipo, labora_programa_estudios, 
                 cargo_actual, condicion_laboral, ingreso_bruto_mensual, 
                 satisfaccion_trabajo, fecha_inicio, fecha_fin, actividad) 
                VALUES
                (\"$this->estudiante\", $empresa_value, \"$this->trabaja\", 
                 $tipo_value, $labora_programa_estudios_value, $cargo_actual_value, 
                 $condicion_laboral_value, $ingreso_bruto_mensual_value, 
                 $satisfaccion_trabajo_value, $fecha_inicio_value, 
                 $fecha_fin_value, $actividad_value)";
        
        return Executor::doit($sql);
    }

    // Actualizar encuesta existente - MODIFICADO PARA INCLUIR TIPO
    public function update() {
        // Preparar empresa (puede ser NULL)
        $empresa_sql = "empresa = NULL";
        if ($this->empresa && $this->empresa != '') {
            $empresa_sql = "empresa = \"$this->empresa\"";
        }
        
        // Preparar fecha_fin (puede ser NULL)
        $fecha_fin_sql = "fecha_fin = NULL";
        if ($this->fecha_fin && $this->fecha_fin != '' && $this->fecha_fin != '0000-00-00') {
            $fecha_fin_sql = "fecha_fin = \"$this->fecha_fin\"";
        }
        
        // Preparar actividad (puede ser NULL)
        $actividad_sql = "actividad = NULL";
        if ($this->actividad && $this->actividad != '') {
            $actividad_sql = "actividad = \"$this->actividad\"";
        }
        
        // Preparar tipo (puede ser NULL)
        $tipo_sql = "tipo = NULL";
        if ($this->tipo !== null && $this->tipo !== '') {
            $tipo_sql = "tipo = \"$this->tipo\"";
        }
        
        // Preparar otros campos NULL
        $labora_sql = "labora_programa_estudios = NULL";
        if ($this->labora_programa_estudios !== null && $this->labora_programa_estudios !== '') {
            $labora_sql = "labora_programa_estudios = \"$this->labora_programa_estudios\"";
        }
        
        $cargo_sql = "cargo_actual = NULL";
        if ($this->cargo_actual !== null && $this->cargo_actual !== '') {
            $cargo_sql = "cargo_actual = \"$this->cargo_actual\"";
        }
        
        $condicion_sql = "condicion_laboral = NULL";
        if ($this->condicion_laboral !== null && $this->condicion_laboral !== '') {
            $condicion_sql = "condicion_laboral = \"$this->condicion_laboral\"";
        }
        
        $ingreso_sql = "ingreso_bruto_mensual = NULL";
        if ($this->ingreso_bruto_mensual !== null && $this->ingreso_bruto_mensual !== '') {
            $ingreso_sql = "ingreso_bruto_mensual = \"$this->ingreso_bruto_mensual\"";
        }
        
        $satisfaccion_sql = "satisfaccion_trabajo = NULL";
        if ($this->satisfaccion_trabajo !== null && $this->satisfaccion_trabajo !== '') {
            $satisfaccion_sql = "satisfaccion_trabajo = \"$this->satisfaccion_trabajo\"";
        }
        
        $fecha_inicio_sql = "fecha_inicio = NULL";
        if ($this->fecha_inicio !== null && $this->fecha_inicio !== '') {
            $fecha_inicio_sql = "fecha_inicio = \"$this->fecha_inicio\"";
        }
        
        $sql = "UPDATE situacion_laboral SET 
            estudiante = \"$this->estudiante\",
            $empresa_sql,
            trabaja = \"$this->trabaja\",
            $tipo_sql,
            $labora_sql,
            $cargo_sql,
            $condicion_sql,
            $ingreso_sql,
            $satisfaccion_sql,
            $fecha_inicio_sql,
            $fecha_fin_sql,
            $actividad_sql
            WHERE id = $this->id";

        return Executor::doit($sql);
    }

    // Eliminar una encuesta
    public static function deleteById($id) {
        $sql = "DELETE FROM situacion_laboral WHERE id = $id";
        return Executor::doit($sql);
    }
    
    // Método adicional: Obtener encuestas por estudiante
    public static function getByEstudianteId($estudiante_id) {
        $sql = "SELECT * FROM situacion_laboral WHERE estudiante = $estudiante_id ORDER BY fecha_inicio DESC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new EncuestaData());
    }
    
    // Método adicional: Contar total de encuestas
    public static function getCount() {
        $sql = "SELECT COUNT(*) as total FROM situacion_laboral";
        $query = Executor::doit($sql);
        $result = Model::one($query[0], new EncuestaData());
        return $result ? $result->total : 0;
    }
    
    // Método adicional: Contar encuestas por tipo
    public static function getCountByTipo($tipo = null) {
        if ($tipo !== null) {
            $sql = "SELECT COUNT(*) as total FROM situacion_laboral WHERE tipo = $tipo";
        } else {
            $sql = "SELECT tipo, COUNT(*) as total FROM situacion_laboral GROUP BY tipo";
        }
        $query = Executor::doit($sql);
        
        if ($tipo !== null) {
            $result = Model::one($query[0], new EncuestaData());
            return $result ? $result->total : 0;
        } else {
            return Model::many($query[0], new EncuestaData());
        }
    }
    
    // Método adicional: Obtener encuestas por tipo con detalles
    public static function getByTipoWithDetails($tipo) {
        $sql = "SELECT sl.*, 
                       e.dni_est as estudiante_dni,
                       CONCAT(e.nom_est, ' ', e.ap_est, ' ', e.am_est) as estudiante_nombre_completo,
                       CASE 
                            WHEN sl.tipo = 1 THEN 'Encuesta Externa'
                            WHEN sl.tipo = 0 THEN 'Encuesta Interna'
                            ELSE 'Sin tipo definido'
                       END as tipo_descripcion
                FROM situacion_laboral sl
                LEFT JOIN estudiante e ON sl.estudiante = e.id
                WHERE sl.tipo = $tipo
                ORDER BY sl.fecha_inicio DESC";
        
        $query = Executor::doit($sql);
        return Model::many($query[0], new EncuestaData());
    }
    
    // Método adicional: Verificar si estudiante ya tiene encuesta (por DNI)
    public static function estudianteHasEncuesta($dni) {
        $sql = "SELECT COUNT(*) as total 
                FROM situacion_laboral sl
                INNER JOIN estudiante e ON sl.estudiante = e.id
                WHERE e.dni_est = \"$dni\"";
        
        $query = Executor::doit($sql);
        $result = Model::one($query[0], new EncuestaData());
        return $result ? $result->total > 0 : false;
    }
    
    // Método adicional: Obtener estadísticas por tipo
    public static function getEstadisticasPorTipo() {
        $sql = "SELECT 
                    CASE 
                        WHEN tipo = 1 THEN 'Encuesta Externa'
                        WHEN tipo = 0 THEN 'Encuesta Interna'
                        ELSE 'Sin tipo definido'
                    END as origen,
                    COUNT(*) as total_encuestas,
                    COUNT(DISTINCT estudiante) as total_estudiantes,
                    AVG(ingreso_bruto_mensual) as ingreso_promedio,
                    ROUND((SUM(CASE WHEN trabaja = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 2) as porcentaje_trabaja
                FROM situacion_laboral
                GROUP BY tipo
                ORDER BY total_encuestas DESC";
        
        $query = Executor::doit($sql);
        return Model::many($query[0], new EncuestaData());
    }
}
?>