<?php

class ActividadesData {
    public $id;
    public $titulo;
    public $descripcion;
    public $fecha_inicio;
    public $fecha_fin;
    public $estado;
    public $fecha_registro;

    // Obtener todas las actividades
    public static function getAll() {
        $sql = "SELECT * FROM actividades ORDER BY fecha_inicio DESC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new ActividadesData());
    }

    // Obtener actividades activas
    public static function getActivas() {
        $sql = "SELECT * FROM actividades WHERE estado = 1 ORDER BY fecha_inicio DESC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new ActividadesData());
    }

    // Obtener actividad por ID
    public static function getById($id) {
        $sql = "SELECT * FROM actividades WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new ActividadesData());
    }

    // Obtener actividad activa actual (basada en fecha)
    public static function getActividadActivaActual() {
        $hoy = date('Y-m-d');
        $sql = "SELECT * FROM actividades 
                WHERE estado = 1 
                AND fecha_inicio <= '$hoy' 
                AND fecha_fin >= '$hoy' 
                LIMIT 1";
        $query = Executor::doit($sql);
        return Model::one($query[0], new ActividadesData());
    }

    // Verificar si hay alguna actividad activa en este momento
    public static function isEncuestaHabilitada() {
        $actividad = self::getActividadActivaActual();
        return ($actividad != null);
    }

    // Obtener la actividad activa actual (si existe)
    public static function getEncuestaActividadInfo() {
        return self::getActividadActivaActual();
    }

    // Crear nueva actividad
    public function add() {
        $sql = "INSERT INTO actividades (titulo, descripcion, fecha_inicio, fecha_fin, estado) 
                VALUES (\"$this->titulo\", \"$this->descripcion\", \"$this->fecha_inicio\", \"$this->fecha_fin\", \"$this->estado\")";
        
        return Executor::doit($sql);
    }

    // Actualizar actividad
    public function update() {
        $sql = "UPDATE actividades SET 
                titulo = \"$this->titulo\",
                descripcion = \"$this->descripcion\",
                fecha_inicio = \"$this->fecha_inicio\",
                fecha_fin = \"$this->fecha_fin\",
                estado = \"$this->estado\"
                WHERE id = $this->id";

        return Executor::doit($sql);
    }

    // Eliminar actividad
    public static function deleteById($id) {
        // 1. Primero verificar si hay referencias en situacion_laboral
        $sql_check = "SELECT COUNT(*) as total FROM situacion_laboral WHERE actividad = $id";
        $query_check = Executor::doit($sql_check);
        $result = Model::one($query_check[0], new stdClass());
        
        if ($result && $result->total > 0) {
            // OPCIÓN 2A: Establecer actividad a NULL en las referencias
            $sql_update = "UPDATE situacion_laboral SET actividad = NULL WHERE actividad = $id";
            Executor::doit($sql_update);
            
            // Luego eliminar la actividad
            $sql_delete = "DELETE FROM actividades WHERE id = $id";
            return Executor::doit($sql_delete);
            
            // OPCIÓN 2B: Si prefieres no eliminar y mostrar mensaje:
            // return [false, "No se puede eliminar porque hay $result->total registros relacionados"];
        }
        
        // Si no hay referencias, eliminar normalmente
        $sql = "DELETE FROM actividades WHERE id = $id";
        return Executor::doit($sql);
    }
    // Activar/Desactivar actividad
    public static function toggleEstado($id) {
        $sql = "UPDATE actividades SET estado = NOT estado WHERE id = $id";
        return Executor::doit($sql);
    }

    // ✅ NUEVO: Verificar si existe actividad con exactamente las mismas fechas
    public static function existeActividadConMismasFechas($fecha_inicio, $fecha_fin, $excluir_id = null) {
        $condicion_excluir = $excluir_id ? " AND id != $excluir_id" : "";
        $sql = "SELECT COUNT(*) as total FROM actividades 
                WHERE fecha_inicio = '$fecha_inicio' 
                AND fecha_fin = '$fecha_fin' 
                $condicion_excluir";
        $query = Executor::doit($sql);
        $result = Model::one($query[0], new stdClass());
        return ($result && $result->total > 0);
    }

    // ✅ NUEVO: Verificar solapamiento de rangos de fechas
    public static function existeSolapamientoDeFechas($fecha_inicio, $fecha_fin, $excluir_id = null) {
        $condicion_excluir = $excluir_id ? " AND id != $excluir_id" : "";
        $sql = "SELECT COUNT(*) as total FROM actividades 
                WHERE (
                    ('$fecha_inicio' BETWEEN fecha_inicio AND fecha_fin) OR
                    ('$fecha_fin' BETWEEN fecha_inicio AND fecha_fin) OR
                    (fecha_inicio BETWEEN '$fecha_inicio' AND '$fecha_fin') OR
                    (fecha_fin BETWEEN '$fecha_inicio' AND '$fecha_fin')
                ) 
                $condicion_excluir";
        $query = Executor::doit($sql);
        $result = Model::one($query[0], new stdClass());
        return ($result && $result->total > 0);
    }

    // ✅ NUEVO: Obtener actividad que causa solapamiento (para mostrar detalles)
    public static function getActividadSolapada($fecha_inicio, $fecha_fin, $excluir_id = null) {
        $condicion_excluir = $excluir_id ? " AND id != $excluir_id" : "";
        $sql = "SELECT * FROM actividades 
                WHERE (
                    ('$fecha_inicio' BETWEEN fecha_inicio AND fecha_fin) OR
                    ('$fecha_fin' BETWEEN fecha_inicio AND fecha_fin) OR
                    (fecha_inicio BETWEEN '$fecha_inicio' AND '$fecha_fin') OR
                    (fecha_fin BETWEEN '$fecha_inicio' AND '$fecha_fin')
                ) 
                $condicion_excluir
                LIMIT 1";
        $query = Executor::doit($sql);
        return Model::one($query[0], new ActividadesData());
    }

    // ✅ NUEVO: Obtener actividad con exactamente las mismas fechas (para mostrar detalles)
    public static function getActividadConMismasFechas($fecha_inicio, $fecha_fin, $excluir_id = null) {
        $condicion_excluir = $excluir_id ? " AND id != $excluir_id" : "";
        $sql = "SELECT * FROM actividades 
                WHERE fecha_inicio = '$fecha_inicio' 
                AND fecha_fin = '$fecha_fin' 
                $condicion_excluir
                LIMIT 1";
        $query = Executor::doit($sql);
        return Model::one($query[0], new ActividadesData());
    }

    // Obtener actividad por fecha específica
    public static function getActividadPorFecha($fecha = null) {
        if ($fecha === null) {
            $fecha = date('Y-m-d');
        }
        
        $sql = "SELECT * FROM actividades 
                WHERE estado = 1 
                AND fecha_inicio <= '$fecha' 
                AND fecha_fin >= '$fecha' 
                ORDER BY fecha_inicio DESC 
                LIMIT 1";
        
        $query = Executor::doit($sql);
        return Model::one($query[0], new ActividadesData());
    }
    
}

?>