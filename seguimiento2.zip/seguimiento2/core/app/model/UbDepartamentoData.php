<?php
class UbDepartamentoData {
    public static $tablename = "ubdepartamento";

    public $id;
    public $departamento;

    public static function getAll() {
        $sql = "SELECT * FROM " . self::$tablename . " ORDER BY departamento ASC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta UbDepartamentoData::getAll: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new UbDepartamentoData());
    }

    public static function getById($id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new UbDepartamentoData());
    }
}
?>