<?php
class HistoriallaboralData {
    public static $tablename = "historial_laboral";

    public $id;
    public $situacion;
    public $tiempo_primer_empleo;
    public $razon_desempleo;
    public $empresa;      // Añadido del primer código
    public $puesto;       // Añadido del primer código
    public $fecha_inicio;
    public $fecha_fin;
    public $fecha_registro;

    // Propiedades adicionales para JOIN
    public $ap_est;
    public $am_est;
    public $nom_est;
    public $empresa_nombre;
    public $ruc;

    // ========== MOSTRAR TODOS LOS REGISTROS ==========
    public static function getAll() {
        $sql = "SELECT hl.* FROM " . self::$tablename . " hl ORDER BY hl.fecha_registro DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getAll: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // ========== BUSCAR POR ID (para EDITAR + VER DETALLES) ==========
    public static function getById($id) {
        $id = intval($id);
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id LIMIT 1";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getById: " . $query[1]);
            return null;
        }
        
        return Model::one($query[0], new HistoriallaboralData());
    }

    // ========== AGREGAR NUEVO HISTORIAL ==========
    public function add() {
        $sql = "INSERT INTO " . self::$tablename . " 
                (situacion, tiempo_primer_empleo, razon_desempleo, empresa, puesto, fecha_inicio, fecha_fin, fecha_registro) 
                VALUES (
                    $this->situacion,
                    \"$this->tiempo_primer_empleo\",
                    \"$this->razon_desempleo\",
                    \"$this->empresa\",
                    \"$this->puesto\",
                    \"$this->fecha_inicio\",
                    " . ($this->fecha_fin ? "\"$this->fecha_fin\"" : "NULL") . ",
                    NOW()
                )";
        return Executor::doit($sql);
    }

    // ========== EDITAR HISTORIAL EXISTENTE ==========
    public function update() {
        $sql = "UPDATE " . self::$tablename . " SET 
                situacion = $this->situacion,
                tiempo_primer_empleo = \"$this->tiempo_primer_empleo\",
                razon_desempleo = \"$this->razon_desempleo\",
                empresa = \"$this->empresa\",
                puesto = \"$this->puesto\",
                fecha_inicio = \"$this->fecha_inicio\",
                fecha_fin = " . ($this->fecha_fin ? "\"$this->fecha_fin\"" : "NULL") . "
                WHERE id = $this->id";
        return Executor::doit($sql);
    }

    // ========== ELIMINAR HISTORIAL ==========
    public static function delete($id) {
        $id = intval($id);
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = $id";
        return Executor::doit($sql);
    }

    // ========== MÉTODO ELIMINAR POR ID (del primer código) ==========
    public static function deleteById($id) {
        $id = intval($id);
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = $id";
        return Executor::doit($sql);
    }

    // ========== BÚSQUEDA AVANZADA ==========
    public static function search($busqueda, $criterio = 'todas') {
        $busqueda = trim($busqueda);
        $sql = "SELECT hl.* FROM " . self::$tablename . " hl WHERE ";
        
        switch($criterio) {
            case 'tiempo_primer_empleo':
                $sql .= "hl.tiempo_primer_empleo LIKE '%$busqueda%'";
                break;
            case 'razon_desempleo':
                $sql .= "hl.razon_desempleo LIKE '%$busqueda%'";
                break;
            case 'empresa':                 // Añadido
                $sql .= "hl.empresa LIKE '%$busqueda%'";
                break;
            case 'puesto':                  // Añadido
                $sql .= "hl.puesto LIKE '%$busqueda%'";
                break;
            case 'fecha_inicio':
                $sql .= "hl.fecha_inicio LIKE '%$busqueda%'";
                break;
            case 'todas':
            default:
                $sql .= "(hl.tiempo_primer_empleo LIKE '%$busqueda%' OR 
                         hl.razon_desempleo LIKE '%$busqueda%' OR
                         hl.empresa LIKE '%$busqueda%' OR
                         hl.puesto LIKE '%$busqueda%' OR
                         hl.fecha_inicio LIKE '%$busqueda%' OR
                         hl.fecha_fin LIKE '%$busqueda%')";
                break;
        }
        
        $sql .= " ORDER BY hl.fecha_registro DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta search: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // ========== MÉTODOS ADICIONALES ==========

    // Buscar por situación laboral
    public static function getBySituacion($situacion_id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE situacion = $situacion_id ORDER BY fecha_registro DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getBySituacion: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // Verificar si existe registro por situación
    public static function existsBySituacion($situacion_id) {
        $sql = "SELECT COUNT(*) as total FROM " . self::$tablename . " WHERE situacion = $situacion_id";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta existsBySituacion: " . $query[1]);
            return false;
        }
        
        $result = Model::one($query[0], new stdClass());
        return $result->total > 0;
    }

    // Obtener registros entre fechas específicas
    public static function getByDateRange($fecha_inicio, $fecha_fin) {
        $sql = "SELECT * FROM " . self::$tablename . " 
                WHERE fecha_inicio >= \"$fecha_inicio\" 
                AND fecha_inicio <= \"$fecha_fin\"
                ORDER BY fecha_inicio DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getByDateRange: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // Contar registros por situación
    public static function countBySituacion() {
        $sql = "SELECT situacion, COUNT(*) as total
                FROM " . self::$tablename . "
                GROUP BY situacion
                ORDER BY total DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta countBySituacion: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new stdClass());
    }

    // Obtener el último registro
    public static function getLast() {
        $sql = "SELECT * FROM " . self::$tablename . " ORDER BY fecha_registro DESC LIMIT 1";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getLast: " . $query[1]);
            return null;
        }
        
        return Model::one($query[0], new HistoriallaboralData());
    }

    // Análisis de tiempos de empleo (estadísticas)
    public static function getAnalisisTiempos() {
        $sql = "SELECT 
                    tiempo_primer_empleo,
                    COUNT(*) as cantidad,
                    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM " . self::$tablename . "), 2) as porcentaje
                FROM " . self::$tablename . "
                GROUP BY tiempo_primer_empleo
                ORDER BY cantidad DESC";
        
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getAnalisisTiempos: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new stdClass());
    }

    // Obtener razones principales de desempleo
    public static function getRazonesDesempleo() {
        $sql = "SELECT 
                    razon_desempleo,
                    COUNT(*) as cantidad
                FROM " . self::$tablename . "
                WHERE razon_desempleo IS NOT NULL AND razon_desempleo != ''
                GROUP BY razon_desempleo
                ORDER BY cantidad DESC
                LIMIT 10";
        
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getRazonesDesempleo: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new stdClass());
    }

    // Obtener historial con detalles completos
    public static function getAllWithDetails() {
        $sql = "SELECT hl.* FROM " . self::$tablename . " hl ORDER BY hl.fecha_registro DESC";
        
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getAllWithDetails: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // ========== MÉTODO DE BÚSQUEDA ALTERNATIVO ==========
    public static function searchAlternative($busqueda, $criterio = 'todas') {
        $busqueda = trim($busqueda);
        $sql = "SELECT * FROM " . self::$tablename . " WHERE ";

        switch ($criterio) {
            case 'tiempo_primer_empleo':
                $sql .= "tiempo_primer_empleo LIKE '%$busqueda%'";
                break;

            case 'razon_desempleo':
                $sql .= "razon_desempleo LIKE '%$busqueda%'";
                break;

            case 'empresa':                 // Añadido
                $sql .= "empresa LIKE '%$busqueda%'";
                break;

            case 'puesto':                  // Añadido
                $sql .= "puesto LIKE '%$busqueda%'";
                break;

            case 'fecha_inicio':
                $sql .= "fecha_inicio LIKE '%$busqueda%'";
                break;

            default:
                $sql .= "(tiempo_primer_empleo LIKE '%$busqueda%' OR 
                          razon_desempleo LIKE '%$busqueda%' OR
                          empresa LIKE '%$busqueda%' OR
                          puesto LIKE '%$busqueda%' OR
                          fecha_inicio LIKE '%$busqueda%' OR
                          fecha_fin LIKE '%$busqueda%')";
        }

        $sql .= " ORDER BY fecha_registro DESC";

        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta searchAlternative: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // ========== MÉTODOS ESPECÍFICOS PARA EMPRESA Y PUESTO ==========

    // Buscar por empresa (nuevo método)
    public static function getByEmpresa($empresa) {
        $sql = "SELECT * FROM " . self::$tablename . " 
                WHERE empresa LIKE '%$empresa%' 
                ORDER BY fecha_registro DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getByEmpresa: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // Buscar por puesto (nuevo método)
    public static function getByPuesto($puesto) {
        $sql = "SELECT * FROM " . self::$tablename . " 
                WHERE puesto LIKE '%$puesto%' 
                ORDER BY fecha_registro DESC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getByPuesto: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new HistoriallaboralData());
    }

    // Obtener todas las empresas únicas (nuevo método)
    public static function getEmpresasUnicas() {
        $sql = "SELECT DISTINCT empresa 
                FROM " . self::$tablename . " 
                WHERE empresa IS NOT NULL AND empresa != ''
                ORDER BY empresa ASC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getEmpresasUnicas: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new stdClass());
    }

    // Obtener todos los puestos únicos (nuevo método)
    public static function getPuestosUnicos() {
        $sql = "SELECT DISTINCT puesto 
                FROM " . self::$tablename . " 
                WHERE puesto IS NOT NULL AND puesto != ''
                ORDER BY puesto ASC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta getPuestosUnicos: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new stdClass());
    }
}
?>