<?php
class CondicionAcademicaData {
    public static $tablename = "condicion_academica";

    public $id;
    public $nombre_condicion;

    // Obtener todas las condiciones académicas
    public static function getAll() {
        $sql = "SELECT * FROM " . self::$tablename . " ORDER BY nombre_condicion ASC";
        $query = Executor::doit($sql);
        return Model::many($query[0], new CondicionAcademicaData());
    }

    // Obtener una condición académica por ID
    public static function getById($id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new CondicionAcademicaData());
    }

    // Registrar una nueva condición académica
    public function add() {
        $sql = "INSERT INTO " . self::$tablename . " (nombre_condicion) 
                VALUES (\"$this->nombre_condicion\")";
        return Executor::doit($sql);
    }

    // Actualizar una condición académica existente
    public function update() {
        $sql = "UPDATE " . self::$tablename . " 
                SET nombre_condicion = \"$this->nombre_condicion\" 
                WHERE id = $this->id";
        return Executor::doit($sql);
    }

    // Eliminar una condición académica
    public static function delete($id) {
        $sql = "DELETE FROM " . self::$tablename . " WHERE id = $id";
        return Executor::doit($sql);
    }
}
?>