<?php
session_start();
require_once "core/app/model/EstudianteData.php";

// Verificar si hay una sesión de administrador
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

// Obtener el DNI del estudiante desde POST
if (isset($_POST['dni_est']) && !empty($_POST['dni_est'])) {
    $dni_est = $_POST['dni_est'];
    
    // Buscar el correo del estudiante por DNI
    $estudiante = EstudianteData::getByDni($dni_est);
    
    if ($estudiante) {
        // Llamar a la función para enviar correo
        $resultado = enviarCorreoEstudiante($estudiante->correo, $estudiante->nombre);
        
        if ($resultado['success']) {
            echo json_encode(['success' => true, 'message' => 'Correo enviado exitosamente']);
        } else {
            echo json_encode(['success' => false, 'message' => $resultado['error']]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Estudiante no encontrado con el DNI proporcionado']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'DNI no proporcionado']);
}

function enviarCorreoEstudiante($correoDestino, $nombreEstudiante) {
    require 'correo/vendor/autoload.php';
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer(true);

    try {
        // ---------------------------------------------------------
        // CONFIGURACIÓN SMTP
        // ---------------------------------------------------------
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'giseniavalerocainicela@gmail.com'; // Tu correo
        $mail->Password = 'woyu zpnd yqsh vkai'; // Tu contraseña o App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // ---------------------------------------------------------
        // REMITENTE Y DESTINATARIO
        // ---------------------------------------------------------
        $mail->setFrom('giseniavalerocainicela@gmail.com', 'Seguimiento de Egresados - IESTP');
        $mail->addAddress($correoDestino, $nombreEstudiante);

        // ---------------------------------------------------------
        // CONTENIDO DEL MENSAJE
        // ---------------------------------------------------------
        $mail->isHTML(true);
        $mail->Subject = 'Encuesta de Egresados - IESTP Andres Avelino Cáceres Dorregaray';

        // ----------------- DISEÑO MODERNO DEL CORREO -----------------
        $mail->Body = '
        <div style="font-family: Arial, sans-serif; background-color:#f4f4f4; padding: 30px;">
            <div style="max-width:600px; margin:0 auto; background:white; border-radius:12px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,0.1);">

                <!-- Encabezado -->
                <div style="background:#1a73e8; padding:20px; text-align:center; color:white;">
                    <h2 style="margin:0; font-size:24px;">Encuesta de Egresados</h2>
                    <p style="margin:5px 0 0; font-size:14px;">IESTP Andrés Avelino Cáceres Dorregaray</p>
                </div>

                <!-- Cuerpo -->
                <div style="padding: 30px; color:#333; font-size:16px; line-height:1.6;">
                    <p>Estimado(a) <strong>' . htmlspecialchars($nombreEstudiante) . '</strong>,</p>

                    <p>
                        Reciba un cordial saludo. Le invitamos atentamente a completar la siguiente 
                        <strong>Encuesta de Egresados</strong>, con el propósito de mejorar nuestros servicios 
                        educativos y fortalecer el vínculo con nuestros estudiantes.
                    </p>

                    <div style="text-align:center; margin:30px 0;">
                        <a href="https://seguimiento.mallfers.com/encuesta.php" 
                           style="
                               display:inline-block;
                               background:#1a73e8;
                               color:white;
                               padding:14px 26px;
                               border-radius:8px;
                               text-decoration:none;
                               font-size:18px;
                               font-weight:bold;
                               box-shadow:0 3px 6px rgba(0,0,0,0.2);
                               transition:0.3s;
                           ">
                            Completar encuesta
                        </a>
                    </div>

                    <p style="font-size:14px; color:#555;">
                        Su participación es muy valiosa para nosotros y solo le tomará unos minutos.
                        ¡Gracias por contribuir al crecimiento institucional!
                    </p>
                </div>

                <!-- Pie -->
                <div style="background:#f0f0f0; padding:15px; text-align:center; font-size:13px; color:#666;">
                    © ' . date("Y") . ' IESTP Andrés Avelino Cáceres Dorregaray<br>
                    Este es un mensaje automático, por favor no responder.
                </div>

            </div>
        </div>
        ';

        // Enviar el correo
        $mail->send();
        return ['success' => true, 'message' => 'Correo enviado exitosamente'];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'No se pudo enviar el mensaje. Error: ' . $mail->ErrorInfo];
    }
}
?>