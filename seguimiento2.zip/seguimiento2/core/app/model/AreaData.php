<?php
class AreaData {
    public $id_area;
    public $nombre_area;

    public static function getAll() {
        $sql = "SELECT * FROM area ORDER BY nombre_area";
        $query = Executor::doit($sql);
        return Model::many($query[0], new AreaData());
    }
    
    public static function getById($id) {
        $sql = "SELECT * FROM area WHERE id_area = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new AreaData());
    }
    
    public static function getByNombre($nombre) {
        $sql = "SELECT * FROM area WHERE nombre_area = \"$nombre\"";
        $query = Executor::doit($sql);
        return Model::one($query[0], new AreaData());
    }
}
?>