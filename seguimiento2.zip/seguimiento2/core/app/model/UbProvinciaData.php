<?php
class UbProvinciaData {
    public static $tablename = "ubprovincia";

    public $id;
    public $provincia;
    public $ubdepartamento;

    public static function getByDepartamento($departamento_id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE ubdepartamento = $departamento_id ORDER BY provincia ASC";
        $query = Executor::doit($sql);
        
        if (!$query[0]) {
            error_log("Error en consulta UbProvinciaData::getByDepartamento: " . $query[1]);
            return [];
        }
        
        return Model::many($query[0], new UbProvinciaData());
    }

    public static function getById($id) {
        $sql = "SELECT * FROM " . self::$tablename . " WHERE id = $id";
        $query = Executor::doit($sql);
        return Model::one($query[0], new UbProvinciaData());
    }
}
?>