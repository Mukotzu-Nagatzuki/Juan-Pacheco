<?php
// Iniciar sesión para mensajes
session_start();

// CONFIGURACIÓN DE ERRORES PARA DEBUG
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión directa a la base de datos PDO
$host = '50.31.174.34';
$dbname = 'wxwdrnht_integrado_db';
$username = 'wxwdrnht_wxwdrnht_integrado_db';
$password = 'integrado_db2025.';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}

// ========== FUNCIONES PARA ACTIVIDADES ==========
function isEncuestaHabilitada($conn)
{
    $hoy = date('Y-m-d');
    $sql = "SELECT COUNT(*) as total FROM actividades 
            WHERE estado = 1 
            AND fecha_inicio <= :hoy_inicio 
            AND fecha_fin >= :hoy_fin";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'hoy_inicio' => $hoy,
        'hoy_fin' => $hoy
    ]);
    $result = $stmt->fetch();

    return ($result && $result['total'] > 0);
}

function getEncuestaActividadInfo($conn)
{
    $hoy = date('Y-m-d');
    $sql = "SELECT * FROM actividades 
            WHERE estado = 1 
            AND fecha_inicio <= :hoy_inicio 
            AND fecha_fin >= :hoy_fin 
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'hoy_inicio' => $hoy,
        'hoy_fin' => $hoy
    ]);

    return $stmt->fetch();
}

function getActividadActivaActual($conn)
{
    $hoy = date('Y-m-d');
    $sql = "SELECT * FROM actividades 
            WHERE estado = 1 
            AND fecha_inicio <= :hoy_inicio 
            AND fecha_fin >= :hoy_fin 
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'hoy_inicio' => $hoy,
        'hoy_fin' => $hoy
    ]);

    return $stmt->fetch();
}

// ========== FUNCIÓN SIMPLIFICADA PARA VERIFICAR SI YA RESPONDIÓ ==========
function yaRespondioEncuesta($conn, $estudiante_id, $actividad_id)
{
    $sql = "SELECT id FROM situacion_laboral 
            WHERE estudiante = ? AND actividad = ? 
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([$estudiante_id, $actividad_id]);
    
    return $stmt->fetch() ? true : false;
}

// ========== FUNCIÓN PARA OBTENER FECHA DE RESPUESTA ANTERIOR ==========
function getFechaRespuestaAnterior($conn, $estudiante_id, $actividad_id)
{
    // Primero verificar qué columnas existen en la tabla
    try {
        $sql_check_columns = "SHOW COLUMNS FROM situacion_laboral";
        $stmt_check = $conn->prepare($sql_check_columns);
        $stmt_check->execute();
        $columns = $stmt_check->fetchAll();
        $column_names = array_column($columns, 'Field');
        
        // Verificar qué columna de fecha usar
        $fecha_column = 'fecha_creacion'; // valor por defecto
        
        if (in_array('fecha_registro', $column_names)) {
            $fecha_column = 'fecha_registro';
        } elseif (in_array('fecha_creacion', $column_names)) {
            $fecha_column = 'fecha_creacion';
        } elseif (in_array('created_at', $column_names)) {
            $fecha_column = 'created_at';
        } elseif (in_array('fecha', $column_names)) {
            $fecha_column = 'fecha';
        }
        
        $sql = "SELECT $fecha_column FROM situacion_laboral 
               WHERE estudiante = ? AND actividad = ? 
               LIMIT 1";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([$estudiante_id, $actividad_id]);
        $result = $stmt->fetch();
        
        return $result ? $result[$fecha_column] : null;
        
    } catch (Exception $e) {
        error_log("Error al obtener fecha de respuesta: " . $e->getMessage());
        return null;
    }
}

// Verificar si la encuesta está habilitada
$encuestaHabilitada = isEncuestaHabilitada($conn);
$actividadActual = getEncuestaActividadInfo($conn);

// Si NO está habilitada, mostrar mensaje y salir
if (!$encuestaHabilitada) {
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Encuesta no disponible</title>
        <link rel="stylesheet" href="assets/css/encuestaexterna.css">
        <style>
            .error-container {
                max-width: 800px;
                margin: 100px auto;
                padding: 40px;
                background: #fff;
                border-radius: 10px;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);
                text-align: center;
            }
            .error-icon {
                font-size: 80px;
                color: #ff6b6b;
                margin-bottom: 20px;
            }
            .error-title {
                color: #e74c3c;
                margin-bottom: 20px;
            }
            .error-message {
                font-size: 18px;
                color: #555;
                margin-bottom: 30px;
                line-height: 1.6;
            }
            .activity-info {
                background: #f8f9fa;
                border-left: 4px solid #3498db;
                padding: 15px;
                margin: 20px 0;
                text-align: left;
            }
        </style>
    </head>
    <body>
        <div class="main-wrapper">
            <div class="error-container">
                <div class="error-icon">⏸️</div>
                <h1 class="error-title">Encuesta temporalmente no disponible</h1>
                <p class="error-message">
                    La encuesta de situación laboral no está disponible en este momento.
                </p>
                <div class="activity-info">
                    <h4>📅 Períodos de encuesta activos:</h4>
                    <?php
                    $sql = "SELECT * FROM actividades WHERE estado = 1 ORDER BY fecha_inicio ASC";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute();
                    $actividades = $stmt->fetchAll();
                    
                    if (empty($actividades)) {
                        echo "<p>No hay actividades programadas actualmente.</p>";
                    } else {
                        echo "<ul>";
                        foreach ($actividades as $actividad) {
                            $inicio = date('d/m/Y', strtotime($actividad['fecha_inicio']));
                            $fin = date('d/m/Y', strtotime($actividad['fecha_fin']));
                            echo "<li><strong>" . htmlspecialchars($actividad['titulo']) . "</strong><br>";
                            echo "Del $inicio al $fin</li>";
                        }
                        echo "</ul>";
                    }
                    ?>
                </div>
                <p>Por favor, intente nuevamente durante los períodos de encuesta habilitados.</p>
                <a href="javascript:history.back()" class="btn btn-primary">Volver atrás</a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// ========== FUNCIONES PARA UBIGEO ==========
function getDepartamentos($conn)
{
    $sql = "SELECT id, departamento FROM ubdepartamento ORDER BY departamento ASC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getProvinciasByDepartamento($conn, $departamento_id)
{
    $sql = "SELECT id, provincia FROM ubprovincia WHERE ubdepartamento = ? ORDER BY provincia ASC";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$departamento_id]);
    return $stmt->fetchAll();
}

function getDistritosByProvincia($conn, $provincia_id)
{
    $sql = "SELECT id, distrito FROM ubdistrito WHERE ubprovincia = ? ORDER BY distrito ASC";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$provincia_id]);
    return $stmt->fetchAll();
}

function getDepartamentoById($conn, $id)
{
    $sql = "SELECT departamento FROM ubdepartamento WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    $result = $stmt->fetch();
    return $result ? $result['departamento'] : '';
}

function getProvinciaById($conn, $id)
{
    $sql = "SELECT provincia FROM ubprovincia WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    $result = $stmt->fetch();
    return $result ? $result['provincia'] : '';
}

function getDistritoById($conn, $id)
{
    $sql = "SELECT distrito FROM ubdistrito WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    $result = $stmt->fetch();
    return $result ? $result['distrito'] : '';
}

// ========== MANEJAR PETICIONES AJAX ==========
if (isset($_GET['get_provincias']) || isset($_GET['get_distritos'])) {
    header('Content-Type: application/json');
    if (isset($_GET['get_provincias']) && isset($_GET['departamento_id'])) {
        $departamento_id = intval($_GET['departamento_id']);
        try {
            $provincias = getProvinciasByDepartamento($conn, $departamento_id);
            $html = '<option value="">Seleccione Provincia</option>';
            if (!empty($provincias)) {
                foreach ($provincias as $provincia) {
                    $html .= '<option value="' . $provincia['id'] . '">' . htmlspecialchars($provincia['provincia']) . '</option>';
                }
            }
            echo json_encode(['success' => true, 'html' => $html]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error al cargar provincias: ' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_GET['get_distritos']) && isset($_GET['provincia_id'])) {
        $provincia_id = intval($_GET['provincia_id']);
        try {
            $distritos = getDistritosByProvincia($conn, $provincia_id);
            $html = '<option value="">Seleccione Distrito</option>';
            if (!empty($distritos)) {
                foreach ($distritos as $distrito) {
                    $html .= '<option value="' . $distrito['id'] . '">' . htmlspecialchars($distrito['distrito']) . '</option>';
                }
            }
            echo json_encode(['success' => true, 'html' => $html]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error al cargar distritos: ' . $e->getMessage()]);
        }
        exit;
    }
    echo json_encode(['success' => false, 'message' => 'Parámetros inválidos']);
    exit;
}

// ========== MANEJAR PETICIONES AJAX PARA VERIFICAR EMPRESA ==========
if (isset($_GET['check_empresa']) && isset($_GET['ruc'])) {
    header('Content-Type: application/json');
    $ruc = isset($_GET['ruc']) ? trim($_GET['ruc']) : '';
    try {
        $sql_check = "SELECT id, razon_social FROM empresa WHERE ruc = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->execute([$ruc]);
        $empresa = $stmt_check->fetch();
        if ($empresa) {
            echo json_encode([
                'success' => true,
                'exists' => true,
                'razon_social' => $empresa['razon_social']
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'exists' => false
            ]);
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error al verificar empresa: ' . $e->getMessage()
        ]);
    }
    exit;
}

// ========== MANEJAR PETICIONES AJAX PARA VERIFICAR ESTUDIANTE ==========
if (isset($_GET['check_estudiante']) && isset($_GET['dni'])) {
    header('Content-Type: application/json');
    $dni = isset($_GET['dni']) ? trim($_GET['dni']) : '';
    
    // Validación del DNI
    if (strlen($dni) != 8 || !is_numeric($dni)) {
        echo json_encode([
            'success' => false,
            'exists' => false,
            'message' => 'DNI inválido (debe tener 8 dígitos)'
        ]);
        exit;
    }
    
    try {
        // PRIMERO: Verificar la estructura de tu tabla estudiante
        $sql_structure = "SHOW COLUMNS FROM estudiante";
        $stmt_structure = $conn->prepare($sql_structure);
        $stmt_structure->execute();
        $columns = $stmt_structure->fetchAll();
        
        $column_names = array_column($columns, 'Field');
        
        // Construir consulta según las columnas existentes
        $select_fields = [];
        
        if (in_array('id', $column_names)) {
            $select_fields[] = 'id';
        }
        
        if (in_array('dni_est', $column_names)) {
            $select_fields[] = 'dni_est';
        }
        
        if (in_array('nombres', $column_names)) {
            $select_fields[] = 'nombres';
        } elseif (in_array('nom_est', $column_names)) {
            $select_fields[] = 'nom_est as nombres';
        }
        
        if (in_array('apellido_paterno', $column_names)) {
            $select_fields[] = 'apellido_paterno';
        } elseif (in_array('ap_est', $column_names)) {
            $select_fields[] = 'ap_est as apellido_paterno';
        }
        
        if (in_array('apellido_materno', $column_names)) {
            $select_fields[] = 'apellido_materno';
        } elseif (in_array('am_est', $column_names)) {
            $select_fields[] = 'am_est as apellido_materno';
        }
        
        // Agregar campo estado si existe
        if (in_array('estado', $column_names)) {
            $select_fields[] = 'estado';
        }
        
        if (empty($select_fields)) {
            throw new Exception("No se encontraron columnas en la tabla estudiante");
        }
        
        $sql_check = "SELECT " . implode(', ', $select_fields) . " FROM estudiante WHERE dni_est = ?";
        
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->execute([$dni]);
        $estudiante = $stmt_check->fetch();
        
        if ($estudiante) {
            // Construir nombre completo según las columnas disponibles
            $nombre_completo = '';
            if (isset($estudiante['nombres'])) {
                $nombre_completo .= $estudiante['nombres'];
            }
            if (isset($estudiante['apellido_paterno'])) {
                $nombre_completo .= ' ' . $estudiante['apellido_paterno'];
            }
            if (isset($estudiante['apellido_materno'])) {
                $nombre_completo .= ' ' . $estudiante['apellido_materno'];
            }
            $nombre_completo = trim($nombre_completo);
            
            // Determinar tipo de estudiante si existe el campo estado
            $tipo_estado = 'estudiante activo';
            $activo = true;
            if (isset($estudiante['estado'])) {
                if ($estudiante['estado'] == 1) {
                    $tipo_estado = 'egresado';
                } elseif ($estudiante['estado'] == 0) {
                    $tipo_estado = 'estudiante activo';
                } else {
                    $tipo_estado = 'estudiante inactivo';
                    $activo = false;
                }
            }
            
            // VERIFICAR SI YA RESPONDIÓ EN LA ACTIVIDAD ACTUAL
            $yaRespondio = false;
            $mensajeEstado = '';
            $actividad_id_actual = null;
            $actividad_titulo_actual = '';
            $fecha_respuesta_anterior = '';
            
            // Obtener actividad actual
            $hoy = date('Y-m-d');
            $sql_actividad = "SELECT * FROM actividades 
                            WHERE estado = 1 
                            AND fecha_inicio <= :hoy_inicio 
                            AND fecha_fin >= :hoy_fin 
                            LIMIT 1";
            $stmt_actividad = $conn->prepare($sql_actividad);
            $stmt_actividad->execute([
                'hoy_inicio' => $hoy,
                'hoy_fin' => $hoy
            ]);
            $actividadActual = $stmt_actividad->fetch();
            
            if ($actividadActual) {
                $actividad_id_actual = $actividadActual['id'];
                $actividad_titulo_actual = $actividadActual['titulo'];
                
                $yaRespondio = yaRespondioEncuesta($conn, $estudiante['id'], $actividadActual['id']);
                if ($yaRespondio) {
                    $mensajeEstado = 'YA_RESPONDIO';
                    // Obtener fecha de respuesta anterior
                    $fecha_respuesta = getFechaRespuestaAnterior($conn, $estudiante['id'], $actividadActual['id']);
                    if ($fecha_respuesta) {
                        $fecha_respuesta_anterior = date('d/m/Y H:i', strtotime($fecha_respuesta));
                    }
                }
            }
            
            echo json_encode([
                'success' => true,
                'exists' => true,
                'id' => $estudiante['id'] ?? 0,
                'dni_est' => $estudiante['dni_est'] ?? $dni,
                'nombres' => $estudiante['nombres'] ?? '',
                'apellido_paterno' => $estudiante['apellido_paterno'] ?? '',
                'apellido_materno' => $estudiante['apellido_materno'] ?? '',
                'nombre_completo' => $nombre_completo,
                'estado' => $estudiante['estado'] ?? 0,
                'tipo_estado' => $tipo_estado,
                'activo' => $activo,
                'ya_respondio' => $yaRespondio,
                'mensaje_estado' => $mensajeEstado,
                'actividad_id' => $actividad_id_actual,
                'actividad_titulo' => $actividad_titulo_actual,
                'fecha_respuesta_anterior' => $fecha_respuesta_anterior,
                'message' => 'Estudiante encontrado'
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'exists' => false,
                'message' => 'No se encontró un estudiante con este DNI'
            ]);
        }
    } catch (Exception $e) {
        error_log("Error al verificar estudiante: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error en el servidor al verificar estudiante: ' . $e->getMessage()
        ]);
    }
    exit;
}

// Cargar departamentos para el formulario
$departamentos = getDepartamentos($conn);

// Procesar el formulario de SITUACIÓN LABORAL cuando se envía
$mensaje_situacion = '';
$tipo_mensaje_situacion = '';

// Procesar el formulario de EMPRESA cuando se envía
$mensaje_empresa = '';
$tipo_mensaje_empresa = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // DETERMINAR QUÉ FORMULARIO SE ENVIÓ
    if (isset($_POST['form_type']) && $_POST['form_type'] == 'situacion_laboral') {
        try {
            // Obtener y validar datos del formulario de situación laboral
            $dni_est = isset($_POST['dni_est']) ? trim($_POST['dni_est']) : '';
            $trabaja = isset($_POST['trabaja']) ? intval($_POST['trabaja']) : 0;
            
            // Validaciones básicas - SOLO DNI y si trabaja
            if (empty($dni_est) || strlen($dni_est) != 8 || !is_numeric($dni_est)) {
                throw new Exception("El DNI debe tener exactamente 8 dígitos numéricos");
            }
            
            if (!in_array($trabaja, [0, 1])) {
                throw new Exception("Debe seleccionar si trabaja o no");
            }

            // Verificar si el estudiante existe - USANDO LA MISMA LÓGICA QUE EN AJAX
            $sql_structure = "SHOW COLUMNS FROM estudiante";
            $stmt_structure = $conn->prepare($sql_structure);
            $stmt_structure->execute();
            $columns = $stmt_structure->fetchAll();
            $column_names = array_column($columns, 'Field');
            
            $select_fields = ['id', 'dni_est'];
            if (in_array('estado', $column_names)) {
                $select_fields[] = 'estado';
            }
            
            $sql_estudiante = "SELECT " . implode(', ', $select_fields) . " FROM estudiante WHERE dni_est = ?";
            $stmt_estudiante = $conn->prepare($sql_estudiante);
            $stmt_estudiante->execute([$dni_est]);
            $estudiante = $stmt_estudiante->fetch();

            if (!$estudiante) {
                throw new Exception("No se encontró un estudiante con el DNI: $dni_est. Por favor, póngase en contacto con la administración del instituto.");
            }

            // Verificar que el estudiante esté activo (si existe campo estado)
            if (isset($estudiante['estado']) && !in_array($estudiante['estado'], [0, 1])) {
                throw new Exception("El estudiante con DNI $dni_est no está activo en el sistema.");
            }

            $estudiante_id = $estudiante['id'];
            
            // ========== VERIFICAR SI YA RESPONDIÓ EN ESTA ACTIVIDAD ==========
            if ($actividadActual) {
                $yaRespondio = yaRespondioEncuesta($conn, $estudiante_id, $actividadActual['id']);
                
                if ($yaRespondio) {
                    // Obtener información de la respuesta anterior
                    $fecha_respuesta = getFechaRespuestaAnterior($conn, $estudiante_id, $actividadActual['id']);
                    
                    $fecha_formateada = '';
                    if ($fecha_respuesta) {
                        $fecha_formateada = date('d/m/Y H:i', strtotime($fecha_respuesta));
                    }
                    
                    throw new Exception("Ya respondió esta encuesta en la actividad actual.<br>
                                       <strong>Actividad:</strong> " . htmlspecialchars($actividadActual['titulo']) . "<br>
                                       " . ($fecha_formateada ? "<strong>Fecha de respuesta anterior:</strong> $fecha_formateada<br>" : "") . "
                                       <br>Solo puede responder una vez por cada período de encuesta.");
                }
            }
            
            // Obtener otros datos (todos opcionales)
            $ruc_empresa = null;
            $labora_programa_estudios = null;
            $cargo_actual = null;
            $condicion_laboral = null;
            $ingreso_bruto_mensual = null;
            $satisfaccion_trabajo = null;
            $fecha_inicio = null;
            $fecha_fin = null;
            $empresa_id = null;
            
            // Solo procesar empresa si trabaja y hay RUC válido
            if ($trabaja == 1) {
                $ruc_empresa = isset($_POST['ruc_empresa']) ? trim($_POST['ruc_empresa']) : '';
                
                // Solo obtener los otros datos si trabaja
                $labora_programa_estudios = isset($_POST['labora_programa_estudios']) && $_POST['labora_programa_estudios'] !== '' 
                    ? intval($_POST['labora_programa_estudios']) 
                    : null;
                $cargo_actual = isset($_POST['cargo_actual']) && $_POST['cargo_actual'] !== '' 
                    ? trim($_POST['cargo_actual']) 
                    : null;
                $condicion_laboral = isset($_POST['condicion_laboral']) && $_POST['condicion_laboral'] !== ''
                    ? intval($_POST['condicion_laboral'])
                    : null;
                $ingreso_bruto_mensual = isset($_POST['ingreso_bruto_mensual']) && $_POST['ingreso_bruto_mensual'] !== ''
                    ? floatval($_POST['ingreso_bruto_mensual'])
                    : null;
                $satisfaccion_trabajo = isset($_POST['satisfaccion_trabajo']) && $_POST['satisfaccion_trabajo'] !== ''
                    ? trim($_POST['satisfaccion_trabajo'])
                    : null;
                $fecha_inicio = isset($_POST['fecha_inicio']) && $_POST['fecha_inicio'] !== ''
                    ? trim($_POST['fecha_inicio'])
                    : null;
                $fecha_fin = isset($_POST['fecha_fin']) && $_POST['fecha_fin'] !== ''
                    ? trim($_POST['fecha_fin'])
                    : null;
                
                // Procesar empresa solo si hay RUC válido
                if (!empty($ruc_empresa) && strlen($ruc_empresa) == 11 && is_numeric($ruc_empresa)) {
                    // Buscar/crear empresa solo si trabaja y tiene RUC válido
                    $sql_empresa = "SELECT id FROM empresa WHERE ruc = ?";
                    $stmt_empresa = $conn->prepare($sql_empresa);
                    $stmt_empresa->execute([$ruc_empresa]);
                    $empresa = $stmt_empresa->fetch();

                    if (!$empresa) {
                        // Crear nueva empresa automáticamente con datos básicos
                        $sql_insert_empresa = "INSERT INTO empresa (ruc, razon_social, direccion_fiscal, telefono, email, estado, validado, registro_manual) 
                                               VALUES (?, ?, ?, ?, ?, 'ACTIVO', 0, 1)";
                        $stmt_insert_empresa = $conn->prepare($sql_insert_empresa);
                        $razon_social = "Empresa RUC " . $ruc_empresa;
                        $direccion = "Por definir";
                        $telefono = "000000000";
                        $email = "contacto@empresa.com";

                        $stmt_insert_empresa->execute([$ruc_empresa, $razon_social, $direccion, $telefono, $email]);
                        $empresa_id = $conn->lastInsertId();
                    } else {
                        $empresa_id = $empresa['id'];
                    }
                }
            }

            // OBTENER LA ACTIVIDAD ACTIVA ACTUAL PARA ASIGNARLA AUTOMÁTICAMENTE
            $actividad_id = null;
            if ($actividadActual) {
                $actividad_id = $actividadActual['id'];
            } else {
                // Si no hay actividad activa, buscar la última actividad creada
                $sql_ultima_actividad = "SELECT id FROM actividades ORDER BY id DESC LIMIT 1";
                $stmt_ultima = $conn->prepare($sql_ultima_actividad);
                $stmt_ultima->execute();
                $ultimaActividad = $stmt_ultima->fetch();
                
                if ($ultimaActividad) {
                    $actividad_id = $ultimaActividad['id'];
                }
            }

            // Insertar en situacion_laboral
            $sql_insert = "INSERT INTO situacion_laboral 
                          (estudiante, empresa, trabaja, labora_programa_estudios, cargo_actual, 
                           condicion_laboral, ingreso_bruto_mensual, satisfaccion_trabajo, 
                           fecha_inicio, fecha_fin, actividad) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->execute([
                $estudiante_id,
                $empresa_id, // NULL si no trabaja o no tiene empresa
                $trabaja,
                $labora_programa_estudios, // NULL si no trabaja
                $cargo_actual, // NULL si no trabaja
                $condicion_laboral, // NULL si no trabaja
                $ingreso_bruto_mensual, // NULL si no trabaja
                $satisfaccion_trabajo, // NULL si no trabaja
                $fecha_inicio, // NULL si no trabaja
                $fecha_fin, // NULL si no trabaja
                $actividad_id // Asignación automática de la actividad
            ]);

            // Crear mensaje con información de la actividad
            $actividad_info = "";
            if ($actividadActual) {
                $fecha_inicio_act = date('d/m/Y', strtotime($actividadActual['fecha_inicio']));
                $fecha_fin_act = date('d/m/Y', strtotime($actividadActual['fecha_fin']));
                $actividad_info = "<br><strong>📅 Esta encuesta pertenece a la actividad:</strong><br>";
                $actividad_info .= htmlspecialchars($actividadActual['titulo']) . "<br>";
                $actividad_info .= "Período: $fecha_inicio_act al $fecha_fin_act";
            }

            $mensaje_situacion = "✅ Encuesta de situación laboral registrada correctamente. Gracias por su cooperación" . $actividad_info;
            $tipo_mensaje_situacion = 'success';

            // Limpiar el localStorage después del éxito
            echo '<script>localStorage.removeItem("encuestaData");</script>';
            echo '<script>document.getElementById("encuestaForm").reset();</script>';

            // También limpiar los campos de fecha después del éxito
            echo '<script>';
            echo 'document.getElementById("camposLaborales").style.display = "none";';
            echo 'document.getElementById("trabaja").value = "";';
            echo 'toggleLaboralFields();';
            echo '</script>';

        } catch (Exception $e) {
            $mensaje_situacion = "❌ " . $e->getMessage();
            $tipo_mensaje_situacion = 'error';
        }
    }

    // PROCESAR FORMULARIO DE EMPRESA
    elseif (isset($_POST['form_type']) && $_POST['form_type'] == 'registro_empresa') {
        try {
            // Obtener y validar datos del formulario de empresa
            $ruc = isset($_POST['ruc']) ? trim($_POST['ruc']) : '';
            $razon_social = isset($_POST['razon_social']) ? trim($_POST['razon_social']) : '';
            $nombre_comercial = isset($_POST['nombre_comercial']) ? trim($_POST['nombre_comercial']) : '';
            $direccion_fiscal = isset($_POST['direccion_fiscal']) ? trim($_POST['direccion_fiscal']) : '';
            $telefono = isset($_POST['telefono']) ? trim($_POST['telefono']) : '';
            $email = isset($_POST['email']) ? trim($_POST['email']) : '';
            $sector = isset($_POST['sector']) ? trim($_POST['sector']) : '';
            $estado = isset($_POST['estado']) ? trim($_POST['estado']) : 'ACTIVO';
            $condicion_sunat = isset($_POST['condicion_sunat']) ? trim($_POST['condicion_sunat']) : '';

            // Campos de ubigeo
            $ubigeo = isset($_POST['ubigeo_code']) ? trim($_POST['ubigeo_code']) : '';
            $departamento_id = isset($_POST['departamento']) ? trim($_POST['departamento']) : '';
            $provincia_id = isset($_POST['provincia']) ? trim($_POST['provincia']) : '';
            $distrito_id = isset($_POST['distrito']) ? trim($_POST['distrito']) : '';

            // Obtener nombres de ubigeo usando las funciones
            $departamento_nombre = '';
            $provincia_nombre = '';
            $distrito_nombre = '';

            if ($departamento_id) {
                $departamento_nombre = getDepartamentoById($conn, $departamento_id);
            }

            if ($provincia_id) {
                $provincia_nombre = getProvinciaById($conn, $provincia_id);
            }

            if ($distrito_id) {
                $distrito_nombre = getDistritoById($conn, $distrito_id);
                if (!$ubigeo) {
                    $ubigeo = $distrito_id;
                }
            }

            // Validaciones básicas
            if (empty($ruc) || strlen($ruc) != 11 || !is_numeric($ruc)) {
                throw new Exception("El RUC debe tener exactamente 11 dígitos numéricos");
            }

            if (empty($razon_social)) {
                throw new Exception("La razón social es requerida");
            }

            if (!empty($telefono) && (strlen($telefono) != 9 || !is_numeric($telefono))) {
                throw new Exception("El teléfono debe tener 9 dígitos numéricos");
            }

            if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("El formato del email es inválido");
            }

            // Verificar si la empresa ya existe
            $sql_check = "SELECT id FROM empresa WHERE ruc = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->execute([$ruc]);

            if ($stmt_check->fetch()) {
                throw new Exception("Ya existe una empresa registrada con el RUC: $ruc");
            }

            // Insertar nueva empresa
            $sql_insert_empresa = "INSERT INTO empresa 
                                  (ruc, razon_social, nombre_comercial, direccion_fiscal, 
                                   telefono, email, sector, estado, condicion_sunat, 
                                   ubigeo, departamento, provincia, distrito, 
                                   validado, registro_manual, fecha_creacion) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, NOW())";

            $stmt_insert = $conn->prepare($sql_insert_empresa);
            $stmt_insert->execute([
                $ruc,
                $razon_social,
                $nombre_comercial,
                $direccion_fiscal,
                $telefono,
                $email,
                $sector,
                $estado,
                $condicion_sunat,
                $ubigeo,
                $departamento_nombre,
                $provincia_nombre,
                $distrito_nombre
            ]);

            $mensaje_empresa = "✅ Empresa registrada correctamente";
            $tipo_mensaje_empresa = 'success';

            // Limpiar formulario
            echo '<script>document.getElementById("empresaForm").reset();</script>';
            echo '<script>resetUbigeoFields();</script>';

            // Actualizar estado de empresa para que pueda continuar con la encuesta
            echo '<script>';
            echo 'empresaExiste = true;';
            echo 'empresaRazonSocial = "' . addslashes($razon_social) . '";';
            echo 'document.getElementById("empresa_info_message").innerHTML = "<strong>✓ Empresa registrada exitosamente</strong><br>Ahora puede continuar con la encuesta de situación laboral";';
            echo 'document.getElementById("empresa_info_message").className = "empresa-info-message empresa-existe-message";';
            echo 'mostrarFormularioEmpresa(false);';
            echo '</script>';

        } catch (Exception $e) {
            $mensaje_empresa = "" . $e->getMessage();
            $tipo_mensaje_empresa = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encuestas - Situación Laboral y Registro de Empresas</title>
    <link rel="stylesheet" href="assets/css/encuestaexterna.css">
    <style>
        .optional-field-note {
            color: #666;
            font-size: 0.9em;
            margin-top: 10px;
            font-style: italic;
        }
        .field-optional {
            color: #666;
        }
        .disabled-field {
            background-color: #f8f9fa;
            color: #6c757d;
            cursor: not-allowed;
        }
        .estudiante-info-message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            font-size: 0.9em;
            background-color: #f8f9fa;
            border-left: 4px solid transparent;
        }
        .estudiante-existe-message {
            background-color: #d1ecf1;
            border-left-color: #0c5460;
            color: #0c5460;
        }
        .estudiante-no-existe-message {
            background-color: #f8d7da;
            border-left-color: #721c24;
            color: #721c24;
        }
        .estudiante-error-message {
            background-color: #fff3cd;
            border-left-color: #856404;
            color: #856404;
        }
        .registro-contacto-required {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            font-size: 0.95em;
        }
        .registro-contacto-required strong {
            display: block;
            margin-bottom: 5px;
            font-size: 1.1em;
        }
        .form-disabled {
            opacity: 0.6;
            pointer-events: none;
        }
        .dni-success {
            border-color: #28a745 !important;
        }
        .dni-error {
            border-color: #dc3545 !important;
        }
        .bloqueo-formulario {
            padding: 15px;
            border: 2px solid #c6d3f5ff;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
        }
        /* EL DNI NUNCA SE DESHABILITA */
        #dni_est {
            background-color: white !important;
            color: #000 !important;
            cursor: text !important;
            pointer-events: auto !important;
        }
        .activity-alert {
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }
        .activity-alert h3 {
            margin-top: 0;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .activity-alert h3 i {
            font-size: 1.5em;
        }
        .activity-dates {
            background: rgba(255,255,255,0.2);
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 0.95em;
        }
        .ubigeo-container {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-top: 10px;
        }
        .ubigeo-select {
            width: 100%;
        }
        /* Estilos para tipo de estudiante */
        .tipo-estudiante {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-left: 5px;
        }
        .tipo-estudiante-egresado {
            background-color: #4CAF50;
            color: white;
        }
        .tipo-estudiante-activo {
            background-color: #2196F3;
            color: white;
        }
        .tipo-estudiante-inactivo {
            background-color: #ff9800;
            color: white;
        }
        /* Estilos para bloqueo completo */
        .form-bloqueado-completo {
            opacity: 0.7;
            pointer-events: none;
        }
        .form-bloqueado-completo .form-control {
            background-color: #f8f9fa !important;
            color: #6c757d !important;
            cursor: not-allowed !important;
        }
        .ya-respondido-container {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .ya-respondido-container h4 {
            margin-top: 0;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .ya-respondido-container p {
            margin: 10px 0;
        }
        /* Estilo para indicador de respuesta anterior */
        .respuesta-anterior-info {
            background: rgba(255,255,255,0.1);
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 0.9em;
        }
        /* Estilos para mensaje de ya respondido */
        .ya-respondido-alert {
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            color: #856404;
        }
        .ya-respondido-alert h4 {
            color: #856404;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .ya-respondido-alert h4 i {
            color: #dc3545;
        }
    </style>
</head>

<body>
    <div class="main-wrapper">
        <div class="forms-container" id="formsContainer">
            <!-- ALERTA DE ACTIVIDAD ACTUAL -->
            <?php if ($actividadActual): ?>
            <div class="activity-alert">
                <h3>Período de Encuesta Activo</h3>
                <p><strong><?php echo htmlspecialchars($actividadActual['titulo']); ?></strong></p>
                <div class="activity-dates">
                    <strong>Fecha:</strong> 
                    <?php echo date('d/m/Y', strtotime($actividadActual['fecha_inicio'])); ?> 
                    al 
                    <?php echo date('d/m/Y', strtotime($actividadActual['fecha_fin'])); ?>
                </div>
                <p><small>Esta encuesta se asignará automáticamente a este período</small></p>
            </div>
            <?php endif; ?>

            <!-- FORMULARIO 1: SITUACIÓN LABORAL -->
            <div class="form-section situacion-laboral">
                <div class="form-header">
                    <div class="form-logo-section">
                        <img src="assets/img/inst.png"
                            alt="Logo IESTP Andrés Avelino Cáceres" class="institutional-logo">
                    </div>
                    <div class="form-title-section">
                        <h2>ENCUESTA DE SITUACIÓN LABORAL IESTP "AACD"</h2>
                    </div>
                </div>

                <?php if (!empty($mensaje_situacion)): ?>
                    <div class="alert alert-<?php echo $tipo_mensaje_situacion; ?>">
                        <?php echo $mensaje_situacion; ?>
                    </div>
                <?php endif; ?>

                <!-- Bloqueo inicial - Mostrar hasta que se verifique DNI -->
                <div id="bloqueoInicial" class="bloqueo-formulario">
                    <h3>VERIFICACIÓN REQUERIDA</h3>
                    <p>Para continuar con la encuesta, primero debe ingresar su DNI y verificar que esté registrado en nuestro sistema.</p>
                    <p><strong>Ingrese su DNI de 8 dígitos en el campo a continuación:</strong></p>
                </div>

                <form id="encuestaForm" method="POST" action="" class="form-disabled">
                    <input type="hidden" name="form_type" value="situacion_laboral">

                    <div class="form-group">
                        <label for="dni_est" class="form-label required-field">DNI del Estudiante</label>
                        <input type="number" name="dni_est" id="dni_est" class="form-control" required maxlength="8"
                            placeholder="Ingrese 8 dígitos">
                        <span class="validation-rules">Debe contener exactamente 8 dígitos numéricos</span>
                        <span class="field-status" id="dni_message"></span>
                        
                        <!-- Mensaje informativo sobre estado del estudiante -->
                        <div class="estudiante-info-message" id="estudiante_info_message" style="display: none;"></div>

                        <!-- Mensaje cuando el estudiante no está registrado -->
                        <div class="registro-contacto-required" id="estudiante_no_registrado" style="display: none;">
                            <strong>ESTUDIANTE NO REGISTRADO</strong>
                            No se encontró un estudiante con este DNI en nuestro sistema.<br><br>
                            <strong>Por favor, póngase en contacto con la administración del instituto para regularizar su situación:</strong>
                            <ul>
                                <li><strong>Teléfono:</strong> (01) 123-4567</li>
                                <li><strong>Email:</strong> registro@iestp-aacd.edu.pe</li>
                                <li><strong>Oficina de Registros Académicos</strong></li>
                                <li><strong>Horario:</strong> Lunes a Viernes 8:00 am - 4:00 pm</li>
                            </ul>
                            <p>Una vez regularizada su situación, podrá completar la encuesta.</p>
                        </div>
                    </div>

                    <!-- ✅✅✅ AQUÍ ESTÁ LA PREGUNTA "¿ESTÁS TRABAJANDO ACTUALMENTE?" ✅✅✅ -->
                    <div class="form-group">
                        <label for="trabaja" class="form-label required-field">¿Estás trabajando actualmente?</label>
                        <select name="trabaja" id="trabaja" class="form-control" required disabled>
                            <option value="">Seleccione...</option>
                            <option value="1">Sí</option>
                            <option value="0">No</option>
                        </select>
                        <span class="field-status" id="trabaja_message"></span>
                    </div>

                    <!-- Campos que se habilitan/deshabilitan según la respuesta -->
                    <div id="camposLaborales" style="display: none;">
                        <div class="form-group">
                            <label for="ruc_empresa" class="form-label">RUC de la Empresa</label>
                            <input type="number" name="ruc_empresa" id="ruc_empresa" class="form-control" maxlength="11"
                                placeholder="Ingrese 11 dígitos" disabled>
                            <span class="validation-rules">11 dígitos numéricos</span>
                            <span class="field-status" id="ruc_message"></span>

                            <!-- Mensaje informativo sobre estado de la empresa -->
                            <div class="empresa-info-message" id="empresa_info_message" style="display: none;"></div>

                            <!-- Mensaje cuando se requiere registrar nueva empresa -->
                            <div class="registro-requerido" id="registro_requerido" style="display: none;">
                                <strong>REGISTRO REQUERIDO</strong><br>
                                Esta empresa no está registrada en el sistema. Por favor complete el formulario de
                                registro a continuación.
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="labora_programa_estudios" class="form-label">¿Trabajas en el área de tu carrera?</label>
                            <select name="labora_programa_estudios" id="labora_programa_estudios" class="form-control" disabled>
                                <option value="">Seleccione...</option>
                                <option value="1">Sí</option>
                                <option value="0">No</option>
                            </select>
                            <span class="field-status" id="labora_message"></span>
                        </div>

                        <div class="form-group">
                            <label for="cargo_actual" class="form-label">Cargo actual</label>
                            <input type="text" name="cargo_actual" id="cargo_actual" class="form-control"
                                placeholder="Ej: Analista de Sistemas" maxlength="100" disabled>
                            <span class="validation-rules">Mínimo 2 caracteres, máximo 100 caracteres</span>
                            <span class="field-status" id="cargo_message"></span>
                        </div>

                        <div class="form-group">
                            <label for="condicion_laboral" class="form-label">Condición laboral</label>
                            <select name="condicion_laboral" id="condicion_laboral" class="form-control" disabled>
                                <option value="">Seleccione...</option>
                                <option value="1">Dependiente</option>
                                <option value="2">Independiente</option>
                                <option value="3">Prácticas</option>
                            </select>
                            <span class="field-status" id="condicion_message"></span>
                        </div>

                        <div class="form-group">
                            <label for="ingreso_bruto_mensual" class="form-label">Ingreso Bruto Mensual (S/)</label>
                            <input type="number" step="0.01" name="ingreso_bruto_mensual" id="ingreso_bruto_mensual"
                                class="form-control" placeholder="Ej: 1500.00" min="0" max="999999.99" disabled>
                            <span class="validation-rules"></span>
                            <span class="field-status" id="ingreso_message"></span>
                        </div>

                        <div class="form-group">
                            <label for="satisfaccion_trabajo" class="form-label">Nivel de satisfacción con tu trabajo</label>
                            <select name="satisfaccion_trabajo" id="satisfaccion_trabajo" class="form-control" disabled>
                                <option value="">Seleccione...</option>
                                <option value="Muy satisfecho">Muy satisfecho</option>
                                <option value="Satisfecho">Satisfecho</option>
                                <option value="Neutral">Neutral</option>
                                <option value="Insatisfecho">Insatisfecho</option>
                                <option value="Muy insatisfecho">Muy insatisfecho</option>
                            </select>
                            <span class="field-status" id="satisfaccion_message"></span>
                        </div>

                        <div class="form-group">
                            <label for="fecha_inicio" class="form-label">Fecha de inicio en el trabajo</label>
                            <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-control"
                                max="<?php echo date('Y-m-d'); ?>" disabled>
                            <span class="validation-rules"></span>
                            <span class="field-status" id="fecha_message"></span>
                        </div>

                        <!-- NUEVO CAMPO: FECHA FIN (SIN LÍMITE) -->
                        <div class="form-group">
                            <label for="fecha_fin" class="form-label">Fecha de fin en el trabajo</label>
                            <input type="date" name="fecha_fin" id="fecha_fin" class="form-control" disabled>
                            <span class="validation-rules">(Opcional, puede ser una fecha futura si planea dejar el trabajo)</span>
                            <span class="field-status" id="fecha_fin_message"></span>
                        </div>
                    </div>

                    <p class="optional-field-note" id="notaEncuesta" style="display: none;">Nota: Todos los campos de información laboral son opcionales. Puede enviar la encuesta con solo DNI y si trabaja o no.</p>

                    <div class="form-buttons">
                        <button type="submit" class="btn btn-primary" id="submitEncuestaBtn" disabled>Enviar Encuesta</button>
                        <button type="button" class="btn btn-secondary" onclick="clearLocalStorage()" disabled>Limpiar Datos</button>
                    </div>
                </form>
            </div>

            <!-- FORMULARIO 2: REGISTRO DE EMPRESA (OCULTO POR DEFECTO) -->
            <div class="form-section registro-empresa">
                <div class="form-header">
                    <div class="form-logo-section">
                        <img src="assets/img/inst.png"
                            alt="Logo IESTP Andrés Avelino Cáceres" class="institutional-logo">
                    </div>
                    <div class="form-title-section">
                        <h2>Registro de Nueva Empresa</h2>
                        <p class="form-subtitle">(Formulario complementario)</p>
                    </div>
                </div>

                <?php if (!empty($mensaje_empresa)): ?>
                    <div class="alert alert-<?php echo $tipo_mensaje_empresa; ?>">
                        <?php echo $mensaje_empresa; ?>
                    </div>
                <?php endif; ?>

                <form id="empresaForm" method="POST" action="">
                    <input type="hidden" name="form_type" value="registro_empresa">

                    <!-- RUC ya prellenado desde el primer formulario -->
                    <div class="form-group">
                        <label for="ruc" class="form-label required-field">RUC</label>
                        <input type="number" name="ruc" id="ruc" class="form-control" required maxlength="11"
                            placeholder="El RUC se prellenará automáticamente" readonly>
                        <span class="validation-rules">11 dígitos numéricos</span>
                        <span class="field-status" id="ruc_empresa_message"></span>
                    </div>

                    <div class="form-group">
                        <label for="razon_social" class="form-label required-field">Razón Social</label>
                        <input type="text" name="razon_social" id="razon_social" class="form-control"
                            placeholder="Nombre legal de la empresa" required>
                        <span class="field-status" id="razon_social_message"></span>
                    </div>

                    <div class="form-group">
                        <label for="nombre_comercial" class="form-label">Nombre Comercial</label>
                        <input type="text" name="nombre_comercial" id="nombre_comercial" class="form-control"
                            placeholder="Nombre comercial">
                    </div>

                    <div class="form-group">
                        <label for="sector" class="form-label">Sector</label>
                        <select name="sector" id="sector" class="form-control">
                            <option value="">Seleccione...</option>
                            <option value="Tecnología">Tecnología</option>
                            <option value="Educación">Educación</option>
                            <option value="Salud">Salud</option>
                            <option value="Comercio">Comercio</option>
                            <option value="Industria">Industria</option>
                            <option value="Servicios">Servicios</option>
                            <option value="Construcción">Construcción</option>
                            <option value="Finanzas">Finanzas</option>
                            <option value="Agricultura">Agricultura</option>
                            <option value="Mineria">Minería</option>
                            <option value="Transporte">Transporte</option>
                            <option value="Turismo">Turismo</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" id="email" class="form-control"
                            placeholder="correo@empresa.com">
                        <span class="field-status" id="email_message"></span>
                    </div>

                    <div class="form-group">
                        <label for="telefono" class="form-label">Teléfono</label>
                        <input type="text" name="telefono" id="telefono" class="form-control" placeholder="9 dígitos"
                            maxlength="9">
                        <span class="validation-rules">9 dígitos sin espacios</span>
                        <span class="field-status" id="telefono_message"></span>
                    </div>

                    <div class="form-group">
                        <label for="direccion_fiscal" class="form-label">Dirección Fiscal</label>
                        <textarea name="direccion_fiscal" id="direccion_fiscal" class="form-control"
                            placeholder="Dirección completa" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="estado" class="form-label">Estado SUNAT</label>
                        <select name="estado" id="estado" class="form-control">
                            <option value="ACTIVO" selected>ACTIVO</option>
                            <option value="INACTIVO">INACTIVO</option>
                            <option value="BAJA">BAJA</option>
                            <option value="SUSPENDIDO">SUSPENDIDO</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="condicion_sunat" class="form-label">Condición SUNAT</label>
                        <select name="condicion_sunat" id="condicion_sunat" class="form-control">
                            <option value="">Seleccione...</option>
                            <option value="HABIDO">HABIDO</option>
                            <option value="NO HABIDO">NO HABIDO</option>
                            <option value="PENDIENTE">PENDIENTE</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Ubigeo</label>
                        <div class="ubigeo-container">
                            <div>
                                <label for="departamento" class="form-label">Departamento</label>
                                <select name="departamento" id="departamento" class="form-control ubigeo-select">
                                    <option value="">Seleccionar Departamento</option>
                                    <?php if (!empty($departamentos)): ?>
                                        <?php foreach ($departamentos as $dep): ?>
                                            <option value="<?php echo $dep['id']; ?>">
                                                <?php echo htmlspecialchars($dep['departamento']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                                <input type="hidden" name="departamento_nombre" id="departamento_nombre">
                            </div>
                            <div>
                                <label for="provincia" class="form-label">Provincia</label>
                                <select name="provincia" id="provincia" class="form-control ubigeo-select" disabled>
                                    <option value="">Seleccionar Provincia</option>
                                </select>
                                <input type="hidden" name="provincia_nombre" id="provincia_nombre">
                            </div>
                            <div>
                                <label for="distrito" class="form-label">Distrito</label>
                                <select name="distrito" id="distrito" class="form-control ubigeo-select" disabled>
                                    <option value="">Seleccionar Distrito</option>
                                </select>
                                <input type="hidden" name="distrito_nombre" id="distrito_nombre">
                            </div>
                        </div>
                        <input type="hidden" name="ubigeo_code" id="ubigeo_code">
                    </div>

                    <div class="form-buttons">
                        <button type="submit" class="btn btn-success">Registrar Empresa</button>
                        <button type="button" class="btn btn-secondary" onclick="cancelarRegistroEmpresa()">Cancelar Registro</button>
                        <input type="hidden" name="origen" value="encuesta_interna">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // ==================== SITUACIÓN LABORAL ====================
        let encuestaData = JSON.parse(localStorage.getItem('encuestaData')) || {};
        let submitted = false;
        let empresaExiste = false;
        let empresaRazonSocial = '';
        let estudianteExiste = false;
        let estudianteYaRespondio = false;
        let estudianteInfo = {};

        // Función para habilitar/deshabilitar el formulario completo (EXCEPTO DNI)
        function toggleFormulario(habilitar) {
            const form = document.getElementById('encuestaForm');
            const bloqueoInicial = document.getElementById('bloqueoInicial');
            const camposLaborales = document.getElementById('camposLaborales');
            const notaEncuesta = document.getElementById('notaEncuesta');
            const submitBtn = document.getElementById('submitEncuestaBtn');
            const btnLimpiar = document.querySelector('.btn-secondary[onclick="clearLocalStorage()"]');
            const trabajaSelect = document.getElementById('trabaja');
            const dniInput = document.getElementById('dni_est');
            
            // EL DNI SIEMPRE ESTÁ HABILITADO - NUNCA SE BLOQUEA
            dniInput.disabled = false;
            dniInput.classList.remove('disabled-field');
            dniInput.style.backgroundColor = 'white';
            dniInput.style.color = '#000';
            dniInput.style.cursor = 'text';
            dniInput.style.pointerEvents = 'auto';
            
            if (habilitar && estudianteExiste && !estudianteYaRespondio) {
                // Habilitar formulario (excepto DNI que ya está habilitado)
                form.classList.remove('form-disabled');
                bloqueoInicial.style.display = 'none';
                notaEncuesta.style.display = 'block';
                
                // Habilitar campos (excepto DNI)
                trabajaSelect.disabled = false;
                submitBtn.disabled = false;
                btnLimpiar.disabled = false;
                
                // DNI exitoso
                dniInput.classList.add('dni-success');
                dniInput.classList.remove('dni-error');
                
                // Ocultar mensaje de bloqueo
                bloqueoInicial.style.display = 'none';
            } else {
                // Deshabilitar formulario (excepto DNI)
                form.classList.add('form-disabled');
                
                // Mostrar mensaje de bloqueo solo si no hay estudiante válido
                if (!estudianteExiste) {
                    bloqueoInicial.style.display = 'block';
                } else {
                    bloqueoInicial.style.display = 'none';
                }
                
                notaEncuesta.style.display = 'none';
                
                // Deshabilitar todos los campos EXCEPTO DNI
                trabajaSelect.disabled = true;
                trabajaSelect.value = '';
                camposLaborales.style.display = 'none';
                submitBtn.disabled = true;
                btnLimpiar.disabled = true;
                
                // Limpiar campos laborales
                const fields = [
                    'ruc_empresa', 'labora_programa_estudios', 'cargo_actual',
                    'condicion_laboral', 'ingreso_bruto_mensual', 'satisfaccion_trabajo',
                    'fecha_inicio', 'fecha_fin'
                ];
                fields.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.disabled = true;
                        field.value = '';
                    }
                });
                
                // Resetear mensajes de empresa
                document.getElementById('empresa_info_message').style.display = 'none';
                document.getElementById('registro_requerido').style.display = 'none';
                mostrarFormularioEmpresa(false);
                
                // Resetear estilos del DNI según si existe o no
                if (!estudianteExiste) {
                    dniInput.classList.remove('dni-success');
                    dniInput.classList.add('dni-error');
                }
            }
        }

        // ==================== FUNCIÓN PARA BLOQUEAR FORMULARIO COMPLETAMENTE ====================
        function bloquearFormularioCompletamente() {
            const form = document.getElementById('encuestaForm');
            const bloqueoInicial = document.getElementById('bloqueoInicial');
            const camposLaborales = document.getElementById('camposLaborales');
            const notaEncuesta = document.getElementById('notaEncuesta');
            const submitBtn = document.getElementById('submitEncuestaBtn');
            const btnLimpiar = document.querySelector('.btn-secondary[onclick="clearLocalStorage()"]');
            const trabajaSelect = document.getElementById('trabaja');
            const dniInput = document.getElementById('dni_est');
            
            // Añadir clase de bloqueo
            form.classList.add('form-disabled', 'form-bloqueado-completo');
            
            // Ocultar mensajes
            bloqueoInicial.style.display = 'none';
            notaEncuesta.style.display = 'none';
            
            // Deshabilitar TODOS los campos incluyendo DNI (readonly en este caso)
            const allFields = form.querySelectorAll('input, select, textarea, button');
            allFields.forEach(field => {
                field.disabled = true;
                field.style.backgroundColor = '#f8f9fa';
                field.style.color = '#6c757d';
                field.style.cursor = 'not-allowed';
                field.readOnly = true;
            });
            
            // Permitir que el DNI sea visible pero no editable
            dniInput.disabled = true;
            dniInput.readOnly = true;
            dniInput.style.backgroundColor = '#f8f9fa';
            dniInput.style.color = '#6c757d';
            dniInput.style.cursor = 'not-allowed';
            
            // Campos laborales ocultos
            camposLaborales.style.display = 'none';
            
            // Ocultar botones
            submitBtn.style.display = 'none';
            btnLimpiar.style.display = 'none';
            
            // Mensaje específico
            const infoMessage = document.getElementById('estudiante_info_message');
            if (infoMessage) {
                infoMessage.style.display = 'block';
            }
        }

        function mostrarFormularioEmpresa(mostrar) {
            const formsContainer = document.getElementById('formsContainer');
            const rucInput = document.getElementById('ruc');
            const rucEmpresaInput = document.getElementById('ruc_empresa');

            if (mostrar && rucEmpresaInput && rucEmpresaInput.value) {
                if (rucInput) {
                    rucInput.value = rucEmpresaInput.value;
                }
                formsContainer.classList.add('empresa-visible');
                setTimeout(() => {
                    formsContainer.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }, 300);
            } else {
                formsContainer.classList.remove('empresa-visible');
            }
        }

        function cancelarRegistroEmpresa() {
            if (confirm('¿Está seguro de cancelar el registro de esta empresa?\n\nLa encuesta de situación laboral se enviará igualmente, pero la empresa se registrará con datos básicos si es necesario.')) {
                mostrarFormularioEmpresa(false);
                document.getElementById('empresaForm').reset();
                resetUbigeoFields();
            }
        }

        function saveField(field, value) {
            encuestaData[field] = value;
            localStorage.setItem('encuestaData', JSON.stringify(encuestaData));
        }

        function validateField(field, value, showVisual = false) {
            const messageElement = document.getElementById(field + '_message');
            const inputElement = document.getElementById(field);

            const validationResult = validationsSituacion[field] ? validationsSituacion[field](value) : '';

            if (inputElement) {
                inputElement.classList.remove('valid', 'invalid');
            }

            if (!validationResult) {
                if (messageElement) messageElement.innerHTML = '';
                if ((submitted || showVisual) && inputElement && value) {
                    inputElement.classList.add('valid');
                }
                return true;
            } else {
                if (messageElement) {
                    if (submitted || showVisual) {
                        messageElement.innerHTML = validationResult;
                    } else {
                        messageElement.innerHTML = '';
                    }
                }

                if (inputElement && (submitted || showVisual)) {
                    inputElement.classList.add('invalid');
                }
                return false;
            }
        }

        const validationsSituacion = {
            dni_est: (value) => {
                if (!value) return 'El DNI es requerido';
                if (value.length !== 8) return 'El DNI debe tener exactamente 8 dígitos';
                if (!/^\d+$/.test(value)) return 'El DNI debe contener solo números';
                return '';
            },
            trabaja: (value) => {
                if (value === '' || value === null) return 'Debe seleccionar si trabaja o no';
                return '';
            },
            ruc_empresa: (value) => {
                // Solo validar formato si se ingresa algo
                if (value && value !== '') {
                    if (value.length !== 11) return 'El RUC debe tener exactamente 11 dígitos';
                    if (!/^\d+$/.test(value)) return 'El RUC debe contener solo números';
                }
                return '';
            },
            cargo_actual: (value) => {
                // Solo validar si se ingresa algo
                if (value && value !== '') {
                    if (value.length < 2) return 'El cargo debe tener al menos 2 caracteres';
                    if (value.length > 100) return 'El cargo no puede tener más de 100 caracteres';
                }
                return '';
            },
            ingreso_bruto_mensual: (value) => {
                // Solo validar si se ingresa algo
                if (value && value !== '') {
                    if (parseFloat(value) < 0) return 'El ingreso no puede ser negativo';
                    if (parseFloat(value) > 999999.99) return 'El ingreso no puede ser mayor a 999,999.99';
                }
                return '';
            }
        };

        function applySilentValidationSituacion(fieldId) {
            const element = document.getElementById(fieldId);
            if (element) {
                element.addEventListener('input', function () {
                    validateField(fieldId, this.value, false);
                    saveField(fieldId, this.value);
                });

                element.addEventListener('change', function () {
                    validateField(fieldId, this.value, false);
                    saveField(fieldId, this.value);
                });
            }
        }

        function loadSavedData() {
            if (Object.keys(encuestaData).length > 0) {
                for (const [field, value] of Object.entries(encuestaData)) {
                    const element = document.getElementById(field);
                    if (element) {
                        element.value = value;
                        validateField(field, value, false);
                    }
                }
            }
        }

        function clearLocalStorage() {
            if (confirm('¿Está seguro de limpiar todos los datos guardados?')) {
                localStorage.removeItem('encuestaData');
                encuestaData = {};
                document.getElementById('encuestaForm').reset();
                submitted = false;

                const statusElements = document.querySelectorAll('[id$="_message"]');
                statusElements.forEach(element => {
                    element.innerHTML = '';
                });

                const inputElements = document.querySelectorAll('.form-control');
                inputElements.forEach(element => {
                    element.classList.remove('valid', 'invalid', 'dni-success', 'dni-error');
                });

                // Limpiar mensajes de estudiante
                document.getElementById('estudiante_info_message').style.display = 'none';
                document.getElementById('estudiante_no_registrado').style.display = 'none';
                estudianteExiste = false;
                estudianteYaRespondio = false;

                // Deshabilitar formulario (excepto DNI)
                toggleFormulario(false);

                alert('Datos temporales eliminados');
            }
        }

        function validateAllFieldsWithColors() {
            let allValid = true;
            
            // SOLO validar estos 2 campos obligatorios
            const requiredFields = ['dni_est', 'trabaja'];
            
            for (const field of requiredFields) {
                const element = document.getElementById(field);
                if (element) {
                    if (!validateField(field, element.value, true)) {
                        allValid = false;
                    }
                }
            }
            
            // Validar campos opcionales solo si tienen datos
            const optionalFields = ['ruc_empresa', 'cargo_actual', 'ingreso_bruto_mensual'];
            for (const field of optionalFields) {
                const element = document.getElementById(field);
                if (element && element.value && element.value !== '') {
                    if (!validateField(field, element.value, true)) {
                        allValid = false;
                    }
                }
            }

            return allValid;
        }

        function initializeSituacionValidations() {
            // Solo aplicar validación silenciosa a campos que la necesitan
            const fields = ['dni_est', 'ruc_empresa', 'cargo_actual', 'ingreso_bruto_mensual'];
            fields.forEach(field => applySilentValidationSituacion(field));

            document.getElementById('dni_est').addEventListener('input', function (e) {
                this.value = this.value.replace(/[^0-9]/g, '');
                if (this.value.length > 8) {
                    this.value = this.value.slice(0, 8);
                }
                
                // Asegurarse de que el DNI siempre esté habilitado
                this.disabled = false;
                this.classList.remove('disabled-field');
                this.style.backgroundColor = 'white';
                this.style.color = '#000';
                this.style.cursor = 'text';
                this.style.pointerEvents = 'auto';
            });

            document.getElementById('ruc_empresa').addEventListener('input', function (e) {
                this.value = this.value.replace(/[^0-9]/g, '');
                if (this.value.length > 11) {
                    this.value = this.value.slice(0, 11);
                }
            });
        }

        // ==================== FUNCIÓN PARA VERIFICAR ESTUDIANTE ====================
        function verificarEstudiante(dni) {
            // Solo verificar si se ingresa DNI completo
            if (!dni || dni.length !== 8) {
                const infoMessage = document.getElementById('estudiante_info_message');
                const noRegistrado = document.getElementById('estudiante_no_registrado');
                const dniInput = document.getElementById('dni_est');

                infoMessage.style.display = 'none';
                noRegistrado.style.display = 'none';
                estudianteExiste = false;
                estudianteYaRespondio = false;
                
                // Resetear estilos del DNI
                dniInput.classList.remove('dni-success', 'dni-error');
                
                // Asegurarse que el DNI siga habilitado
                dniInput.disabled = false;
                dniInput.classList.remove('disabled-field');
                dniInput.style.backgroundColor = 'white';
                dniInput.style.color = '#000';
                dniInput.style.cursor = 'text';
                dniInput.style.pointerEvents = 'auto';
                
                // Deshabilitar formulario (excepto DNI)
                toggleFormulario(false);
                return;
            }

            // Mostrar indicador de carga
            const infoMessage = document.getElementById('estudiante_info_message');
            infoMessage.innerHTML = '🔍 Verificando estudiante en la base de datos...';
            infoMessage.className = 'estudiante-info-message';
            infoMessage.style.display = 'block';
            
            // Ocultar mensaje de no registrado
            document.getElementById('estudiante_no_registrado').style.display = 'none';

            // Asegurarse que el DNI siga habilitado durante la verificación
            const dniInput = document.getElementById('dni_est');
            dniInput.disabled = false;
            dniInput.classList.remove('disabled-field');
            dniInput.style.backgroundColor = 'white';
            dniInput.style.color = '#000';
            dniInput.style.cursor = 'text';
            dniInput.style.pointerEvents = 'auto';

            // Realizar la petición AJAX
            fetch(`?check_estudiante=1&dni=${encodeURIComponent(dni)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor: ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Respuesta del servidor:', data);
                    
                    if (data.success === undefined) {
                        throw new Error('Respuesta del servidor inválida');
                    }
                    
                    if (data.success) {
                        if (data.exists) {
                            // Estudiante EXISTE - Verificar si está activo
                            if (data.activo !== false) {
                                // ========== VERIFICAR SI YA RESPONDIÓ ==========
                                if (data.ya_respondio) {
                                    estudianteExiste = true;
                                    estudianteYaRespondio = true;
                                    estudianteInfo = data;

                                    // Construir mensaje con fecha de respuesta anterior
                                    let mensajeFecha = '';
                                    if (data.fecha_respuesta_anterior) {
                                        mensajeFecha = `<p><strong>Fecha de respuesta anterior:</strong> ${data.fecha_respuesta_anterior}</p>`;
                                    }

                                    // Mostrar mensaje de que ya respondió
                                    infoMessage.innerHTML = `
                                        <div class="ya-respondido-alert">
                                            <h4><i></i> YA RESPONDIÓ ESTA ENCUESTA</h4>
                                            <p><strong>Actividad:</strong> ${data.actividad_titulo || 'Actual'}</p>
                                            <p><strong>Estudiante:</strong> ${data.nombre_completo}</p>
                                            <p><strong>DNI:</strong> ${data.dni_est}</p>
                                            <p><strong>Tipo:</strong> ${data.tipo_estado}</p>
                                            ${mensajeFecha}
                                            <p style="color: #721c24; font-weight: bold; margin-top: 15px;">Ya completó esta encuesta en el período actual.
                                            </p>
                                            <p style="font-size: 0.9em; color: #666; margin-top: 10px;">
                                                Solo puede responder una vez por cada período de encuesta.
                                            </p>
                                        </div>
                                    `;
                                    infoMessage.className = 'estudiante-info-message estudiante-no-existe-message';

                                    // Ocultar mensaje de no registrado
                                    document.getElementById('estudiante_no_registrado').style.display = 'none';
                                    
                                    // Bloquear formulario COMPLETAMENTE
                                    bloquearFormularioCompletamente();
                                    
                                    // Asegurarse que el DNI siga habilitado (pero readonly)
                                    dniInput.disabled = true;
                                    dniInput.readOnly = true;
                                    dniInput.classList.remove('disabled-field');
                                    dniInput.style.backgroundColor = '#f8f9fa';
                                    dniInput.style.color = '#6c757d';
                                    dniInput.style.cursor = 'not-allowed';
                                    dniInput.style.pointerEvents = 'none';
                                    
                                    return;
                                }
                                
                                // Si NO ha respondido, continuar normal
                                estudianteExiste = true;
                                estudianteYaRespondio = false;
                                estudianteInfo = data;

                                // Determinar tipo de persona y clase CSS
                                let tipoClase = 'tipo-estudiante-activo';
                                if (data.tipo_estado === 'egresado') {
                                    tipoClase = 'tipo-estudiante-egresado';
                                } else if (data.tipo_estado === 'estudiante inactivo') {
                                    tipoClase = 'tipo-estudiante-inactivo';
                                }
                                
                                infoMessage.innerHTML = `<strong>✅ ${data.tipo_estado.toUpperCase()} VERIFICADO</strong>
                                <span class="tipo-estudiante ${tipoClase}">${data.tipo_estado}</span><br>
                                <strong>Nombre:</strong> ${data.nombre_completo}<br>
                                <strong>DNI:</strong> ${data.dni_est}<br>
                                <small>Ahora puede completar la encuesta de situación laboral.</small>`;
                                infoMessage.className = 'estudiante-info-message estudiante-existe-message';

                                // Ocultar mensaje de no registrado
                                document.getElementById('estudiante_no_registrado').style.display = 'none';
                                
                                // Habilitar formulario completo (excepto DNI que ya está habilitado)
                                toggleFormulario(true);
                                
                                // Guardar DNI en localStorage
                                saveField('dni_est', dni);
                                
                                // Asegurarse que el DNI siga habilitado
                                dniInput.disabled = false;
                                dniInput.classList.remove('disabled-field');
                                dniInput.style.backgroundColor = 'white';
                                dniInput.style.color = '#000';
                                dniInput.style.cursor = 'text';
                                dniInput.style.pointerEvents = 'auto';
                            } else {
                                // Estudiante existe pero no está activo
                                estudianteExiste = false;
                                estudianteYaRespondio = false;

                                infoMessage.innerHTML = `<strong>ESTUDIANTE NO ACTIVO</strong><br>
                                El estudiante con DNI ${dni} existe pero no está activo en el sistema.<br>
                                <small>Tipo: ${data.tipo_estado}</small>`;
                                infoMessage.className = 'estudiante-info-message estudiante-no-existe-message';

                                // Mostrar mensaje de contacto con administración
                                document.getElementById('estudiante_no_registrado').style.display = 'block';
                                
                                // Marcar DNI como error
                                dniInput.classList.add('dni-error');
                                dniInput.classList.remove('dni-success');
                                dniInput.disabled = false; // SIGUE HABILITADO
                                dniInput.classList.remove('disabled-field');
                                dniInput.style.backgroundColor = 'white';
                                dniInput.style.color = '#000';
                                dniInput.style.cursor = 'text';
                                dniInput.style.pointerEvents = 'auto';
                                
                                // Deshabilitar formulario (excepto DNI)
                                toggleFormulario(false);
                            }
                        } else {
                            // Estudiante NO EXISTE
                            estudianteExiste = false;
                            estudianteYaRespondio = false;

                            infoMessage.innerHTML = `<strong>ESTUDIANTE NO ENCONTRADO</strong><br>
                                                     El DNI ${dni} no está registrado en nuestro sistema`;
                            infoMessage.className = 'estudiante-info-message estudiante-no-existe-message';

                            // Mostrar mensaje de contacto con administración
                            document.getElementById('estudiante_no_registrado').style.display = 'block';
                            
                            // Marcar DNI como error
                                dniInput.classList.add('dni-error');
                            dniInput.classList.remove('dni-success');
                            dniInput.disabled = false; // SIGUE HABILITADO
                            dniInput.classList.remove('disabled-field');
                            dniInput.style.backgroundColor = 'white';
                            dniInput.style.color = '#000';
                            dniInput.style.cursor = 'text';
                            dniInput.style.pointerEvents = 'auto';
                            
                            // Deshabilitar formulario (excepto DNI)
                            toggleFormulario(false);
                        }
                    } else {
                        // Error en la verificación
                        infoMessage.innerHTML = `${data.message || 'Error al verificar estudiante. Intente nuevamente.'}`;
                        infoMessage.className = 'estudiante-info-message estudiante-error-message';
                        estudianteExiste = false;
                        estudianteYaRespondio = false;
                        
                        // Asegurarse que el DNI siga habilitado
                        dniInput.disabled = false;
                        dniInput.classList.remove('disabled-field');
                        dniInput.style.backgroundColor = 'white';
                        dniInput.style.color = '#000';
                        dniInput.style.cursor = 'text';
                        dniInput.style.pointerEvents = 'auto';
                        
                        // Deshabilitar formulario (excepto DNI)
                        toggleFormulario(false);
                    }
                })
                .catch(error => {
                    console.error('Error al verificar estudiante:', error);
                    const infoMessage = document.getElementById('estudiante_info_message');
                    
                    infoMessage.innerHTML = 'Error de conexión. Verifique su internet e intente nuevamente.';
                    infoMessage.className = 'estudiante-info-message estudiante-error-message';
                    infoMessage.style.display = 'block';
                    
                    estudianteExiste = false;
                    estudianteYaRespondio = false;
                    
                    // Asegurarse que el DNI siga habilitado
                    const dniInput = document.getElementById('dni_est');
                    dniInput.disabled = false;
                    dniInput.classList.remove('disabled-field');
                    dniInput.style.backgroundColor = 'white';
                    dniInput.style.color = '#000';
                    dniInput.style.cursor = 'text';
                    dniInput.style.pointerEvents = 'auto';
                    
                    // Deshabilitar formulario (excepto DNI)
                    toggleFormulario(false);
                });
        }

        // ==================== FUNCIÓN PARA VERIFICAR EMPRESA ====================
        function verificarEmpresa(ruc) {
            // Solo verificar si se ingresa RUC completo
            if (!ruc || ruc.length !== 11) {
                const infoMessage = document.getElementById('empresa_info_message');
                const registroRequerido = document.getElementById('registro_requerido');

                infoMessage.style.display = 'none';
                registroRequerido.style.display = 'none';
                mostrarFormularioEmpresa(false);

                empresaExiste = false;
                return;
            }

            // Mostrar indicador de carga
            const infoMessage = document.getElementById('empresa_info_message');
            infoMessage.innerHTML = '🔍 Verificando empresa en la base de datos...';
            infoMessage.className = 'empresa-info-message';
            infoMessage.style.display = 'block';

            fetch(`?check_empresa=1&ruc=${ruc}`)
                .then(response => {
                    if (!response.ok) throw new Error('Error en la respuesta');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        if (data.exists) {
                            // Empresa EXISTE
                            empresaExiste = true;
                            empresaRazonSocial = data.razon_social;

                            infoMessage.innerHTML = `<strong>Empresa ya registrada</strong><br>Razón Social: ${data.razon_social}<br><small>No es necesario registrarla nuevamente</small>`;
                            infoMessage.className = 'empresa-info-message empresa-existe-message';

                            // Ocultar mensaje de registro requerido y formulario
                            document.getElementById('registro_requerido').style.display = 'none';
                            mostrarFormularioEmpresa(false);
                        } else {
                            // Empresa NO EXISTE
                            empresaExiste = false;

                            infoMessage.innerHTML = `<strong>Empresa no encontrada</strong><br>El RUC ${ruc} no está registrado en el sistema`;
                            infoMessage.className = 'empresa-info-message empresa-no-existe-message';

                            // Mostrar mensaje de registro requerido
                            document.getElementById('registro_requerido').style.display = 'block';

                            // Mostrar formulario de registro de empresa AL COSTADO
                            mostrarFormularioEmpresa(true);
                        }
                    } else {
                        infoMessage.innerHTML = 'Error al verificar empresa. Intente nuevamente.';
                        infoMessage.className = 'empresa-info-message';
                        mostrarFormularioEmpresa(false);
                    }
                })
                .catch(error => {
                    console.error('Error al verificar empresa:', error);
                    infoMessage.innerHTML = 'Error de conexión. Verifique su internet.';
                    infoMessage.className = 'empresa-info-message';
                    mostrarFormularioEmpresa(false);
                });
        }

        // ==================== FUNCIÓN PARA HABILITAR/DESHABILITAR CAMPOS ====================
        function toggleLaboralFields() {
            // Solo funciona si el estudiante existe y no ha respondido
            if (!estudianteExiste || estudianteYaRespondio) return;
            
            const trabajaSelect = document.getElementById('trabaja');
            const trabajaValue = parseInt(trabajaSelect.value);
            const camposLaborales = document.getElementById('camposLaborales');
            const rucEmpresaInput = document.getElementById('ruc_empresa');

            // AGREGAR 'fecha_fin' AL ARRAY DE CAMPOS
            const fieldsToToggle = [
                'ruc_empresa', 'labora_programa_estudios', 'cargo_actual',
                'condicion_laboral', 'ingreso_bruto_mensual', 'satisfaccion_trabajo', 
                'fecha_inicio', 'fecha_fin'
            ];

            if (trabajaValue === 1) {
                // Si responde "Sí", mostrar campos
                camposLaborales.style.display = 'block';
                fieldsToToggle.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.disabled = false;
                        field.required = false;
                        field.readOnly = false;

                        // Quitar cualquier valor predeterminado
                        if (fieldId === 'ruc_empresa') {
                            field.placeholder = "Ingrese 11 dígitos";
                            if (field.value === '00000000000') field.value = '';
                        }
                        if (fieldId === 'cargo_actual') {
                            field.placeholder = "Ej: Analista de Sistemas";
                            if (field.value === 'NO TRABAJA') field.value = '';
                        }
                        if (fieldId === 'ingreso_bruto_mensual') {
                            field.placeholder = "Ej: 1500.00";
                            if (field.value === '0') field.value = '';
                        }
                        if (fieldId === 'fecha_inicio' && field.value === '1900-01-01') field.value = '';
                        if (fieldId === 'fecha_fin' && field.value === '1900-01-01') field.value = '';
                    }
                });

                // Cambiar placeholder y quitar límite de fecha_fin
                const fechaFinInput = document.getElementById('fecha_fin');
                if (fechaFinInput) {
                    fechaFinInput.placeholder = "Opcional: puede dejar vacío si aún trabaja";
                    // Remover cualquier atributo max si existe
                    fechaFinInput.removeAttribute('max');
                }

                // Mostrar campos laborales
                camposLaborales.style.display = 'block';

                // Si hay RUC ingresado, verificar empresa
                if (rucEmpresaInput && rucEmpresaInput.value && rucEmpresaInput.value.length === 11) {
                    verificarEmpresa(rucEmpresaInput.value);
                } else {
                    // Ocultar mensajes y formulario de empresa
                    document.getElementById('empresa_info_message').style.display = 'none';
                    document.getElementById('registro_requerido').style.display = 'none';
                    mostrarFormularioEmpresa(false);
                }

            } else if (trabajaValue === 0) {
                // Si responde "No", mantener campos visibles pero deshabilitados
                camposLaborales.style.display = 'block';
                fieldsToToggle.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.disabled = true;
                        field.required = false;

                        // Limpiar valores pero mantener placeholders informativos
                        if (fieldId === 'ruc_empresa') {
                            field.value = '';
                            field.placeholder = "No aplica - No trabaja";
                        }
                        if (fieldId === 'cargo_actual') {
                            field.value = '';
                            field.placeholder = "No aplica - No trabaja";
                        }
                        if (fieldId === 'ingreso_bruto_mensual') {
                            field.value = '';
                            field.placeholder = "No aplica - No trabaja";
                        }
                        if (fieldId === 'fecha_inicio') {
                            field.value = '';
                        }
                        if (fieldId === 'fecha_fin') {
                            field.value = '';
                            field.placeholder = "No aplica - No trabaja";
                        }
                        if (fieldId === 'labora_programa_estudios') {
                            field.value = '';
                        }
                        if (fieldId === 'condicion_laboral') {
                            field.value = '';
                        }
                        if (fieldId === 'satisfaccion_trabajo') {
                            field.value = '';
                        }
                    }
                });

                // Ocultar mensajes y formulario de empresa
                document.getElementById('empresa_info_message').style.display = 'none';
                document.getElementById('registro_requerido').style.display = 'none';
                mostrarFormularioEmpresa(false);

            } else {
                // Si no ha seleccionado nada, ocultar campos
                camposLaborales.style.display = 'none';
                fieldsToToggle.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.required = false;
                        field.value = '';
                        field.disabled = true;
                    }
                });

                // Ocultar mensajes y formulario de empresa
                document.getElementById('empresa_info_message').style.display = 'none';
                document.getElementById('registro_requerido').style.display = 'none';
                mostrarFormularioEmpresa(false);
            }
        }

        // ==================== VALIDACIÓN FECHA FIN NO SEA ANTERIOR A FECHA INICIO ====================
        function validarFechaFin() {
            const fechaInicio = document.getElementById('fecha_inicio').value;
            const fechaFin = document.getElementById('fecha_fin').value;
            const messageElement = document.getElementById('fecha_fin_message');
            
            // Solo validar si ambas fechas tienen valor
            if (fechaInicio && fechaFin) {
                if (fechaFin < fechaInicio) {
                    if (messageElement) {
                        messageElement.innerHTML = 'La fecha fin no puede ser anterior a la fecha inicio';
                        messageElement.style.color = '#e74c3c';
                    }
                    document.getElementById('fecha_fin').style.borderColor = '#e74c3c';
                    return false;
                } else {
                    if (messageElement) messageElement.innerHTML = '';
                    document.getElementById('fecha_fin').style.borderColor = '';
                    return true;
                }
            }
            
            // Si no hay fecha fin o no hay fecha inicio, no hay error
            if (messageElement) messageElement.innerHTML = '';
            document.getElementById('fecha_fin').style.borderColor = '';
            return true;
        }

        // ==================== UBIGEO ====================
        let ubigeoInicializado = false;

        function inicializarUbigeo() {
            if (ubigeoInicializado) return;

            console.log("Inicializando ubigeo...");

            const departamentoSelect = document.getElementById('departamento');
            const provinciaSelect = document.getElementById('provincia');
            const distritoSelect = document.getElementById('distrito');

            if (!departamentoSelect || !provinciaSelect || !distritoSelect) {
                console.error("Elementos de ubigeo no encontrados");
                return;
            }

            // Configurar evento para departamento
            departamentoSelect.addEventListener('change', function () {
                const departamentoId = this.value;
                console.log("Departamento seleccionado:", departamentoId);

                // Actualizar campo hidden del nombre del departamento
                const departamentoNombreInput = document.getElementById('departamento_nombre');
                if (departamentoNombreInput) {
                    const selectedOption = this.options[this.selectedIndex];
                    departamentoNombreInput.value = selectedOption.text;
                }

                // Limpiar y deshabilitar provincias y distritos
                provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
                provinciaSelect.disabled = true;
                distritoSelect.innerHTML = '<option value="">Seleccionar Distrito</option>';
                distritoSelect.disabled = true;

                if (departamentoId) {
                    cargarProvincias(departamentoId);
                }
            });

            // Configurar evento para provincia
            provinciaSelect.addEventListener('change', function () {
                const provinciaId = this.value;
                console.log("Provincia seleccionada:", provinciaId);

                // Actualizar campo hidden del nombre de la provincia
                const provinciaNombreInput = document.getElementById('provincia_nombre');
                if (provinciaNombreInput) {
                    const selectedOption = this.options[this.selectedIndex];
                    provinciaNombreInput.value = selectedOption.text;
                }

                // Limpiar y deshabilitar distritos
                distritoSelect.innerHTML = '<option value="">Seleccionar Distrito</option>';
                distritoSelect.disabled = true;

                if (provinciaId) {
                    cargarDistritos(provinciaId);
                }
            });

            // Configurar evento para distrito
            distritoSelect.addEventListener('change', function () {
                const distritoId = this.value;
                console.log("Distrito seleccionado:", distritoId);

                // Actualizar campos hidden
                const distritoNombreInput = document.getElementById('distrito_nombre');
                const ubigeoCodeInput = document.getElementById('ubigeo_code');

                if (distritoNombreInput) {
                    const selectedOption = this.options[this.selectedIndex];
                    distritoNombreInput.value = selectedOption.text;
                }

                if (ubigeoCodeInput && distritoId) {
                    ubigeoCodeInput.value = distritoId;
                }
            });

            ubigeoInicializado = true;
        }

        function cargarProvincias(departamentoId) {
            return new Promise((resolve, reject) => {
                const provinciaSelect = document.getElementById('provincia');
                if (!provinciaSelect) {
                    reject('provinciaSelect no encontrado');
                    return;
                }

                provinciaSelect.disabled = true;
                provinciaSelect.innerHTML = '<option value="">Cargando provincias...</option>';

                fetch(`?get_provincias=1&departamento_id=${departamentoId}`)
                    .then(response => {
                        if (!response.ok) throw new Error('Error en la respuesta');
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            provinciaSelect.innerHTML = data.html;
                            provinciaSelect.disabled = false;
                            resolve(data);
                        } else {
                            provinciaSelect.innerHTML = '<option value="">Error al cargar provincias</option>';
                            reject(data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error al cargar provincias:', error);
                        provinciaSelect.innerHTML = '<option value="">Error al cargar provincias</option>';
                        reject(error);
                    });
            });
        }

        function cargarDistritos(provinciaId) {
            return new Promise((resolve, reject) => {
                const distritoSelect = document.getElementById('distrito');
                if (!distritoSelect) {
                    reject('distritoSelect no encontrado');
                    return;
                }

                distritoSelect.disabled = true;
                distritoSelect.innerHTML = '<option value="">Cargando distritos...</option>';

                fetch(`?get_distritos=1&provincia_id=${provinciaId}`)
                    .then(response => {
                        if (!response.ok) throw new Error('Error en la respuesta');
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            distritoSelect.innerHTML = data.html;
                            distritoSelect.disabled = false;
                            resolve(data);
                        } else {
                            distritoSelect.innerHTML = '<option value="">Error al cargar distritos</option>';
                            reject(data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error al cargar distritos:', error);
                        distritoSelect.innerHTML = '<option value="">Error al cargar distritos</option>';
                        reject(error);
                    });
            });
        }

        function resetUbigeoFields() {
            const departamentoSelect = document.getElementById('departamento');
            const provinciaSelect = document.getElementById('provincia');
            const distritoSelect = document.getElementById('distrito');

            if (departamentoSelect) departamentoSelect.selectedIndex = 0;
            if (provinciaSelect) {
                provinciaSelect.innerHTML = '<option value="">Seleccionar Provincia</option>';
                provinciaSelect.disabled = true;
            }
            if (distritoSelect) {
                distritoSelect.innerHTML = '<option value="">Seleccionar Distrito</option>';
                distritoSelect.disabled = true;
            }

            // Limpiar campos hidden
            document.getElementById('departamento_nombre').value = '';
            document.getElementById('provincia_nombre').value = '';
            document.getElementById('distrito_nombre').value = '';
            document.getElementById('ubigeo_code').value = '';
        }

        // ==================== VALIDACIÓN FORMULARIO EMPRESA ====================
        function validarFormularioEmpresa() {
            // Si la empresa ya existe, no permitir enviar
            if (empresaExiste) {
                alert('Esta empresa ya está registrada en la base de datos. No puede registrarla nuevamente.');
                return false;
            }

            const form = document.getElementById('empresaForm');
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;

            // Resetear bordes
            form.querySelectorAll('input, select, textarea').forEach(field => {
                field.style.borderColor = '';
            });

            // Validar campos requeridos (solo RUC y razón social)
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = '#e74c3c';
                }
            });

            // Validar RUC (11 dígitos)
            const ruc = form.querySelector('input[name="ruc"]');
            if (ruc && !/^\d{11}$/.test(ruc.value)) {
                isValid = false;
                ruc.style.borderColor = '#e74c3c';
            }

            return isValid;
        }

        // ==================== INICIALIZACIÓN ====================
        document.addEventListener('DOMContentLoaded', function () {
            console.log("=== ENCUESTAS JS INICIALIZADO ===");

            // Asegurarse que el DNI esté habilitado al inicio
            const dniInput = document.getElementById('dni_est');
            dniInput.disabled = false;
            dniInput.classList.remove('disabled-field');
            dniInput.style.backgroundColor = 'white';
            dniInput.style.color = '#000';
            dniInput.style.cursor = 'text';
            dniInput.style.pointerEvents = 'auto';

            // Deshabilitar formulario al inicio (excepto DNI)
            toggleFormulario(false);

            // Cargar datos de situación laboral
            loadSavedData();
            initializeSituacionValidations();

            // Inicializar ubigeo (solo para el formulario de empresa)
            inicializarUbigeo();

            // Configurar evento para la pregunta "¿Estás trabajando actualmente?"
            document.getElementById('trabaja').addEventListener('change', toggleLaboralFields);

            // Configurar evento para verificar estudiante cuando se escribe DNI
            dniInput.addEventListener('input', function () {
                const dni = this.value;

                // Limpiar solo números y limitar a 8 dígitos
                this.value = this.value.replace(/[^0-9]/g, '');
                if (this.value.length > 8) {
                    this.value = this.value.slice(0, 8);
                }

                // Verificar estudiante después de 500ms de inactividad
                clearTimeout(this.verificarTimeout);
                this.verificarTimeout = setTimeout(() => {
                    if (dni.length === 8) {
                        verificarEstudiante(dni);
                    } else {
                        // Si no es DNI completo, ocultar mensajes y deshabilitar formulario (excepto DNI)
                        document.getElementById('estudiante_info_message').style.display = 'none';
                        document.getElementById('estudiante_no_registrado').style.display = 'none';
                        estudianteExiste = false;
                        estudianteYaRespondio = false;
                        
                        // Asegurarse que el DNI siga habilitado
                        this.disabled = false;
                        this.classList.remove('disabled-field');
                        this.style.backgroundColor = 'white';
                        this.style.color = '#000';
                        this.style.cursor = 'text';
                        this.style.pointerEvents = 'auto';
                        
                        // Deshabilitar formulario (excepto DNI)
                        toggleFormulario(false);
                    }
                }, 500);
            });

            // Configurar evento para verificar empresa cuando se escribe RUC
            document.getElementById('ruc_empresa').addEventListener('input', function () {
                const ruc = this.value;

                // Limpiar solo números y limitar a 11 dígitos
                this.value = this.value.replace(/[^0-9]/g, '');
                if (this.value.length > 11) {
                    this.value = this.value.slice(0, 11);
                }

                // Verificar empresa después de 500ms de inactividad
                clearTimeout(this.verificarTimeout);
                this.verificarTimeout = setTimeout(() => {
                    if (ruc.length === 11) {
                        verificarEmpresa(ruc);
                    } else {
                        // Si no es RUC completo, ocultar todo
                        document.getElementById('empresa_info_message').style.display = 'none';
                        document.getElementById('registro_requerido').style.display = 'none';
                        mostrarFormularioEmpresa(false);
                    }
                }, 500);
            });

            // Configurar validación para fecha_fin
            document.getElementById('fecha_fin').addEventListener('change', validarFechaFin);
            document.getElementById('fecha_inicio').addEventListener('change', validarFechaFin);

            // Validación antes de enviar formulario de situación laboral
            document.getElementById('encuestaForm').addEventListener('submit', function (e) {
                submitted = true;
                document.body.classList.add('submit-validation');

                // Validar que el estudiante exista
                if (!estudianteExiste) {
                    e.preventDefault();
                    alert(' No puede enviar la encuesta porque el DNI ingresado no está registrado como estudiante activo.\n\nPor favor, póngase en contacto con la administración del instituto para regularizar su situación.');
                    return;
                }

                // Validar que NO haya respondido ya
                if (estudianteYaRespondio) {
                    e.preventDefault();
                    alert('Ya ha respondido esta encuesta en el período actual.\n\nSolo puede responder una vez por cada período de encuesta.');
                    return;
                }

                // Validar que fecha_fin no sea anterior a fecha_inicio
                if (!validarFechaFin()) {
                    e.preventDefault();
                    alert('La fecha fin no puede ser anterior a la fecha inicio.');
                    return;
                }

                if (!validateAllFieldsWithColors()) {
                    e.preventDefault();
                    alert(' Por favor, complete los campos obligatorios correctamente antes de enviar.');
                    const firstError = document.querySelector('.invalid');
                    if (firstError) {
                        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        firstError.focus();
                    }
                } else {
                    // Mostrar confirmación con resumen
                    const trabajaValue = parseInt(document.getElementById('trabaja').value);
                    let mensaje = "¿Confirma el envío de la encuesta?\n\n";
                    mensaje += "DNI: " + document.getElementById('dni_est').value + "\n";
                    mensaje += "Nombre: " + (estudianteInfo.nombre_completo || 'No disponible') + "\n";
                    mensaje += "Tipo: " + (estudianteInfo.tipo_estado || 'Estudiante') + "\n";
                    mensaje += "Trabaja actualmente: " + (trabajaValue === 1 ? "Sí" : "No");

                    if (trabajaValue === 1) {
                        const fechaInicio = document.getElementById('fecha_inicio').value;
                        const fechaFin = document.getElementById('fecha_fin').value;
                        
                        if (fechaInicio) {
                            mensaje += "\nFecha inicio: " + fechaInicio;
                        }
                        if (fechaFin) {
                            mensaje += "\nFecha fin: " + fechaFin + " (puede ser fecha futura)";
                        }
                        
                        const ruc = document.getElementById('ruc_empresa').value;
                        if (ruc && ruc.length === 11) {
                            mensaje += "\nRUC Empresa: " + ruc;
                            
                            // Información sobre estado de la empresa
                            if (empresaExiste) {
                                mensaje += "\n\nEsta empresa ya está registrada: " + empresaRazonSocial;
                            } else {
                                mensaje += "\n\nATENCIÓN: Esta empresa no está registrada.";
                                mensaje += "\nSe creará automáticamente con datos básicos si proporciona RUC.";
                            }
                        }
                    }

                    if (!confirm(mensaje)) {
                        e.preventDefault();
                    }
                }
            });

            // Validación antes de enviar formulario de empresa
            document.getElementById('empresaForm').addEventListener('submit', function (e) {
                // Si la empresa ya existe, bloquear envío
                if (empresaExiste) {
                    e.preventDefault();
                    alert('Esta empresa ya está registrada en la base de datos.');
                    return;
                }

                if (!validarFormularioEmpresa()) {
                    e.preventDefault();
                    alert('Por favor, complete los campos obligatorios del formulario de empresa correctamente.');
                    return;
                }

                const ruc = document.getElementById('ruc').value;
                if (!confirm(`¿Está seguro de registrar la empresa con RUC ${ruc}?\n\nEsto es complementario. Puede continuar con la encuesta sin registrar la empresa.`)) {
                    e.preventDefault();
                }
            });

            // Validación de RUC en formulario de empresa
            document.getElementById('ruc').addEventListener('input', function (e) {
                this.value = this.value.replace(/[^0-9]/g, '');
                if (this.value.length > 11) {
                    this.value = this.value.slice(0, 11);
                }
            });

            // Validación de teléfono en formulario de empresa
            document.getElementById('telefono').addEventListener('input', function (e) {
                this.value = this.value.replace(/[^0-9]/g, '');
                if (this.value.length > 9) {
                    this.value = this.value.slice(0, 9);
                }
            });

            console.log("=== TODAS LAS FUNCIONES INICIALIZADAS ===");
        });
    </script>

</body>

</html>