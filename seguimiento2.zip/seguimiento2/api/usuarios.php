<?php
// usuarios.php - VERSIÓN CORREGIDA

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Manejar CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Cargar autoload desde la ubicación correcta
$base_dir = dirname(__DIR__);
$autoload_path = $base_dir . '/core/autoload.php';

if (!file_exists($autoload_path)) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error del sistema: autoload.php no encontrado"
    ]);
    exit();
}

require_once $autoload_path;

// Verificar método
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido. Use GET."
    ]);
    exit();
}

try {
    // Consulta CORREGIDA para tu estructura
    $sql = "SELECT id, usuario, tipo, nivel, estado FROM usuarios WHERE estado = 1 ORDER BY usuario";
    $result = Executor::doit($sql);
    $stmt = $result[0];
    
    $usuarios = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $usuarios[] = [
            "id" => (int)$row['id'],
            "usuario" => $row['usuario'],
            "tipo" => (int)$row['tipo'],
            "nivel" => (int)$row['nivel'],
            "estado" => (int)$row['estado']
        ];
    }
    
    echo json_encode([
        "success" => true,
        "message" => "Usuarios obtenidos correctamente",
        "data" => $usuarios,
        "total" => count($usuarios),
        "timestamp" => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error al obtener usuarios: " . $e->getMessage()
    ]);
}
?>