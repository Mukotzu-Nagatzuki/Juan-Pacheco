<?php
header("Content-Type: application/json; charset=UTF-8");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar estructura de carpetas
$current_dir = __DIR__;
$parent_dir = dirname(__DIR__);

echo json_encode([
    "success" => true,
    "message" => "Debug - Verificación de estructura",
    "directories" => [
        "current" => $current_dir,
        "parent" => $parent_dir,
        "files_in_current" => array_values(array_diff(scandir($current_dir), ['.', '..'])),
        "files_in_parent" => array_values(array_diff(scandir($parent_dir), ['.', '..']))
    ],
    "autoload_exists" => file_exists($parent_dir . '/autoload.php') ? "SÍ" : "NO",
    "controller_exists" => is_dir($parent_dir . '/controller') ? "SÍ" : "NO"
]);
?>