<?php
// ver_usuarios.php - Versión CORREGIDA para tu estructura de BD

header("Content-Type: text/html; charset=UTF-8");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cargar autoload
$base_dir = dirname(__DIR__);
$autoload_path = $base_dir . '/core/autoload.php';

if (!file_exists($autoload_path)) {
    die("Error: autoload.php no encontrado en: $autoload_path");
}

require_once $autoload_path;

try {
    // Obtener TODOS los usuarios con la estructura CORRECTA
    $sql = "SELECT id, usuario, password, tipo, nivel, estado FROM usuarios ORDER BY id";
    $result = Executor::doit($sql);
    $stmt = $result[0];
    
    echo "<h1>Usuarios en la Base de Datos</h1>";
    echo "<p>Tabla: usuarios</p>";
    
    if ($stmt->rowCount() > 0) {
        echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
        echo "<tr style='background-color: #f2f2f2;'>
                <th>ID</th>
                <th>Usuario</th>
                <th>Contraseña (Hash)</th>
                <th>Tipo</th>
                <th>Nivel</th>
                <th>Estado</th>
                <th>Prueba cURL</th>
              </tr>";
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $hash = $row['password'];
            $hash_length = strlen($hash);
            
            // Determinar tipo de hash
            if ($hash_length == 60 && substr($hash, 0, 4) === '$2y$') {
                $hash_type = 'bcrypt';
            } elseif (substr($hash, 0, 7) === '$2a$10$') {
                $hash_type = 'bcrypt';
            } elseif (substr($hash, 0, 1) === '$') {
                $hash_type = 'crypt/blowfish';
            } else {
                $hash_type = 'desconocido';
            }
            
            echo "<tr>";
            echo "<td>{$row['id']}</td>";
            echo "<td><strong>{$row['usuario']}</strong></td>";
            echo "<td title='Tipo: {$hash_type}'>
                    <div style='max-width: 200px; overflow: hidden; text-overflow: ellipsis; font-size: 10px;'>
                    " . substr($hash, 0, 30) . "..."
                  . "</div>
                  </td>";
            echo "<td>{$row['tipo']}</td>";
            echo "<td>{$row['nivel']}</td>";
            echo "<td>" . ($row['estado'] == 1 ? 'Activo' : 'Inactivo') . "</td>";
            echo "<td>
                    <code style='font-size: 10px;'>
                    curl -X POST https://seguimiento.mallfers.com/api/login.php \\<br>
                    -H 'Content-Type: application/json' \\<br>
                    -d '{\"usuario\":\"{$row['usuario']}\",\"password\":\"TU_CONTRASEÑA_AQUÍ\"}'
                    </code>
                  </td>";
            echo "</tr>";
        }
        
        echo "</table>";
        
    } else {
        echo "<p style='color: red;'>No hay usuarios en la base de datos.</p>";
    }
    
} catch (Exception $e) {
    echo "<h1 style='color: red;'>Error:</h1>";
    echo "<p>" . $e->getMessage() . "</p>";
}
?>
