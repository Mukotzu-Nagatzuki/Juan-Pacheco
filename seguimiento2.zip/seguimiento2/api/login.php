<?php
// login.php - VERSIÓN FINAL SOLO PARA POST

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Manejar preflight CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ========== QUITAR LA PARTE DE GET ==========
// NO mostrar información en peticiones GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Solo para debugging - en producción quitar esto
    echo json_encode([
        "success" => false,
        "message" => "Este endpoint solo acepta POST. Envía usuario y password en formato JSON.",
        "example" => [
            "method" => "POST",
            "headers" => ["Content-Type: application/json"],
            "body" => '{"usuario":"tu_usuario","password":"tu_contraseña"}'
        ]
    ]);
    exit();
}
// ========== FIN DE QUITAR ==========

// Cargar autoload
$base_dir = dirname(__DIR__);
$autoload_path = $base_dir . '/core/autoload.php';

if (!file_exists($autoload_path)) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error: autoload.php no encontrado"
    ]);
    exit();
}

require_once $autoload_path;

// ========== PROCESAR SOLO POST ==========
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido. Use POST."
    ]);
    exit();
}

// Obtener datos JSON
$raw_input = file_get_contents('php://input');

// Log para debugging
error_log("Raw input recibido: " . $raw_input);

$input = json_decode($raw_input, true);

// Si no hay JSON válido
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "JSON inválido: " . json_last_error_msg(),
        "raw_input" => $raw_input
    ]);
    exit();
}

// Validar datos
if (!$input || !isset($input["usuario"]) || !isset($input["password"])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Datos incompletos. Se requieren usuario y password.",
        "received" => $input
    ]);
    exit();
}

$usuario = trim($input["usuario"]);
$password = trim($input["password"]);

// Validar que no estén vacíos
if (empty($usuario) || empty($password)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Usuario y password no pueden estar vacíos"
    ]);
    exit();
}

try {
    // Consulta CORREGIDA para tu estructura
    $sql = "SELECT id, usuario, password, tipo, nivel, estado FROM usuarios WHERE usuario = :usuario AND estado = 1";
    $params = [":usuario" => $usuario];
    
    // Usar tu Executor
    $result = Executor::doit($sql, $params);
    $stmt = $result[0];
    
    error_log("Consulta ejecutada para usuario: " . $usuario);
    
    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Log para debugging (quitar en producción)
        error_log("Usuario encontrado: " . $row['usuario']);
        error_log("Password hash: " . substr($row['password'], 0, 20) . "...");
        
        // Verificar contraseña
        if (password_verify($password, $row['password'])) {
            // Login exitoso
            error_log("Login exitoso para: " . $usuario);
            
            echo json_encode([
                "success" => true,
                "message" => "Login exitoso",
                "id" => (int)$row['id'],
                "usuario" => $row['usuario'],
                "tipo" => isset($row['tipo']) ? (int)$row['tipo'] : 0,
                "nivel" => isset($row['nivel']) ? (int)$row['nivel'] : 0,
                "estado" => (int)$row['estado'],
                "timestamp" => date('Y-m-d H:i:s')
            ]);
        } else {
            // Contraseña incorrecta
            error_log("Contraseña incorrecta para: " . $usuario);
            
            http_response_code(401);
            echo json_encode([
                "success" => false,
                "message" => "Usuario o contraseña incorrectos"
            ]);
        }
    } else {
        // Usuario no encontrado o inactivo
        error_log("Usuario no encontrado o inactivo: " . $usuario);
        
        http_response_code(401);
        echo json_encode([
            "success" => false,
            "message" => "Usuario no encontrado o cuenta inactiva"
        ]);
    }
    
} catch (Exception $e) {
    // Error en la base de datos
    error_log("Error en login: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error en el servidor",
        "error" => $e->getMessage(),
        "trace" => $e->getTraceAsString()
    ]);
}
?>