<?php
// test.php - Archivo de prueba
header("Content-Type: application/json; charset=UTF-8");
echo json_encode([
    "success" => true,
    "message" => "API funcionando correctamente",
    "timestamp" => date('Y-m-d H:i:s')
]);
?>