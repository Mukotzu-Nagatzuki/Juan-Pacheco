<?php
header("Content-Type: application/json; charset=UTF-8");

// Buscar autoload.php en varias ubicaciones comunes
$paths_to_check = [
    __DIR__ . '/../autoload.php',
    __DIR__ . '/../core/autoload.php',
    __DIR__ . '/../../autoload.php',
    __DIR__ . '/../../../autoload.php',
    '/home/wxwdrnht/seguimiento.mallfers.com/core/autoload.php',
    '/home/wxwdrnht/seguimiento.mallfers.com/autoload.php'
];

$found = [];
foreach ($paths_to_check as $path) {
    $found[$path] = [
        'exists' => file_exists($path) ? 'YES' : 'NO',
        'is_readable' => is_readable($path) ? 'YES' : 'NO'
    ];
}

echo json_encode([
    "success" => true,
    "message" => "Búsqueda de autoload.php",
    "current_dir" => __DIR__,
    "paths_checked" => $found,
    "files_in_core" => is_dir(__DIR__ . '/../core') ? 
        array_values(array_diff(scandir(__DIR__ . '/../core'), ['.', '..'])) : 
        "core directory not found"
]);
?>