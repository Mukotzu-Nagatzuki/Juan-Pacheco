// empresa.js - Gestión de empresas con paginación

document.addEventListener("DOMContentLoaded", function() {
    console.log("=== EMPRESA JS CON PAGINACIÓN CARGADO ===");
    
    const modal = document.getElementById("empresaModal");
    const openBtn = document.getElementById("openCreateModal");
    const closeBtn = document.querySelector(".admin-modal-close");
    const cancelBtn = document.querySelector(".admin-btn-secondary");
    const submitBtn = document.getElementById("submitEmpresaForm");
    const form = document.getElementById("empresaForm");
    const modalTitle = document.getElementById("modalTitle");
    
    // Elementos de ubigeo
    const departamentoSelect = document.getElementById('departamento_id');
    const provinciaSelect = document.getElementById('provincia_id');
    const distritoSelect = document.getElementById('distrito_id');
    
    console.log("Elementos encontrados:", {
        modal: !!modal,
        openBtn: !!openBtn,
        closeBtn: !!closeBtn,
        cancelBtn: !!cancelBtn,
        submitBtn: !!submitBtn,
        form: !!form,
        modalTitle: !!modalTitle,
        departamentoSelect: !!departamentoSelect,
        provinciaSelect: !!provinciaSelect,
        distritoSelect: !!distritoSelect
    });

    // ========== PAGINACIÓN CLIENTE-SIDE ==========
    class PaginationEmpresas {
        constructor() {
            this.currentPage = 1;
            this.itemsPerPage = parseInt(document.getElementById('itemsPerPage')?.value || 10);
            this.filteredItems = [];
            this.allItems = [];
            this.searchTerm = '';
            this.searchCriterio = 'todas';
            this.initPagination();
        }

        initPagination() {
            // Obtener todos los elementos de la tabla (excluyendo la fila de "no hay empresas")
            this.allItems = Array.from(document.querySelectorAll('#empresasTableBody tr.empresa-row'));
            this.filteredItems = [...this.allItems];
            
            // Configurar eventos de paginación
            this.setupPaginationEvents();
            
            // Inicializar con búsqueda si hay término en el input
            const searchInput = document.getElementById('searchEmpresas');
            const searchCriterio = document.getElementById('searchCriterio');
            
            if (searchInput && searchInput.value.trim()) {
                this.searchTerm = searchInput.value.trim().toLowerCase();
                this.searchCriterio = searchCriterio ? searchCriterio.value : 'todas';
                this.filterItems();
            }
            
            // Inicializar paginación
            this.updatePagination();
        }

        setupPaginationEvents() {
            // Eventos de botones de paginación
            document.getElementById('firstPage')?.addEventListener('click', () => this.goToPage(1));
            document.getElementById('prevPage')?.addEventListener('click', () => this.goToPage(this.currentPage - 1));
            document.getElementById('nextPage')?.addEventListener('click', () => this.goToPage(this.currentPage + 1));
            document.getElementById('lastPage')?.addEventListener('click', () => this.goToPage(this.getTotalPages()));
            
            // Evento para cambiar items por página
            const itemsPerPageSelect = document.getElementById('itemsPerPage');
            if (itemsPerPageSelect) {
                itemsPerPageSelect.value = this.itemsPerPage.toString();
                itemsPerPageSelect.addEventListener('change', (e) => {
                    this.itemsPerPage = parseInt(e.target.value);
                    this.currentPage = 1;
                    this.updatePagination();
                });
            }
            
            // Configurar búsqueda en tiempo real
            const searchInput = document.getElementById('searchEmpresas');
            const searchCriterio = document.getElementById('searchCriterio');
            const searchForm = document.getElementById('searchForm');
            
            if (searchInput) {
                let searchTimeout;
                searchInput.addEventListener('input', () => {
                    clearTimeout(searchTimeout);
                    searchTimeout = setTimeout(() => {
                        this.searchTerm = searchInput.value.trim().toLowerCase();
                        this.searchCriterio = searchCriterio ? searchCriterio.value : 'todas';
                        this.filterItems();
                    }, 300);
                });
            }
            
            if (searchCriterio) {
                searchCriterio.addEventListener('change', () => {
                    this.searchCriterio = searchCriterio.value;
                    if (this.searchTerm) {
                        this.filterItems();
                    }
                });
            }
            
            // Prevenir envío del formulario de búsqueda tradicional
            if (searchForm) {
                searchForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.searchTerm = searchInput.value.trim().toLowerCase();
                    this.searchCriterio = searchCriterio ? searchCriterio.value : 'todas';
                    this.filterItems();
                });
            }
        }

        getTotalPages() {
            return Math.ceil(this.filteredItems.length / this.itemsPerPage) || 1;
        }

        goToPage(page) {
            const totalPages = this.getTotalPages();
            
            if (page < 1) page = 1;
            if (page > totalPages) page = totalPages;
            
            this.currentPage = page;
            this.updatePagination();
        }

        filterItems() {
            this.currentPage = 1;
            
            if (!this.searchTerm) {
                this.filteredItems = [...this.allItems];
            } else {
                this.filteredItems = this.allItems.filter(row => {
                    let rowText = '';
                    
                    if (this.searchCriterio === 'todas') {
                        // Buscar en todas las columnas
                        rowText = row.textContent.toLowerCase();
                    } else {
                        // Buscar en columna específica
                        switch(this.searchCriterio) {
                            case 'ruc':
                                rowText = row.querySelector('.empresa-ruc')?.textContent.toLowerCase() || '';
                                break;
                            case 'razon_social':
                                rowText = row.querySelector('.empresa-razon-social')?.textContent.toLowerCase() || '';
                                break;
                            case 'nombre_comercial':
                                rowText = row.querySelector('.empresa-nombre-comercial')?.textContent.toLowerCase() || '';
                                break;
                            case 'sector':
                                rowText = row.querySelector('.empresa-sector')?.textContent.toLowerCase() || '';
                                break;
                            default:
                                rowText = row.textContent.toLowerCase();
                        }
                    }
                    
                    return rowText.includes(this.searchTerm);
                });
            }
            
            this.updatePagination();
            this.highlightSearchResults();
        }

        updatePagination() {
            const totalPages = this.getTotalPages();
            const startIndex = (this.currentPage - 1) * this.itemsPerPage;
            const endIndex = startIndex + this.itemsPerPage;
            
            // Ocultar todas las filas
            this.allItems.forEach(row => row.style.display = 'none');
            
            // Mostrar solo las filas de la página actual
            this.filteredItems.slice(startIndex, endIndex).forEach(row => {
                if (row) row.style.display = '';
            });
            
            // Manejar estado de "no hay empresas"
            this.handleNoResults();
            
            // Actualizar controles de paginación
            this.updatePaginationControls(totalPages);
            this.updatePaginationInfo(totalPages);
            this.updateResultCount();
        }

        updatePaginationControls(totalPages) {
            const pageNumbersContainer = document.getElementById('pageNumbers');
            if (!pageNumbersContainer) return;
            
            pageNumbersContainer.innerHTML = '';
            
            // Mostrar máximo 5 números de página
            let startPage = Math.max(1, this.currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            // Botón para primera página si es necesario
            if (startPage > 1) {
                const firstPageBtn = document.createElement('button');
                firstPageBtn.className = 'admin-page-number';
                firstPageBtn.textContent = '1';
                firstPageBtn.addEventListener('click', () => this.goToPage(1));
                pageNumbersContainer.appendChild(firstPageBtn);
                
                if (startPage > 2) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
            }
            
            // Números de página
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `admin-page-number ${i === this.currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.addEventListener('click', () => this.goToPage(i));
                pageNumbersContainer.appendChild(pageBtn);
            }
            
            // Botón para última página si es necesario
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
                
                const lastPageBtn = document.createElement('button');
                lastPageBtn.className = 'admin-page-number';
                lastPageBtn.textContent = totalPages;
                lastPageBtn.addEventListener('click', () => this.goToPage(totalPages));
                pageNumbersContainer.appendChild(lastPageBtn);
            }
            
            // Actualizar estado de botones
            const firstBtn = document.getElementById('firstPage');
            const prevBtn = document.getElementById('prevPage');
            const nextBtn = document.getElementById('nextPage');
            const lastBtn = document.getElementById('lastPage');
            
            if (firstBtn) firstBtn.disabled = this.currentPage === 1;
            if (prevBtn) prevBtn.disabled = this.currentPage === 1;
            if (nextBtn) nextBtn.disabled = this.currentPage === totalPages || totalPages === 0;
            if (lastBtn) lastBtn.disabled = this.currentPage === totalPages || totalPages === 0;
            
            // Mostrar/ocultar controles de paginación
            const paginationControls = document.getElementById('paginationControls');
            if (paginationControls) {
                paginationControls.style.display = this.filteredItems.length > 0 ? '' : 'none';
            }
        }

        updatePaginationInfo(totalPages) {
            const currentPageSpan = document.getElementById('currentPage');
            const totalPagesSpan = document.getElementById('totalPages');
            
            if (currentPageSpan) currentPageSpan.textContent = this.currentPage;
            if (totalPagesSpan) totalPagesSpan.textContent = totalPages;
        }

        updateResultCount() {
            const resultCount = document.getElementById('resultCount');
            if (!resultCount) return;
            
            const totalItems = this.filteredItems.length;
            const startIndex = (this.currentPage - 1) * this.itemsPerPage + 1;
            const endIndex = Math.min(startIndex + this.itemsPerPage - 1, totalItems);
            
            if (totalItems === 0) {
                if (this.searchTerm) {
                    resultCount.textContent = `No se encontraron resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = 'No hay empresas registradas';
                }
            } else if (totalItems <= this.itemsPerPage) {
                if (this.searchTerm) {
                    resultCount.textContent = `Mostrando ${totalItems} resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = `Mostrando ${totalItems} empresas`;
                }
            } else {
                if (this.searchTerm) {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} empresas`;
                }
            }
        }

        handleNoResults() {
            const noResultsRow = document.getElementById('noResultsRow');
            const noResultsSearch = document.getElementById('noResultsSearch');
            const tableBody = document.getElementById('empresasTableBody');
            
            // Ocultar la fila de "no hay empresas" original
            if (noResultsRow) {
                noResultsRow.style.display = 'none';
            }
            
            if (this.filteredItems.length === 0) {
                // Mostrar mensaje de no resultados
                if (noResultsSearch) {
                    noResultsSearch.style.display = 'block';
                }
                if (tableBody) {
                    tableBody.style.display = 'none';
                }
            } else {
                // Ocultar mensaje de no resultados
                if (noResultsSearch) {
                    noResultsSearch.style.display = 'none';
                }
                if (tableBody) {
                    tableBody.style.display = '';
                }
            }
        }

        highlightSearchResults() {
            if (!this.searchTerm) {
                // Remover resaltado si no hay búsqueda
                const cells = document.querySelectorAll('.empresa-row td');
                cells.forEach(cell => {
                    if (cell.hasAttribute('data-original-text')) {
                        cell.innerHTML = cell.getAttribute('data-original-text');
                    }
                });
                return;
            }
            
            // Resaltar términos de búsqueda
            this.filteredItems.forEach(row => {
                const cells = row.querySelectorAll('td');
                cells.forEach(cell => {
                    // Guardar el texto original si no está guardado
                    if (!cell.hasAttribute('data-original-text')) {
                        cell.setAttribute('data-original-text', cell.innerHTML);
                    }
                    
                    const originalHTML = cell.getAttribute('data-original-text');
                    const textContent = cell.textContent || '';
                    
                    // Resaltar solo si hay coincidencia en esta celda específica
                    if (textContent.toLowerCase().includes(this.searchTerm)) {
                        const highlightedText = textContent.replace(
                            new RegExp(this.searchTerm, 'gi'),
                            match => `<span class="highlight">${match}</span>`
                        );
                        cell.innerHTML = highlightedText;
                    } else {
                        cell.innerHTML = originalHTML;
                    }
                });
            });
        }

        refresh() {
            this.allItems = Array.from(document.querySelectorAll('#empresasTableBody tr.empresa-row'));
            this.filterItems();
        }
    }

    // Instanciar paginación
    let pagination = null;

    // ========== FUNCIONALIDAD DEL MODAL ==========

    // Función para mostrar modal
    function showModal() {
        if (modal) {
            modal.style.display = "flex";
            document.body.style.overflow = "hidden";
            modal.offsetHeight;
            modal.classList.add("active");
            console.log("Modal mostrado");
        }
    }

    // Función para ocultar modal
    function hideModal() {
        if (modal) {
            modal.classList.remove("active");
            setTimeout(() => {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
                console.log("Modal ocultado");
            }, 300);
        }
    }

    // Función para resetear el formulario
    function resetForm() {
        if (form) {
            form.reset();
            const idEmpresa = document.getElementById('id_empresa');
            const actionsInput = document.querySelector('input[name="actions"]');
            
            if (idEmpresa) idEmpresa.value = "";
            if (actionsInput) actionsInput.value = "1";
        }
        
        if (modalTitle) {
            modalTitle.textContent = "Registrar Nueva Empresa";
        }
        
        // Resetear selects de ubigeo
        if (departamentoSelect) {
            departamentoSelect.value = "";
            provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
            provinciaSelect.disabled = true;
            distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
            distritoSelect.disabled = true;
        }
        
        // Limpiar estilos de validación
        if (form) {
            form.querySelectorAll('input, select').forEach(field => {
                field.style.borderColor = '';
            });
        }
    }

    // Abrir modal para crear
    if (openBtn) {
        openBtn.addEventListener("click", function(e) {
            e.preventDefault();
            console.log("Botón abrir modal clickeado");
            resetForm();
            showModal();
            
            // Inicializar ubigeo después de mostrar el modal
            setTimeout(() => {
                inicializarUbigeo();
            }, 100);
        });
    }

    // Cerrar modal
    function closeModal() {
        console.log("Cerrando modal");
        hideModal();
    }

    // Asignar eventos de cierre
    if (closeBtn) {
        closeBtn.addEventListener("click", function(e) {
            e.preventDefault();
            closeModal();
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener("click", function(e) {
            e.preventDefault();
            closeModal();
        });
    }

    // Cerrar modal con tecla Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal && modal.style.display === 'flex') {
            closeModal();
        }
    });

    // Función para cerrar cualquier modal
    function closeAnyModal(modal) {
        if (modal) {
            modal.classList.remove("active");
            setTimeout(() => {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
            }, 300);
        }
    }

    // ========== MANEJO DE BOTONES EDITAR ==========
    
    document.addEventListener('click', function(e) {
        const editBtn = e.target.closest('.edit-empresa-btn');
        if (editBtn) {
            e.preventDefault();
            console.log("Botón editar empresa clickeado", editBtn);
            
            // Cargar datos en el formulario
            const idEmpresa = document.getElementById('id_empresa');
            const rucInput = form.querySelector('input[name="ruc"]');
            const razonSocialInput = form.querySelector('input[name="razon_social"]');
            const nombreComercialInput = form.querySelector('input[name="nombre_comercial"]');
            const sectorSelect = form.querySelector('select[name="sector"]');
            const emailInput = form.querySelector('input[name="email"]');
            const telefonoInput = form.querySelector('input[name="telefono"]');
            const direccionFiscalInput = form.querySelector('textarea[name="direccion_fiscal"]');
            const estadoSelect = form.querySelector('select[name="estado"]');
            const condicionSunatSelect = form.querySelector('select[name="condicion_sunat"]');
            const validadoSelect = form.querySelector('select[name="validado"]');
            const registroManualSelect = form.querySelector('select[name="registro_manual"]');
            const ubigeoInput = form.querySelector('input[name="ubigeo"]');
            const actionsInput = form.querySelector('input[name="actions"]');
            
            // Asignar valores
            if (idEmpresa) idEmpresa.value = editBtn.getAttribute('data-empresa-id') || '';
            if (rucInput) rucInput.value = editBtn.getAttribute('data-ruc') || '';
            if (razonSocialInput) razonSocialInput.value = editBtn.getAttribute('data-razon-social') || '';
            if (nombreComercialInput) nombreComercialInput.value = editBtn.getAttribute('data-nombre-comercial') || '';
            if (sectorSelect) sectorSelect.value = editBtn.getAttribute('data-sector') || '';
            if (emailInput) emailInput.value = editBtn.getAttribute('data-email') || '';
            if (telefonoInput) telefonoInput.value = editBtn.getAttribute('data-telefono') || '';
            if (direccionFiscalInput) direccionFiscalInput.value = editBtn.getAttribute('data-direccion-fiscal') || '';
            if (estadoSelect) estadoSelect.value = editBtn.getAttribute('data-estado') || '';
            if (condicionSunatSelect) condicionSunatSelect.value = editBtn.getAttribute('data-condicion-sunat') || '';
            if (validadoSelect) validadoSelect.value = editBtn.getAttribute('data-validado') || '0';
            if (registroManualSelect) registroManualSelect.value = editBtn.getAttribute('data-registro-manual') || '0';
            if (ubigeoInput) ubigeoInput.value = editBtn.getAttribute('data-ubigeo') || '';
            
            if (modalTitle) {
                modalTitle.textContent = "Editar Empresa";
            }
            
            if (actionsInput) {
                actionsInput.value = "2";
            }
            
            // Cargar ubigeo si existe
            const departamentoNombre = editBtn.getAttribute('data-departamento');
            const provinciaNombre = editBtn.getAttribute('data-provincia');
            const distritoNombre = editBtn.getAttribute('data-distrito');
            
            if (departamentoNombre && provinciaNombre && distritoNombre) {
                cargarUbigeoExistente(departamentoNombre, provinciaNombre, distritoNombre);
            } else {
                // Resetear selects de ubigeo
                if (departamentoSelect) {
                    departamentoSelect.value = '';
                    provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
                    provinciaSelect.disabled = true;
                    distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                    distritoSelect.disabled = true;
                }
            }
            
            showModal();
            
            // Inicializar ubigeo después de mostrar el modal
            setTimeout(() => {
                inicializarUbigeo();
            }, 100);
        }
    });

    // ========== FUNCIONALIDAD DE UBIGEO ==========

    let ubigeoInicializado = false;

    function inicializarUbigeo() {
        if (ubigeoInicializado) return;
        
        console.log("Inicializando ubigeo empresas...");
        
        if (departamentoSelect) {
            departamentoSelect.onchange = null;
            
            departamentoSelect.addEventListener('change', function() {
                const departamentoId = this.value;
                console.log("Departamento seleccionado:", departamentoId);
                
                // Actualizar nombre del departamento en hidden field
                const departamentoNombreInput = document.getElementById('departamento_nombre');
                if (departamentoNombreInput) {
                    const selectedOption = this.options[this.selectedIndex];
                    departamentoNombreInput.value = selectedOption.text;
                }
                
                // Limpiar y deshabilitar provincias y distritos
                if (provinciaSelect) {
                    provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
                    provinciaSelect.disabled = true;
                }
                if (distritoSelect) {
                    distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                    distritoSelect.disabled = true;
                }
                
                if (departamentoId) {
                    cargarProvincias(departamentoId);
                }
            });
        }

        if (provinciaSelect) {
            provinciaSelect.onchange = null;
            
            provinciaSelect.addEventListener('change', function() {
                const provinciaId = this.value;
                console.log("Provincia seleccionada:", provinciaId);
                
                // Actualizar nombre de la provincia en hidden field
                const provinciaNombreInput = document.getElementById('provincia_nombre');
                if (provinciaNombreInput) {
                    const selectedOption = this.options[this.selectedIndex];
                    provinciaNombreInput.value = selectedOption.text;
                }
                
                // Limpiar y deshabilitar distritos
                if (distritoSelect) {
                    distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                    distritoSelect.disabled = true;
                }
                
                if (provinciaId) {
                    cargarDistritos(provinciaId);
                }
            });
        }

        if (distritoSelect) {
            distritoSelect.onchange = null;
            
            distritoSelect.addEventListener('change', function() {
                const distritoId = this.value;
                console.log("Distrito seleccionado:", distritoId);
                
                // Actualizar nombre del distrito en hidden field
                const distritoNombreInput = document.getElementById('distrito_nombre');
                const ubigeoCodeInput = document.getElementById('ubigeo_code');
                if (distritoNombreInput) {
                    const selectedOption = this.options[this.selectedIndex];
                    distritoNombreInput.value = selectedOption.text;
                }
                if (ubigeoCodeInput && distritoId) {
                    ubigeoCodeInput.value = distritoId;
                }
            });
        }
        
        ubigeoInicializado = true;
    }

    function cargarProvincias(departamentoId) {
        return new Promise((resolve, reject) => {
            if (!provinciaSelect) {
                reject('provinciaSelect no encontrado');
                return;
            }
            
            provinciaSelect.disabled = true;
            provinciaSelect.innerHTML = '<option value="">Cargando provincias...</option>';
            
            fetch(`index.php?action=empresas&get_provincias=1&departamento_id=${departamentoId}`)
                .then(response => {
                    if (!response.ok) throw new Error('Error en la respuesta');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        provinciaSelect.innerHTML = data.html;
                        provinciaSelect.disabled = false;
                        provinciaSelect.style.borderColor = '';
                        resolve(data);
                    } else {
                        provinciaSelect.innerHTML = '<option value="">Error al cargar provincias</option>';
                        reject(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    provinciaSelect.innerHTML = '<option value="">Error al cargar provincias</option>';
                    reject(error);
                });
        });
    }

    function cargarDistritos(provinciaId) {
        return new Promise((resolve, reject) => {
            if (!distritoSelect) {
                reject('distritoSelect no encontrado');
                return;
            }
            
            distritoSelect.disabled = true;
            distritoSelect.innerHTML = '<option value="">Cargando distritos...</option>';
            
            fetch(`index.php?action=empresas&get_distritos=1&provincia_id=${provinciaId}`)
                .then(response => {
                    if (!response.ok) throw new Error('Error en la respuesta');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        distritoSelect.innerHTML = data.html;
                        distritoSelect.disabled = false;
                        distritoSelect.style.borderColor = '';
                        resolve(data);
                    } else {
                        distritoSelect.innerHTML = '<option value="">Error al cargar distritos</option>';
                        reject(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    distritoSelect.innerHTML = '<option value="">Error al cargar distritos</option>';
                    reject(error);
                });
        });
    }

    function cargarUbigeoExistente(departamentoNombre, provinciaNombre, distritoNombre) {
        if (!departamentoSelect || !provinciaSelect || !distritoSelect) return;
        
        console.log("Cargando ubigeo existente:", {departamentoNombre, provinciaNombre, distritoNombre});
        
        // Resetear primero
        provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
        provinciaSelect.disabled = true;
        distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
        distritoSelect.disabled = true;
        
        // Buscar departamento por nombre
        let departamentoEncontrado = false;
        for (let i = 0; i < departamentoSelect.options.length; i++) {
            if (departamentoSelect.options[i].text === departamentoNombre) {
                departamentoSelect.value = departamentoSelect.options[i].value;
                departamentoEncontrado = true;
                console.log("Departamento encontrado:", departamentoSelect.value);
                break;
            }
        }
        
        if (!departamentoEncontrado) {
            console.warn("Departamento no encontrado:", departamentoNombre);
            return;
        }
        
        // Cargar provincias del departamento seleccionado
        cargarProvincias(departamentoSelect.value).then(() => {
            // Buscar provincia por nombre después de cargar
            setTimeout(() => {
                let provinciaEncontrada = false;
                for (let i = 0; i < provinciaSelect.options.length; i++) {
                    if (provinciaSelect.options[i].text === provinciaNombre) {
                        provinciaSelect.value = provinciaSelect.options[i].value;
                        provinciaEncontrada = true;
                        console.log("Provincia encontrada:", provinciaSelect.value);
                        
                        // Actualizar campo hidden de provincia
                        const provinciaNombreInput = document.getElementById('provincia_nombre');
                        if (provinciaNombreInput) {
                            provinciaNombreInput.value = provinciaNombre;
                        }
                        break;
                    }
                }
                
                if (!provinciaEncontrada) {
                    console.warn("Provincia no encontrada:", provinciaNombre);
                    return;
                }
                
                // Cargar distritos de la provincia seleccionada
                cargarDistritos(provinciaSelect.value).then(() => {
                    // Buscar distrito por nombre después de cargar
                    setTimeout(() => {
                        let distritoEncontrado = false;
                        for (let i = 0; i < distritoSelect.options.length; i++) {
                            if (distritoSelect.options[i].text === distritoNombre) {
                                distritoSelect.value = distritoSelect.options[i].value;
                                distritoEncontrado = true;
                                console.log("Distrito encontrado:", distritoSelect.value);
                                
                                // Actualizar campos hidden
                                const distritoNombreInput = document.getElementById('distrito_nombre');
                                const ubigeoCodeInput = document.getElementById('ubigeo_code');
                                if (distritoNombreInput) {
                                    distritoNombreInput.value = distritoNombre;
                                }
                                if (ubigeoCodeInput) {
                                    ubigeoCodeInput.value = distritoSelect.value;
                                }
                                break;
                            }
                        }
                        
                        if (!distritoEncontrado) {
                            console.warn("Distrito no encontrado:", distritoNombre);
                        }
                    }, 300);
                });
            }, 300);
        });
    }

    // ========== ENVIAR FORMULARIO ==========

    if (submitBtn && form) {
        submitBtn.addEventListener("click", function(e) {
            e.preventDefault();
            
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            let firstInvalidField = null;

            // Resetear bordes
            form.querySelectorAll('input, select, textarea').forEach(function(field) {
                field.style.borderColor = '';
            });

            // Validar campos requeridos
            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'red';
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                }
            });

            // Validar RUC (11 dígitos)
            const ruc = form.querySelector('input[name="ruc"]');
            if (ruc && !/^\d{11}$/.test(ruc.value)) {
                isValid = false;
                ruc.style.borderColor = 'red';
                if (!firstInvalidField) firstInvalidField = ruc;
            }

            if (!isValid) {
                alert('⚠️ Por favor, complete todos los campos obligatorios correctamente.');
                if (firstInvalidField) {
                    firstInvalidField.focus();
                }
                return;
            }

            // Mostrar confirmación
            const isEdit = form.querySelector('input[name="actions"]').value === "2";
            const actionText = isEdit ? "editar" : "registrar";
            
            if (confirm(`¿Está seguro de ${actionText} esta empresa?`)) {
                console.log("Enviando formulario de empresa...");
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="bx bx-loader bx-spin"></i> Procesando...';
                
                // Actualizar los campos hidden con los nombres antes de enviar
                const departamentoNombre = document.getElementById('departamento_nombre');
                const provinciaNombre = document.getElementById('provincia_nombre');
                const distritoNombre = document.getElementById('distrito_nombre');
                
                if (departamentoNombre && departamentoSelect) {
                    const selectedOption = departamentoSelect.options[departamentoSelect.selectedIndex];
                    departamentoNombre.value = selectedOption.text;
                }
                
                setTimeout(() => {
                    form.submit();
                }, 500);
            }
        });
    }

    // ========== INICIALIZACIÓN ==========

    function inicializarTodo() {
        // Inicializar paginación
        if (typeof PaginationEmpresas === 'function') {
            pagination = new PaginationEmpresas();
        }
        
        // Inicializar ubigeo si el modal está abierto
        if (modal && modal.style.display === 'flex') {
            inicializarUbigeo();
        }
        
        // Observar cambios en la tabla (para cuando se agreguen/eliminen elementos)
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && pagination) {
                    setTimeout(() => {
                        pagination.refresh();
                    }, 200);
                }
            });
        });
        
        // Observar cambios en el tbody de la tabla
        const tableBody = document.getElementById('empresasTableBody');
        if (tableBody) {
            observer.observe(tableBody, { childList: true, subtree: true });
        }
    }

    // Esperar un poco para asegurar que todo esté cargado
    setTimeout(inicializarTodo, 100);

    // Agregar estilos CSS si no existen
    if (!document.querySelector('#empresa-modal-styles')) {
        const style = document.createElement('style');
        style.id = 'empresa-modal-styles';
        style.textContent = `
            .admin-modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 9999;
                opacity: 0;
                transition: opacity 0.3s ease;
                align-items: center;
                justify-content: center;
            }
            .admin-modal.active {
                opacity: 1;
            }
            .admin-modal-dialog {
                background: white;
                border-radius: 8px;
                margin: auto;
                max-width: 800px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
                transform: translateY(-50px);
                transition: transform 0.3s ease;
            }
            .admin-modal.active .admin-modal-dialog {
                transform: translateY(0);
            }
            .edit-empresa-btn, .delete-empresa-btn {
                cursor: pointer;
                transition: all 0.2s ease;
            }
            .edit-empresa-btn:hover, .delete-empresa-btn:hover {
                transform: scale(1.05);
            }
            .admin-btn-primary:disabled {
                background-color: #6c757d;
                cursor: not-allowed;
                opacity: 0.6;
            }
            .highlight {
                background-color: #fff3cd !important;
                font-weight: bold;
                padding: 2px 4px;
                border-radius: 3px;
            }
            .admin-pagination-btn:disabled {
                opacity: 0.5;
                cursor: not-allowed;
            }
            .admin-page-number.active {
                background-color: #0A2647 !important;
                color: white !important;
                border-color: #0A2647 !important;
            }
            .admin-page-number.dots {
                background: transparent !important;
                border: none !important;
                cursor: default !important;
            }
        `;
        document.head.appendChild(style);
    }

    console.log("=== EMPRESA JS CON PAGINACIÓN INICIALIZADO CORRECTAMENTE ===");
});