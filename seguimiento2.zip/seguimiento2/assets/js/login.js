document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password'); // Corregido: de 'contrasena' a 'password'
    const errorMessage = document.getElementById('error-message');

    // Función para auto-ocultar mensajes de error después de 3 segundos
    function setupAutoHideError() {
        if (errorMessage && errorMessage.getAttribute('data-auto-hide') === 'true') {
            setTimeout(() => {
                errorMessage.style.opacity = '0';
                errorMessage.style.transition = 'opacity 0.5s ease';
                
                // Remover completamente después de la animación
                setTimeout(() => {
                    if (errorMessage.parentElement) {
                        errorMessage.remove();
                    }
                }, 500);
            }, 3000); // 3 segundos
        }
    }

    // Configurar auto-ocultar para mensajes de error
    setupAutoHideError();

    // Función para mostrar/ocultar contraseña
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('bx-hide');
            this.classList.toggle('bx-show');
        });
        
        // Mostrar icono cuando hay contenido
        passwordInput.addEventListener('input', function() {
            if (this.value.length > 0) {
                togglePassword.style.display = 'block';
            } else {
                togglePassword.style.display = 'none';
            }
        });

        // Ocultar icono inicialmente si no hay contenido
        if (passwordInput.value.length === 0) {
            togglePassword.style.display = 'none';
        }
    }

    // Validación de campos en tiempo real
    const inputs = loginForm.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            clearFieldError(this);
            // Ocultar mensaje de error global al empezar a escribir
            if (errorMessage && !errorMessage.getAttribute('data-auto-hide')) {
                errorMessage.style.display = 'none';
            }
        });
    });

    // Validación del formulario
    loginForm.addEventListener('submit', function(e) {
        let isValid = true;
        inputs.forEach(input => {
            if (!validateField(input)) {
                isValid = false;
            }
        });

        if (!isValid) {
            e.preventDefault();
            showError('Por favor, complete todos los campos correctamente.');
        }
    });

    // Funciones de validación
    function validateField(field) {
        const errorElement = field.parentElement.nextElementSibling;
        
        if (field.value.trim() === '') {
            showFieldError(field, 'Este campo es obligatorio');
            return false;
        }
        
        clearFieldError(field);
        return true;
    }

    function showFieldError(field, message) {
        const errorElement = field.parentElement.nextElementSibling;
        field.style.borderColor = '#dc2626';
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
    }

    function clearFieldError(field) {
        const errorElement = field.parentElement.nextElementSibling;
        field.style.borderColor = '';
        if (errorElement) {
            errorElement.style.display = 'none';
        }
    }

    function showError(message) {
        if (errorMessage) {
            errorMessage.innerHTML = `<i class='bx bx-error-circle'></i><span>${message}</span>`;
            errorMessage.style.display = 'flex';
            errorMessage.removeAttribute('data-auto-hide'); // Remover auto-hide para errores de validación en tiempo real
            
            // Ocultar después de 3 segundos también para errores de validación
            setTimeout(() => {
                errorMessage.style.opacity = '0';
                errorMessage.style.transition = 'opacity 0.5s ease';
                
                setTimeout(() => {
                    if (errorMessage.parentElement) {
                        errorMessage.style.display = 'none';
                        errorMessage.style.opacity = '1'; // Reset para futuros usos
                    }
                }, 500);
            }, 3000);
        }
    }
});