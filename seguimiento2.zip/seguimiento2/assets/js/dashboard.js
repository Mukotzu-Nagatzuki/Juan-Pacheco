// dashboard.js - Versión corregida
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

function initializeDashboard() {
    const sidebar = document.querySelector(".sidebar");
    const menuLinks = document.querySelectorAll(".menu-link");
    const logoutBtn = document.querySelector(".logout-btn");
    const mainContent = document.querySelector('.main-content');
    const headerToggle = document.querySelector('.header-toggle');

    // Crear tooltip global
    const tooltip = document.createElement('div');
    tooltip.className = 'custom-tooltip';
    document.body.appendChild(tooltip);

    // Toggle sidebar desde el header
    if (headerToggle && sidebar) {
        headerToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            updateMainContentMargin();
            // Ocultar tooltip al colapsar/expandir
            hideTooltip();
        });
    }

    // Función para actualizar el margen del contenido principal
    function updateMainContentMargin() {
        if (mainContent) {
            if (sidebar.classList.contains('collapsed')) {
                mainContent.style.marginLeft = '90px';
            } else {
                mainContent.style.marginLeft = '270px';
            }
        }
    }

    // Expand sidebar by default on large screens
    if (window.innerWidth > 768) {
        sidebar.classList.remove("collapsed");
    }
    updateMainContentMargin(); // Asegurar que el margen sea correcto al cargar

    // Funcionalidad de tooltips
    menuLinks.forEach(link => {
        link.addEventListener('mouseenter', function(e) {
            if (!sidebar.classList.contains('collapsed')) return;
            
            const tooltipText = this.getAttribute('data-tooltip');
            if (!tooltipText) return;
            
            showTooltip(this, tooltipText);
        });
        
        link.addEventListener('mouseleave', function() {
            hideTooltip();
        });
        
        link.addEventListener('click', function() {
            hideTooltip();
        });
    });

    // Función para mostrar tooltip
    function showTooltip(element, text) {
        const rect = element.getBoundingClientRect();
        
        tooltip.textContent = text;
        tooltip.style.left = (rect.right + 10) + 'px';
        tooltip.style.top = (rect.top + (rect.height / 2)) + 'px';
        tooltip.style.transform = 'translateY(-50%)';
        
        // Verificar si el tooltip se sale de la pantalla
        const tooltipRect = tooltip.getBoundingClientRect();
        if (tooltipRect.right > window.innerWidth - 10) {
            tooltip.style.left = (rect.left - tooltipRect.width - 10) + 'px';
            tooltip.style.transform = 'translateY(-50%)';
        }
        
        tooltip.classList.add('show');
    }

    // Función para ocultar tooltip
    function hideTooltip() {
        tooltip.classList.remove('show');
    }

    // Ocultar tooltip al hacer scroll o redimensionar
    window.addEventListener('scroll', hideTooltip);
    window.addEventListener('resize', hideTooltip);

    // Cerrar tooltip al hacer click fuera
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.menu-link') && !e.target.closest('.custom-tooltip')) {
            hideTooltip();
        }
    });

    // Re-inicializar después de cargar contenido dinámico
    window.reinitializeDashboard = initializeDashboard;
}

// También inicializar cuando la página esté completamente cargada
window.addEventListener('load', initializeDashboard);