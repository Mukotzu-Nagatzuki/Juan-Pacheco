const shareBtn = document.getElementById('btnCompartir');

shareBtn.addEventListener('click', function(event) {
    event.preventDefault();

    // URL fija del archivo independiente de acceso directo
    const url = "https://seguimiento.mallfers.com/encuesta.php"; 

    // Texto que se compartirá
    const mensaje = `¡Hola! 📊 Te invito a completar esta encuesta de situación laboral. Es rápida y anónima.\n\n🔗 ${url}\n\n¡Tu participación es muy importante! 🙏`;

    // Detectar si es dispositivo móvil
    const isMobile = /android|iphone|ipad|mobile/i.test(navigator.userAgent);

    if (isMobile) {
        // Para móviles: intentar WhatsApp primero
        const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(mensaje)}`;
        window.open(whatsappUrl, '_blank');
    } else {
        // Para escritorio: ofrecer opción de copiar al portapapeles
        navigator.clipboard.writeText(mensaje)
            .then(() => {
                alert('✅ Enlace copiado al portapapeles. Ahora puedes compartirlo por WhatsApp, correo o cualquier otra aplicación.');
            })
            .catch(err => {
                // Fallback: abrir cliente de correo
                window.location.href = `mailto:?subject=Encuesta de Situación Laboral&body=${encodeURIComponent(mensaje)}`;
            });
    }
});

// ========== CÓDIGO DE VALIDACIONES ==========

// Objeto para almacenar datos temporalmente
let encuestaData = JSON.parse(localStorage.getItem('encuestaData')) || {};
let submitted = false; // Controlar si se hizo clic en enviar

// Función para guardar datos en localStorage
function saveField(field, value) {
    encuestaData[field] = value;
    localStorage.setItem('encuestaData', JSON.stringify(encuestaData));
    showSavedBadge(field + '_status');
}

// Función para mostrar indicador de guardado
function showSavedBadge(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<span class="badge bg-success">✓ Guardado</span>';
        setTimeout(() => {
            element.innerHTML = '';
        }, 2000);
    }
}

// Función para validar y mostrar estado del campo
function validateField(field, value, showVisual = false) {
    const messageElement = document.getElementById(field + '_message');
    const statusElement = document.getElementById(field + '_status');
    const inputElement = document.getElementById(field);
    
    const validationResult = validations[field] ? validations[field](value) : '';
    
    // Limpiar clases anteriores
    if (inputElement) {
        inputElement.classList.remove('is-valid', 'is-invalid');
    }
    
    if (!validationResult) {
        // Campo válido
        if (messageElement) messageElement.innerHTML = '';
        if (statusElement) statusElement.innerHTML = '';
        
        // Solo mostrar verde si se ha hecho submit o showVisual es true
        if ((submitted || showVisual) && inputElement && value) {
            inputElement.classList.add('is-valid');
            if (statusElement) statusElement.innerHTML = '✅';
        }
        return true;
    } else {
        // Campo inválido - solo mostrar rojo si se ha hecho submit
        if (messageElement) {
            if (submitted || showVisual) {
                messageElement.innerHTML = validationResult;
            } else {
                messageElement.innerHTML = '';
            }
        }
        
        if (statusElement) {
            if (submitted || showVisual) {
                statusElement.innerHTML = '❌';
            } else {
                statusElement.innerHTML = '';
            }
        }
        
        if (inputElement && (submitted || showVisual)) {
            inputElement.classList.add('is-invalid');
        }
        return false;
    }
}

// Validaciones específicas para cada campo
const validations = {
    dni_est: (value) => {
        if (!value) return '❌ El DNI es requerido';
        if (value.length !== 8) return '❌ El DNI debe tener exactamente 8 dígitos';
        if (!/^\d+$/.test(value)) return '❌ El DNI debe contener solo números';
        return '';
    },
    ruc_empresa: (value) => {
        if (!value) return '❌ El RUC es requerido';
        if (value.length !== 11) return '❌ El RUC debe tener exactamente 11 dígitos';
        if (!/^\d+$/.test(value)) return '❌ El RUC debe contener solo números';
        return '';
    },
    trabaja: (value) => {
        if (!value) return '❌ Este campo es requerido';
        return '';
    },
    labora_programa_estudios: (value) => {
        if (!value) return '❌ Este campo es requerido';
        return '';
    },
    cargo_actual: (value) => {
        if (!value) return '❌ El cargo actual es requerido';
        if (value.length < 2) return '❌ El cargo debe tener al menos 2 caracteres';
        if (value.length > 100) return '❌ El cargo no puede tener más de 100 caracteres';
        if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s\-\.,0-9]+$/.test(value)) return '❌ Solo se permiten letras, números y espacios';
        return '';
    },
    condicion_laboral: (value) => {
        if (!value) return '❌ Este campo es requerido';
        return '';
    },
    ingreso_bruto_mensual: (value) => {
        if (!value) return '❌ El ingreso bruto mensual es requerido';
        if (parseFloat(value) <= 0) return '❌ El ingreso debe ser mayor a 0';
        if (parseFloat(value) > 999999.99) return '❌ El ingreso no puede ser mayor a 999,999.99';
        return '';
    },
    satisfaccion_trabajo: (value) => {
        if (!value) return '❌ Este campo es requerido';
        return '';
    },
    fecha_inicio: (value) => {
        if (!value) return '❌ La fecha de inicio es requerida';
        const selectedDate = new Date(value);
        const today = new Date();
        today.setHours(23, 59, 59, 999);
        if (selectedDate > today) return '❌ La fecha no puede ser futura';
        
        const minDate = new Date();
        minDate.setFullYear(today.getFullYear() - 50);
        if (selectedDate < minDate) return '❌ La fecha no puede ser menor a 50 años atrás';
        return '';
    }
};

// Función para aplicar validación silenciosa (sin colores)
function applySilentValidation(fieldId) {
    const element = document.getElementById(fieldId);
    if (element) {
        // Validar silenciosamente mientras se escribe (sin mostrar colores)
        element.addEventListener('input', function() {
            validateField(fieldId, this.value, false); // false = no mostrar colores
            saveField(fieldId, this.value);
        });
        
        // Validar silenciosamente al cambiar (para selects)
        element.addEventListener('change', function() {
            validateField(fieldId, this.value, false); // false = no mostrar colores
            saveField(fieldId, this.value);
        });
    }
}

// Cargar datos guardados al iniciar la página
function loadSavedData() {
    if (Object.keys(encuestaData).length > 0) {
        for (const [field, value] of Object.entries(encuestaData)) {
            const element = document.getElementById(field);
            if (element) {
                element.value = value;
                // Validar el campo cargado silenciosamente
                validateField(field, value, false);
            }
        }
    }
}

// Limpiar localStorage
function clearLocalStorage() {
    localStorage.removeItem('encuestaData');
    encuestaData = {};
    document.getElementById('encuestaForm').reset();
    submitted = false;
    
    // Limpiar mensajes de estado y clases
    const statusElements = document.querySelectorAll('[id$="_status"], [id$="_message"]');
    statusElements.forEach(element => {
        element.innerHTML = '';
    });
    
    const inputElements = document.querySelectorAll('.form-control');
    inputElements.forEach(element => {
        element.classList.remove('is-valid', 'is-invalid');
    });
    
    alert('Datos temporales eliminados');
}

// Validar todos los campos con colores (para el submit)
function validateAllFieldsWithColors() {
    let allValid = true;
    for (const field in validations) {
        const element = document.getElementById(field);
        if (element) {
            if (!validateField(field, element.value, true)) { // true = mostrar colores
                allValid = false;
            }
        }
    }
    return allValid;
}

// Inicializar todas las validaciones silenciosas
function initializeSilentValidations() {
    // Aplicar validación silenciosa a todos los campos
    for (const field in validations) {
        applySilentValidation(field);
    }
    
    // Validaciones especiales para campos numéricos
    document.getElementById('dni_est').addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length > 8) {
            this.value = this.value.slice(0, 8);
        }
    });

    document.getElementById('ruc_empresa').addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length > 11) {
            this.value = this.value.slice(0, 11);
        }
    });
}

// Event listeners para cada campo
document.addEventListener('DOMContentLoaded', function() {
    loadSavedData();
    initializeSilentValidations();

    // Validación antes de enviar el formulario
    document.getElementById('encuestaForm').addEventListener('submit', function(e) {
        submitted = true; // Marcar que se hizo clic en enviar
        
        if (!validateAllFieldsWithColors()) {
            e.preventDefault();
            alert('❌ Por favor, complete todos los campos correctamente antes de enviar.');
            // Hacer scroll al primer campo con error
            const firstError = document.querySelector('.is-invalid');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstError.focus();
            }
        }
    });

    // Botón copiar enlace (funcionalidad existente)
    const copyBtn = document.getElementById('btnCopiarEnlace');
    copyBtn.addEventListener('click', function(event) {
        const urlEncuesta = `https://seguimiento.mallfers.com/encuesta.php`;
        navigator.clipboard.writeText(urlEncuesta)
            .then(() => {
                alert("🔗 Enlace copiado. Ahora puedes compartirlo libremente 💌");
            })
            .catch(err => {
                console.error("Error al copiar el enlace: ", err);
                alert("⚠ Error copiando el enlace. Hazlo manual si es urgente.");
            });
    });
});