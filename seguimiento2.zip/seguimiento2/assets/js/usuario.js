document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("userModal");
    const openBtn = document.getElementById("openCreateModal");
    const closeBtn = document.getElementById("closeModal");
    const cancelBtn = document.getElementById("cancelModal");
    const saveBtn = document.getElementById("saveUserBtn");
    const togglePass = document.getElementById("togglePassword");
    const toggleConfirm = document.getElementById("toggleConfirmPassword");

    // 🟢 Abrir modal
    openBtn.addEventListener("click", () => {
        modal.classList.add("show");
        document.body.style.overflow = "hidden";
    });

    // 🔴 Cerrar modal
    const closeModal = () => {
        modal.classList.remove("show");
        document.body.style.overflow = "auto";
        document.getElementById("userForm").reset();
    };

    closeBtn.addEventListener("click", closeModal);
    cancelBtn.addEventListener("click", closeModal);

    // 👁️ Mostrar / ocultar contraseñas
    const toggleVisibility = (inputId, icon) => {
        const input = document.getElementById(inputId);
        if (input.type === "password") {
            input.type = "text";
            icon.innerHTML = "<i class='bx bx-show'></i>";
        } else {
            input.type = "password";
            icon.innerHTML = "<i class='bx bx-hide'></i>";
        }
    };

    togglePass.addEventListener("click", () => toggleVisibility("modalPassword", togglePass));
    toggleConfirm.addEventListener("click", () => toggleVisibility("modalConfirmPassword", toggleConfirm));

    // 💾 Guardar usuario REAL (con fetch)
    saveBtn.addEventListener("click", async (e) => {
        e.preventDefault();

        const usuario = document.getElementById("modalUsuario").value.trim();
        const pass = document.getElementById("modalPassword").value.trim();
        const confirm = document.getElementById("modalConfirmPassword").value.trim();
        const tipo = document.getElementById("modalTipo").value;

        if (!usuario || !pass || !confirm || !tipo) {
            alert("Completa todos los campos obligatorios.");
            return;
        }
        if (pass !== confirm) {
            alert("Las contraseñas no coinciden.");
            return;
        }

        // Preparamos datos
        const formData = new FormData();
        formData.append("usuario", usuario);
        formData.append("password", pass);
        formData.append("tipo", tipo);

        try {
            // Enviamos al backend
            const response = await fetch("index.php?action=crear_usuario", {
                method: "POST",
                body: formData
            });

            const result = await response.json();

            if (result.status === "ok") {
                alert("✅ " + result.message);
                closeModal();
                location.reload(); // refresca para ver el nuevo usuario
            } else {
                alert("❌ " + result.message);
            }
        } catch (error) {
            console.error(error);
            alert("❌ Error al conectar con el servidor.");
        }
    });
});
