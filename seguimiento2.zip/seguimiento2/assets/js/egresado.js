// egresados.js - Script simplificado para gestión de egresados con paginación

document.addEventListener("DOMContentLoaded", function() {
    console.log("=== EGRESADO JS CARGADO ===");
    
    const modal = document.getElementById("egresadoModal");
    const openBtn = document.getElementById("openCreateModal");
    const closeBtn = document.getElementById("autocompletarBtn");
    const cancelBtn = document.querySelector(".admin-btn-secondary");
    const submitBtn = document.getElementById("submitEgresadoForm");
    const form = document.getElementById("egresadoForm");
    const modalTitle = document.getElementById("modalTitle");
    
    console.log("Elementos encontrados:", {
        modal: !!modal,
        openBtn: !!openBtn,
        closeBtn: !!closeBtn,
        cancelBtn: !!cancelBtn,
        submitBtn: !!submitBtn,
        form: !!form,
        modalTitle: !!modalTitle
    });

    // ========== AUTO-OCULTAR ALERTAS DESPUÉS DE 3 SEGUNDOS ==========
    const alerts = document.querySelectorAll('.admin-alert');
    
    alerts.forEach(alert => {
        setTimeout(() => {
            // Añadir animación de salida
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            alert.style.transition = 'all 0.3s ease';
            
            // Eliminar completamente después de la animación
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.parentNode.removeChild(alert);
                }
            }, 300);
        }, 3000); // 3 segundos
    });

    // ========== PAGINACIÓN INTEGRADA ==========
    class PaginationEgresados {
        constructor() {
            this.currentPage = 1;
            this.itemsPerPage = parseInt(document.getElementById('itemsPerPage')?.value || 10);
            this.filteredItems = [];
            this.allItems = [];
            this.searchTerm = '';
            this.initPagination();
        }

        initPagination() {
            // Obtener todos los elementos de la tabla
            this.allItems = Array.from(document.querySelectorAll('#egresadosTableBody tr.egresado-row'));
            this.filteredItems = [...this.allItems];
            
            // Configurar eventos de paginación
            this.setupPaginationEvents();
            
            // Inicializar paginación
            this.updatePagination();
        }

        setupPaginationEvents() {
            // Eventos de botones de paginación
            document.getElementById('firstPage')?.addEventListener('click', () => this.goToPage(1));
            document.getElementById('prevPage')?.addEventListener('click', () => this.goToPage(this.currentPage - 1));
            document.getElementById('nextPage')?.addEventListener('click', () => this.goToPage(this.currentPage + 1));
            document.getElementById('lastPage')?.addEventListener('click', () => this.goToPage(this.getTotalPages()));
            
            // Evento para cambiar items por página
            const itemsPerPageSelect = document.getElementById('itemsPerPage');
            if (itemsPerPageSelect) {
                itemsPerPageSelect.value = this.itemsPerPage.toString();
                itemsPerPageSelect.addEventListener('change', (e) => {
                    this.itemsPerPage = parseInt(e.target.value);
                    this.currentPage = 1;
                    this.updatePagination();
                });
            }
        }

        getTotalPages() {
            return Math.ceil(this.filteredItems.length / this.itemsPerPage) || 1;
        }

        goToPage(page) {
            const totalPages = this.getTotalPages();
            
            if (page < 1) page = 1;
            if (page > totalPages) page = totalPages;
            
            this.currentPage = page;
            this.updatePagination();
        }

        updatePagination() {
            const totalPages = this.getTotalPages();
            const startIndex = (this.currentPage - 1) * this.itemsPerPage;
            const endIndex = startIndex + this.itemsPerPage;
            
            // Ocultar todas las filas
            this.allItems.forEach(row => row.style.display = 'none');
            
            // Mostrar solo las filas de la página actual
            this.filteredItems.slice(startIndex, endIndex).forEach(row => {
                if (row) row.style.display = '';
            });
            
            // Actualizar controles de paginación
            this.updatePaginationControls(totalPages);
            this.updatePaginationInfo(totalPages);
            this.updateResultCount();
        }

        updatePaginationControls(totalPages) {
            const pageNumbersContainer = document.getElementById('pageNumbers');
            if (!pageNumbersContainer) return;
            
            pageNumbersContainer.innerHTML = '';
            
            // Mostrar máximo 5 números de página
            let startPage = Math.max(1, this.currentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            // Botón para primera página si es necesario
            if (startPage > 1) {
                const firstPageBtn = document.createElement('button');
                firstPageBtn.className = 'admin-page-number';
                firstPageBtn.textContent = '1';
                firstPageBtn.addEventListener('click', () => this.goToPage(1));
                pageNumbersContainer.appendChild(firstPageBtn);
                
                if (startPage > 2) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
            }
            
            // Números de página
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `admin-page-number ${i === this.currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.addEventListener('click', () => this.goToPage(i));
                pageNumbersContainer.appendChild(pageBtn);
            }
            
            // Botón para última página si es necesario
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    const dots = document.createElement('span');
                    dots.className = 'admin-page-number dots';
                    dots.textContent = '...';
                    pageNumbersContainer.appendChild(dots);
                }
                
                const lastPageBtn = document.createElement('button');
                lastPageBtn.className = 'admin-page-number';
                lastPageBtn.textContent = totalPages;
                lastPageBtn.addEventListener('click', () => this.goToPage(totalPages));
                pageNumbersContainer.appendChild(lastPageBtn);
            }
            
            // Actualizar estado de botones
            const firstBtn = document.getElementById('firstPage');
            const prevBtn = document.getElementById('prevPage');
            const nextBtn = document.getElementById('nextPage');
            const lastBtn = document.getElementById('lastPage');
            
            if (firstBtn) firstBtn.disabled = this.currentPage === 1;
            if (prevBtn) prevBtn.disabled = this.currentPage === 1;
            if (nextBtn) nextBtn.disabled = this.currentPage === totalPages || totalPages === 0;
            if (lastBtn) lastBtn.disabled = this.currentPage === totalPages || totalPages === 0;
        }

        updatePaginationInfo(totalPages) {
            const currentPageSpan = document.getElementById('currentPage');
            const totalPagesSpan = document.getElementById('totalPages');
            
            if (currentPageSpan) currentPageSpan.textContent = this.currentPage;
            if (totalPagesSpan) totalPagesSpan.textContent = totalPages;
        }

        updateResultCount() {
            const resultCount = document.getElementById('resultCount');
            if (!resultCount) return;
            
            const totalItems = this.filteredItems.length;
            const startIndex = (this.currentPage - 1) * this.itemsPerPage + 1;
            const endIndex = Math.min(startIndex + this.itemsPerPage - 1, totalItems);
            
            if (totalItems === 0) {
                resultCount.textContent = 'No hay resultados';
            } else if (totalItems <= this.itemsPerPage) {
                if (this.searchTerm) {
                    resultCount.textContent = `Mostrando ${totalItems} resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = `Mostrando ${totalItems} egresados`;
                }
            } else {
                if (this.searchTerm) {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} resultados para "${this.searchTerm}"`;
                } else {
                    resultCount.textContent = `Mostrando ${startIndex}-${endIndex} de ${totalItems} egresados`;
                }
            }
        }

        filterItems(searchTerm) {
            this.searchTerm = searchTerm.toLowerCase().trim();
            this.currentPage = 1;
            
            if (!this.searchTerm) {
                this.filteredItems = [...this.allItems];
            } else {
                this.filteredItems = this.allItems.filter(row => {
                    const rowText = row.textContent.toLowerCase();
                    return rowText.includes(this.searchTerm);
                });
            }
            
            this.updatePagination();
        }

        refresh() {
            this.allItems = Array.from(document.querySelectorAll('#egresadosTableBody tr.egresado-row'));
            this.filterItems(this.searchTerm);
        }
    }

    // Instanciar paginación
    let pagination = null;

    // ========== VALIDACIÓN DE DNI DUPLICADO ==========
// ========== VALIDACIÓN MEJORADA DE DNI DUPLICADO ==========
let dniValidationTimeout = null;
const dniInput = document.getElementById('dni_input');
const dniError = document.getElementById('dniError');

// Funciones auxiliares para mostrar/ocultar errores
function showDniError(message) {
    if (dniError) {
        dniError.innerHTML = `<i class="bx bx-error-circle"></i> ${message}`;
        dniError.style.display = 'block';
        dniError.className = 'admin-form-error admin-form-error-error';
    }
    if (dniInput) {
        dniInput.style.borderColor = '#dc3545';
    }
}

function showDniSuccess(message) {
    if (dniError) {
        dniError.innerHTML = `<i class="bx bx-check-circle"></i> ${message}`;
        dniError.style.display = 'block';
        dniError.className = 'admin-form-error admin-form-error-success';
    }
    if (dniInput) {
        dniInput.style.borderColor = '#28a745';
    }
}

function hideDniError() {
    if (dniError) {
        dniError.style.display = 'none';
        dniError.className = 'admin-form-error';
    }
    if (dniInput) {
        dniInput.style.borderColor = '';
    }
}

// Función mejorada para validar DNI duplicado
function validarDNIDuplicado(isEditMode = false) {
    const dni = dniInput.value.trim();
    const currentId = document.getElementById('id_egresado')?.value || '';
    
    // Validar formato primero
    if (!/^\d{8}$/.test(dni)) {
        hideDniError();
        return Promise.resolve({ isValid: false, isDuplicate: false });
    }
    
    // Limpiar timeout anterior
    if (dniValidationTimeout) {
        clearTimeout(dniValidationTimeout);
    }
    
    return new Promise((resolve) => {
        dniValidationTimeout = setTimeout(async () => {
            // Mostrar mensaje de "validando..."
            if (dniError) {
                dniError.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Validando DNI...';
                dniError.style.display = 'block';
                dniError.className = 'admin-form-error';
            }
            
            try {
                // Construir URL con parámetro edit_id si estamos en modo edición
                let url = `index.php?action=buscar_estudiante&dni=${dni}`;
                if (isEditMode && currentId) {
                    url += `&edit_id=${currentId}`;
                }
                
                // Hacer la petición AJAX
                const response = await fetch(url);
                const data = await response.json();
                
                if (data.success && data.is_duplicate) {
                    // DNI duplicado encontrado
                    showDniError(`Este DNI ya pertenece a: ${data.data.nombres}`);
                    resolve({ isValid: false, isDuplicate: true });
                } else if (data.success && data.is_self) {
                    // Es el mismo registro en modo edición
                    hideDniError();
                    resolve({ isValid: true, isDuplicate: false });
                } else if (!data.success && !data.is_duplicate) {
                    // DNI disponible
                    showDniSuccess('DNI disponible');
                    setTimeout(() => hideDniError(), 2000);
                    resolve({ isValid: true, isDuplicate: false });
                } else {
                    // Otro caso
                    hideDniError();
                    resolve({ isValid: true, isDuplicate: false });
                }
            } catch (error) {
                console.error('Error validando DNI:', error);
                hideDniError();
                resolve({ isValid: false, isDuplicate: false, error: true });
            }
        }, 500); // Delay de 500ms
    });
}

// Aplicar validación si el elemento existe
if (dniInput) {
    // Al escribir en el campo DNI
    dniInput.addEventListener('input', function(e) {
        // Limitar a 8 números
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length > 8) {
            this.value = this.value.slice(0, 8);
        }
        
        // Validar formato básico en tiempo real
        if (this.value.length === 8) {
            if (!/^\d{8}$/.test(this.value)) {
                showDniError('El DNI debe tener solo 8 dígitos');
            } else {
                // Formato válido, validar duplicado
                const isEditMode = document.getElementById('id_egresado')?.value !== '';
                validarDNIDuplicado(isEditMode);
            }
        } else if (this.value.length > 0 && this.value.length < 8) {
            showDniError('El DNI debe tener 8 dígitos');
        } else {
            // Campo vacío
            hideDniError();
        }
    });
    
    // También validar cuando se pierde el foco
    dniInput.addEventListener('blur', function() {
        if (this.value.length === 8 && /^\d{8}$/.test(this.value)) {
            const isEditMode = document.getElementById('id_egresado')?.value !== '';
            validarDNIDuplicado(isEditMode);
        }
    });
}
    // ========== FUNCIONALIDAD DEL MODAL ==========

    // Función para mostrar modal
    function showModal() {
        if (modal) {
            modal.style.display = "flex";
            document.body.style.overflow = "hidden";
            // Forzar reflow para animación
            modal.offsetHeight;
            modal.classList.add("active");
        }
    }

    // Función para ocultar modal
    function hideModal() {
        if (modal) {
            modal.classList.remove("active");
            setTimeout(() => {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
            }, 300);
        }
    }

    // Función para resetear el formulario
    function resetForm() {
        if (form) {
            form.reset();
            const idEgresado = document.getElementById('id_egresado');
            const actionsInput = document.querySelector('input[name="actions"]');
            
            if (idEgresado) idEgresado.value = "";
            if (actionsInput) actionsInput.value = "1";
        }
        
        if (modalTitle) {
            modalTitle.textContent = "Registrar Nuevo Egresado";
        }
        
        // Resetear selects de ubigeo
        if (departamentoSelect) {
            departamentoSelect.value = "";
            if (provinciaSelect) {
                provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
                provinciaSelect.disabled = true;
            }
            if (distritoSelect) {
                distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                distritoSelect.disabled = true;
            }
        }
        
        // Resetear campos hidden de ubigeo
        const departamentoNombreInput = document.getElementById('departamento_nombre');
        const provinciaNombreInput = document.getElementById('provincia_nombre');
        const distritoNombreInput = document.getElementById('distrito_nombre');
        
        if (departamentoNombreInput) departamentoNombreInput.value = "";
        if (provinciaNombreInput) provinciaNombreInput.value = "";
        if (distritoNombreInput) distritoNombreInput.value = "";
        
        // Limpiar estilos de validación
        if (form) {
            form.querySelectorAll('input, select').forEach(field => {
                field.style.borderColor = '';
            });
        }
        
        // Limpiar mensaje de error de DNI
        if (dniError) {
            dniError.style.display = 'none';
        }
    }

    // Abrir modal para crear
    if (openBtn) {
        openBtn.addEventListener("click", function(e) {
            e.preventDefault();
            console.log("Botón abrir modal clickeado");
            resetForm();
            showModal();
            
            // Enfocar el primer campo
            setTimeout(() => {
                const dniInput = document.getElementById('dni_input');
                if (dniInput) dniInput.focus();
            }, 100);
        });
    }

    // Cerrar modal
    function closeModal() {
        console.log("Cerrando modal");
        hideModal();
    }

    // Asignar eventos de cierre
    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener("click", closeModal);
    }

    // Cerrar modal con tecla Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal && modal.style.display === 'flex') {
            closeModal();
        }
    });

    // ========== FUNCIONALIDAD GENERAL PARA CERRAR MODALES ==========
    
    // Función para cerrar cualquier modal
    function closeAnyModal(modal) {
        if (modal) {
            modal.classList.remove("active");
            setTimeout(() => {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
            }, 300);
        }
    }
    
    // Manejar todos los botones de cierre con data-dismiss="modal"
    document.addEventListener('click', function(e) {
        // Botones con data-dismiss="modal"
        if (e.target.closest('[data-dismiss="modal"]')) {
            const closeBtn = e.target.closest('[data-dismiss="modal"]');
            const modal = closeBtn.closest('.admin-modal');
            if (modal) {
                closeAnyModal(modal);
            }
        }
        
        // Botones con clase admin-modal-close (como respaldo)
        if (e.target.closest('.admin-modal-close')) {
            const closeBtn = e.target.closest('.admin-modal-close');
            const modal = closeBtn.closest('.admin-modal');
            if (modal) {
                closeAnyModal(modal);
            }
        }
    });

    // Manejar botones de editar
    document.addEventListener('click', function(e) {
        if (e.target.closest('.edit-egresado-btn')) {
            const btn = e.target.closest('.edit-egresado-btn');
            console.log("Botón editar clickeado", btn);
            
            // Cargar datos en el formulario
            const idEgresado = document.getElementById('id_egresado');
            const dniInput = document.getElementById('dni_input');
            const apellidoPaterno = document.getElementById('apellido_paterno');
            const apellidoMaterno = document.getElementById('apellido_materno');
            const nombres = document.getElementById('nombres');
            const correo = document.getElementById('correo');
            const telefono = document.getElementById('numero_telefonico');
            const estadoSelect = document.getElementById('estado');
            const actionsInput = document.querySelector('input[name="actions"]');
            
            if (idEgresado) idEgresado.value = btn.getAttribute('data-egresado-id') || '';
            if (dniInput) dniInput.value = btn.getAttribute('data-dni') || '';
            if (apellidoPaterno) apellidoPaterno.value = btn.getAttribute('data-apellido-paterno') || '';
            if (apellidoMaterno) apellidoMaterno.value = btn.getAttribute('data-apellido-materno') || '';
            if (nombres) nombres.value = btn.getAttribute('data-nombres') || '';
            if (correo) correo.value = btn.getAttribute('data-correo') || '';
            if (telefono) telefono.value = btn.getAttribute('data-telefono') || '';
            if (estadoSelect) estadoSelect.value = btn.getAttribute('data-estado') || 'estudiante';
            
            if (modalTitle) {
                modalTitle.textContent = "Editar Egresado";
            }
            
            if (actionsInput) {
                actionsInput.value = "2";
            }
            
            // Limpiar mensaje de error de DNI al editar
            if (dniError) {
                dniError.style.display = 'none';
                dniInput.style.borderColor = '';
            }
            
            // Cargar ubigeo si existe
            const ubigeoId = btn.getAttribute('data-ubigeo');
            if (ubigeoId && ubigeoId !== '') {
                cargarUbigeoExistente(ubigeoId);
            } else {
                // Resetear selects de ubigeo
                if (departamentoSelect) {
                    departamentoSelect.value = '';
                    if (provinciaSelect) {
                        provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
                        provinciaSelect.disabled = true;
                    }
                    if (distritoSelect) {
                        distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                        distritoSelect.disabled = true;
                    }
                }
                
                // Resetear campos hidden de ubigeo
                if (departamentoNombreInput) departamentoNombreInput.value = "";
                if (provinciaNombreInput) provinciaNombreInput.value = "";
                if (distritoNombreInput) distritoNombreInput.value = "";
            }
            
            showModal();
            
            // Inicializar ubigeo después de mostrar el modal
            setTimeout(() => {
                inicializarUbigeo();
            }, 100);
        }
    });

    // Enviar formulario con validación mejorada
    if (submitBtn && form) {
        submitBtn.addEventListener("click", function(e) {
            e.preventDefault();
            
            // Verificar si hay error de DNI duplicado
            if (dniError && dniError.style.display === 'block' && dniError.className.includes('admin-form-error-error')) {
                alert('⚠️ No se puede guardar: El DNI ingresado ya existe en el sistema.');
                dniInput.focus();
                return;
            }
            
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            let firstInvalidField = null;

            // Resetear bordes
            form.querySelectorAll('input, select').forEach(function(field) {
                field.style.borderColor = '';
            });

            // Validar campos requeridos
            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'red';
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                }
            });

            if (!isValid) {
                alert('⚠️ Por favor, complete todos los campos obligatorios.');
                if (firstInvalidField) {
                    firstInvalidField.focus();
                }
                return;
            }

            // Validar DNI (8 dígitos)
            const dni = document.querySelector('input[name="dni"]');
            if (dni && !/^\d{8}$/.test(dni.value)) {
                alert('⚠️ El DNI debe tener exactamente 8 dígitos.');
                dni.style.borderColor = 'red';
                dni.focus();
                return;
            }

            // Validar teléfono (9 dígitos)
            const telefono = document.querySelector('input[name="numero_telefonico"]');
            if (telefono && !/^\d{9}$/.test(telefono.value)) {
                alert('⚠️ El teléfono debe tener exactamente 9 dígitos.');
                telefono.style.borderColor = 'red';
                telefono.focus();
                return;
            }

            // Validar email
            const email = document.querySelector('input[name="correo"]');
            if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
                alert('⚠️ Por favor, ingrese un correo electrónico válido.');
                email.style.borderColor = 'red';
                email.focus();
                return;
            }

            // Mostrar confirmación
            const isEdit = document.querySelector('input[name="actions"]').value === "2";
            const actionText = isEdit ? "editar" : "registrar";
            
            if (confirm(`¿Está seguro de ${actionText} este egresado?`)) {
                console.log("Enviando formulario...");
                
                // Asegurar que los campos hidden tengan los valores actualizados
                if (departamentoSelect && departamentoSelect.options[departamentoSelect.selectedIndex] && departamentoNombreInput) {
                    departamentoNombreInput.value = departamentoSelect.options[departamentoSelect.selectedIndex].text;
                }
                if (provinciaSelect && provinciaSelect.options[provinciaSelect.selectedIndex] && provinciaNombreInput) {
                    provinciaNombreInput.value = provinciaSelect.options[provinciaSelect.selectedIndex].text;
                }
                if (distritoSelect && distritoSelect.options[distritoSelect.selectedIndex] && distritoNombreInput) {
                    distritoNombreInput.value = distritoSelect.options[distritoSelect.selectedIndex].text;
                }
                
                // Cambiar texto del botón a "Guardando..."
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Guardando...';
                submitBtn.disabled = true;
                
                form.submit();
            }
        });
    }

    // ========== FUNCIONALIDAD DE UBIGEO MEJORADA ==========

    // Elementos de ubigeo
    const departamentoSelect = document.getElementById('departamento');
    const provinciaSelect = document.getElementById('provincia');
    const distritoSelect = document.getElementById('distrito');

    // Campos hidden para nombres de ubigeo
    const departamentoNombreInput = document.getElementById('departamento_nombre');
    const provinciaNombreInput = document.getElementById('provincia_nombre');
    const distritoNombreInput = document.getElementById('distrito_nombre');

    // Bandera para evitar inicialización múltiple
    let ubigeoInicializado = false;

    // Inicializar eventos de ubigeo
    function inicializarUbigeo() {
        if (ubigeoInicializado) return;
        
        console.log("Inicializando ubigeo para egresados...");
        
        if (departamentoSelect) {
            // Remover event listeners existentes para evitar duplicados
            departamentoSelect.onchange = null;
            
            departamentoSelect.addEventListener('change', function() {
                const departamentoId = this.value;
                console.log("Departamento seleccionado:", departamentoId);
                
                // Actualizar campo hidden del departamento
                if (departamentoNombreInput && this.options[this.selectedIndex]) {
                    departamentoNombreInput.value = this.options[this.selectedIndex].text;
                }
                
                // Limpiar y deshabilitar provincias y distritos
                if (provinciaSelect) {
                    provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
                    provinciaSelect.disabled = true;
                    if (provinciaNombreInput) provinciaNombreInput.value = "";
                }
                if (distritoSelect) {
                    distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                    distritoSelect.disabled = true;
                    if (distritoNombreInput) distritoNombreInput.value = "";
                }
                
                if (departamentoId) {
                    cargarProvincias(departamentoId);
                }
            });
        }

        if (provinciaSelect) {
            // Remover event listeners existentes para evitar duplicados
            provinciaSelect.onchange = null;
            
            provinciaSelect.addEventListener('change', function() {
                const provinciaId = this.value;
                console.log("Provincia seleccionada:", provinciaId);
                
                // Actualizar campo hidden de la provincia
                if (provinciaNombreInput && this.options[this.selectedIndex]) {
                    provinciaNombreInput.value = this.options[this.selectedIndex].text;
                }
                
                // Limpiar y deshabilitar distritos
                if (distritoSelect) {
                    distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
                    distritoSelect.disabled = true;
                    if (distritoNombreInput) distritoNombreInput.value = "";
                }
                
                if (provinciaId) {
                    cargarDistritos(provinciaId);
                }
            });
        }

        if (distritoSelect) {
            // Remover event listeners existentes para evitar duplicados
            distritoSelect.onchange = null;
            
            distritoSelect.addEventListener('change', function() {
                const distritoId = this.value;
                console.log("Distrito seleccionado:", distritoId);
                
                // Actualizar campo hidden del distrito
                if (distritoNombreInput && this.options[this.selectedIndex]) {
                    distritoNombreInput.value = this.options[this.selectedIndex].text;
                }
            });
        }
        
        ubigeoInicializado = true;
    }

    // Función para cargar provincias
    function cargarProvincias(departamentoId) {
        return new Promise((resolve, reject) => {
            if (!provinciaSelect) {
                reject('provinciaSelect no encontrado');
                return;
            }
            
            provinciaSelect.disabled = true;
            provinciaSelect.innerHTML = '<option value="">Cargando provincias...</option>';
            
            fetch(`index.php?action=egresado&get_provincias=1&departamento_id=${departamentoId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        provinciaSelect.innerHTML = data.html;
                        provinciaSelect.disabled = false;
                        provinciaSelect.style.borderColor = '';
                        resolve(data);
                    } else {
                        provinciaSelect.innerHTML = '<option value="">Error al cargar provincias</option>';
                        reject(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    provinciaSelect.innerHTML = '<option value="">Error al cargar provincias</option>';
                    reject(error);
                });
        });
    }

    // Función para cargar distritos
    function cargarDistritos(provinciaId) {
        return new Promise((resolve, reject) => {
            if (!distritoSelect) {
                reject('distritoSelect no encontrado');
                return;
            }
            
            distritoSelect.disabled = true;
            distritoSelect.innerHTML = '<option value="">Cargando distritos...</option>';
            
            fetch(`index.php?action=egresado&get_distritos=1&provincia_id=${provinciaId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        distritoSelect.innerHTML = data.html;
                        distritoSelect.disabled = false;
                        distritoSelect.style.borderColor = '';
                        resolve(data);
                    } else {
                        distritoSelect.innerHTML = '<option value="">Error al cargar distritos</option>';
                        reject(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    distritoSelect.innerHTML = '<option value="">Error al cargar distritos</option>';
                    reject(error);
                });
        });
    }

    // Función para cargar ubigeo existente al editar
    function cargarUbigeoExistente(distritoId) {
        if (!distritoId || !departamentoSelect || !provinciaSelect || !distritoSelect) return;
        
        console.log("Cargando ubigeo existente para egresado:", distritoId);
        
        // Resetear selects primero
        provinciaSelect.innerHTML = '<option value="">Seleccione Provincia</option>';
        provinciaSelect.disabled = true;
        distritoSelect.innerHTML = '<option value="">Seleccione Distrito</option>';
        distritoSelect.disabled = true;
        
        // Resetear campos hidden
        if (provinciaNombreInput) provinciaNombreInput.value = "";
        if (distritoNombreInput) distritoNombreInput.value = "";
        
        // Obtener datos completos del ubigeo
        fetch(`index.php?action=egresado&get_ubigeo_completo&distrito_id=${distritoId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log("Datos ubigeo recibidos:", data);
                    
                    // Seleccionar departamento
                    departamentoSelect.value = data.departamento_id;
                    
                    // Actualizar campo hidden del departamento
                    if (departamentoNombreInput && departamentoSelect.options[departamentoSelect.selectedIndex]) {
                        departamentoNombreInput.value = departamentoSelect.options[departamentoSelect.selectedIndex].text;
                    }
                    
                    // Cargar provincias y luego seleccionar
                    cargarProvincias(data.departamento_id).then(() => {
                        // Esperar a que se carguen las provincias antes de seleccionar
                        setTimeout(() => {
                            if (provinciaSelect) {
                                provinciaSelect.value = data.provincia_id;
                                
                                // Actualizar campo hidden de la provincia
                                if (provinciaNombreInput && provinciaSelect.options[provinciaSelect.selectedIndex]) {
                                    provinciaNombreInput.value = provinciaSelect.options[provinciaSelect.selectedIndex].text;
                                }
                                
                                // Cargar distritos y luego seleccionar
                                cargarDistritos(data.provincia_id).then(() => {
                                    // Esperar a que se carguen los distritos antes de seleccionar
                                    setTimeout(() => {
                                        if (distritoSelect) {
                                            distritoSelect.value = data.distrito_id;
                                            
                                            // Actualizar campo hidden del distrito
                                            if (distritoNombreInput && distritoSelect.options[distritoSelect.selectedIndex]) {
                                                distritoNombreInput.value = distritoSelect.options[distritoSelect.selectedIndex].text;
                                            }
                                            
                                            console.log("Ubigeo cargado completamente para egresado");
                                        }
                                    }, 300);
                                });
                            }
                        }, 300);
                    });
                } else {
                    console.error('Error en datos ubigeo:', data.message);
                }
            })
            .catch(error => {
                console.error('Error cargando ubigeo:', error);
            });
    }

    // Inicializar ubigeo cuando se abre el modal
    if (openBtn) {
        openBtn.addEventListener("click", function() {
            // Pequeño delay para asegurar que el modal esté visible
            setTimeout(() => {
                inicializarUbigeo();
            }, 100);
        });
    }

    // También inicializar cuando se edita
    document.addEventListener('click', function(e) {
        if (e.target.closest('.edit-egresado-btn')) {
            setTimeout(() => {
                inicializarUbigeo();
            }, 100);
        }
    });

    // Inicializar al cargar la página si el modal está abierto
    if (modal && modal.style.display === 'flex') {
        inicializarUbigeo();
    }

    // ========== VALIDACIONES EN TIEMPO REAL ==========

    // Validación en tiempo real para teléfono
    const telefonoField = document.querySelector('input[name="numero_telefonico"]');
    if (telefonoField) {
        telefonoField.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 9) {
                this.value = this.value.slice(0, 9);
            }
            this.style.borderColor = '';
        });
    }

    // ========== FUNCIONALIDAD DEL BUSCADOR CON PAGINACIÓN ==========

    // Elementos del buscador
    const searchInput = document.getElementById("searchEgresados");
    const clearSearchBtn = document.getElementById("clearSearch");
    const noResults = document.getElementById("noResults");
    
    // Función de búsqueda con paginación
    function buscarEgresadosConPaginacion(searchTerm) {
        if (!pagination) {
            // Si la paginación no está inicializada, inicializarla primero
            if (typeof PaginationEgresados === 'function') {
                pagination = new PaginationEgresados();
            } else {
                console.error('La clase PaginationEgresados no está definida');
                return;
            }
        }
        
        // Actualizar el término de búsqueda y aplicar filtro
        pagination.filterItems(searchTerm);
        
        // Mostrar/ocultar botón limpiar
        if (clearSearchBtn) {
            clearSearchBtn.style.display = searchTerm.trim() ? 'flex' : 'none';
        }
        
        // Manejar estado de "no resultados"
        if (noResults) {
            const tableBody = document.getElementById("egresadosTableBody");
            const paginationControls = document.getElementById("paginationControls");
            
            if (pagination.filteredItems.length === 0) {
                noResults.style.display = 'block';
                if (tableBody) tableBody.style.display = 'none';
                if (paginationControls) paginationControls.style.display = 'none';
            } else {
                noResults.style.display = 'none';
                if (tableBody) tableBody.style.display = '';
                if (paginationControls) paginationControls.style.display = '';
            }
        }
        
        // Resaltar texto coincidente en todas las celdas
        if (searchTerm.trim()) {
            const rows = Array.from(document.querySelectorAll('#egresadosTableBody tr.egresado-row'));
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                cells.forEach(cell => {
                    // Guardar el texto original si no está guardado
                    if (!cell.hasAttribute('data-original-text')) {
                        cell.setAttribute('data-original-text', cell.innerHTML);
                    }
                    
                    const originalHTML = cell.getAttribute('data-original-text');
                    const textContent = cell.textContent || '';
                    
                    // Resaltar solo si hay coincidencia en esta celda específica
                    if (textContent.toLowerCase().includes(searchTerm.toLowerCase())) {
                        const highlightedText = textContent.replace(
                            new RegExp(searchTerm, 'gi'),
                            match => `<span class="highlight">${match}</span>`
                        );
                        cell.innerHTML = highlightedText;
                    } else {
                        cell.innerHTML = originalHTML;
                    }
                });
            });
        } else {
            // Restaurar el contenido original sin resaltado
            const cells = document.querySelectorAll('td[data-original-text]');
            cells.forEach(cell => {
                if (cell.hasAttribute('data-original-text')) {
                    cell.innerHTML = cell.getAttribute('data-original-text');
                }
            });
        }
    }

    // Event listeners para el buscador
    if (searchInput) {
        // Búsqueda en tiempo real con debounce
        let searchTimeout = null;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                buscarEgresadosConPaginacion(this.value);
            }, 300);
        });
        
        // Limpiar con Escape
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Escape') {
                this.value = '';
                buscarEgresadosConPaginacion('');
                this.blur();
            }
        });
        
        // Prevenir que el Enter envíe el formulario
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                buscarEgresadosConPaginacion(this.value);
            }
        });
        
        // Inicializar estado del botón limpiar
        if (clearSearchBtn) {
            clearSearchBtn.style.display = searchInput.value.trim() ? 'flex' : 'none';
        }
    }

    if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', function() {
            if (searchInput) {
                searchInput.value = '';
                buscarEgresadosConPaginacion('');
                searchInput.focus();
            }
        });
    }

    // ========== INICIALIZACIÓN ==========

    // Inicializar paginación al cargar la página
    function inicializarTodo() {
        // Inicializar paginación si existe
        if (typeof PaginationEgresados === 'function') {
            pagination = new PaginationEgresados();
            
            // Aplicar búsqueda inicial si hay término en el buscador
            if (searchInput && searchInput.value.trim()) {
                buscarEgresadosConPaginacion(searchInput.value.trim());
            }
        }
        
        // Inicializar ubigeo si el modal está abierto
        if (modal && modal.style.display === 'flex') {
            inicializarUbigeo();
        }
    }

    // Esperar un poco para asegurar que todo esté cargado
    setTimeout(inicializarTodo, 100);

    // Observar cambios en la tabla (para cuando se agreguen/eliminen elementos)
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList' && pagination) {
                // Esperar un poco para que el DOM se actualice
                setTimeout(() => {
                    pagination.refresh();
                }, 200);
            }
        });
    });
    
    // Observar cambios en el tbody de la tabla
    const tableBody = document.getElementById('egresadosTableBody');
    if (tableBody) {
        observer.observe(tableBody, { childList: true, subtree: true });
    }

    // Agregar estilos CSS para el modal y resaltado si no existen
    if (!document.querySelector('#modal-styles')) {
        const style = document.createElement('style');
        style.id = 'modal-styles';
        style.textContent = `
            .admin-modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 9999;
                opacity: 0;
                transition: opacity 0.3s ease;
                align-items: center;
                justify-content: center;
            }
            .admin-modal.active {
                opacity: 1;
            }
            .admin-modal-dialog {
                background: white;
                border-radius: 8px;
                margin: auto;
                max-width: 800px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
                transform: translateY(-50px);
                transition: transform 0.3s ease;
            }
            .admin-modal.active .admin-modal-dialog {
                transform: translateY(0);
            }
            .highlight {
                background-color: #fff3cd !important;
                font-weight: bold;
                padding: 2px 4px;
                border-radius: 3px;
            }
            .search-input-group {
                position: relative;
            }
            .clear-search-btn {
                position: absolute;
                right: 8px;
                top: 50%;
                transform: translateY(-50%);
                background: none;
                border: none;
                cursor: pointer;
                padding: 4px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .admin-form-input:disabled {
                background-color: #f8f9fa;
                color: #6c757d;
                cursor: not-allowed;
                opacity: 0.7;
            }
            .admin-form-input:not(:disabled) {
                background-color: white;
                color: #495057;
                cursor: pointer;
            }
            .admin-form-error {
                color: #dc3545;
                font-size: 0.875rem;
                margin-top: 0.25rem;
                display: flex;
                align-items: center;
                gap: 0.25rem;
            }
            .admin-form-error-error {
                color: #dc3545 !important;
            }
            /* Estilos para paginación si no existen en CSS */
            .admin-pagination-btn:disabled {
                opacity: 0.5;
                cursor: not-allowed;
            }
            .admin-page-number.active {
                background-color: #0A2647 !important;
                color: white !important;
                border-color: #0A2647 !important;
            }
            .admin-page-number.dots {
                background: transparent !important;
                border: none !important;
                cursor: default !important;
            }
        `;
        document.head.appendChild(style);
    }

    console.log("=== EGRESADO JS CON PAGINACIÓN INICIALIZADO CORRECTAMENTE ===");
});