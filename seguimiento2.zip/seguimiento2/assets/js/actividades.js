document.addEventListener('DOMContentLoaded', function() {
            // Validar que la fecha de fin sea mayor o igual a la fecha de inicio
            const fechaInicio = document.getElementById('fecha_inicio');
            const fechaFin = document.getElementById('fecha_fin');
            
            // Establecer fecha mínima como hoy
            const hoy = new Date().toISOString().split('T')[0];
            fechaInicio.min = hoy;
            
            fechaInicio.addEventListener('change', function() {
                fechaFin.min = this.value;
                
                // Si fechaFin es anterior a fechaInicio, actualizarla
                if (fechaFin.value && fechaFin.value < this.value) {
                    fechaFin.value = this.value;
                }
            });
            
            fechaFin.addEventListener('change', function() {
                if (fechaInicio.value && this.value < fechaInicio.value) {
                    alert('La fecha de fin no puede ser anterior a la fecha de inicio');
                    this.value = fechaInicio.value;
                }
            });
            
            // Función para verificar solapamiento de fechas con actividades existentes
            function verificarSolapamientoFechas(fechaInicio, fechaFin) {
                // Obtener todas las actividades del DOM
                const actividades = document.querySelectorAll('.actividad-card');
                
                for (const actividad of actividades) {
                    // Extraer fechas de la actividad existente
                    const fechaInicioExistente = actividad.querySelector('strong:nth-of-type(1)').textContent.trim();
                    const fechaFinExistente = actividad.querySelector('strong:nth-of-type(2)').textContent.trim();
                    
                    // Verificar que los elementos existen
                    if (!fechaInicioExistente || !fechaFinExistente) continue;
                    
                    // Convertir fechas a formato YYYY-MM-DD para comparación
                    const [diaI, mesI, anioI] = fechaInicioExistente.split('/');
                    const [diaF, mesF, anioF] = fechaFinExistente.split('/');
                    
                    // Validar formato de fecha
                    if (!diaI || !mesI || !anioI || !diaF || !mesF || !anioF) continue;
                    
                    const inicioExistente = `${anioI}-${mesI.padStart(2, '0')}-${diaI.padStart(2, '0')}`;
                    const finExistente = `${anioF}-${mesF.padStart(2, '0')}-${diaF.padStart(2, '0')}`;
                    
                    // Verificar si son exactamente las mismas fechas
                    if (fechaInicio === inicioExistente && fechaFin === finExistente) {
                        return {
                            solapamiento: true,
                            tipo: 'exacto',
                            titulo: actividad.querySelector('h5').textContent.trim(),
                            fechas: `${fechaInicioExistente} - ${fechaFinExistente}`
                        };
                    }
                    
                    // Convertir a Date objects para comparación de rangos
                    const inicioNueva = new Date(fechaInicio);
                    const finNueva = new Date(fechaFin);
                    const inicioExist = new Date(inicioExistente);
                    const finExist = new Date(finExistente);
                    
                    // Verificar solapamiento de rangos
                    // Condición 1: Nueva fecha inicio dentro de rango existente
                    // Condición 2: Nueva fecha fin dentro de rango existente
                    // Condición 3: Nueva rango contiene rango existente
                    // Condición 4: Rango existente contiene nueva rango
                    if ((inicioNueva >= inicioExist && inicioNueva <= finExist) ||
                        (finNueva >= inicioExist && finNueva <= finExist) ||
                        (inicioNueva <= inicioExist && finNueva >= finExist) ||
                        (inicioExist <= inicioNueva && finExist >= finNueva)) {
                        return {
                            solapamiento: true,
                            tipo: 'rango',
                            titulo: actividad.querySelector('h5').textContent.trim(),
                            fechas: `${fechaInicioExistente} - ${fechaFinExistente}`
                        };
                    }
                }
                
                return { solapamiento: false };
            }
            
            // Validación del formulario
            document.getElementById('formActividad').addEventListener('submit', function(e) {
                // Validaciones básicas
                if (!fechaInicio.value || !fechaFin.value) {
                    e.preventDefault();
                    alert('Por favor, complete ambas fechas');
                    return;
                }
                
                const inicio = new Date(fechaInicio.value);
                const fin = new Date(fechaFin.value);
                
                if (fin < inicio) {
                    e.preventDefault();
                    alert('La fecha de fin no puede ser anterior a la fecha de inicio');
                    return;
                }
                
                // ✅ NUEVA VALIDACIÓN: Verificar solapamiento de fechas
                const verificar = verificarSolapamientoFechas(fechaInicio.value, fechaFin.value);
                
                if (verificar.solapamiento) {
                    e.preventDefault();
                    let mensaje = '';
                    
                    if (verificar.tipo === 'exacto') {
                        mensaje = `❌ Ya existe una actividad programada con exactamente las mismas fechas:\n\n` +
                                `"${verificar.titulo}"\n` +
                                `Fechas: ${verificar.fechas}\n\n` +
                                `No se permiten duplicados de fechas exactas.`;
                    } else {
                        mensaje = `❌ Ya existe una actividad programada con fechas que se solapan:\n\n` +
                                `"${verificar.titulo}"\n` +
                                `Fechas: ${verificar.fechas}\n\n` +
                                `Por favor, selecciona fechas diferentes.`;
                    }
                    
                    alert(mensaje);
                    return;
                }
                
                // Confirmación para activar
                const estado = document.getElementById('estado').value;
                if (estado == '1') {
                    if (!confirm('¿Está seguro de activar la encuesta externa con estas fechas?\n\nLos egresados podrán acceder al formulario durante este período.')) {
                        e.preventDefault();
                    }
                }
            });
            
            // Auto-ocultar mensajes después de 5 segundos
            setTimeout(function() {
                const messages = document.querySelectorAll('.alert-session');
                messages.forEach(function(message) {
                    message.style.transition = 'opacity 0.5s ease';
                    message.style.opacity = '0';
                    setTimeout(function() {
                        message.style.display = 'none';
                    }, 500);
                });
            }, 5000);
            
            // Validación en tiempo real mientras se seleccionan fechas
            fechaInicio.addEventListener('change', function() {
                if (fechaFin.value) {
                    const verificar = verificarSolapamientoFechas(this.value, fechaFin.value);
                    if (verificar.solapamiento) {
                        alert(`⚠️ Atención: Las fechas seleccionadas se solapan con:\n\n"${verificar.titulo}"\nFechas: ${verificar.fechas}`);
                        this.focus();
                    }
                }
            });
            
            fechaFin.addEventListener('change', function() {
                if (fechaInicio.value) {
                    const verificar = verificarSolapamientoFechas(fechaInicio.value, this.value);
                    if (verificar.solapamiento) {
                        alert(`⚠️ Atención: Las fechas seleccionadas se solapan con:\n\n"${verificar.titulo}"\nFechas: ${verificar.fechas}`);
                        this.focus();
                    }
                }
            });
        });