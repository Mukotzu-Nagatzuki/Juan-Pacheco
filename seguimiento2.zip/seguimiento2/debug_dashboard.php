<?php
// debug_dashboard.php
session_start();

// Configuración de base de datos - AJUSTA ESTOS VALORES
$host = "50.31.174.34";
$user = "wxwdrnht_wxwdrnht_integrado_db"; // tu usuario de MySQL
$pass = "integrado_db2025."; // tu contraseña de MySQL
$dbname = "wxwdrnht_integrado_db"; // nombre de tu base de datos

// Conectar a MySQL
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

echo "<h1>DIAGNÓSTICO DEL DASHBOARD</h1>";

// 1. Verificar tablas existentes
echo "<h2>1. Tablas en la base de datos:</h2>";
$sql = "SHOW TABLES";
$result = $conn->query($sql);
echo "<ul>";
while($row = $result->fetch_array()) {
    echo "<li>" . $row[0] . "</li>";
}
echo "</ul>";

// 2. Contar registros en cada tabla importante
$tablas = ['estudiante', 'empresa', 'prog_estudios', 'situacion_laboral', 'matricula'];
echo "<h2>2. Conteo de registros:</h2>";
foreach ($tablas as $tabla) {
    $sql = "SELECT COUNT(*) as total FROM $tabla";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    echo "$tabla: " . $row['total'] . " registros<br>";
}

// 3. Mostrar algunos estudiantes
echo "<h2>3. Primeros 5 estudiantes:</h2>";
$sql = "SELECT id, dni_est, ap_est, am_est, nom_est FROM estudiante LIMIT 5";
$result = $conn->query($sql);
echo "<table border='1'>";
echo "<tr><th>ID</th><th>DNI</th><th>Apellidos</th><th>Nombre</th></tr>";
while($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['dni_est'] . "</td>";
    echo "<td>" . $row['ap_est'] . " " . $row['am_est'] . "</td>";
    echo "<td>" . $row['nom_est'] . "</td>";
    echo "</tr>";
}
echo "</table>";

$conn->close();
?>