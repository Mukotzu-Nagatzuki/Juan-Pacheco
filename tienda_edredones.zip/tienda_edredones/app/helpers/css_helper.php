<?php
function loadPageCSS() {
    $base_path = 'public/css/';
    
    // Detectar página actual
    if (isset($_SESSION['current_page'])) {
        $page = $_SESSION['current_page'];
    } else {
        $page = 'home';
    }
    
    $css_files = [
        'home' => 'home.css',
        'login' => 'auth.css',
        'registro' => 'auth.css',
        'productos' => 'products.css',
        'perfil' => 'profile.css'
    ];
    
    if (isset($css_files[$page])) {
        echo '<link rel="stylesheet" href="' . $base_path . $css_files[$page] . '">' . "\n";
    }
}
?>