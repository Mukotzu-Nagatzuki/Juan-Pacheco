<?php
require_once __DIR__ . '/../config/database.php'; // Ruta correcta a tu Database.php

// Iniciar sesión si no existe
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Función para obtener la conexión PDO
function getConnection() {
    $database = new Database();
    return $database->getConnection();
}

// Función para verificar si el usuario está logueado - CORREGIDA
function checkAuth() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: index.php?action=login');
        exit;
    }
}

// =============================================
// FUNCIONES DE USUARIO Y PERFIL
// =============================================

/**
 * Obtener perfil de usuario
 */
function getUserProfile($id_usuario) {
    $conn = getConnection();
    if (!$conn) {
        die("❌ Error al conectar con la base de datos");
    }

    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id_usuario = :id_usuario");
    $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Actualizar perfil de usuario
 */
function updateUserProfile($id_usuario, $nombre, $apellido, $correo, $telefono, $direccion, $ciudad, $provincia, $distrito, $referencia) {
    $conn = getConnection();
    if (!$conn) return false;

    $stmt = $conn->prepare("
        UPDATE usuarios 
        SET nombre = :nombre, apellido = :apellido, correo = :correo, telefono = :telefono, 
            direccion = :direccion, ciudad = :ciudad, provincia = :provincia, 
            distrito = :distrito, referencia = :referencia
        WHERE id_usuario = :id_usuario
    ");
    
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':apellido', $apellido);
    $stmt->bindParam(':correo', $correo);
    $stmt->bindParam(':telefono', $telefono);
    $stmt->bindParam(':direccion', $direccion);
    $stmt->bindParam(':ciudad', $ciudad);
    $stmt->bindParam(':provincia', $provincia);
    $stmt->bindParam(':distrito', $distrito);
    $stmt->bindParam(':referencia', $referencia);
    $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);

    return $stmt->execute();
}

/**
 * Cambiar contraseña de usuario
 */
function changePassword($id_usuario, $nueva_clave_hash) {
    $conn = getConnection();
    if (!$conn) return false;

    $stmt = $conn->prepare("UPDATE usuarios SET clave = :clave WHERE id_usuario = :id_usuario");
    $stmt->bindParam(':clave', $nueva_clave_hash);
    $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);

    return $stmt->execute();
}

// =============================================
// FUNCIONES DE PEDIDOS
// =============================================

/**
 * Obtener todos los pedidos de un usuario
 */
function obtenerPedidosUsuario($id_usuario) {
    $conn = getConnection();
    try {
        $sql = "SELECT * FROM pedidos WHERE id_usuario = :id_usuario ORDER BY fecha_pedido DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener pedidos del usuario: " . $e->getMessage());
        return [];
    }
}

/**
 * Obtener detalle de un pedido específico
 */
function obtenerDetallePedido($id_pedido) {
    $conn = getConnection();
    try {
        $sql = "SELECT dp.*, p.nombre AS nombre_producto, p.precio, p.imagen_principal,
                       p.medida, p.color, p.material
                FROM detalle_pedido dp
                INNER JOIN productos p ON dp.id_producto = p.id_producto
                WHERE dp.id_pedido = :id_pedido";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_pedido', $id_pedido, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener detalle del pedido: " . $e->getMessage());
        return [];
    }
}

/**
 * Contar productos en un pedido
 */
function contarProductosPedido($id_pedido) {
    $conn = getConnection();
    try {
        $sql = "SELECT COUNT(*) AS total FROM detalle_pedido WHERE id_pedido = :id_pedido";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_pedido', $id_pedido, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    } catch (PDOException $e) {
        error_log("Error al contar productos del pedido: " . $e->getMessage());
        return 0;
    }
}

/**
 * Obtener pedido por ID
 */
function obtenerPedidoPorId($id_pedido) {
    $conn = getConnection();
    try {
        $sql = "SELECT p.*, u.nombre, u.apellido, u.correo, u.telefono
                FROM pedidos p
                INNER JOIN usuarios u ON p.id_usuario = u.id_usuario
                WHERE p.id_pedido = :id_pedido";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_pedido', $id_pedido, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener pedido: " . $e->getMessage());
        return null;
    }
}

// =============================================
// FUNCIONES DE PRODUCTOS
// =============================================

/**
 * Obtener todos los productos activos
 */
function obtenerProductos($categoria_id = null) {
    $conn = getConnection();
    try {
        $sql = "SELECT p.*, c.nombre as categoria_nombre 
                FROM productos p 
                LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                WHERE p.estado = 'activo'";
        
        if ($categoria_id) {
            $sql .= " AND p.id_categoria = :categoria_id";
        }
        
        $sql .= " ORDER BY p.fecha_registro DESC";
        
        $stmt = $conn->prepare($sql);
        
        if ($categoria_id) {
            $stmt->bindParam(':categoria_id', $categoria_id, PDO::PARAM_INT);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener productos: " . $e->getMessage());
        return [];
    }
}

/**
 * Obtener producto por ID
 */
function obtenerProductoPorId($id_producto) {
    $conn = getConnection();
    try {
        $sql = "SELECT p.*, c.nombre as categoria_nombre 
                FROM productos p 
                LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                WHERE p.id_producto = :id_producto";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_producto', $id_producto, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener producto: " . $e->getMessage());
        return null;
    }
}

// =============================================
// FUNCIONES DE CARRITO
// =============================================

/**
 * Obtener carrito del usuario
 */
function obtenerCarritoUsuario($id_usuario) {
    $conn = getConnection();
    try {
        $sql = "SELECT c.*, p.nombre, p.precio, p.imagen_principal, p.stock
                FROM carrito c
                INNER JOIN productos p ON c.id_producto = p.id_producto
                WHERE c.id_usuario = :id_usuario AND c.estado = 'activo'";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener carrito: " . $e->getMessage());
        return [];
    }
}

/**
 * Agregar producto al carrito
 */
function agregarAlCarrito($id_usuario, $id_producto, $cantidad = 1) {
    $conn = getConnection();
    try {
        // Verificar si el producto ya está en el carrito
        $sql = "SELECT * FROM carrito 
                WHERE id_usuario = :id_usuario AND id_producto = :id_producto AND estado = 'activo'";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->bindParam(':id_producto', $id_producto, PDO::PARAM_INT);
        $stmt->execute();
        $existente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existente) {
            // Actualizar cantidad
            $nueva_cantidad = $existente['cantidad'] + $cantidad;
            $sql = "UPDATE carrito SET cantidad = :cantidad WHERE id_carrito = :id_carrito";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':cantidad', $nueva_cantidad, PDO::PARAM_INT);
            $stmt->bindParam(':id_carrito', $existente['id_carrito'], PDO::PARAM_INT);
            return $stmt->execute();
        } else {
            // Obtener precio del producto
            $producto = obtenerProductoPorId($id_producto);
            $subtotal = $producto['precio'] * $cantidad;

            // Insertar nuevo item
            $sql = "INSERT INTO carrito (id_usuario, id_producto, cantidad, subtotal, estado)
                    VALUES (:id_usuario, :id_producto, :cantidad, :subtotal, 'activo')";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
            $stmt->bindParam(':id_producto', $id_producto, PDO::PARAM_INT);
            $stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
            $stmt->bindParam(':subtotal', $subtotal);
            return $stmt->execute();
        }
    } catch (PDOException $e) {
        error_log("Error al agregar al carrito: " . $e->getMessage());
        return false;
    }
}

// =============================================
// FUNCIONES DE UTILIDAD
// =============================================

/**
 * Redireccionar con mensaje
 */
function redirectWithMessage($url, $type, $message) {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    header("Location: $url");
    exit;
}

/**
 * Obtener mensaje flash
 */
function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
        return ['message' => $message, 'type' => $type];
    }
    return null;
}

/**
 * Formatear moneda
 */
function formatCurrency($amount) {
    return 'S/ ' . number_format($amount, 2);
}

/**
 * Validar email
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Sanitizar entrada
 */
function sanitizeInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// =============================================
// FUNCIONES PARA ROLES - AGREGADAS
// =============================================

/**
 * Verificar si el usuario es administrador
 */
function isAdmin() {
    return isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin';
}

/**
 * Verificar si el usuario es cliente
 */
function isCliente() {
    return isset($_SESSION['rol']) && $_SESSION['rol'] === 'cliente';
}

/**
 * Verificar permisos de administrador
 */
function checkAdminAuth() {
    checkAuth(); // Primero verifica que esté logueado
    
    if (!isAdmin()) {
        // En lugar de redirigir al dashboard, podrías mostrar un error
        $_SESSION['error'] = "No tienes permisos de administrador para acceder a esta página";
        header('Location: index.php?action=dashboard');
        exit;
    }
}

/**
 * Verificar permisos de cliente
 */
function checkClienteAuth() {
    checkAuth();
    if (!isCliente()) {
        $_SESSION['error'] = "Esta sección es solo para clientes";
        header('Location: index.php?action=dashboard');
        exit;
    }
}
?>