<?php
function obtenerConfiguracion($clave, $valorPorDefecto = '') {
    $database = new Database();
    $conn = $database->getConnection();
    
    $query = "SELECT valor FROM configuraciones_sitio WHERE clave = :clave";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':clave', $clave);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result ? $result['valor'] : $valorPorDefecto;
}
?>