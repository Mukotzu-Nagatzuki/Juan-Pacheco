<?php
// =====================================================
// ⚙ CONFIGURACIÓN GLOBAL DEL SISTEMA
// =====================================================

// Zona horaria (Perú)
date_default_timezone_set('America/Lima');

// URL base del proyecto (ajústala si tu carpeta tiene otro nombre)
define('BASE_URL', 'http://localhost/tienda_edredones/public/');

// Datos generales del sitio
define('SITE_NAME', 'Tienda de Edredones');
define('SITE_EMAIL', 'contacto@tiendaedredones.com');

// Parámetros de seguridad
define('PASSWORD_COST', 12); // nivel de seguridad del hash de contraseñas

// Configuración de Pago (TEST o PRODUCTION)
define('PAYMENT_MODE', 'TEST');

// Claves Públicas Izipay
define('IZIPAY_PUBLIC_KEY_TEST', '69697151:testpublickey_3jhpsoUyhsrV85jET7v2YtOf2CxKWTNANgFmxmqovfmBc');
define('IZIPAY_PUBLIC_KEY_PROD', '69697151:publickey_UxXHz1Yh5yP4zL4JFo0PqfIzis90CbBk91SSRKeNQku8E');

// Claves HMAC-SHA-256 para validar callbacks (kr-hash)
define('IZIPAY_HMAC_TEST', 'YH9KNhETfkaupD5Jb6CWqKQYdSq16if2c88Gew5Bm9M6f');
define('IZIPAY_HMAC_PROD', 'XTLMbHQxpeIu7e5CMlf2bVrHExybP5i09IDfjlw3NTUGf');

// Mostrar errores (solo durante desarrollo)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// =====================================================
// 📦 INCLUYE LA CONEXIÓN A LA BASE DE DATOS
// =====================================================
require_once 'database.php';

// =====================================================
// 🔁 FUNCIONES AUXILIARES
// =====================================================

// Redirigir fácilmente a otra página
function redirect($url)
{
    header("Location: " . BASE_URL . $url);
    exit;
}
?>