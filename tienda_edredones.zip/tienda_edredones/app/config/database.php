<?php
class Database {
    private $host = "localhost";   // host de InfinityFree
    private $db_name = "vjetvzgr_edredones"; // tu base de datos
    private $username = "vjetvzgr_edredones";          // tu usuario
    private $password = "edredones.qatunas.com/";      // tu contraseña (la del vPanel)
    private $port = 3306;
    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name}";

            $this->conn = new PDO(
                $dsn,
                $this->username,
                $this->password
            );

            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $this->conn;

        } catch (PDOException $exception) {
            error_log("Error de conexión: " . $exception->getMessage());
            echo "⚠ Error de conexión a la base de datos.";
        }

        return $this->conn;
    }
}
?>
