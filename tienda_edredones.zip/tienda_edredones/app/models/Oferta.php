<?php
class Oferta {
    private $db;
    private $table = 'ofertas';

    public function __construct() {
        $this->db = new Database();
    }

    public function obtenerTodas() {
        $conn = $this->db->getConnection();
        $stmt = $conn->prepare("SELECT * FROM {$this->table} ORDER BY fecha_creacion DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id) {
        $conn = $this->db->getConnection();
        $stmt = $conn->prepare("SELECT * FROM {$this->table} WHERE id_oferta = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPorCodigo($codigo) {
        $conn = $this->db->getConnection();
        $stmt = $conn->prepare("SELECT * FROM {$this->table} WHERE codigo_oferta = ? AND estado = 'activa'");
        $stmt->execute([$codigo]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function crear($datos) {
        $conn = $this->db->getConnection();
        $sql = "INSERT INTO {$this->table} (codigo_oferta, descripcion, tipo_descuento, valor_descuento, fecha_inicio, fecha_fin, usos_maximos, minimo_compra, aplica_todo, estado) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        return $stmt->execute([
            $datos['codigo_oferta'],
            $datos['descripcion'],
            $datos['tipo_descuento'],
            $datos['valor_descuento'],
            $datos['fecha_inicio'],
            $datos['fecha_fin'],
            $datos['usos_maximos'],
            $datos['minimo_compra'],
            $datos['aplica_todo'],
            $datos['estado']
        ]);
    }

    public function actualizar($id, $datos) {
        $conn = $this->db->getConnection();
        $sql = "UPDATE {$this->table} SET codigo_oferta = ?, descripcion = ?, tipo_descuento = ?, valor_descuento = ?, fecha_inicio = ?, fecha_fin = ?, usos_maximos = ?, minimo_compra = ?, aplica_todo = ?, estado = ? WHERE id_oferta = ?";
        
        $stmt = $conn->prepare($sql);
        return $stmt->execute([
            $datos['codigo_oferta'],
            $datos['descripcion'],
            $datos['tipo_descuento'],
            $datos['valor_descuento'],
            $datos['fecha_inicio'],
            $datos['fecha_fin'],
            $datos['usos_maximos'],
            $datos['minimo_compra'],
            $datos['aplica_todo'],
            $datos['estado'],
            $id
        ]);
    }

    public function eliminar($id) {
        $conn = $this->db->getConnection();
        $stmt = $conn->prepare("DELETE FROM {$this->table} WHERE id_oferta = ?");
        return $stmt->execute([$id]);
    }

    public function obtenerOfertasDisponibles() {
        $conn = $this->db->getConnection();
        $sql = "SELECT * FROM {$this->table} 
                WHERE estado = 'activa' 
                AND fecha_inicio <= NOW() 
                AND fecha_fin >= NOW() 
                AND (usos_maximos IS NULL OR usos_actuales < usos_maximos)
                ORDER BY fecha_creacion DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerEstadisticas($id_oferta) {
        $conn = $this->db->getConnection();
        
        $stmt = $conn->prepare("
            SELECT 
                COUNT(ou.id_uso) as total_usos,
                COALESCE(SUM(ou.monto_descuento), 0) as total_descuento,
                COALESCE(AVG(ou.monto_descuento), 0) as promedio_descuento
            FROM oferta_usos ou
            WHERE ou.id_oferta = ?
        ");
        $stmt->execute([$id_oferta]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerUsos($id_oferta) {
        $conn = $this->db->getConnection();
        $stmt = $conn->prepare("
            SELECT ou.*, u.nombre, u.apellido, p.total
            FROM oferta_usos ou
            JOIN usuarios u ON ou.id_usuario = u.id_usuario
            JOIN pedidos p ON ou.id_pedido = p.id_pedido
            WHERE ou.id_oferta = ?
            ORDER BY ou.fecha_uso DESC
        ");
        $stmt->execute([$id_oferta]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerUsosPorUsuario($id_usuario) {
        $conn = $this->db->getConnection();
        $stmt = $conn->prepare("
            SELECT ou.*, o.codigo_oferta, o.descripcion, p.total
            FROM oferta_usos ou
            JOIN ofertas o ON ou.id_oferta = o.id_oferta
            JOIN pedidos p ON ou.id_pedido = p.id_pedido
            WHERE ou.id_usuario = ?
            ORDER BY ou.fecha_uso DESC
        ");
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function validarOferta($codigo, $monto_compra = 0) {
        $oferta = $this->obtenerPorCodigo($codigo);
        
        if (!$oferta) {
            return ['valida' => false, 'mensaje' => 'Código de oferta no válido'];
        }
        
        // Verificar fechas
        $ahora = date('Y-m-d H:i:s');
        if ($ahora < $oferta['fecha_inicio'] || $ahora > $oferta['fecha_fin']) {
            return ['valida' => false, 'mensaje' => 'La oferta ha expirado'];
        }
        
        // Verificar usos máximos
        if ($oferta['usos_maximos'] && $oferta['usos_actuales'] >= $oferta['usos_maximos']) {
            return ['valida' => false, 'mensaje' => 'La oferta ha alcanzado el límite de usos'];
        }
        
        // Verificar monto mínimo
        if ($monto_compra < $oferta['minimo_compra']) {
            return ['valida' => false, 'mensaje' => 'El monto mínimo para esta oferta es S/ ' . number_format($oferta['minimo_compra'], 2)];
        }
        
        return ['valida' => true, 'oferta' => $oferta];
    }
}
?>