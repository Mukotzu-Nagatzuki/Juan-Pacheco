<?php
require_once 'app/config/database.php';

class Producto {
    private $conn;
    private $table = "productos";

    public function __construct($db = null) {
        if ($db) {
            $this->conn = $db;
        } else {
            $database = new Database();
            $this->conn = $database->getConnection();
        }
    }

    // Listar todos los productos (admin)
    public function obtenerTodos() {
        $query = "SELECT p.*, c.nombre AS categoria 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                  ORDER BY p.fecha_registro DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Listar todos los productos activos (para clientes)
    public function obtenerTodosActivos() {
        $query = "SELECT p.*, c.nombre AS categoria 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                  WHERE p.estado = 'activo' 
                  ORDER BY p.fecha_registro DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener productos populares
    public function obtenerPopulares($limite = 12) {
        try {
            // Esta consulta simula productos populares basados en ventas
            // En un sistema real, usarías datos reales de ventas
            $query = "SELECT p.*, c.nombre AS categoria,
                             (SELECT COUNT(*) FROM detalle_pedido dp WHERE dp.id_producto = p.id_producto) as ventas
                      FROM productos p 
                      LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                      WHERE p.estado = 'activo'
                      ORDER BY ventas DESC, p.fecha_registro DESC 
                      LIMIT ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $limite, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error al obtener productos populares: " . $e->getMessage());
            // Fallback: devolver productos recientes si hay error
            return $this->obtenerRecientes($limite);
        }
    }

    // Obtener productos por categoría
    public function obtenerPorCategoria($id_categoria) {
        $query = "SELECT p.*, c.nombre AS categoria 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                  WHERE p.id_categoria = ? AND p.estado = 'activo' 
                  ORDER BY p.fecha_registro DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id_categoria]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener productos recientes (para home)
    public function obtenerRecientes($limite = 6) {
        $query = "SELECT p.*, c.nombre AS categoria 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                  WHERE p.estado = 'activo' 
                  ORDER BY p.fecha_registro DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(1, $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener producto por ID
    public function obtenerPorId($id) {
        $query = "SELECT p.*, c.nombre AS categoria 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                  WHERE p.id_producto = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Buscar productos
    public function buscar($termino) {
        $query = "SELECT p.*, c.nombre AS categoria 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                  WHERE (p.nombre LIKE ? OR p.descripcion LIKE ? OR c.nombre LIKE ?) 
                  AND p.estado = 'activo' 
                  ORDER BY p.fecha_registro DESC";
        $stmt = $this->conn->prepare($query);
        $terminoBusqueda = "%$termino%";
        $stmt->execute([$terminoBusqueda, $terminoBusqueda, $terminoBusqueda]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Agregar producto
    public function agregar($nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $imagen, $estado) {
        $query = "INSERT INTO productos (nombre, id_categoria, precio, material, color, descripcion, medida, stock, imagen_principal, estado) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $imagen, $estado]);
    }

    // Actualizar producto - VERSIÓN MEJORADA
    public function actualizar($id, $nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $imagen, $estado) {
        try {
            // Si hay imagen (no vacía)
            if (!empty($imagen)) {
                $query = "UPDATE productos 
                          SET nombre = ?, id_categoria = ?, precio = ?, material = ?, color = ?, 
                              descripcion = ?, medida = ?, stock = ?, imagen_principal = ?, estado = ? 
                          WHERE id_producto = ?";
                $stmt = $this->conn->prepare($query);
                return $stmt->execute([$nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $imagen, $estado, $id]);
            } else {
                // Sin imagen, mantener la actual
                $query = "UPDATE productos 
                          SET nombre = ?, id_categoria = ?, precio = ?, material = ?, color = ?, 
                              descripcion = ?, medida = ?, stock = ?, estado = ? 
                          WHERE id_producto = ?";
                $stmt = $this->conn->prepare($query);
                return $stmt->execute([$nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $estado, $id]);
            }
        } catch (PDOException $e) {
            error_log("Error al actualizar producto: " . $e->getMessage());
            return false;
        }
    }

    // Eliminar producto
    public function eliminar($id) {
        $query = "DELETE FROM productos WHERE id_producto = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }
}
?>