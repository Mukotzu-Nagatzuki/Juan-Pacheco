<?php
// app/models/Pedido.php
require_once __DIR__ . '/../config/database.php';

class Pedido {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Obtener todos los pedidos de un usuario
     */
    public function obtenerPedidosUsuario($id_usuario) {
        try {
            $sql = "SELECT * FROM pedidos WHERE id_usuario = :id_usuario ORDER BY fecha_pedido DESC";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error al obtener los pedidos: " . $e->getMessage());
        }
    }

    /**
     * Obtener los detalles de un pedido específico
     */
    public function obtenerDetallePedido($id_pedido) {
        try {
            $sql = "SELECT dp.*, p.nombre AS nombre_producto, p.precio, p.imagen_principal
                    FROM detalle_pedido dp
                    INNER JOIN productos p ON dp.id_producto = p.id_producto
                    WHERE dp.id_pedido = :id_pedido";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id_pedido', $id_pedido, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error al obtener el detalle del pedido: " . $e->getMessage());
        }
    }

    /**
     * Contar cuántos productos hay en un pedido
     */
    public function contarProductosPedido($id_pedido) {
        try {
            $sql = "SELECT COUNT(*) AS total FROM detalle_pedido WHERE id_pedido = :id_pedido";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id_pedido', $id_pedido, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['total'] ?? 0;
        } catch (PDOException $e) {
            die("Error al contar los productos del pedido: " . $e->getMessage());
        }
    }

    /**
     * Crear un nuevo pedido
     */
    public function crearPedido($id_usuario, $total, $metodo_pago, $direccion_envio = null, $distrito = null, $ciudad = null, $provincia = null, $referencia = null, $order_id = null) {
        try {
            // Verificar si la tabla tiene columna order_id o numero_pedido
            $sql = "INSERT INTO pedidos (id_usuario, total, metodo_pago, direccion_envio, distrito, ciudad, provincia, referencia, estado, fecha_pedido";
            
            // Intentar agregar order_id si la columna existe
            $columns = "id_usuario, total, metodo_pago, direccion_envio, distrito, ciudad, provincia, referencia, estado, fecha_pedido";
            $values = ":id_usuario, :total, :metodo_pago, :direccion_envio, :distrito, :ciudad, :provincia, :referencia, 'pendiente', NOW()";
            
            if ($order_id) {
                // Intentar con order_id primero
                try {
                    $sql = "INSERT INTO pedidos ($columns, order_id) VALUES ($values, :order_id)";
                    $stmt = $this->conn->prepare($sql);
                    $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
                    $stmt->bindParam(':total', $total);
                    $stmt->bindParam(':metodo_pago', $metodo_pago);
                    $stmt->bindParam(':direccion_envio', $direccion_envio);
                    $stmt->bindParam(':distrito', $distrito);
                    $stmt->bindParam(':ciudad', $ciudad);
                    $stmt->bindParam(':provincia', $provincia);
                    $stmt->bindParam(':referencia', $referencia);
                    $stmt->bindParam(':order_id', $order_id);
                    $stmt->execute();
                    return $this->conn->lastInsertId();
                } catch (PDOException $e) {
                    // Si falla, intentar sin order_id
                    error_log("No se pudo insertar order_id, intentando sin él: " . $e->getMessage());
                }
            }
            
            // Versión sin order_id
            $sql = "INSERT INTO pedidos ($columns) VALUES ($values)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
            $stmt->bindParam(':total', $total);
            $stmt->bindParam(':metodo_pago', $metodo_pago);
            $stmt->bindParam(':direccion_envio', $direccion_envio);
            $stmt->bindParam(':distrito', $distrito);
            $stmt->bindParam(':ciudad', $ciudad);
            $stmt->bindParam(':provincia', $provincia);
            $stmt->bindParam(':referencia', $referencia);
            $stmt->execute();
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            error_log("Error al crear el pedido: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Agregar detalle de producto a un pedido
     */
    public function agregarDetalle($id_pedido, $id_producto, $cantidad, $precio_unitario) {
        try {
            $subtotal = $cantidad * $precio_unitario;
            $sql = "INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario, subtotal)
                    VALUES (:id_pedido, :id_producto, :cantidad, :precio_unitario, :subtotal)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id_pedido', $id_pedido, PDO::PARAM_INT);
            $stmt->bindParam(':id_producto', $id_producto, PDO::PARAM_INT);
            $stmt->bindParam(':cantidad', $cantidad);
            $stmt->bindParam(':precio_unitario', $precio_unitario);
            $stmt->bindParam(':subtotal', $subtotal);
            return $stmt->execute();
        } catch (PDOException $e) {
            die("Error al agregar detalle del pedido: " . $e->getMessage());
        }
    }
}
?>
