<?php
require_once 'app/config/database.php';

class Carrusel {
    private $conn;
    private $table = "carrusel_hero";

    public function __construct($db = null) {
        if ($db) {
            $this->conn = $db;
        } else {
            $database = new Database();
            $this->conn = $database->getConnection();
        }
    }

    // Obtener todas las imágenes del carrusel activas
    public function obtenerActivos() {
        $query = "SELECT * FROM $this->table WHERE estado = 'activo' ORDER BY orden ASC, fecha_creacion DESC LIMIT 5";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener todas las imágenes (para admin)
    public function obtenerTodos() {
        $query = "SELECT * FROM $this->table ORDER BY orden ASC, fecha_creacion DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener por ID
    public function obtenerPorId($id) {
        $query = "SELECT * FROM $this->table WHERE id_carrusel = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Agregar nueva imagen al carrusel
    public function agregar($titulo, $subtitulo, $imagen_url, $orden = 0) {
        $query = "INSERT INTO $this->table (titulo, subtitulo, imagen_url, orden) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$titulo, $subtitulo, $imagen_url, $orden]);
    }

    // Actualizar imagen del carrusel
    public function actualizar($id, $titulo, $subtitulo, $imagen_url = null, $orden = 0, $estado = 'activo') {
        if ($imagen_url) {
            $query = "UPDATE $this->table SET titulo = ?, subtitulo = ?, imagen_url = ?, orden = ?, estado = ? WHERE id_carrusel = ?";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$titulo, $subtitulo, $imagen_url, $orden, $estado, $id]);
        } else {
            $query = "UPDATE $this->table SET titulo = ?, subtitulo = ?, orden = ?, estado = ? WHERE id_carrusel = ?";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$titulo, $subtitulo, $orden, $estado, $id]);
        }
    }

    // Eliminar imagen del carrusel
    public function eliminar($id) {
        $query = "DELETE FROM $this->table WHERE id_carrusel = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    // Contar imágenes activas
    public function contarActivos() {
        $query = "SELECT COUNT(*) as total FROM $this->table WHERE estado = 'activo'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'];
    }
}
?>