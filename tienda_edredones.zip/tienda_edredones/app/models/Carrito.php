<?php
require_once 'app/config/database.php';

class Carrito {
    private $conn;
    private $table = "carrito";

    public function __construct($db = null) {
        if ($db) {
            $this->conn = $db;
        } else {
            $database = new Database();
            $this->conn = $database->getConnection();
        }
    }

    /* ==========================================================
       AGREGAR PRODUCTO AL CARRITO
    ========================================================== */
    public function agregar($id_usuario, $id_producto, $cantidad = 1) {
        try {
            // Verificar stock disponible
            $stock = $this->verificarStock($id_producto, $cantidad);
            if (!$stock['disponible']) {
                return false;
            }

            // Verificar si ya existe en el carrito
            $itemExistente = $this->obtenerItem($id_usuario, $id_producto);

            if ($itemExistente) {
                $nuevaCantidad = $itemExistente['cantidad'] + $cantidad;

                // Verificar stock con la nueva cantidad
                $stockNuevo = $this->verificarStock($id_producto, $nuevaCantidad);
                if (!$stockNuevo['disponible']) {
                    return false;
                }

                return $this->actualizarCantidad($id_usuario, $id_producto, $nuevaCantidad);
            } else {
                // Insertar nuevo producto sin subtotal (ya no se usa)
                $query = "INSERT INTO carrito (id_usuario, id_producto, cantidad, estado)
                          VALUES (?, ?, ?, 'activo')";
                $stmt = $this->conn->prepare($query);
                return $stmt->execute([$id_usuario, $id_producto, $cantidad]);
            }

        } catch (PDOException $e) {
            error_log("Error en agregar carrito: " . $e->getMessage());
            return false;
        }
    }

    /* ==========================================================
       OBTENER CARRITO COMPLETO
    ========================================================== */
    public function obtenerCarrito($id_usuario) {
        try {
            $query = "SELECT 
                        c.id_carrito,
                        c.id_usuario,
                        c.id_producto,
                        c.cantidad,
                        p.nombre,
                        p.descripcion,
                        p.precio,
                        p.imagen_principal,
                        p.stock,
                        p.medida,
                        p.color,
                        p.material,
                        (c.cantidad * p.precio) AS subtotal_calculado
                      FROM carrito c 
                      INNER JOIN productos p ON c.id_producto = p.id_producto
                      WHERE c.id_usuario = ? AND c.estado = 'activo'
                      ORDER BY c.fecha_agregado DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_usuario]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            error_log("Error en obtenerCarrito: " . $e->getMessage());
            return [];
        }
    }

    /* ==========================================================
       OBTENER ITEM INDIVIDUAL
    ========================================================== */
    public function obtenerItem($id_usuario, $id_producto) {
        try {
            $query = "SELECT * FROM carrito 
                      WHERE id_usuario = ? AND id_producto = ? AND estado = 'activo'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_usuario, $id_producto]);
            return $stmt->fetch(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            error_log("Error en obtenerItem: " . $e->getMessage());
            return false;
        }
    }

    /* ==========================================================
       ACTUALIZAR CANTIDAD DE PRODUCTO
    ========================================================== */
    public function actualizarCantidad($id_usuario, $id_producto, $cantidad) {
        try {
            if ($cantidad <= 0) {
                return $this->eliminar($id_usuario, $id_producto);
            }

            // Verificar stock
            $stock = $this->verificarStock($id_producto, $cantidad);
            if (!$stock['disponible']) {
                return false;
            }

            $query = "UPDATE carrito 
                      SET cantidad = ?
                      WHERE id_usuario = ? AND id_producto = ? AND estado = 'activo'";

            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$cantidad, $id_usuario, $id_producto]);

        } catch (PDOException $e) {
            error_log("Error en actualizarCantidad: " . $e->getMessage());
            return false;
        }
    }

    /* ==========================================================
       ELIMINAR PRODUCTO DEL CARRITO
    ========================================================== */
    public function eliminar($id_usuario, $id_producto) {
        try {
            $query = "DELETE FROM carrito 
                      WHERE id_usuario = ? AND id_producto = ? AND estado = 'activo'";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$id_usuario, $id_producto]);

        } catch (PDOException $e) {
            error_log("Error en eliminar carrito: " . $e->getMessage());
            return false;
        }
    }

    /* ==========================================================
       VACIAR CARRITO COMPLETO
    ========================================================== */
    public function vaciar($id_usuario) {
        try {
            $query = "DELETE FROM carrito WHERE id_usuario = ? AND estado = 'activo'";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$id_usuario]);

        } catch (PDOException $e) {
            error_log("Error en vaciar carrito: " . $e->getMessage());
            return false;
        }
    }

    /* ==========================================================
       TOTAL DEL CARRITO (DINÁMICO, SIN SUBTOTAL EN BD)
    ========================================================== */
    public function obtenerTotal($id_usuario) {
        try {
            $query = "SELECT SUM(c.cantidad * p.precio) AS total
                      FROM carrito c
                      INNER JOIN productos p ON c.id_producto = p.id_producto
                      WHERE c.id_usuario = ? AND c.estado = 'activo'";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_usuario]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            return floatval($result['total'] ?? 0);

        } catch (PDOException $e) {
            error_log("Error en obtenerTotal: " . $e->getMessage());
            return 0;
        }
    }

    /* ==========================================================
       CANTIDAD TOTAL DE ITEMS
    ========================================================== */
    public function obtenerCantidadItems($id_usuario) {
        try {
            $query = "SELECT SUM(cantidad) AS total_items 
                      FROM carrito 
                      WHERE id_usuario = ? AND estado = 'activo'";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_usuario]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            return intval($result['total_items'] ?? 0);

        } catch (PDOException $e) {
            error_log("Error en obtenerCantidadItems: " . $e->getMessage());
            return 0;
        }
    }

    /* ==========================================================
       OBTENER PRECIO REAL DEL PRODUCTO
    ========================================================== */
    private function obtenerPrecioProducto($id_producto) {
        try {
            $query = "SELECT precio FROM productos 
                      WHERE id_producto = ? AND estado = 'activo'";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_producto]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            return $result ? floatval($result['precio']) : false;

        } catch (PDOException $e) {
            error_log("Error en obtenerPrecioProducto: " . $e->getMessage());
            return false;
        }
    }

    /* ==========================================================
       VERIFICAR STOCK
    ========================================================== */
    private function verificarStock($id_producto, $cantidad) {
        try {
            $query = "SELECT stock, nombre 
                      FROM productos 
                      WHERE id_producto = ? AND estado = 'activo'";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_producto]);
            $producto = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$producto) {
                return ['disponible' => false, 'mensaje' => 'Producto no encontrado'];
            }

            if ($producto['stock'] < $cantidad) {
                return [
                    'disponible' => false,
                    'mensaje' => 'Stock insuficiente. Solo quedan ' . 
                                $producto['stock'] . ' unidades de ' . 
                                $producto['nombre']
                ];
            }

            return ['disponible' => true, 'stock' => $producto['stock']];

        } catch (PDOException $e) {
            error_log("Error en verificarStock: " . $e->getMessage());
            return ['disponible' => false, 'mensaje' => 'Error al verificar stock'];
        }
    }

    /* ==========================================================
       MARCAR COMO COMPRADOS
    ========================================================== */
    public function marcarComoComprados($id_usuario, $id_pedido) {
        try {
            $query = "UPDATE carrito 
                      SET estado = 'comprado' 
                      WHERE id_usuario = ? AND estado = 'activo'";

            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$id_usuario]);

        } catch (PDOException $e) {
            error_log("Error en marcarComoComprados: " . $e->getMessage());
            return false;
        }
    }
        /* ==========================================================
       ACTUALIZAR STOCK DESPUÉS DE PAGO
    ========================================================== */
    public function actualizarStockDespuesPago($id_usuario) {
        try {
            // Obtener todos los productos del carrito
            $query = "SELECT c.id_producto, c.cantidad, p.stock 
                      FROM carrito c 
                      INNER JOIN productos p ON c.id_producto = p.id_producto
                      WHERE c.id_usuario = ? AND c.estado = 'activo'";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id_usuario]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Actualizar stock de cada producto
            foreach ($items as $item) {
                $nuevo_stock = $item['stock'] - $item['cantidad'];
                $updateQuery = "UPDATE productos SET stock = ? WHERE id_producto = ?";
                $updateStmt = $this->conn->prepare($updateQuery);
                $updateStmt->execute([$nuevo_stock, $item['id_producto']]);
            }
            
            return true;
            
        } catch (PDOException $e) {
            error_log("Error en actualizarStockDespuesPago: " . $e->getMessage());
            return false;
        }
    }
}
?>
