<?php
require_once 'app/config/database.php';

class ListaDeseos {
    private $conn;
    private $table = "lista_deseos";

    public function __construct($db = null) {
        if ($db) {
            $this->conn = $db;
        } else {
            $database = new Database();
            $this->conn = $database->getConnection();
        }
    }

    // Agregar producto a lista de deseos
    public function agregar($id_usuario, $id_producto) {
        // Verificar si ya existe en la lista
        $query = "SELECT * FROM $this->table WHERE id_usuario = ? AND id_producto = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id_usuario, $id_producto]);
        
        if ($stmt->rowCount() > 0) {
            return false; // Ya existe en la lista
        }

        // Agregar a la lista
        $query = "INSERT INTO $this->table (id_usuario, id_producto, fecha_agregado) VALUES (?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id_usuario, $id_producto]);
    }

    // Eliminar producto de lista de deseos
    public function eliminar($id_usuario, $id_producto) {
        $query = "DELETE FROM $this->table WHERE id_usuario = ? AND id_producto = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id_usuario, $id_producto]);
    }

    // Verificar si producto está en lista de deseos
    public function estaEnLista($id_usuario, $id_producto) {
        $query = "SELECT * FROM $this->table WHERE id_usuario = ? AND id_producto = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id_usuario, $id_producto]);
        return $stmt->rowCount() > 0;
    }

    // Obtener lista de deseos del usuario
    public function obtenerPorUsuario($id_usuario) {
        $query = "SELECT ld.*, p.nombre, p.precio, p.imagen_principal, p.descripcion, 
                         p.material, p.color, p.medida, c.nombre as categoria_nombre
                  FROM $this->table ld
                  INNER JOIN productos p ON ld.id_producto = p.id_producto
                  LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                  WHERE ld.id_usuario = ? AND p.estado = 'activo'
                  ORDER BY ld.fecha_agregado DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Contar productos en lista de deseos
    public function contarPorUsuario($id_usuario) {
        $query = "SELECT COUNT(*) as total FROM $this->table WHERE id_usuario = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id_usuario]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }
}
?>