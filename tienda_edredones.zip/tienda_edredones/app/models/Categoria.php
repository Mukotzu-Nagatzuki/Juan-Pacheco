<?php
// app/models/Categoria.php
require_once 'app/config/database.php';

class Categoria {
    private $conn;
    private $table = "categorias";

    public function __construct($db = null) {
        if ($db) {
            $this->conn = $db;
        } else {
            $database = new Database();
            $this->conn = $database->getConnection();
        }
    }

    // Obtener todas las categorías activas
    public function obtenerTodasActivas() {
        $query = "SELECT * FROM $this->table WHERE estado = 'activo' ORDER BY nombre ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener categoría por ID
    public function obtenerPorId($id) {
        $query = "SELECT * FROM $this->table WHERE id_categoria = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Obtener todas las categorías (incluyendo inactivas)
    public function obtenerTodos() {
        $query = "SELECT * FROM $this->table ORDER BY nombre ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Agregar nueva categoría
    public function agregar($nombre, $descripcion = null, $slug = null) {
        $query = "INSERT INTO $this->table (nombre, descripcion, slug) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        
        if (!$slug) {
            $slug = $this->generarSlug($nombre);
        }
        
        return $stmt->execute([$nombre, $descripcion, $slug]);
    }

    // Actualizar categoría
    public function actualizar($id, $nombre, $descripcion = null, $slug = null, $estado = 'activo') {
        $query = "UPDATE $this->table SET nombre = ?, descripcion = ?, slug = ?, estado = ? WHERE id_categoria = ?";
        $stmt = $this->conn->prepare($query);
        
        if (!$slug) {
            $slug = $this->generarSlug($nombre);
        }
        
        return $stmt->execute([$nombre, $descripcion, $slug, $estado, $id]);
    }

    // Eliminar categoría (cambiar estado a inactivo)
    public function eliminar($id) {
        $query = "UPDATE $this->table SET estado = 'inactivo' WHERE id_categoria = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    // Generar slug automáticamente
    private function generarSlug($texto) {
        // Reemplazar espacios y caracteres especiales
        $slug = strtolower(trim($texto));
        $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        return $slug;
    }
}
?>