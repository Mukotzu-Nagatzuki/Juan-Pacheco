<?php
require_once 'app/config/database.php';

class Usuario {
    private $conn;
    private $table = 'usuarios';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // 🧩 Registrar nuevo usuario CON TODOS LOS CAMPOS
    public function registrar($nombre, $apellido, $correo, $clave, $telefono = null, $direccion = null, $rol = 'cliente') {
        try {
            $sql = "INSERT INTO {$this->table} (nombre, apellido, correo, clave, telefono, direccion, rol) 
                    VALUES (:nombre, :apellido, :correo, :clave, :telefono, :direccion, :rol)";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':apellido', $apellido);
            $stmt->bindParam(':correo', $correo);
            $stmt->bindParam(':clave', $clave); // Esta ya debe venir hasheada del controlador
            $stmt->bindParam(':telefono', $telefono);
            $stmt->bindParam(':direccion', $direccion);
            $stmt->bindParam(':rol', $rol);

            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Error al registrar usuario: " . $e->getMessage());
            return false;
        }
    }

    // 🔍 Buscar usuario por correo
    public function obtenerPorCorreo($correo) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE correo = :correo LIMIT 1";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':correo', $correo);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error al obtener usuario por correo: " . $e->getMessage());
            return null;
        }
    }

    // 🔎 Obtener usuario por ID
    public function obtenerPorId($id_usuario) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE id_usuario = :id LIMIT 1";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id', $id_usuario);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error al obtener usuario por ID: " . $e->getMessage());
            return null;
        }
    }

    // 🚫 Verificar si el correo ya existe
    public function existeCorreo($correo) {
        try {
            $sql = "SELECT COUNT(*) FROM {$this->table} WHERE correo = :correo";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':correo', $correo);
            $stmt->execute();
            $count = $stmt->fetchColumn();

            return $count > 0;
        } catch (PDOException $e) {
            error_log("Error al verificar correo: " . $e->getMessage());
            return false;
        }
    }
}
?>