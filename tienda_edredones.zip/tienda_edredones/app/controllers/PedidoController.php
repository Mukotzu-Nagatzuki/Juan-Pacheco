<?php
// app/controllers/PedidoController.php

require_once 'app/models/Pedido.php';
require_once 'app/models/Carrito.php';
require_once 'app/config/database.php';

class PedidoController
{
    private $db;
    private $pedido;
    private $carrito;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        $database = new Database();
        $this->db = $database->getConnection();
        $this->pedido = new Pedido();
        $this->carrito = new Carrito($this->db);
    }

    /**
     * Mostrar la página de checkout
     */
    public function mostrarCheckout()
    {
        if (!isset($_SESSION['usuario_id'])) {
            $_SESSION['error'] = "Debe iniciar sesión para realizar un pedido.";
            header('Location: index.php?action=login');
            exit;
        }

        $id_usuario = $_SESSION['usuario_id'];
        $items = $this->carrito->obtenerCarrito($id_usuario);
        $total = $this->carrito->obtenerTotal($id_usuario);

        if (empty($items)) {
            $_SESSION['error'] = "Su carrito está vacío.";
            header('Location: index.php?action=carrito');
            exit;
        }

        include 'app/views/carrito/checkout.php';
    }

    /**
     * Procesar un pedido (para otros métodos de pago o validación previa)
     */
    public function procesarPedido()
    {
        // Esta función puede usarse para validar datos antes de ir a la pasarela
        // o para métodos de pago manuales (transferencia, etc.)
        echo json_encode(['success' => true, 'message' => 'Pedido en proceso']);
    }

    /**
     * Ver lista de pedidos del usuario
     */
    public function misPedidos()
    {
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=login');
            exit;
        }

        $id_usuario = $_SESSION['usuario_id'];
        $pedidos = $this->pedido->obtenerPedidosUsuario($id_usuario);

        include 'app/views/usuarios/pedido.php';
    }
}
