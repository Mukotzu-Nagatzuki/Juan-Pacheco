<?php

class ChatbotController {
    
    private $apiKey = 'knHBIB9oQgSuWm9ZKRhq4MVTCYhNJjg0XaqjPn2u0f8';
    private $apiUrl = 'https://api.poe.com/bot/fetch_chat';
    
    public function procesarMensaje() {
        // Headers para CORS
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['reply' => 'Método no permitido']);
            return;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $userMessage = $input['message'] ?? '';
        
        if (empty($userMessage)) {
            echo json_encode(['reply' => 'No recibí ningún mensaje.']);
            return;
        }
        
        try {
            // Intentar con la API de Poe primero
            $response = $this->enviarAPoe($userMessage);
            echo json_encode(['reply' => $response]);
        } catch (Exception $e) {
            // Fallback a respuestas inteligentes
            error_log("Error en chatbot: " . $e->getMessage());
            $fallbackResponse = $this->generarRespuestaInteligente($userMessage);
            echo json_encode(['reply' => $fallbackResponse]);
        }
    }
    
    private function enviarAPoe($mensaje) {
        // Para Poe real, necesitamos un enfoque diferente
        // Intentemos con un enfoque más directo
        
        $data = [
            'message' => $mensaje,
            'bot' => 'assistant', // O el bot específico que quieras usar
            'context' => $this->getSystemPrompt()
        ];
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey,
                'User-Agent: DreamHouse-Chatbot/1.0'
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception('Error de conexión: ' . $error);
        }
        
        if ($httpCode !== 200) {
            // Si falla la API de Poe, usar OpenAI directamente como fallback
            return $this->usarOpenAIFallback($mensaje);
        }
        
        $responseData = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error decodificando JSON: ' . json_last_error_msg());
        }
        
        if (isset($responseData['response'])) {
            return $responseData['response'];
        } else {
            // Fallback a OpenAI
            return $this->usarOpenAIFallback($mensaje);
        }
    }
    
    private function usarOpenAIFallback($mensaje) {
        // Usar OpenAI directamente como fallback
        $openai_key = 'sk-tu-api-key-de-openai-aqui'; // Necesitarás una API key de OpenAI
        
        $data = [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => $this->getSystemPrompt()
                ],
                [
                    'role' => 'user',
                    'content' => $mensaje
                ]
            ],
            'max_tokens' => 500,
            'temperature' => 0.7
        ];
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => 'https://api.openai.com/v1/chat/completions',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $openai_key
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $responseData = json_decode($response, true);
            return $responseData['choices'][0]['message']['content'];
        }
        
        throw new Exception('No se pudo conectar con ningún servicio de IA');
    }
    
    private function getSystemPrompt() {
        return "Eres 'Asistente Dream', el chatbot oficial de Dream House - Tienda Virtual de Edredones con sede en Perú.

INFORMACIÓN ESPECÍFICA DE DREAM HOUSE (según el manual):

**SOBRE LA EMPRESA:**
- Nombre: Dream House
- Eslogan: 'Transformamos hogares en santuarios de descanso'
- Productos principales: Edredones, sábanas, cubrecamas, fundas, almohadas
- Ubicación: Perú
- Moneda: Soles (S/)

**CATÁLOGO DE PRODUCTOS:**
- Tamaños disponibles: 1.5 plazas, 2 plazas, 2.5 plazas, 3 plazas
- Materiales: Algodón egipcio, microfibra, pluma de ganso, seda
- Precios: Desde S/50 (básico) hasta S/250 (premium)

**PROCESO DE COMPRA:**
1. Cliente explora catálogo
2. Agrega productos al carrito
3. Aplica cupones de descuento (VERANO25, etc.)
4. Finaliza compra
5. Envío en 24-48 horas

**ESTADOS DE PEDIDO:**
- Pendiente → Confirmado → En Preparación → En Reparto → Entregado
- También: Cancelado, Devuelto

**MÉTODOS DE PAGO:**
- Efectivo, Yape, Plin, Transferencia, Tarjeta, Contra Entrega

**PANEL ADMINISTRADOR:**
- Gestión de productos, pedidos, clientes, ofertas
- Reportes y estadísticas
- Configuración del sitio web

**OFERTAS Y CUPONES:**
- Tipos: Porcentaje (%) o Monto Fijo
- Ejemplos: VERANO25, DREAMHOUSE15
- Configuración: Fechas de vigencia, límite de usos, monto mínimo

INSTRUCCIONES DE RESPUESTA:
- Sé extremadamente específico con información del manual
- Usa datos exactos: precios, tamaños, procesos
- Para preguntas técnicas, explica paso a paso según el manual
- Mantén un tono amable pero profesional
- Usa emojis relevantes ocasionalmente
- Si no sabes algo, di 'Según el manual de Dream House, no tengo información sobre eso. Te recomiendo contactar al administrador.'

NO inventes información fuera del manual proporcionado.

Ejemplo de respuestas correctas:
- 'Los edredones de microfibra cuestan entre S/50 y S/80 según el manual'
- 'Para agregar un producto ve a Catálogo → Haz clic en el producto → Agregar al carrito'
- 'Los estados de pedido son: Pendiente, Confirmado, En Preparación, En Reparto, Entregado'";
    }
    
    private function generarRespuestaInteligente($mensaje) {
        // Respuestas mejoradas basadas específicamente en el manual
        $mensaje = strtolower(trim($mensaje));
        
        // Respuestas específicas del manual
        if (preg_match('/hola|buenas|saludos|hello|hi/', $mensaje)) {
            return "¡Hola! 🏠 Soy **Asistente Dream** de **Dream House** - Tu tienda virtual de edredones premium.\n\n*Transformamos hogares en santuarios de descanso*\n\n¿En qué puedo ayudarte hoy?\n\n• 🛏️ **Catálogo**: Edredones 1.5, 2, 2.5, 3 plazas\n• 🛒 **Compras**: Proceso fácil y seguro\n• 📦 **Pedidos**: Seguimiento en tiempo real\n• 🎁 **Ofertas**: Cupones VERANO25, etc.\n• 👨‍💼 **Admin**: Gestión completa del sistema";
        }
        
        if (preg_match('/precio|coste|valor|cuánto cuesta|s\/|sol/', $mensaje)) {
            return "💰 **Precios Dream House** (según manual):\n\n🛏️ **EDREDONES:**\n• **Microfibra**: S/ 50 - S/ 80\n• **Algodón Egipcio**: S/ 80 - S/ 150  \n• **Pluma de Ganso**: S/ 150 - S/ 250\n• **Seda Natural**: S/ 180 - S/ 300\n\n🛏️ **SÁBANAS Y ACCESORIOS:**\n• Sábanas Microfibra: S/ 50\n• Fundas y complementos: S/ 30 - S/ 80\n\n¿Te interesa algún material en particular?";
        }
        
        if (preg_match('/tamaño|medida|plaza|individual|doble|queen|king/', $mensaje)) {
            return "📏 **Guía de Tamaños Dream House**:\n\n• **1.5 Plazas** (Individual): 90x190 cm\n• **2 Plazas** (Doble): 135x190 cm  \n• **2.5 Plazas** (Queen): 160x200 cm\n• **3 Plazas** (King): 200x200 cm\n\nCada edredón muestra su tamaño específico en el catálogo. ¿Para qué tipo de cama necesitas?";
        }
        
        if (preg_match('/material|algodón|microfibra|pluma|seda/', $mensaje)) {
            return "🧵 **Materiales Dream House**:\n\n🌿 **ALGODÓN EGIPCIO**\n• Suavidad premium • Transpirable • Pieles sensibles\n• Precio: S/ 80 - S/ 150\n\n🐑 **MICROFIBRA** \n• Hipoalergénico • Fácil cuidado • No necesita planchado\n• Precio: S/ 50 - S/ 80\n\n🦢 **PLUMA DE GANSO**\n• Máximo calor • Ligereza • Aislante natural\n• Precio: S/ 150 - S/ 250\n\n🪡 **SEDA NATURAL**\n• Lujo supremo • Regula temperatura • Pieles muy sensibles\n• Precio: S/ 180 - S/ 300\n\n¿Cuál te interesa conocer más?";
        }
        
        if (preg_match('/comprar|carrito|agregar|pedido|compra/', $mensaje)) {
            return "🛒 **Proceso de Compra - Dream House**\n\n**PASO A PASO:**\n1. 📋 **Explorar Catálogo**: Ve a 'Volver a la Tienda'\n2. 🔍 **Buscar**: Usa barra de búsqueda o filtros\n3. ➕ **Agregar**: Haz clic en 'Agregar al carrito'\n4. 🛒 **Ver Carrito**: Icono superior derecho\n5. 🔢 **Cantidades**: Modifica si es necesario\n6. 🏷️ **Cupones**: Aplica descuentos (VERANO25)\n7. ✅ **Continuar**: Haz clic en 'Continuar con la compra'\n8. 📝 **Datos**: Completa dirección y contacto\n9. 💳 **Pago**: Elige método (Efectivo, Yape, etc.)\n10. 🚀 **Confirmación**: ¡Pedido realizado!\n\n⏱️ **Envío**: 24-48 horas hábiles";
        }
        
        if (preg_match('/estado|pedido|seguimiento|dónde está/', $mensaje)) {
            return "📦 **Estados de Pedido Dream House**:\n\n🕒 **PENDIENTE** - Pedido recibido\n✅ **CONFIRMADO** - Verificado y confirmado  \n📦 **EN PREPARACIÓN** - Productos siendo preparados\n🚚 **EN REPARTO** - En camino al cliente\n🏠 **ENTREGADO** - Completado exitosamente\n❌ **CANCELADO** - Pedido anulado\n🔄 **DEVUELTO** - Productos devueltos\n\n**Para ver tu pedido:**\nClientes: Mi Perfil → Mis Pedidos\nAdministradores: Gestión de Pedidos";
        }
        
        if (preg_match('/cupón|descuento|oferta|promoción|código/', $mensaje)) {
            return "🎁 **Sistema de Ofertas Dream House**:\n\n**TIPOS DE DESCUENTO:**\n• **Porcentaje**: 10%, 20%, 25% sobre el total\n• **Monto Fijo**: S/ 15, S/ 25, S/ 50 descuento directo\n\n**CUPONES EJEMPLO:**\n• VERANO25 - 25% de descuento\n• DREAMHOUSE15 - S/ 15 de descuento\n\n**CONFIGURACIÓN ADMIN:**\n• Fechas de vigencia\n• Límite de usos (ej: 100 clientes)\n• Monto mínimo de compra\n• Aplicar a todo el catálogo\n\n¿Tienes un cupón para aplicar?";
        }
        
        if (preg_match('/administrador|admin|dashboard|panel/', $mensaje)) {
            return "👨‍💼 **Panel Administrador Dream House**:\n\n**MÓDULOS DISPONIBLES:**\n\n📊 **DASHBOARD**\n• Resumen ventas del día\n• Pedidos pendientes\n• Nuevos clientes (últimos 7 días)\n• Ofertas activas\n\n📦 **GESTIÓN DE PRODUCTOS**\n• Agregar nuevos edredones\n• Editar productos existentes  \n• Control de stock e imágenes\n• Estado Activo/Inactivo\n\n🛒 **GESTIÓN DE PEDIDOS**\n• Ver todos los pedidos\n• Cambiar estados\n• Filtrar por fecha\n• Registrar pagos\n\n👥 **GESTIÓN DE CLIENTES**\n• Base de datos completa\n• Historial de compras\n• Actualizar datos\n\n🎁 **GESTIÓN DE OFERTAS**\n• Crear cupones descuento\n• Activar/desactivar promociones\n• Ver estadísticas de uso\n\n📈 **REPORTES**\n• Ventas por fecha\n• Productos más vendidos\n• Métodos de pago utilizados\n• Arqueo de caja\n\n⚙️ **CONFIGURACIÓN**\n• Carrusel de imágenes (máx. 5)\n• Información de la tienda\n• Logo y redes sociales\n\n¿Necesitas ayuda con algún módulo específico?";
        }
        
        if (preg_match('/contacto|ubicación|teléfono|email|correo|dirección/', $mensaje)) {
            return "📞 **Contacto Dream House**:\n\n**INFORMACIÓN OFICIAL:**\n• 📧 Email: admin@tienda.com\n• 📞 Teléfono: [Disponible en sistema]\n• 📍 Dirección: [Configurar en panel admin]\n• ⏰ Horario: Lunes a Viernes 9am - 6pm\n\n**REDES SOCIALES:**\n• Configurables en: Configuración → Footer\n• Facebook, TikTok, WhatsApp, Instagram, YouTube\n\n**PARA ADMINISTRADORES:**\nPuedes configurar esta información en:\nConfiguración → Información de la Tienda";
        }
        
        if (preg_match('/carrusel|imagen|slide|banner/', $mensaje)) {
            return "🖼️ **Carrusel Dream House - Configuración**:\n\n**LÍMITES:**\n• Máximo 5 imágenes activas\n• Formatos: JPG, PNG, GIF, WEBP  \n• Tamaño máximo: 5MB\n• Recomendado: 1920x1080px\n\n**CONFIGURACIÓN POR IMAGEN:**\n• Título principal\n• Subtítulo descriptivo  \n• Orden de visualización\n• Estado Activo/Inactivo\n\n**ACCESO:**\nConfiguración → Carrusel de Imágenes";
        }
        
        // Respuesta por defecto mejorada
        return "¡Hola! 🤔 Como **Asistente Dream** especializado en Dream House, puedo ayudarte con información específica de nuestro sistema:\n\n🔹 **INFORMACIÓN PRECISA DEL MANUAL**\n• Precios exactos y materiales\n• Procesos de compra paso a paso\n• Gestión de pedidos y estados\n• Configuración para administradores\n\n🔹 **CATÁLOGO COMPLETO** \n• Tamaños: 1.5, 2, 2.5, 3 plazas\n• Materiales: Microfibra, Algodón, Pluma, Seda\n• Precios: S/50 - S/300\n\n🔹 **GESTIÓN AVANZADA**\n• Panel administrador completo\n• Sistema de ofertas y cupones\n• Reportes y estadísticas\n• Configuración del sitio\n\n¿Qué información específica necesitas? 😊";
    }
}