<?php
require_once 'app/config/database.php';
require_once 'app/models/Carrusel.php';

class CarruselController {
    private $db;
    private $carrusel;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->carrusel = new Carrusel($this->db);
    }

    // Mostrar configuración del carrusel (admin)
    public function configuracionCarrusel() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        $imagenes = $this->carrusel->obtenerTodos();
        include 'app/views/admin/configuracion_carrusel.php';
    }

    // Agregar nueva imagen al carrusel
    public function agregarImagen() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titulo = $_POST['titulo'] ?? '';
            $subtitulo = $_POST['subtitulo'] ?? '';
            $orden = $_POST['orden'] ?? 0;

            // Validar límite de imágenes
            if ($this->carrusel->contarActivos() >= 5) {
                $_SESSION['error'] = "Ya has alcanzado el límite máximo de 5 imágenes en el carrusel";
                header('Location: index.php?action=configuracion-carrusel');
                exit;
            }

            // Procesar imagen
            if (!empty($_FILES['imagen']['name'])) {
                try {
                    $nombreArchivo = $this->procesarImagen($_FILES['imagen']);
                    
                    if ($this->carrusel->agregar($titulo, $subtitulo, $nombreArchivo, $orden)) {
                        $_SESSION['mensaje'] = "Imagen agregada correctamente al carrusel";
                    } else {
                        $_SESSION['error'] = "Error al agregar la imagen";
                    }
                } catch (Exception $e) {
                    $_SESSION['error'] = $e->getMessage();
                }
            } else {
                $_SESSION['error'] = "Debes seleccionar una imagen";
            }

            header('Location: index.php?action=configuracion-carrusel');
            exit;
        }
    }

    // Editar imagen del carrusel
    public function editarImagen() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        if (!isset($_GET['id'])) {
            header("Location: index.php?action=configuracion-carrusel");
            exit;
        }

        $id = $_GET['id'];
        $imagen = $this->carrusel->obtenerPorId($id);

        if (!$imagen) {
            $_SESSION['error'] = "❌ Imagen no encontrada";
            header("Location: index.php?action=configuracion-carrusel");
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titulo = $_POST['titulo'] ?? '';
            $subtitulo = $_POST['subtitulo'] ?? '';
            $orden = $_POST['orden'] ?? 0;
            $estado = $_POST['estado'] ?? 'activo';

            // Procesar nueva imagen si se subió
            $nombreArchivo = null;
            if (!empty($_FILES['imagen']['name'])) {
                try {
                    $nombreArchivo = $this->procesarImagen($_FILES['imagen']);
                    // Eliminar imagen anterior
                    $this->eliminarArchivoImagen($imagen['imagen_url']);
                } catch (Exception $e) {
                    $_SESSION['error'] = $e->getMessage();
                    header("Location: index.php?action=editar-imagen-carrusel&id=" . $id);
                    exit;
                }
            }

            if ($this->carrusel->actualizar($id, $titulo, $subtitulo, $nombreArchivo, $orden, $estado)) {
                $_SESSION['mensaje'] = "Imagen actualizada correctamente";
            } else {
                $_SESSION['error'] = "Error al actualizar la imagen";
            }

            header('Location: index.php?action=configuracion-carrusel');
            exit;
        }

        include 'app/views/admin/editar_imagen_carrusel.php';
    }

    // Eliminar imagen del carrusel - CORREGIDO (cambié el nombre)
    public function eliminarImagenCarrusel() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $imagen = $this->carrusel->obtenerPorId($id);

            if ($imagen) {
                // Eliminar archivo de imagen
                $this->eliminarArchivoImagen($imagen['imagen_url']);
                
                if ($this->carrusel->eliminar($id)) {
                    $_SESSION['mensaje'] = "Imagen eliminada correctamente";
                } else {
                    $_SESSION['error'] = "Error al eliminar la imagen";
                }
            } else {
                $_SESSION['error'] = "Imagen no encontrada";
            }
        }

        header('Location: index.php?action=configuracion-carrusel');
        exit;
    }

    // Función para procesar imágenes
    private function procesarImagen($archivo) {
        $directorio = "public/img/carrusel/";
        
        // Crear directorio si no existe
        if (!is_dir($directorio)) {
            mkdir($directorio, 0755, true);
        }

        $nombreArchivo = time() . '_' . uniqid() . '_' . basename($archivo['name']);
        $rutaDestino = $directorio . $nombreArchivo;

        // Validar tipo de archivo
        $tipoPermitido = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
        
        if (!in_array($extension, $tipoPermitido)) {
            throw new Exception("Tipo de archivo no permitido. Solo se permiten: " . implode(', ', $tipoPermitido));
        }

        // Validar tamaño (máximo 5MB)
        if ($archivo['size'] > 5 * 1024 * 1024) {
            throw new Exception("La imagen es demasiado grande. Tamaño máximo: 5MB");
        }

        // Mover archivo
        if (move_uploaded_file($archivo['tmp_name'], $rutaDestino)) {
            return $nombreArchivo;
        } else {
            throw new Exception("Error al subir la imagen. Verifique los permisos del directorio.");
        }
    }

    // Función para eliminar imagen del servidor - CORREGIDO (cambié el nombre)
    private function eliminarArchivoImagen($nombreArchivo) {
        if (!empty($nombreArchivo)) {
            $rutaArchivo = "public/img/carrusel/" . $nombreArchivo;
            if (file_exists($rutaArchivo) && is_file($rutaArchivo)) {
                unlink($rutaArchivo);
            }
        }
    }
}
?>