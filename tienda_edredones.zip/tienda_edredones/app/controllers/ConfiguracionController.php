<?php
require_once 'app/config/database.php';

class ConfiguracionController
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    // Mostrar página principal de configuración
    public function mostrarConfiguracion()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        include 'app/views/admin/configuracion.php';
    }

    // Mostrar configuración general
    public function mostrarConfiguracionGeneral()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        // Obtener todas las configuraciones
        $configuraciones = $this->obtenerConfiguraciones();

        include 'app/views/admin/configuracion_general.php';
    }

    // Guardar configuración general - ACTUALIZADO
    public function guardarConfiguracionGeneral()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // Guardar configuraciones de texto
                foreach ($_POST as $key => $value) {
                    if (strpos($key, 'config_') === 0) {
                        $clave = str_replace('config_', '', $key);
                        $this->guardarConfiguracion($clave, $value);
                    }
                }

                // Manejar subida de logo
                if (isset($_FILES['nuevo_logo']) && $_FILES['nuevo_logo']['error'] === UPLOAD_ERR_OK) {
                    $this->procesarLogo($_FILES['nuevo_logo']);
                }

                // Manejar subida de imagen de la página Nosotros - NUEVO
                if (isset($_FILES['imagen_nosotros_upload']) && $_FILES['imagen_nosotros_upload']['error'] === UPLOAD_ERR_OK) {
                    $this->procesarImagenNosotros($_FILES['imagen_nosotros_upload']);
                }

                $_SESSION['mensaje'] = 'Configuración guardada exitosamente';
            } catch (Exception $e) {
                $_SESSION['error'] = 'Error al guardar la configuración: ' . $e->getMessage();
            }

            header('Location: index.php?action=configuracion-general');
            exit;
        }
    }

    // Métodos auxiliares para manejar configuraciones
    public function obtenerConfiguraciones()
    {
        $query = "SELECT clave, valor, tipo FROM configuraciones_sitio";
        $stmt = $this->db->prepare($query);
        $stmt->execute();

        $configuraciones = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $configuraciones[$row['clave']] = $row['valor'];
        }

        return $configuraciones;
    }

    private function guardarConfiguracion($clave, $valor)
    {
        // Determinar la sección basada en la clave
        $seccion = $this->determinarSeccion($clave);

        $query = "INSERT INTO configuraciones_sitio (seccion, clave, valor, tipo) 
                  VALUES (:seccion, :clave, :valor, 'texto')
                  ON DUPLICATE KEY UPDATE valor = :valor, fecha_actualizacion = CURRENT_TIMESTAMP";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':seccion', $seccion);
        $stmt->bindParam(':clave', $clave);
        $stmt->bindParam(':valor', $valor);

        return $stmt->execute();
    }

    private function procesarLogo($archivoLogo)
    {
        $directorioDestino = 'public/img/logo/';
        $nombreArchivo = 'logoedredon.png';
        $rutaCompleta = $directorioDestino . $nombreArchivo;

        // Validar tipo de archivo
        $tiposPermitidos = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'];
        if (!in_array($archivoLogo['type'], $tiposPermitidos)) {
            throw new Exception('Tipo de archivo no permitido. Use PNG, JPG, JPEG o SVG.');
        }

        // Validar tamaño (2MB máximo)
        if ($archivoLogo['size'] > 2097152) {
            throw new Exception('El archivo es demasiado grande. Máximo 2MB.');
        }

        // Crear directorio si no existe
        if (!is_dir($directorioDestino)) {
            mkdir($directorioDestino, 0755, true);
        }

        // Mover archivo
        if (move_uploaded_file($archivoLogo['tmp_name'], $rutaCompleta)) {
            // Guardar información del logo en la base de datos
            $this->guardarConfiguracion('logo_archivo', $nombreArchivo);
            $this->guardarConfiguracion('logo_tipo', $archivoLogo['type']);
            $this->guardarConfiguracion('logo_tamaño', strval($archivoLogo['size']));
            $this->guardarConfiguracion('logo_ruta', $directorioDestino . $nombreArchivo);

            return true;
        } else {
            throw new Exception('Error al guardar el logo.');
        }
    }
    // NUEVO MÉTODO: Procesar imagen de la página Nosotros
    private function procesarImagenNosotros($archivoImagen)
    {
        $directorioDestino = 'public/img/nosotros/';

        // Nombre fijo para la imagen de nosotros
        $nombreArchivo = 'imagen_nosotros.jpg';
        $rutaCompleta = $directorioDestino . $nombreArchivo;

        // Validar tipo de archivo
        $tiposPermitidos = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
        if (!in_array($archivoImagen['type'], $tiposPermitidos)) {
            throw new Exception('Tipo de archivo no permitido. Use PNG, JPG, JPEG o WEBP.');
        }

        // Validar tamaño (3MB máximo)
        if ($archivoImagen['size'] > 3145728) {
            throw new Exception('El archivo es demasiado grande. Máximo 3MB.');
        }

        // Crear directorio si no existe
        if (!is_dir($directorioDestino)) {
            mkdir($directorioDestino, 0755, true);
        }

        // ELIMINAR IMAGEN ANTERIOR SI EXISTE
        $this->eliminarImagenAnteriorNosotros($directorioDestino);

        // Mover archivo
        if (move_uploaded_file($archivoImagen['tmp_name'], $rutaCompleta)) {
            // Guardar información de la imagen en la base de datos
            $this->guardarConfiguracion('imagen_nosotros', $rutaCompleta);
            $this->guardarConfiguracion('imagen_nosotros_archivo', $nombreArchivo);
            $this->guardarConfiguracion('imagen_nosotros_tipo', $archivoImagen['type']);
            $this->guardarConfiguracion('imagen_nosotros_tamaño', strval($archivoImagen['size']));

            return true;
        } else {
            throw new Exception('Error al guardar la imagen de la página Nosotros.');
        }
    }

    // NUEVO MÉTODO: Eliminar imagen anterior de la página Nosotros
    private function eliminarImagenAnteriorNosotros($directorio)
    {
        // Buscar y eliminar cualquier archivo de imagen en el directorio
        $patrones = [
            $directorio . 'imagen_nosotros.jpg',
            $directorio . 'imagen_nosotros.png',
            $directorio . 'imagen_nosotros.webp',
            $directorio . 'nosotros_*.jpg',
            $directorio . 'nosotros_*.png',
            $directorio . 'nosotros_*.webp'
        ];

        foreach ($patrones as $patron) {
            $archivos = glob($patron);
            foreach ($archivos as $archivo) {
                if (is_file($archivo)) {
                    unlink($archivo);
                }
            }
        }

        // También eliminar la imagen por defecto si existe
        $imagenDefault = $directorio . 'edredon3.jpg';
        if (file_exists($imagenDefault)) {
            unlink($imagenDefault);
        }
    }

    private function determinarSeccion($clave)
    {
        $secciones = [
            'logo' => 'header',
            'descripcion' => 'header',
            'logo_archivo' => 'header',
            'logo_tipo' => 'header',
            'logo_tamaño' => 'header',
            'logo_ruta' => 'header',
            'caracteristicas_titulo' => 'inicio',
            'caracteristicas_subtitulo' => 'inicio',
            'caracteristica_1_titulo' => 'inicio',
            'caracteristica_1_descripcion' => 'inicio',
            'caracteristica_2_titulo' => 'inicio',
            'caracteristica_2_descripcion' => 'inicio',
            'caracteristica_3_titulo' => 'inicio',
            'caracteristica_3_descripcion' => 'inicio',
            'caracteristica_4_titulo' => 'inicio',
            'caracteristica_4_descripcion' => 'inicio',
            'testimonios_titulo' => 'inicio',
            'testimonios_subtitulo' => 'inicio',
            'testimonio_1_texto' => 'inicio',
            'testimonio_1_autor' => 'inicio',
            'testimonio_2_texto' => 'inicio',
            'testimonio_2_autor' => 'inicio',
            'contenido_nosotros' => 'nosotros',
            'contenido_contacto' => 'contacto',
            'telefono' => 'footer',
            'descripcion_footer' => 'footer',
            'facebook_url' => 'footer',
            'tiktok_url' => 'footer',
            'instagram_url' => 'footer',
            'youtube_url' => 'footer',
            'whatsapp_url' => 'footer',
            'direccion' => 'contacto',
            'telefono_contacto' => 'contacto',
            'email_contacto' => 'contacto',
            'horario_atencion' => 'contacto',
            'titulo_nosotros' => 'nosotros',
            'subtitulo_nosotros' => 'nosotros',
            'historia_titulo' => 'nosotros',
            'historia_contenido' => 'nosotros',
            'historia_contenido_2' => 'nosotros',
            'compromiso_1' => 'nosotros',
            'compromiso_2' => 'nosotros',
            'compromiso_3' => 'nosotros',
            'compromiso_4' => 'nosotros',
            'mision_titulo' => 'nosotros',
            'mision_contenido' => 'nosotros',
            'vision_titulo' => 'nosotros',
            'vision_contenido' => 'nosotros',
            'valores_titulo' => 'nosotros',
            'valores_intro' => 'nosotros',
            'valor_1_titulo' => 'nosotros',
            'valor_1_descripcion' => 'nosotros',
            'valor_2_titulo' => 'nosotros',
            'valor_2_descripcion' => 'nosotros',
            'valor_3_titulo' => 'nosotros',
            'valor_3_descripcion' => 'nosotros',
            'valor_4_titulo' => 'nosotros',
            'valor_4_descripcion' => 'nosotros',
            'valor_5_titulo' => 'nosotros',
            'valor_5_descripcion' => 'nosotros',
            'imagen_nosotros' => 'nosotros',
            'imagen_nosotros_archivo' => 'nosotros', 
            'imagen_nosotros_tipo' => 'nosotros',    
            'imagen_nosotros_tamaño' => 'nosotros'  
        ];

        return $secciones[$clave] ?? 'general';
    }
}
?>