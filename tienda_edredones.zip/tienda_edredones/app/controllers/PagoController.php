<?php

require_once 'app/config/database.php';
require_once 'app/models/Carrito.php';

class PagoController
{
    private $apiUser;
    private $apiPassword;
    private $hmacKey;
    private $publicKeyJS;

    private $db;
    private $carrito;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();

        // CREDENCIALES DE PRODUCCIÓN - Dream House (5897120)
        $this->apiUser = "69697151";
        $this->apiPassword = "prodpassword_Hw6V4glvB9jX3nPyHZtvizuBHBJK9vA8vTchzvCUYuV27";
        $this->hmacKey = "xTLMbHQxpeIu7e5CMlf2bVrHExybP5i09IDfjlw3NTUGf";
        $this->publicKeyJS = "69697151:publickey_UxXHz1Yh5yP4zL4JFo0PqfIzis90CbBk91SSRKeNQku8E";

        $database = new Database();
        $this->db = $database->getConnection();
        $this->carrito = new Carrito($this->db);
    }

    public function crear_pago()
    {
        header('Content-Type: application/json');

        // ==================== SISTEMA DE DEPURACIÓN ====================
        $debugLog = [];
        $debugLog['timestamp'] = date('Y-m-d H:i:s');
        $debugLog['session_id'] = session_id();
        $debugLog['usuario_id'] = $_SESSION['usuario_id'] ?? 'no_logueado';
        // ===============================================================

        if (!isset($_SESSION['usuario_id'])) {
            $debugLog['error'] = 'Usuario no autenticado';
            $this->guardarDebugLog($debugLog);
            echo json_encode(['error' => 'Usuario no autenticado']);
            exit;
        }

        $items = $this->carrito->obtenerCarrito($_SESSION['usuario_id']);
        if (empty($items)) {
            $debugLog['error'] = 'Carrito vacío';
            $debugLog['items_count'] = 0;
            $this->guardarDebugLog($debugLog);
            echo json_encode(['error' => 'Carrito vacío']);
            exit;
        }

        $debugLog['items_count'] = count($items);

        // Calcular total con descuento si existe
        $subtotal = $this->carrito->obtenerTotal($_SESSION['usuario_id']);
        $descuento_aplicado = $_SESSION['descuento_aplicado'] ?? null;
        
        if ($descuento_aplicado && isset($descuento_aplicado['total_final'])) {
            $total = $descuento_aplicado['total_final'];
            $debugLog['descuento_aplicado'] = $descuento_aplicado;
        } else {
            $total = $subtotal;
        }
        
        // 🔥 CORRECCIÓN: USAR PRECIO REAL DEL PRODUCTO
        // Convertir a centavos (Izipay requiere enteros)
        $totalCentavos = intval(round($total * 100));
        
        // 🔥 IMPORTANTE: Para pruebas, puedes usar S/ 1.00
        // Descomenta la siguiente línea SOLO para pruebas
        // $totalCentavos = 100; // S/ 1.00 para pruebas
        
        $debugLog['subtotal_soles'] = $subtotal;
        $debugLog['total_soles'] = $total;
        $debugLog['total_centavos'] = $totalCentavos;
        $debugLog['test_mode'] = ($totalCentavos === 100); // Solo test si es S/ 1.00

        // Validar que el total sea mayor a 0
        if ($totalCentavos < 100) { // Mínimo S/ 1.00
            $debugLog['error'] = 'Monto mínimo no alcanzado';
            $this->guardarDebugLog($debugLog);
            echo json_encode(['error' => 'El monto mínimo para pagar es S/ 1.00. Tu total es S/' . number_format($total, 2)]);
            exit;
        }

        // Obtener dominio actual para la URL de retorno
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') || 
                    (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') 
                    ? "https" : "http";
        $dominio = $_SERVER['HTTP_HOST'];
        $dominio = rtrim($dominio, '/');
        
        // 🔥 CORRECCIÓN: Configurar URLs correctas para la redirección
        $baseUrl = $protocol . "://" . $dominio;
        $returnUrl = $baseUrl . "/index.php?action=pago_exitoso";  // URL de callback
        
        $debugLog['protocol'] = $protocol;
        $debugLog['dominio'] = $dominio;
        $debugLog['base_url'] = $baseUrl;
        $debugLog['return_url'] = $returnUrl;

        // Obtener información del usuario
        require_once 'app/models/Usuario.php';
        $usuarioModel = new Usuario();
        $usuario = $usuarioModel->obtenerPorId($_SESSION['usuario_id']);
        
        if (!$usuario) {
            $debugLog['error'] = 'Usuario no encontrado en BD';
            $this->guardarDebugLog($debugLog);
            echo json_encode(['error' => 'Error al obtener datos del usuario']);
            exit;
        }
        
        $debugLog['usuario_data'] = [
            'id' => $usuario['id_usuario'] ?? null,
            'email' => $usuario['correo'] ?? null,
            'nombre' => $usuario['nombre'] ?? null,
            'apellido' => $usuario['apellido'] ?? null,
            'telefono' => $usuario['telefono'] ?? null,
            'direccion' => $usuario['direccion'] ?? null,
            'ciudad' => $usuario['ciudad'] ?? null
        ];

        // Generar Order ID único
        $orderId = "PED-" . date('YmdHis') . "-" . $_SESSION['usuario_id'] . "-" . rand(100, 999);
        
        $debugLog['order_id_generated'] = $orderId;

        // ========== CONFIGURACIÓN OPTIMIZADA CON URLS CORRECTAS ==========
        
        // Construir payload optimizado
        $data = [
            "amount" => $totalCentavos,
            "currency" => "PEN",
            "orderId" => $orderId,
            "customer" => [
                "email" => $usuario['correo'] ?? 'cliente@dreamhouse.com',
                "reference" => (string)$_SESSION['usuario_id']
            ],
            "configuration" => [
                "returnUrl" => $returnUrl,  // 🔥 URL CORRECTA para redirección
                "paymentFormId" => "paymentForm",
                "shopName" => "Dream House Edredones",
                "cardOptions" => [
                    "captureDelay" => 0,
                    "manualValidation" => "NO",
                    "paymentSource" => "EC" // E-commerce
                ]
            ],
            "transactionOptions" => [
                "cardOptions" => [
                    "captureDelay" => 0,
                    "manualValidation" => "NO"
                ]
            ]
        ];
        
        // Agregar billingDetails COMPLETOS (obligatorio para reducir rechazos)
        $data["customer"]["billingDetails"] = [
            "firstName" => !empty($usuario['nombre']) ? $usuario['nombre'] : "Cliente",
            "lastName" => !empty($usuario['apellido']) ? $usuario['apellido'] : "DreamHouse",
            "phoneNumber" => !empty($usuario['telefono']) ? $usuario['telefono'] : "999999999",
            "address" => !empty($usuario['direccion']) ? $usuario['direccion'] : "Av. Principal 123",
            "city" => !empty($usuario['ciudad']) ? $usuario['ciudad'] : "Lima",
            "country" => "PE",
            "zipCode" => "15001" // Código postal por defecto para Lima
        ];
        
        // IMPORTANTE: Para pruebas, usar un email REAL (no genérico)
        if (strpos($data['customer']['email'], 'test') !== false || 
            strpos($data['customer']['email'], 'example') !== false) {
            $data['customer']['email'] = 'cliente_real@dreamhouse.com';
            $debugLog['email_corregido'] = 'Email genérico detectado y corregido';
        }
        
        // Agregar IP del cliente (reduce riesgo)
        $clientIp = $this->getClientIp();
        if ($clientIp && !in_array($clientIp, ['127.0.0.1', '::1'])) {
            $data['customer']['ipAddress'] = $clientIp;
            $debugLog['client_ip'] = $clientIp;
        }

        $payload = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        
        $debugLog['payload_izipay'] = $data;
        $debugLog['payload_json'] = $payload;

        $signature = base64_encode(
            hash_hmac('sha256', $payload, $this->hmacKey, true)
        );
        
        $debugLog['signature_generated'] = substr($signature, 0, 20) . '...';

        $headers = [
            "Content-Type: application/json",
            "Authorization: Basic " . base64_encode($this->apiUser . ":" . $this->apiPassword),
            "X-Signature: " . $signature,
            "User-Agent: DreamHouse-Ecommerce/1.0"
        ];
        
        $debugLog['headers_sent'] = [
            'auth_basic' => 'Basic ' . base64_encode($this->apiUser . ':***'),
            'signature' => 'X-Signature: ' . substr($signature, 0, 20) . '...'
        ];

        // URL de la API REST de producción
        $apiUrl = "https://api.micuentaweb.pe/api-payment/V4/Charge/CreatePayment";
        
        $debugLog['api_url'] = $apiUrl;

        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FAILONERROR => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        
        $debugLog['curl_info'] = [
            'http_code' => $http_code,
            'curl_error' => $curl_error,
            'curl_errno' => curl_errno($ch)
        ];

        if (curl_errno($ch)) {
            curl_close($ch);
            $debugLog['error'] = 'Error de conexión CURL';
            $this->guardarDebugLog($debugLog);
            echo json_encode([
                'error' => 'Error de conexión con la pasarela',
                'debug' => [
                    'curl_error' => $curl_error,
                    'http_code' => $http_code
                ]
            ]);
            exit;
        }

        curl_close($ch);

        $result = json_decode($response, true);
        
        $debugLog['izipay_response'] = [
            'http_code' => $http_code,
            'response_raw' => $response,
            'response_parsed' => $result
        ];

        // Log para debugging
        error_log("=== DEPURACIÓN IZIPAY CREAR_PAGO ===");
        error_log("Order ID: " . $orderId);
        error_log("Amount: S/ " . ($totalCentavos / 100));
        error_log("HTTP Code: " . $http_code);
        error_log("Response: " . $response);

        if ($http_code !== 200 || !isset($result['answer']['formToken'])) {
            $errorMsg = 'No se pudo generar el pago';
            
            // ========== DEPURACIÓN DETALLADA DE ERRORES ==========
            $debugLog['error_analysis'] = [];
            
            if (isset($result['answer']['errorMessage'])) {
                $errorMsg = $result['answer']['errorMessage'];
                $debugLog['error_analysis']['errorMessage'] = $errorMsg;
                error_log("Error Message: " . $errorMsg);
            }
            
            if (isset($result['answer']['errors']) && is_array($result['answer']['errors'])) {
                $debugLog['error_analysis']['errors'] = $result['answer']['errors'];
                foreach ($result['answer']['errors'] as $index => $error) {
                    error_log("Error {$index}: " . json_encode($error));
                    if (isset($error['message'])) {
                        $errorMsg .= " | " . $error['message'];
                    }
                }
            }
            
            if (isset($result['message'])) {
                $errorMsg = $result['message'];
                $debugLog['error_analysis']['message'] = $errorMsg;
            }
            
            // Buscar código de error específico
            $errorCode = null;
            if (isset($result['kr-answer'])) {
                $krAnswer = json_decode($result['kr-answer'], true);
                if ($krAnswer && isset($krAnswer['errorCode'])) {
                    $errorCode = $krAnswer['errorCode'];
                    $errorMsg .= " [Código: {$errorCode}]";
                    $debugLog['error_analysis']['errorCode'] = $errorCode;
                    error_log("Código de error Izipay: " . $errorCode);
                }
            }
            
            if (isset($result['answer']['errorCode'])) {
                $errorCode = $result['answer']['errorCode'];
                $errorMsg .= " [Código: {$errorCode}]";
                $debugLog['error_analysis']['errorCode'] = $errorCode;
                error_log("Código de error (answer): " . $errorCode);
            }
            
            // Interpretación de códigos comunes
            if ($errorCode) {
                $errorInterpretation = $this->interpretarCodigoError($errorCode);
                if ($errorInterpretation) {
                    $errorMsg .= " - " . $errorInterpretation;
                    $debugLog['error_analysis']['interpretation'] = $errorInterpretation;
                }
            }
            
            error_log("=== FIN DEPURACIÓN ===");
            
            $debugLog['final_error'] = $errorMsg;
            $this->guardarDebugLog($debugLog);
            
            echo json_encode([
                'error' => $errorMsg,
                'http_code' => $http_code,
                'response' => $result,
                'debug_summary' => [
                    'order_id' => $orderId,
                    'amount_soles' => $totalCentavos / 100,
                    'error_code' => $errorCode ?? 'N/A',
                    'suggestion' => $this->getSuggestionForError($errorCode)
                ]
            ]);
            exit;
        }

        // Éxito - devolver formToken
        $debugLog['success'] = true;
        $debugLog['formToken_received'] = substr($result['answer']['formToken'], 0, 20) . '...';
        $this->guardarDebugLog($debugLog);
        
        echo json_encode([
            'success' => true,
            'formToken' => $result['answer']['formToken'],
            'publicKey' => $this->publicKeyJS,
            'amount' => $totalCentavos / 100,
            'orderId' => $orderId,
            'debug' => [
                'order_id' => $orderId,
                'amount_soles' => $totalCentavos / 100,
                'customer_email' => $data['customer']['email'],
                'test_mode' => $debugLog['test_mode'] // Indicar si es modo prueba
            ]
        ]);
        exit;
    }

    /**
     * Obtener IP del cliente
     */
    private function getClientIp() {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        // Si hay múltiples IPs (proxy), tomar la primera
        if (strpos($ip, ',') !== false) {
            $ipList = explode(',', $ip);
            $ip = trim($ipList[0]);
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
    }

    /**
     * Interpretar códigos de error comunes de Izipay
     */
    private function interpretarCodigoError($code)
    {
        $interpretations = [
            // ERROR ESPECÍFICO QUE ESTÁS TENIENDO
            'PSP_641' => 'Banco emisor rechazó la transacción (Error del banco)',
            '141' => 'Banco emisor rechazó la transacción - Tarjeta posiblemente bloqueada',
            
            // Otros errores PSP comunes
            'PSP_010' => 'Número de tarjeta inválido',
            'PSP_020' => 'Tarjeta expirada',
            'PSP_030' => 'Código de seguridad (CVV) incorrecto',
            'PSP_040' => 'Transacción denegada por el banco',
            'PSP_050' => 'Fondos insuficientes',
            'PSP_060' => 'Límite de tarjeta excedido',
            'PSP_070' => 'Tarjeta restringida',
            'PSP_080' => 'Problema de comunicación con el banco',
            'PSP_090' => 'Error temporal del sistema bancario',
            'PSP_100' => 'Transacción duplicada',
            
            // Errores de comercio/configuración
            'T07' => 'Tarjeta no permitida para este comercio',
            'T08' => 'Comercio no autorizado para esta operación',
            'T09' => 'BIN de tarjeta no configurado',
            'T10' => 'Comercio no configurado para API V4',
            'T23' => 'Marca de tarjeta no habilitada (Visa/Mastercard)',
            'T99' => 'Error interno del sistema Izipay',
            
            // Errores de tarjeta/fondos
            '51' => 'Fondos insuficientes',
            '54' => 'Tarjeta vencida',
            '55' => 'PIN incorrecto',
            '57' => 'Transacción no permitida para esta tarjeta',
            '58' => 'Transacción no permitida para este terminal',
            '59' => 'Tarjeta sospechosa de fraude',
            '61' => 'Límite de monto excedido',
            
            // Errores de autenticación 3DS
            'A02' => 'Autenticación 3DS fallida o cancelada',
            'A03' => 'Error en proceso de autenticación',
            'A04' => 'Autenticación no disponible',
            
            // Errores de riesgo
            'R01' => 'Transacción rechazada por análisis de riesgo',
            'R02' => 'Monto muy alto para este cliente',
            'R03' => 'Muchas transacciones recientes',
            
            // Errores generales
            '96' => 'Error del sistema bancario',
            '97' => 'Timeout de la transacción',
            '98' => 'Transacción duplicada',
            '99' => 'Error temporal, reintentar'
        ];
        
        return $interpretations[$code] ?? "Código de error desconocido. Contacta a Izipay para más información.";
    }

    /**
     * Sugerencias específicas para errores
     */
    private function getSuggestionForError($errorCode)
    {
        $suggestions = [
            'PSP_641' => 'El banco emisor rechazó la transacción. Verifica: 1) La tarjeta no está bloqueada, 2) Tiene fondos suficientes, 3) Está habilitada para compras online, 4) Los datos son correctos.',
            '141' => 'Contacta a tu banco para desbloquear tu tarjeta para compras online o verificar restricciones.',
            'PSP_050' => 'Fondos insuficientes en la tarjeta.',
            'PSP_020' => 'La tarjeta está vencida. Verifica la fecha de expiración.',
            'PSP_030' => 'Código CVV incorrecto.',
            'A02' => 'Autenticación 3DS fallida. Completa el proceso de verificación que envía tu banco (SMS, app).',
            'T09' => 'Contacta a Izipay para configurar el BIN de tu tarjeta en el comercio.',
            'T23' => 'Marca de tarjeta no habilitada. Contacta a Izipay para habilitar Visa/Mastercard.',
        ];
        
        return $suggestions[$errorCode] ?? 'Por favor, verifica los datos e intenta nuevamente. Si el problema persiste, contacta a tu banco.';
    }

    /**
     * Guardar logs de depuración en archivo
     */
    private function guardarDebugLog($debugData)
    {
        $logDir = __DIR__ . '/../logs/';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . 'pago_debug_' . date('Y-m-d') . '.log';
        $logEntry = "[" . date('Y-m-d H:i:s') . "] " . json_encode($debugData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        $logEntry .= str_repeat("-", 80) . "\n";
        
        file_put_contents($logFile, $logEntry, FILE_APPEND);
        
        // También loguear en el error_log de PHP para acceso inmediato
        error_log("DEBUG PAGO: " . json_encode($debugData, JSON_UNESCAPED_UNICODE));
    }

    /**
     * Obtener email del usuario
     */
    private function obtenerEmailUsuario($id_usuario) {
        try {
            $stmt = $this->db->prepare("SELECT correo FROM usuarios WHERE id_usuario = ?");
            $stmt->execute([$id_usuario]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            return $usuario['correo'] ?? 'cliente@dreamhouse.com';
        } catch (Exception $e) {
            error_log("Error obteniendo email: " . $e->getMessage());
            return 'cliente@dreamhouse.com';
        }
    }

    /**
     * Validar firma HMAC del callback
     */
    private function validarHMAC($kr_answer, $kr_hash) {
        if (empty($kr_hash)) {
            return false;
        }

        // Clave HMAC de producción
        $hmacKey = "xTLMbHQxpeIu7e5CMlf2bVrHExybP5i09IDfjlw3NTUGf";

        // Calcular hash esperado
        $hashCalculado = base64_encode(hash_hmac('sha256', $kr_answer, $hmacKey, true));

        // Comparar hashes de forma segura
        return hash_equals($hashCalculado, $kr_hash);
    }

    /**
     * Procesar el resultado del pago (Callback de retorno) CON DEPURACIÓN
     */
    public function pago_exitoso()
    {
        $debugLog = [];
        $debugLog['timestamp'] = date('Y-m-d H:i:s');
        $debugLog['action'] = 'pago_exitoso_callback';
        $debugLog['session_id'] = session_id();
        
        if (!isset($_SESSION['usuario_id'])) {
            $debugLog['error'] = 'Usuario no autenticado en callback';
            $this->guardarDebugLog($debugLog);
            header('Location: index.php?action=login');
            exit;
        }

        $id_usuario = $_SESSION['usuario_id'];
        $debugLog['usuario_id'] = $id_usuario;

        // Verificar si hay datos de la transacción
        $kr_answer = $_POST['kr-answer'] ?? $_GET['kr-answer'] ?? null;
        $kr_hash = $_POST['kr-hash'] ?? $_GET['kr-hash'] ?? null;
        
        $debugLog['request_data'] = [
            'has_kr_answer' => !empty($kr_answer),
            'has_kr_hash' => !empty($kr_hash),
            'get_params' => $_GET,
            'post_params' => array_keys($_POST)
        ];

        // Si no hay kr-answer, verificar si viene por GET con parámetros
        if (!$kr_answer && isset($_GET['transaction'])) {
            $debugLog['status'] = 'Redirección sin kr-answer';
            $this->guardarDebugLog($debugLog);
            $_SESSION['mensaje'] = "Procesando confirmación del pago...";
            header('Location: index.php?action=carrito');
            exit;
        }

        if (!$kr_answer) {
            $debugLog['error'] = 'No se recibió kr-answer';
            $this->guardarDebugLog($debugLog);
            $_SESSION['error'] = "No se recibió confirmación del pago.";
            header('Location: index.php?action=carrito');
            exit;
        }

        // Validar HMAC si está disponible
        if ($kr_hash && !$this->validarHMAC($kr_answer, $kr_hash)) {
            $debugLog['warning'] = 'HMAC inválido en callback';
            error_log("⚠️ HMAC inválido en callback de pago");
        } else {
            $debugLog['hmac_validation'] = $kr_hash ? 'valid' : 'no_hash_provided';
        }

        $answer = json_decode($kr_answer, true);
        
        if (!$answer) {
            $debugLog['error'] = 'Error decodificando kr-answer';
            $debugLog['kr_answer_raw'] = substr($kr_answer, 0, 200) . '...';
            $this->guardarDebugLog($debugLog);
            $_SESSION['error'] = "Error al procesar la respuesta del pago.";
            header('Location: index.php?action=carrito');
            exit;
        }

        // ========== DEPURACIÓN DETALLADA DE LA RESPUESTA ==========
        $debugLog['izipay_callback'] = $answer;
        
        $orderStatus = $answer['orderStatus'] ?? null;
        $orderId = $answer['orderId'] ?? null;
        $errorMessage = $answer['errorMessage'] ?? null;
        $transactions = $answer['transactions'] ?? [];
        
        $debugLog['analysis'] = [
            'orderStatus' => $orderStatus,
            'orderId' => $orderId,
            'errorMessage' => $errorMessage,
            'transactions_count' => count($transactions)
        ];
        
        if (!empty($transactions)) {
            foreach ($transactions as $i => $transaction) {
                $debugLog['analysis']['transaction_' . $i] = [
                    'status' => $transaction['status'] ?? null,
                    'errorCode' => $transaction['errorCode'] ?? null,
                    'detailedErrorCode' => $transaction['detailedErrorCode'] ?? null,
                    'errorMessage' => $transaction['errorMessage'] ?? null,
                    'detailedStatus' => $transaction['detailedStatus'] ?? null
                ];
            }
        }
        
        error_log("=== DEPURACIÓN CALLBACK IZIPAY ===");
        error_log("Order ID: " . $orderId);
        error_log("Order Status: " . $orderStatus);
        error_log("Error Message: " . $errorMessage);
        
        if ($orderStatus === 'PAID' || $orderStatus === 'EXECUTED') {
            $debugLog['status'] = 'PAGO_EXITOSO';
            $debugLog['amount_paid'] = $answer['amount'] ?? 0;
            $this->guardarDebugLog($debugLog);
            
            require_once 'app/models/Pedido.php';
            require_once 'app/models/Usuario.php';
            require_once 'app/models/Oferta.php';

            $pedidoModel = new Pedido();
            $usuarioModel = new Usuario();
            $ofertaModel = new Oferta();

            $usuario = $usuarioModel->obtenerPorId($id_usuario);
            $items = $this->carrito->obtenerCarrito($id_usuario);

            if (empty($items)) {
                $_SESSION['mensaje'] = "Tu pedido ya ha sido procesado.";
                header('Location: index.php?action=pedidos');
                exit;
            }

            // Calcular total con descuento si existe
            $subtotal = $this->carrito->obtenerTotal($id_usuario);
            $descuento_aplicado = $_SESSION['descuento_aplicado'] ?? null;
            
            if ($descuento_aplicado && isset($descuento_aplicado['total_final'])) {
                $total = $descuento_aplicado['total_final'];
                $monto_descuento = $descuento_aplicado['monto_descuento'] ?? 0;
            } else {
                $total = $subtotal;
                $monto_descuento = 0;
            }

            // Iniciar transacción para asegurar integridad
            $this->db->beginTransaction();

            try {
                // 1. Crear el pedido en la base de datos
                $id_pedido = $pedidoModel->crearPedido(
                    $id_usuario,
                    $total,
                    'Izipay',
                    $usuario['direccion'] ?? 'Dirección no especificada',
                    $usuario['distrito'] ?? '',
                    $usuario['ciudad'] ?? '',
                    $usuario['provincia'] ?? '',
                    $usuario['referencia'] ?? '',
                    $orderId
                );

                if (!$id_pedido) {
                    throw new Exception("Error al crear el pedido");
                }

                // 2. Agregar detalles del pedido
                foreach ($items as $item) {
                    if (!$pedidoModel->agregarDetalle(
                        $id_pedido,
                        $item['id_producto'],
                        $item['cantidad'],
                        $item['precio']
                    )) {
                        throw new Exception("Error al agregar detalle del pedido");
                    }
                }

                // 3. Registrar uso de descuento si existe
                if ($descuento_aplicado && isset($descuento_aplicado['id_oferta'])) {
                    $this->registrarUsoDescuento(
                        $descuento_aplicado['id_oferta'],
                        $id_usuario,
                        $id_pedido,
                        $monto_descuento
                    );
                }

                // 4. Actualizar stock
                if (!$this->carrito->actualizarStockDespuesPago($id_usuario)) {
                    throw new Exception("Error al actualizar el stock");
                }

                // 5. Marcar carrito como comprado y vaciar
                $this->carrito->marcarComoComprados($id_usuario, $id_pedido);
                $this->carrito->vaciar($id_usuario);

                // 6. Confirmar transacción
                $this->db->commit();

                // 7. Limpiar descuentos aplicados
                unset($_SESSION['descuento_aplicado']);

                // 8. Preparar datos para la vista
                $transactionId = $transactions[0]['uuid'] ?? 'N/A';
                $total_mostrar = $total;
                
                $debugLog['pedido_creado'] = [
                    'id_pedido' => $id_pedido,
                    'transaction_id' => $transactionId,
                    'total' => $total_mostrar
                ];
                $this->guardarDebugLog($debugLog);

                // 🔥 REDIRECCIÓN: Guardar datos en sesión y redirigir
                $_SESSION['pago_completado'] = true;
                $_SESSION['orden_id'] = $orderId;
                $_SESSION['monto_total'] = $total_mostrar;
                $_SESSION['id_pedido'] = $id_pedido;

                // 🔥 Incluir la vista de éxito
                require_once 'app/views/carrito/pago_exitoso.php';
                exit;

            } catch (Exception $e) {
                // Rollback en caso de error
                $this->db->rollBack();
                $debugLog['exception'] = $e->getMessage();
                $this->guardarDebugLog($debugLog);
                error_log("Error procesando pago: " . $e->getMessage());
                $_SESSION['error'] = "Error al procesar el pedido. Por favor, contacta con soporte.";
                header('Location: index.php?action=carrito');
                exit;
            }

        } else {
            // Pago no completado - ESPECÍFICO PARA PSP_641
            $debugLog['status'] = 'PAGO_RECHAZADO';
            $this->guardarDebugLog($debugLog);
            
            $errorMessage = $errorMessage ?? 'El pago no fue completado exitosamente.';
            
            // Buscar códigos de error en las transacciones
            if (!empty($transactions)) {
                foreach ($transactions as $transaction) {
                    if (isset($transaction['errorCode'])) {
                        $errorCode = $transaction['errorCode'];
                        $detailedErrorCode = $transaction['detailedErrorCode'] ?? null;
                        $errorInterpretation = $this->interpretarCodigoError($errorCode);
                        
                        if ($errorCode === 'PSP_641' || $detailedErrorCode === '141') {
                            $errorMessage = "⚠️ Tu banco rechazó el pago (Error PSP_641/141).<br>";
                            $errorMessage .= "Posibles causas:<br>";
                            $errorMessage .= "1. Tarjeta bloqueada o restringida<br>";
                            $errorMessage .= "2. Límite de crédito excedido<br>";
                            $errorMessage .= "3. Transacción internacional no permitida<br>";
                            $errorMessage .= "4. Configuración de seguridad del banco<br>";
                            $errorMessage .= "<br><strong>Soluciones:</strong><br>";
                            $errorMessage .= "- Contacta a tu banco para autorizar la compra<br>";
                            $errorMessage .= "- Verifica que la tarjeta esté habilitada para compras online<br>";
                            $errorMessage .= "- Intenta con otra tarjeta";
                        } else {
                            $errorMessage = "Error {$errorCode}: {$errorInterpretation}";
                        }
                        break;
                    }
                }
            }
            
            // Mensajes específicos según estado
            if ($orderStatus === 'REFUSED') {
                if (strpos($errorMessage, 'PSP_641') === false) {
                    $errorMessage = "Tu tarjeta fue rechazada. Verifica los datos o usa otra tarjeta.";
                }
            } elseif ($orderStatus === 'CANCELLED') {
                $errorMessage = "El pago fue cancelado por el usuario.";
            } elseif ($orderStatus === 'NOT_CREATED') {
                $errorMessage = "No se pudo crear la transacción de pago.";
            }
            
            $_SESSION['error'] = $errorMessage;
            header('Location: index.php?action=carrito');
            exit;
        }
    }

    /**
     * Registrar uso de descuento
     */
    private function registrarUsoDescuento($id_oferta, $id_usuario, $id_pedido, $monto_descuento) {
        try {
            // Insertar en oferta_usos
            $stmt = $this->db->prepare("
                INSERT INTO oferta_usos (id_oferta, id_usuario, id_pedido, monto_descuento, fecha_uso)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$id_oferta, $id_usuario, $id_pedido, $monto_descuento]);

            // Actualizar usos_actuales en ofertas
            $stmt = $this->db->prepare("
                UPDATE ofertas 
                SET usos_actuales = COALESCE(usos_actuales, 0) + 1 
                WHERE id_oferta = ?
            ");
            $stmt->execute([$id_oferta]);

            return true;
        } catch (Exception $e) {
            error_log("Error registrando uso de descuento: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Método para limpiar sesión después de pago
     */
    public function limpiarPago() {
        session_start();
        unset($_SESSION['pago_completado']);
        unset($_SESSION['orden_id']);
        unset($_SESSION['monto_total']);
        unset($_SESSION['id_pedido']);
        
        echo json_encode(['success' => true]);
    }

    /**
     * Redirigir al carrito después de mostrar éxito
     */
    public function redirigirCarrito() {
        // Esto se llamará desde JavaScript después de mostrar la página de éxito
        header('Location: index.php?action=carrito');
        exit;
    }
}