<?php
require_once 'app/config/database.php';
require_once 'app/models/Carrito.php';
require_once 'app/models/Producto.php';
require_once 'app/models/Oferta.php';

class CarritoController {
    private $db;
    private $carrito;
    private $producto;
    private $oferta;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->carrito = new Carrito($this->db);
        $this->producto = new Producto($this->db);
        $this->oferta = new Oferta($this->db);
    }

    // ============================
    // AGREGAR PRODUCTO AL CARRITO - MEJORADO
    // ============================
    public function agregar() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'Debe iniciar sesión']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_producto = intval($_POST['id_producto'] ?? 0);
            $cantidad = intval($_POST['cantidad'] ?? 1);

            // DEBUG: Registrar los datos recibidos
            error_log("CarritoController - ID Producto recibido: " . $id_producto);
            error_log("CarritoController - Cantidad recibida: " . $cantidad);
            error_log("CarritoController - POST completo: " . print_r($_POST, true));
            error_log("CarritoController - Usuario ID: " . ($_SESSION['usuario_id'] ?? 'No encontrado'));

            if ($id_producto <= 0) {
                error_log("CarritoController - ERROR: ID Producto inválido o cero");
                echo json_encode(['success' => false, 'message' => 'ID de producto inválido: ' . $id_producto]);
                exit;
            }

            if ($cantidad <= 0) {
                error_log("CarritoController - ERROR: Cantidad inválida");
                echo json_encode(['success' => false, 'message' => 'Cantidad inválida']);
                exit;
            }

            $producto = $this->producto->obtenerPorId($id_producto);
            if (!$producto) {
                error_log("CarritoController - ERROR: Producto no encontrado, ID: " . $id_producto);
                echo json_encode(['success' => false, 'message' => 'Producto no encontrado']);
                exit;
            }

            if ($producto['estado'] !== 'activo') {
                error_log("CarritoController - ERROR: Producto inactivo, ID: " . $id_producto);
                echo json_encode(['success' => false, 'message' => 'Producto no disponible']);
                exit;
            }

            $id_usuario = $_SESSION['usuario_id'];

            // Intentar agregar al carrito
            $resultado = $this->carrito->agregar($id_usuario, $id_producto, $cantidad);
            
            if ($resultado) {
                error_log("CarritoController - ÉXITO: Producto agregado, ID: " . $id_producto . ", Usuario: " . $id_usuario);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Producto agregado al carrito',
                    'total_items' => $this->carrito->obtenerCantidadItems($id_usuario),
                    'debug' => [
                        'product_id' => $id_producto,
                        'product_name' => $producto['nombre'],
                        'usuario_id' => $id_usuario
                    ]
                ]);
            } else {
                error_log("CarritoController - ERROR: No se pudo agregar al carrito, ID: " . $id_producto);
                echo json_encode(['success' => false, 'message' => 'No se pudo agregar al carrito. Verifique el stock disponible.']);
            }
        } else {
            error_log("CarritoController - ERROR: Método no permitido");
            echo json_encode(['success' => false, 'message' => 'Método no permitido']);
        }
    }

    // ============================
    // MOSTRAR CARRITO
    // ============================
    public function verCarrito() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            $_SESSION['error'] = "Debe iniciar sesión para ver el carrito";
            header('Location: index.php?action=login');
            exit;
        }

        $id_usuario = $_SESSION['usuario_id'];
        $items = $this->carrito->obtenerCarrito($id_usuario);
        $total = $this->carrito->obtenerTotal($id_usuario);

        include 'app/views/carrito/ver_carrito.php';
    }

    // ============================
    // CARRITO PARA SIDEBAR (AJAX)
    // ============================
    public function carritoSidebar() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'Debe iniciar sesión']);
            exit;
        }

        $id_usuario = $_SESSION['usuario_id'];

        echo json_encode([
            'success' => true,
            'items' => $this->carrito->obtenerCarrito($id_usuario),
            'total' => $this->carrito->obtenerTotal($id_usuario),
            'total_items' => $this->carrito->obtenerCantidadItems($id_usuario)
        ]);
    }

    // ============================
    // ACTUALIZAR CANTIDAD
    // ============================
    public function actualizar() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'Debe iniciar sesión']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_producto = intval($_POST['id_producto'] ?? 0);
            $cantidad = intval($_POST['cantidad'] ?? 1);
            $id_usuario = $_SESSION['usuario_id'];

            if ($id_producto <= 0) {
                echo json_encode(['success' => false, 'message' => 'Producto inválido']);
                exit;
            }

            if ($this->carrito->actualizarCantidad($id_usuario, $id_producto, $cantidad)) {
                echo json_encode([
                    'success' => true,
                    'total' => number_format($this->carrito->obtenerTotal($id_usuario), 2),
                    'total_items' => $this->carrito->obtenerCantidadItems($id_usuario),
                    'carrito' => $this->carrito->obtenerCarrito($id_usuario)
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Stock insuficiente'
                ]);
            }
        }
    }

    // ============================
    // ELIMINAR PRODUCTO
    // ============================
    public function eliminar() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'Debe iniciar sesión']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_producto = intval($_POST['id_producto'] ?? 0);
            $id_usuario = $_SESSION['usuario_id'];

            if ($id_producto <= 0) {
                echo json_encode(['success' => false, 'message' => 'Producto inválido']);
                exit;
            }

            if ($this->carrito->eliminar($id_usuario, $id_producto)) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Producto eliminado',
                    'total' => number_format($this->carrito->obtenerTotal($id_usuario), 2),
                    'total_items' => $this->carrito->obtenerCantidadItems($id_usuario)
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar']);
            }
        }
    }

    // ============================
    // VACIAR CARRITO
    // ============================
    public function vaciar() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            $_SESSION['error'] = "Debe iniciar sesión";
            header('Location: index.php?action=login');
            exit;
        }

        $id_usuario = $_SESSION['usuario_id'];

        if ($this->carrito->vaciar($id_usuario)) {
            unset($_SESSION['descuento_aplicado']);
            $_SESSION['mensaje'] = "Carrito vaciado correctamente";
        } else {
            $_SESSION['error'] = "Error al vaciar el carrito";
        }

        header('Location: index.php?action=carrito');
        exit;
    }

    // ============================
    // CONTADOR DEL CARRITO
    // ============================
    public function obtenerContador() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['total_items' => 0]);
            exit;
        }

        echo json_encode([
            'total_items' => $this->carrito->obtenerCantidadItems($_SESSION['usuario_id'])
        ]);
    }

    // ============================
    // APLICAR DESCUENTO
    // ============================
    public function aplicarDescuento() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario_id'])) {
            $_SESSION['error'] = "Debe iniciar sesión para aplicar descuentos";
            header('Location: index.php?action=login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $codigo = trim($_POST['codigo_descuento'] ?? '');

            if (empty($codigo)) {
                $_SESSION['error'] = "Por favor ingresa un código de descuento";
                header('Location: index.php?action=carrito');
                exit;
            }

            $id_usuario = $_SESSION['usuario_id'];
            $total = $this->carrito->obtenerTotal($id_usuario);

            if ($total <= 0) {
                $_SESSION['error'] = "Tu carrito está vacío";
                header('Location: index.php?action=carrito');
                exit;
            }

            $validacion = $this->oferta->validarOferta($codigo, $total);

            if ($validacion['valida']) {
                $oferta = $validacion['oferta'];
                $descuento = $this->calcularDescuento($oferta, $total);

                $_SESSION['descuento_aplicado'] = [
                    'id_oferta' => $oferta['id_oferta'],
                    'codigo' => $codigo,
                    'monto_descuento' => $descuento,
                    'subtotal' => $total,
                    'total_final' => $total - $descuento,
                    'oferta_info' => $oferta
                ];

                $_SESSION['success'] = '¡Descuento aplicado correctamente!';
            } else {
                $_SESSION['error'] = $validacion['mensaje'];
            }

            header('Location: index.php?action=carrito');
            exit;
        }
    }

    // ============================
    // REMOVER DESCUENTO
    // ============================
    public function removerDescuento() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        unset($_SESSION['descuento_aplicado']);
        $_SESSION['success'] = "Descuento removido correctamente";

        header('Location: index.php?action=carrito');
        exit;
    }

    // ============================
    // CÁLCULO DEL DESCUENTO
    // ============================
    private function calcularDescuento($oferta, $total) {
        if ($oferta['tipo_descuento'] === 'porcentaje') {
            return $total * ($oferta['valor_descuento'] / 100);
        }
        return min($oferta['valor_descuento'], $total);
    }

    // ============================
    // INFO DESCUENTO (AJAX)
    // ============================
    public function obtenerInfoDescuento() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        $id_usuario = $_SESSION['usuario_id'];

        echo json_encode([
            'success' => true,
            'subtotal' => $this->carrito->obtenerTotal($id_usuario),
            'descuento_aplicado' => $_SESSION['descuento_aplicado'] ?? null
        ]);
    }
}
?>