<?php
require_once __DIR__ . '/../models/Oferta.php';
require_once __DIR__ . '/../helpers/funciones.php';

class OfertasController {
    private $ofertaModel;

    public function __construct() {
        $this->ofertaModel = new Oferta();
    }

    // ADMIN: Listar ofertas
    public function gestionOfertas() {
        checkAdminAuth();
        $ofertas = $this->ofertaModel->obtenerTodas();
        include __DIR__ . '/../views/ofertas/gestion_ofertas.php';
    }

    // ADMIN: Crear oferta
    public function crearOferta() {
        checkAdminAuth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $datos = [
                'codigo_oferta' => $_POST['codigo_oferta'],
                'descripcion' => $_POST['descripcion'],
                'tipo_descuento' => $_POST['tipo_descuento'],
                'valor_descuento' => $_POST['valor_descuento'],
                'fecha_inicio' => $_POST['fecha_inicio'],
                'fecha_fin' => $_POST['fecha_fin'],
                'usos_maximos' => $_POST['usos_maximos'] ?: null,
                'minimo_compra' => $_POST['minimo_compra'] ?: 0,
                'aplica_todo' => isset($_POST['aplica_todo']) ? 1 : 0,
                'estado' => $_POST['estado']
            ];

            if ($this->ofertaModel->crear($datos)) {
                $_SESSION['success'] = 'Oferta creada exitosamente';
            } else {
                $_SESSION['error'] = 'Error al crear la oferta';
            }
            header('Location: index.php?action=gestion_ofertas');
            exit;
        }

        include __DIR__ . '/../views/ofertas/form_oferta.php';
    }

    // ADMIN: Editar oferta
    public function editarOferta() {
        checkAdminAuth();

        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: index.php?action=gestion_ofertas');
            exit;
        }

        $oferta = $this->ofertaModel->obtenerPorId($id);
        if (!$oferta) {
            $_SESSION['error'] = 'Oferta no encontrada';
            header('Location: index.php?action=gestion_ofertas');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $datos = [
                'codigo_oferta' => $_POST['codigo_oferta'],
                'descripcion' => $_POST['descripcion'],
                'tipo_descuento' => $_POST['tipo_descuento'],
                'valor_descuento' => $_POST['valor_descuento'],
                'fecha_inicio' => $_POST['fecha_inicio'],
                'fecha_fin' => $_POST['fecha_fin'],
                'usos_maximos' => $_POST['usos_maximos'] ?: null,
                'minimo_compra' => $_POST['minimo_compra'] ?: 0,
                'aplica_todo' => isset($_POST['aplica_todo']) ? 1 : 0,
                'estado' => $_POST['estado']
            ];

            if ($this->ofertaModel->actualizar($id, $datos)) {
                $_SESSION['success'] = 'Oferta actualizada exitosamente';
            } else {
                $_SESSION['error'] = 'Error al actualizar la oferta';
            }
            header('Location: index.php?action=gestion_ofertas');
            exit;
        }

        include __DIR__ . '/../views/ofertas/form_oferta.php';
    }

    // ADMIN: Eliminar oferta
    public function eliminarOferta() {
        checkAdminAuth();

        $id = $_GET['id'] ?? null;
        if ($id && $this->ofertaModel->eliminar($id)) {
            $_SESSION['success'] = 'Oferta eliminada exitosamente';
        } else {
            $_SESSION['error'] = 'Error al eliminar la oferta';
        }
        header('Location: index.php?action=gestion_ofertas');
        exit;
    }

    // ADMIN: Estadísticas de ofertas
    public function estadisticasOfertas() {
        checkAdminAuth();

        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: index.php?action=gestion_ofertas');
            exit;
        }

        $oferta = $this->ofertaModel->obtenerPorId($id);
        $estadisticas = $this->ofertaModel->obtenerEstadisticas($id);
        $usos = $this->ofertaModel->obtenerUsos($id);

        include __DIR__ . '/../views/ofertas/estadisticas_oferta.php';
    }

    // CLIENTE: Ver ofertas disponibles
    public function misDescuentos() {
        checkClienteAuth();
        
        $ofertas = $this->ofertaModel->obtenerOfertasDisponibles();
        include __DIR__ . '/../views/ofertas/mis_descuentos.php';
    }

    // CLIENTE: Ver historial de descuentos usados
    public function historialDescuentos() {
        checkClienteAuth();
        
        $usos = $this->ofertaModel->obtenerUsosPorUsuario($_SESSION['usuario_id']);
        include __DIR__ . '/../views/ofertas/historial_descuentos.php';
    }
}
?>