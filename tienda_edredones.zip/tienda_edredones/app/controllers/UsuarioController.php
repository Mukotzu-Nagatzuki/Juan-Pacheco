<?php 
require_once 'app/models/Usuario.php';
require_once 'app/config/database.php';

class UsuarioController {

    // Mostrar formulario de registro
    public function mostrarRegistro() {
        include 'app/views/usuarios/registro.php';
    }

    // Procesar registro de usuario
    public function registrarUsuario() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');
            $apellido = trim($_POST['apellido'] ?? '');
            $correo = trim($_POST['correo'] ?? '');
            $clave = trim($_POST['clave'] ?? '');
            $telefono = trim($_POST['telefono'] ?? '');
            $direccion = trim($_POST['direccion'] ?? '');
            $rol = 'cliente';

            if (!empty($nombre) && !empty($correo) && !empty($clave)) {
                $usuarioModel = new Usuario();
                
                if ($usuarioModel->existeCorreo($correo)) {
                    echo "❌ Este correo ya está registrado.";
                    return;
                }
                
                $hash = password_hash($clave, PASSWORD_BCRYPT);
                $exito = $usuarioModel->registrar($nombre, $apellido, $correo, $hash, $telefono, $direccion, $rol);

                if ($exito) {
                    header('Location: index.php?action=login&msg=registrado');
                    exit;
                } else {
                    echo "❌ Error: no se pudo registrar el usuario.";
                }
            } else {
                echo "⚠️ Debes completar los campos obligatorios (Nombre, Correo y Contraseña).";
            }
        }
    }

    // Mostrar formulario de login
    public function mostrarLogin() {
        include 'app/views/usuarios/login.php';
    }

    // Procesar inicio de sesión
// Procesar inicio de sesión
public function loginUsuario() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $correo = trim($_POST['correo'] ?? '');
        $clave = trim($_POST['clave'] ?? '');

        $usuarioModel = new Usuario();
        $usuario = $usuarioModel->obtenerPorCorreo($correo);

        if ($usuario && password_verify($clave, $usuario['clave'])) {
            if (!isset($_SESSION)) session_start();
            $_SESSION['usuario_id'] = $usuario['id_usuario'];
            $_SESSION['nombre'] = $usuario['nombre'];
            $_SESSION['rol'] = $usuario['rol'];

            // Redirigir según el rol
            if ($_SESSION['rol'] === 'admin') {
                header('Location: index.php?action=dashboard');
            } else {
                // Clientes van al home.php
                header('Location: index.php?action=home');
            }
            exit;
        } else {
            header('Location: index.php?action=login&error=1');
            exit;
        }
    }
}

    // Cerrar sesión
    public function logout() {
        session_destroy();
        header('Location: index.php?action=login');
        exit;
    }

    // Mostrar dashboard del usuario
public function mostrarDashboard() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: index.php?action=login');
        exit;
    }

    // Redirigir según el rol
    if ($_SESSION['rol'] === 'admin') {
        // Obtener estadísticas para el admin
        $db = new Database();
        $pdo = $db->getConnection();
        
        try {
            // Ventas de hoy
            $stmt = $pdo->prepare("SELECT COALESCE(SUM(total), 0) as ventas_hoy FROM pedidos WHERE DATE(fecha_pedido) = CURDATE() AND estado != 'cancelado'");
            $stmt->execute();
            $ventas_hoy = $stmt->fetch(PDO::FETCH_ASSOC)['ventas_hoy'] ?? 0;
            
            // Pedidos pendientes
            $stmt = $pdo->prepare("SELECT COUNT(*) as pendientes FROM pedidos WHERE estado IN ('pendiente', 'en preparación')");
            $stmt->execute();
            $pedidos_pendientes = $stmt->fetch(PDO::FETCH_ASSOC)['pendientes'] ?? 0;
            
            // Productos con stock bajo
            $stmt = $pdo->prepare("SELECT COUNT(*) as stock_bajo FROM productos WHERE stock <= 5 AND estado = 'activo'");
            $stmt->execute();
            $stock_bajo = $stmt->fetch(PDO::FETCH_ASSOC)['stock_bajo'] ?? 0;
            
            // Nuevos clientes (últimos 7 días)
            $stmt = $pdo->prepare("SELECT COUNT(*) as nuevos_clientes FROM usuarios WHERE rol = 'cliente' AND DATE(fecha_registro) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
            $stmt->execute();
            $nuevos_clientes = $stmt->fetch(PDO::FETCH_ASSOC)['nuevos_clientes'] ?? 0;
            
            // Pedidos recientes
            $stmt = $pdo->prepare("
                SELECT p.id_pedido, CONCAT(u.nombre, ' ', u.apellido) as cliente, 
                       p.fecha_pedido, p.total, p.estado 
                FROM pedidos p 
                JOIN usuarios u ON p.id_usuario = u.id_usuario 
                ORDER BY p.fecha_pedido DESC 
                LIMIT 5
            ");
            $stmt->execute();
            $pedidos_recientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            // Si hay error en las consultas, establecer valores por defecto
            $ventas_hoy = 0;
            $pedidos_pendientes = 0;
            $stock_bajo = 0;
            $nuevos_clientes = 0;
            $pedidos_recientes = [];
            error_log("Error en dashboard admin: " . $e->getMessage());
        }
        
        include 'app/views/usuarios/dashboard_admin.php';
    } else {
        // Obtener estadísticas para el cliente
        $db = new Database();
        $pdo = $db->getConnection();
        
        try {
            // Total de pedidos del cliente
            $stmt = $pdo->prepare("SELECT COUNT(*) as total_pedidos FROM pedidos WHERE id_usuario = ?");
            $stmt->execute([$_SESSION['usuario_id']]);
            $total_pedidos = $stmt->fetch(PDO::FETCH_ASSOC)['total_pedidos'] ?? 0;

            // Pedidos pendientes del cliente
            $stmt = $pdo->prepare("SELECT COUNT(*) as pedidos_pendientes FROM pedidos WHERE id_usuario = ? AND estado IN ('pendiente', 'en preparación', 'en reparto')");
            $stmt->execute([$_SESSION['usuario_id']]);
            $pedidos_pendientes = $stmt->fetch(PDO::FETCH_ASSOC)['pedidos_pendientes'] ?? 0;

            // Pedidos entregados del cliente
            $stmt = $pdo->prepare("SELECT COUNT(*) as pedidos_entregados FROM pedidos WHERE id_usuario = ? AND estado = 'entregado'");
            $stmt->execute([$_SESSION['usuario_id']]);
            $pedidos_entregados = $stmt->fetch(PDO::FETCH_ASSOC)['pedidos_entregados'] ?? 0;

            // Productos en lista de deseos
            $stmt = $pdo->prepare("SELECT COUNT(*) as total_deseos FROM lista_deseos WHERE id_usuario = ?");
            $stmt->execute([$_SESSION['usuario_id']]);
            $total_deseos = $stmt->fetch(PDO::FETCH_ASSOC)['total_deseos'] ?? 0;

            // Pedidos recientes del cliente
            $stmt = $pdo->prepare("
                SELECT p.id_pedido, p.fecha_pedido, p.total, p.estado 
                FROM pedidos p 
                WHERE p.id_usuario = ?
                ORDER BY p.fecha_pedido DESC 
                LIMIT 5
            ");
            $stmt->execute([$_SESSION['usuario_id']]);
            $pedidos_recientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (Exception $e) {
            // Si hay error en las consultas, establecer valores por defecto
            $total_pedidos = 0;
            $pedidos_pendientes = 0;
            $pedidos_entregados = 0;
            $total_deseos = 0;
            $pedidos_recientes = [];
            error_log("Error en dashboard cliente: " . $e->getMessage());
        }
        
        include 'app/views/usuarios/dashboard.php';
    }
}

    // Mostrar página de pedidos (para clientes)
    public function mostrarPedidos() {
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=login');
            exit;
        }
        include 'app/views/usuarios/pedido.php';
    }

    // ✅ Mostrar gestión de pedidos para admin
    public function mostrarPedidosAdmin() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php?action=login');
            exit;
        }

        $db = new Database();
        $pdo = $db->getConnection();
        
        // Obtener todos los pedidos
        $stmt = $pdo->prepare("
            SELECT p.*, CONCAT(u.nombre, ' ', u.apellido) as cliente 
            FROM pedidos p 
            JOIN usuarios u ON p.id_usuario = u.id_usuario 
            ORDER BY p.fecha_pedido DESC
        ");
        $stmt->execute();
        $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        include 'app/views/admin/pedidos.php';
    }

    // ✅ Mostrar detalles de un pedido específico
    public function mostrarDetallePedido() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php?action=login');
            exit;
        }

        if (!isset($_GET['id'])) {
            header('Location: index.php?action=dashboard');
            exit;
        }

        $id_pedido = $_GET['id'];
        $db = new Database();
        $pdo = $db->getConnection();
        
        // Obtener información del pedido
        $stmt = $pdo->prepare("
            SELECT p.*, CONCAT(u.nombre, ' ', u.apellido) as cliente, 
                   u.correo, u.telefono, u.direccion
            FROM pedidos p 
            JOIN usuarios u ON p.id_usuario = u.id_usuario 
            WHERE p.id_pedido = ?
        ");
        $stmt->execute([$id_pedido]);
        $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Obtener detalles del pedido
        $stmt = $pdo->prepare("
            SELECT dp.*, pr.nombre as producto_nombre 
            FROM detalle_pedido dp 
            JOIN productos pr ON dp.id_producto = pr.id_producto 
            WHERE dp.id_pedido = ?
        ");
        $stmt->execute([$id_pedido]);
        $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        include 'app/views/admin/detalle_pedido.php';
    }

    // ✅ Mostrar gestión de clientes para admin
    public function mostrarGestionClientes() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php?action=login');
            exit;
        }

        $db = new Database();
        $pdo = $db->getConnection();
        
        // Obtener todos los clientes
        $stmt = $pdo->prepare("
            SELECT id_usuario, nombre, apellido, correo, telefono, 
                   direccion, fecha_registro, estado 
            FROM usuarios 
            WHERE rol = 'cliente' 
            ORDER BY fecha_registro DESC
        ");
        $stmt->execute();
        $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        include 'app/views/admin/clientes.php';
    }

    // ✅ Mostrar página de facturas
    public function mostrarFacturas() {
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=login');
            exit;
        }
        include 'app/views/usuarios/facturas.php';
    }

    // ✅ Mostrar página de deseos
    public function mostrarDeseos() {
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=login');
            exit;
        }
        include 'app/views/usuarios/deseo.php';
    }

    // ✅ Eliminar producto de lista de deseos
    public function eliminarDeseo() {
        if (!isset($_SESSION['usuario_id']) || !isset($_GET['id'])) {
            header('Location: index.php?action=deseos');
            exit;
        }

        $db = new Database();
        $conn = $db->getConnection();
        $stmt = $conn->prepare("DELETE FROM lista_deseos WHERE id_usuario = :id_usuario AND id_producto = :id_producto");
        $stmt->execute([
            ':id_usuario' => $_SESSION['usuario_id'],
            ':id_producto' => $_GET['id']
        ]);

        header('Location: index.php?action=deseos');
        exit;
    }
    // ✅ Mostrar perfil del usuario
    public function mostrarPerfil() {
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=login');
            exit;
        }

        $db = new Database();
        $pdo = $db->getConnection();
        
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id_usuario = ?");
        $stmt->execute([$_SESSION['usuario_id']]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        include 'app/views/usuarios/perfil.php';
    }

    // ✅ Actualizar perfil del usuario
    public function actualizarPerfil() {
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');
            $apellido = trim($_POST['apellido'] ?? '');
            $telefono = trim($_POST['telefono'] ?? '');
            $direccion = trim($_POST['direccion'] ?? '');
            $distrito = trim($_POST['distrito'] ?? '');
            $ciudad = trim($_POST['ciudad'] ?? '');
            $provincia = trim($_POST['provincia'] ?? '');
            $referencia = trim($_POST['referencia'] ?? '');

            $db = new Database();
            $pdo = $db->getConnection();
            
            $stmt = $pdo->prepare("
                UPDATE usuarios 
                SET nombre = ?, apellido = ?, telefono = ?, direccion = ?, 
                    distrito = ?, ciudad = ?, provincia = ?, referencia = ?
                WHERE id_usuario = ?
            ");
            
            $exito = $stmt->execute([
                $nombre, $apellido, $telefono, $direccion,
                $distrito, $ciudad, $provincia, $referencia,
                $_SESSION['usuario_id']
            ]);

            if ($exito) {
                $_SESSION['nombre'] = $nombre;
                $_SESSION['mensaje'] = "✅ Perfil actualizado correctamente.";
            } else {
                $_SESSION['mensaje'] = "❌ Error al actualizar el perfil.";
            }
            
            header('Location: index.php?action=perfil');
            exit;
        }
    }

    // ✅ Cambiar contraseña sin cerrar sesión
    public function actualizarPassword() {
        if (!isset($_SESSION)) session_start();

        $id_usuario = $_SESSION['usuario_id'] ?? null;

        if (!$id_usuario) {
            $_SESSION['mensaje'] = "Error de sesión. Intenta nuevamente.";
            header("Location: index.php?action=dashboard");
            exit();
        }

        // ✅ Conexión segura a la base de datos
        $db = new Database();
        $pdo = $db->getConnection();

        $actual = trim($_POST['actual'] ?? '');
        $nueva = trim($_POST['nueva'] ?? '');
        $confirmar = trim($_POST['confirmar'] ?? '');

        if ($nueva !== $confirmar) {
            $_SESSION['mensaje'] = "⚠️ Las contraseñas nuevas no coinciden.";
            header("Location: index.php?action=seguridad");
            exit();
        }

        // ✅ Verificar contraseña actual
        $stmt = $pdo->prepare("SELECT clave FROM usuarios WHERE id_usuario = ?");
        $stmt->execute([$id_usuario]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user || !password_verify($actual, $user['clave'])) {
            $_SESSION['mensaje'] = "❌ La contraseña actual es incorrecta.";
            header("Location: index.php?action=seguridad");
            exit();
        }

        // ✅ Actualizar contraseña nueva
        $nuevo_hash = password_hash($nueva, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE usuarios SET clave = ? WHERE id_usuario = ?");
        $update->execute([$nuevo_hash, $id_usuario]);

        $_SESSION['mensaje'] = "✅ Contraseña actualizada correctamente.";
        header("Location: index.php?action=seguridad");
        exit();
    }

    // ✅ Actualizar estado de pedido (admin)
    public function actualizarEstadoPedido() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php?action=login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_pedido']) && isset($_POST['estado'])) {
            $id_pedido = $_POST['id_pedido'];
            $estado = $_POST['estado'];

            $db = new Database();
            $pdo = $db->getConnection();
            
            $stmt = $pdo->prepare("UPDATE pedidos SET estado = ? WHERE id_pedido = ?");
            $exito = $stmt->execute([$estado, $id_pedido]);

            if ($exito) {
                $_SESSION['mensaje'] = "✅ Estado del pedido actualizado correctamente.";
            } else {
                $_SESSION['mensaje'] = "❌ Error al actualizar el estado del pedido.";
            }
            
            header('Location: index.php?action=pedidos_admin');
            exit;
        }
    }
        // En UsuarioController.php - agregar este método
   // En UsuarioController.php - método actualizarCliente corregido
public function actualizarCliente() {
    if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
        header('Location: index.php?action=login');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id_usuario = $_POST['id_usuario'] ?? '';
        $nombre = trim($_POST['nombre'] ?? '');
        $apellido = trim($_POST['apellido'] ?? ''); // ✅ Agregar esta línea
        $correo = trim($_POST['correo'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $direccion = trim($_POST['direccion'] ?? '');
        $ciudad = trim($_POST['ciudad'] ?? '');
        $distrito = trim($_POST['distrito'] ?? '');
        $provincia = trim($_POST['provincia'] ?? '');
        $estado = $_POST['estado'] ?? 'activo';

        $db = new Database();
        $pdo = $db->getConnection();
        
        $stmt = $pdo->prepare("
            UPDATE usuarios 
            SET nombre = ?, apellido = ?, correo = ?, telefono = ?, direccion = ?, 
                ciudad = ?, distrito = ?, provincia = ?, estado = ?
            WHERE id_usuario = ? AND rol = 'cliente'
        ");
        
        $exito = $stmt->execute([
            $nombre, $apellido, $correo, $telefono, $direccion,
            $ciudad, $distrito, $provincia, $estado,
            $id_usuario
        ]);

        if ($exito) {
            $_SESSION['mensaje'] = "Cliente actualizado correctamente.";
        } else {
            $_SESSION['mensaje'] = "Error al actualizar el cliente.";
        }
        
        header('Location: index.php?action=gestion_clientes');
        exit;
    }
}
    // En UsuarioController.php - agregar este método
    public function eliminarCliente() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php?action=login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_usuario = $_POST['id_usuario'] ?? '';
            
            if (empty($id_usuario)) {
                $_SESSION['mensaje'] = "❌ ID de usuario no válido.";
                header('Location: index.php?action=gestion_clientes');
                exit;
            }

            $db = new Database();
            $pdo = $db->getConnection();

            try {
                // Iniciar transacción para asegurar la integridad de los datos
                $pdo->beginTransaction();

                // 1. Primero eliminar registros relacionados en otras tablas
                
                // Eliminar de lista_deseos
                $stmt = $pdo->prepare("DELETE FROM lista_deseos WHERE id_usuario = ?");
                $stmt->execute([$id_usuario]);

                // Eliminar de resenas
                $stmt = $pdo->prepare("DELETE FROM resenas WHERE id_usuario = ?");
                $stmt->execute([$id_usuario]);

                // Eliminar de carrito
                $stmt = $pdo->prepare("DELETE FROM carrito WHERE id_usuario = ?");
                $stmt->execute([$id_usuario]);

                // 2. Manejar los pedidos del usuario
                // Primero obtener los IDs de pedidos del usuario
                $stmt = $pdo->prepare("SELECT id_pedido FROM pedidos WHERE id_usuario = ?");
                $stmt->execute([$id_usuario]);
                $pedidos = $stmt->fetchAll(PDO::FETCH_COLUMN);

                if (!empty($pedidos)) {
                    // Eliminar detalles de pedido
                    $placeholders = str_repeat('?,', count($pedidos) - 1) . '?';
                    $stmt = $pdo->prepare("DELETE FROM detalle_pedido WHERE id_pedido IN ($placeholders)");
                    $stmt->execute($pedidos);

                    // Eliminar pagos
                    $stmt = $pdo->prepare("DELETE FROM pagos WHERE id_pedido IN ($placeholders)");
                    $stmt->execute($pedidos);

                    // Eliminar pedidos
                    $stmt = $pdo->prepare("DELETE FROM pedidos WHERE id_usuario = ?");
                    $stmt->execute([$id_usuario]);
                }

                // 3. Finalmente eliminar el usuario
                $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario = ? AND rol = 'cliente'");
                $stmt->execute([$id_usuario]);

                // Verificar si se eliminó algún registro
                if ($stmt->rowCount() > 0) {
                    $pdo->commit();
                    $_SESSION['mensaje'] = "✅ Cliente eliminado correctamente.";
                } else {
                    $pdo->rollBack();
                    $_SESSION['mensaje'] = "❌ No se pudo eliminar el cliente. Verifica que exista y sea un cliente.";
                }

            } catch (PDOException $e) {
                $pdo->rollBack();
                $_SESSION['mensaje'] = "❌ Error al eliminar el cliente: " . $e->getMessage();
            }

            header('Location: index.php?action=gestion_clientes');
            exit;
        }
    }
        public function mostrarReportes() {
        if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php?action=login');
            exit;
        }
        
        include 'app/views/admin/reportes.php';
    }

    // En UsuarioController.php, agrega estos métodos:

// Agregar producto a lista de deseos
// En UsuarioController.php
public function agregarDeseo() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    if (!isset($_SESSION['usuario_id'])) {
        $_SESSION['error'] = "Debes iniciar sesión para agregar productos a tu lista de deseos";
        header('Location: index.php?action=login');
        exit;
    }

    if (!isset($_GET['id'])) {
        $_SESSION['error'] = "Producto no especificado";
        header('Location: index.php?action=productos');
        exit;
    }

    $id_producto = $_GET['id'];
    $id_usuario = $_SESSION['usuario_id'];

    // Usar el modelo de lista de deseos
    require_once 'app/models/ListaDeseos.php';
    $listaDeseos = new ListaDeseos();

    if ($listaDeseos->agregar($id_usuario, $id_producto)) {
        $_SESSION['mensaje'] = "✅ Producto agregado a tu lista de deseos";
    } else {
        $_SESSION['error'] = "⚠️ El producto ya está en tu lista de deseos";
    }

    // Redirigir de vuelta a la página del producto
    if (isset($_SERVER['HTTP_REFERER'])) {
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    } else {
        header('Location: index.php?action=productos');
    }
    exit;
}

// Función auxiliar para verificar si está en lista de deseos
private function estaEnListaDeseos($id_usuario, $id_producto) {
    require_once 'app/models/ListaDeseos.php';
    $listaDeseos = new ListaDeseos();
    return $listaDeseos->estaEnLista($id_usuario, $id_producto);
}
}
?>