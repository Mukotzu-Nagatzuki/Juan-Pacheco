<?php
// app/controllers/BuscarController.php

class BuscarController {
    
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Método para buscar productos
    public function buscar() {
        $search_term = $_GET['search'] ?? '';
        
        if (empty($search_term)) {
            // Si no hay término de búsqueda, redirigir a productos
            header('Location: index.php?action=productos');
            exit();
        }
        
        // Buscar productos por nombre o categoría
        try {
            $sql = "SELECT p.*, c.nombre as categoria_nombre 
                    FROM productos p 
                    LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                    WHERE (p.nombre LIKE :search OR p.descripcion LIKE :search OR c.nombre LIKE :search)
                    AND p.estado = 'activo'
                    ORDER BY p.nombre";
            
            $stmt = $this->db->prepare($sql);
            $search_param = "%" . $search_term . "%";
            $stmt->bindParam(':search', $search_param);
            $stmt->execute();
            
            $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Incluir la vista de resultados de búsqueda
            include 'app/views/buscar.php';
            
        } catch (Exception $e) {
            // En caso de error, mostrar página de productos
            header('Location: index.php?action=productos');
            exit();
        }
    }
}