<?php
require_once 'app/config/database.php';
require_once 'app/models/Producto.php';
require_once 'app/models/Categoria.php';

class HomeController {
    private $db;
    private $producto;
    private $categoria;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->producto = new Producto($this->db);
        $this->categoria = new Categoria($this->db);
    }
    
    public function home() {
        // Obtener productos recientes para mostrar en home
        $productosRecientes = $this->producto->obtenerRecientes(6);
        
        // Debug: Ver qué productos se obtienen
        error_log("HomeController - Productos obtenidos: " . print_r($productosRecientes, true));
        
        // CORREGIDO: La ruta correcta es app/views/home/home.php
        include 'app/views/home/home.php';
    }
    
    public function productos() {
        // Redirigir al ProductoController para mostrar todos los productos
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->index();
    }
    
    public function nosotros() {
        include 'app/views/nosotros.php';
    }
    
    public function contacto() {
        include 'app/views/contacto.php';
    }

    // Función para mostrar productos por categoría
    public function categoria() {
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->porCategoria();
    }

    // Búsqueda desde el home
    public function buscar() {
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->buscar();
    }
}
?>