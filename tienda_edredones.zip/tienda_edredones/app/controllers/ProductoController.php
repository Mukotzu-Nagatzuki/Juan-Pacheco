<?php
require_once 'app/config/database.php';
require_once 'app/models/Producto.php';
require_once 'app/models/Categoria.php';

class ProductoController {
    private $db;
    private $producto;
    private $categoria;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->producto = new Producto($this->db);
        $this->categoria = new Categoria($this->db);
    }

    // Mostrar productos en página de productos
    public function index() {
        $productos = $this->producto->obtenerTodosActivos();
        include 'app/views/productos/productos_lista.php';
    }

    // Mostrar productos populares
    public function populares() {
        $productos = $this->producto->obtenerPopulares();
        include 'app/views/productos/productos_lista.php';
    }

    // Mostrar productos por categoría
    public function porCategoria() {
        if (!isset($_GET['id'])) {
            header('Location: index.php');
            exit;
        }
        
        $id_categoria = $_GET['id'];
        $productos = $this->producto->obtenerPorCategoria($id_categoria);
        $categoria = $this->categoria->obtenerPorId($id_categoria);
        
        if (!$categoria) {
            header('Location: index.php');
            exit;
        }
        
        include 'app/views/productos/productos_categoria.php';
    }

    // Mostrar lista de productos (solo admin)
    public function adminPanel() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        $productos = $this->producto->obtenerTodos();
        include 'app/views/productos/productos_admin.php';
    }

    // Mostrar formulario para agregar - CORREGIDO
    // Agregar producto - MODIFICADO PARA MODAL
    public function agregar() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        // Si es POST, procesar el formulario del modal
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $id_categoria = $_POST['id_categoria'] ?? '';
            $precio = $_POST['precio'] ?? '';
            $material = $_POST['material'] ?? '';
            $color = $_POST['color'] ?? '';
            $descripcion = $_POST['descripcion'] ?? '';
            $medida = $_POST['medida'] ?? '';
            $stock = $_POST['stock'] ?? '';
            $estado = $_POST['estado'] ?? 'activo';

            // Validaciones básicas
            if (empty($nombre) || empty($id_categoria) || empty($precio) || empty($medida) || empty($stock)) {
                $_SESSION['error'] = "Por favor complete todos los campos requeridos";
                header("Location: index.php?action=productos_admin");
                exit;
            }

            // Procesar imagen
            $nombreArchivo = null;
            if (!empty($_FILES['imagen']['name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                try {
                    $nombreArchivo = $this->procesarImagen($_FILES['imagen']);
                } catch (Exception $e) {
                    $_SESSION['error'] = $e->getMessage();
                    header("Location: index.php?action=productos_admin");
                    exit;
                }
            }

            if ($this->producto->agregar($nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $nombreArchivo, $estado)) {
                $_SESSION['mensaje'] = "Producto agregado correctamente";
            } else {
                $_SESSION['error'] = "Error al agregar el producto";
            }
            
            // Redirigir a la misma página de productos
            header("Location: index.php?action=productos_admin");
            exit;
        }

        // Si es GET, redirigir a la página de productos
        header("Location: index.php?action=productos_admin");
        exit;
    }

    // Editar producto existente - MODIFICADO PARA MODAL
    public function editar() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        // Si es POST, procesar el formulario del modal
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id_producto'] ?? '';
            $nombre = $_POST['nombre'] ?? '';
            $id_categoria = $_POST['id_categoria'] ?? '';
            $precio = $_POST['precio'] ?? '';
            $material = $_POST['material'] ?? '';
            $color = $_POST['color'] ?? '';
            $descripcion = $_POST['descripcion'] ?? '';
            $medida = $_POST['medida'] ?? '';
            $stock = $_POST['stock'] ?? '';
            $estado = $_POST['estado'] ?? 'activo';
            $imagen_actual = $_POST['imagen_actual'] ?? '';

            // Validaciones básicas
            if (empty($nombre) || empty($id_categoria) || empty($precio) || empty($medida)) {
                $_SESSION['error'] = "Por favor complete todos los campos requeridos";
                header("Location: index.php?action=productos_admin");
                exit;
            }
            
            // Obtener producto actual para mantener imagen si no se sube nueva
            $producto_actual = $this->producto->obtenerPorId($id);
            if (!$producto_actual) {
                $_SESSION['error'] = "❌ Producto no encontrado";
                header("Location: index.php?action=productos_admin");
                exit;
            }
            
            // Procesar imagen - CORRECCIÓN IMPORTANTE
            $imagen = $producto_actual['imagen_principal']; // Por defecto mantener la imagen actual
            
            if (!empty($_FILES['imagen']['name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                try {
                    $nueva_imagen = $this->procesarImagen($_FILES['imagen']);
                    
                    // Si se subió una nueva imagen correctamente
                    if ($nueva_imagen) {
                        // Eliminar imagen anterior si existe
                        if (!empty($producto_actual['imagen_principal'])) {
                            $this->eliminarImagen($producto_actual['imagen_principal']);
                        }
                        $imagen = $nueva_imagen; // Usar la nueva imagen
                    }
                } catch (Exception $e) {
                    $_SESSION['error'] = $e->getMessage();
                    header("Location: index.php?action=productos_admin");
                    exit;
                }
            }
            
            // Si no se subió nueva imagen y hay imagen_actual del formulario, usarla
            if (empty($_FILES['imagen']['name']) && !empty($imagen_actual)) {
                $imagen = $imagen_actual;
            }

            if ($this->producto->actualizar($id, $nombre, $id_categoria, $precio, $material, $color, $descripcion, $medida, $stock, $imagen, $estado)) {
                $_SESSION['mensaje'] = "Producto actualizado correctamente";
            } else {
                $_SESSION['error'] = "Error al actualizar el producto";
            }
            
            header("Location: index.php?action=productos_admin");
            exit;
        }

        // Si es GET, redirigir a la página de productos (no debería pasar con modal)
        header("Location: index.php?action=productos_admin");
        exit;
    }

    // Eliminar producto - MEJORADO
    public function eliminar() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
            header('Location: index.php');
            exit;
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $producto = $this->producto->obtenerPorId($id);
            
            if ($producto) {
                // Eliminar imagen del producto si existe
                if (!empty($producto['imagen_principal'])) {
                    $this->eliminarImagen($producto['imagen_principal']);
                }
                
                if ($this->producto->eliminar($id)) {
                    $_SESSION['mensaje'] = "Producto eliminado correctamente";
                } else {
                    $_SESSION['error'] = "Error al eliminar el producto";
                }
            } else {
                $_SESSION['error'] = "Producto no encontrado";
            }
        } else {
            $_SESSION['error'] = "ID de producto no especificado";
        }
        
        header('Location: index.php?action=admin');
        exit;
    }

    // Búsqueda de productos - MEJORADO
    public function buscar() {
        $termino = trim($_GET['search'] ?? '');
        
        if (empty($termino)) {
            header('Location: index.php?action=productos');
            exit;
        }
        
        $productos = $this->producto->buscar($termino);
        include 'app/views/productos/resultados_busqueda.php';
    }

    // Función para procesar imágenes
    private function procesarImagen($archivo) {
        $directorio = "public/img/productos/";
        
        // Crear directorio si no existe
        if (!is_dir($directorio)) {
            mkdir($directorio, 0755, true);
        }

        $nombreArchivo = time() . '_' . uniqid() . '_' . basename($archivo['name']);
        $rutaDestino = $directorio . $nombreArchivo;

        // Validar tipo de archivo
        $tipoPermitido = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
        
        if (!in_array($extension, $tipoPermitido)) {
            throw new Exception("Tipo de archivo no permitido. Solo se permiten: " . implode(', ', $tipoPermitido));
        }

        // Validar tamaño (máximo 5MB)
        if ($archivo['size'] > 5 * 1024 * 1024) {
            throw new Exception("La imagen es demasiado grande. Tamaño máximo: 5MB");
        }

        // Mover archivo
        if (move_uploaded_file($archivo['tmp_name'], $rutaDestino)) {
            return $nombreArchivo;
        } else {
            throw new Exception("Error al subir la imagen. Verifique los permisos del directorio.");
        }
    }

    // Función para eliminar imagen del servidor
    private function eliminarImagen($nombreArchivo) {
        if (!empty($nombreArchivo)) {
            $rutaArchivo = "public/img/productos/" . $nombreArchivo;
            if (file_exists($rutaArchivo) && is_file($rutaArchivo)) {
                unlink($rutaArchivo);
            }
        }
    }

    // Método para mostrar productos por tipo (para compatibilidad)
    public function mostrarPorTipo() {
        // Redirigir al método porCategoria para mantener compatibilidad
        if (isset($_GET['tipo'])) {
            // Mapear tipos antiguos a IDs de categoría
            $tipoMap = [
                'sabanas' => 1,
                'edredon_reversible' => 2,
                'edredon_sherpa' => 3,
                'cubrecamas' => 4
            ];
            
            $tipo = $_GET['tipo'];
            if (isset($tipoMap[$tipo])) {
                header('Location: index.php?action=categoria&id=' . $tipoMap[$tipo]);
                exit;
            }
        }
        
        header('Location: index.php?action=productos');
        exit;
    }

    // Mostrar detalles de un producto específico
    public function detalle() {
        if (!isset($_GET['id'])) {
            header('Location: index.php');
            exit;
        }
        
        $id_producto = $_GET['id'];
        $producto = $this->producto->obtenerPorId($id_producto);
        
        if (!$producto) {
            header('Location: index.php');
            exit;
        }
        
        include 'app/views/productos/detalle.php';
    }
    
}
?>