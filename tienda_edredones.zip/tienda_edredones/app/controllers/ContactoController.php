<?php
// app/controllers/ContactoController.php

class ContactoController {
    
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Mostrar formulario de contacto
    public function mostrarContacto() {
        include 'app/views/contacto.php';
    }
    
    // Procesar formulario de contacto
    public function enviarContacto() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Validar y sanitizar datos
            $nombre = trim($_POST['nombre']);
            $correo = trim($_POST['correo']);
            $asunto = trim($_POST['asunto']);
            $mensaje = trim($_POST['mensaje']);
            
            // Validaciones básicas
            $errores = [];
            
            if (empty($nombre)) {
                $errores[] = "El nombre completo es requerido";
            }
            
            if (empty($correo) || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
                $errores[] = "El correo electrónico es inválido";
            }
            
            if (empty($asunto)) {
                $errores[] = "El asunto es requerido";
            }
            
            if (empty($mensaje)) {
                $errores[] = "El mensaje es requerido";
            }
            
            if (empty($errores)) {
                // Guardar en base de datos
                try {
                    $sql = "INSERT INTO contactos (nombre_completo, correo_electronico, asunto, mensaje) 
                            VALUES (:nombre, :correo, :asunto, :mensaje)";
                    
                    $stmt = $this->db->prepare($sql);
                    
                    // Bind parameters
                    $stmt->bindParam(':nombre', $nombre);
                    $stmt->bindParam(':correo', $correo);
                    $stmt->bindParam(':asunto', $asunto);
                    $stmt->bindParam(':mensaje', $mensaje);
                    
                    if ($stmt->execute()) {
                        // Éxito - mostrar mensaje de confirmación
                        $_SESSION['mensaje_exito'] = "¡Mensaje enviado correctamente! Te contactaremos pronto.";
                        header('Location: index.php?action=contacto');
                        exit();
                    } else {
                        throw new Exception("Error al guardar el mensaje");
                    }
                    
                } catch (Exception $e) {
                    $_SESSION['mensaje_error'] = "Error al enviar el mensaje. Por favor, intenta nuevamente.";
                    header('Location: index.php?action=contacto');
                    exit();
                }
            } else {
                // Mostrar errores
                $_SESSION['errores_contacto'] = $errores;
                $_SESSION['datos_contacto'] = [
                    'nombre' => $nombre,
                    'correo' => $correo,
                    'asunto' => $asunto,
                    'mensaje' => $mensaje
                ];
                header('Location: index.php?action=contacto');
                exit();
            }
        } else {
            header('Location: index.php?action=contacto');
            exit();
        }
    }
}