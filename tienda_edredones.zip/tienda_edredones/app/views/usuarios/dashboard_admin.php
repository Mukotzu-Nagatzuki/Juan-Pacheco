<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener estadísticas para el dashboard admin
try {
    // Ventas de hoy
    $stmt = $conn->prepare("SELECT COALESCE(SUM(total), 0) as ventas_hoy FROM pedidos WHERE DATE(fecha_pedido) = CURDATE() AND estado != 'cancelado'");
    $stmt->execute();
    $ventas_hoy = $stmt->fetch(PDO::FETCH_ASSOC)['ventas_hoy'] ?? 0;

    // Pedidos pendientes
    $stmt = $conn->prepare("SELECT COUNT(*) as pendientes FROM pedidos WHERE estado IN ('pendiente', 'en preparación')");
    $stmt->execute();
    $pedidos_pendientes = $stmt->fetch(PDO::FETCH_ASSOC)['pendientes'] ?? 0;

    // Productos con stock bajo
    $stmt = $conn->prepare("SELECT COUNT(*) as stock_bajo FROM productos WHERE stock <= 5 AND estado = 'activo'");
    $stmt->execute();
    $stock_bajo = $stmt->fetch(PDO::FETCH_ASSOC)['stock_bajo'] ?? 0;

    // Nuevos clientes (últimos 7 días)
    $stmt = $conn->prepare("SELECT COUNT(*) as nuevos_clientes FROM usuarios WHERE rol = 'cliente' AND DATE(fecha_registro) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
    $stmt->execute();
    $nuevos_clientes = $stmt->fetch(PDO::FETCH_ASSOC)['nuevos_clientes'] ?? 0;

    // Ofertas activas
    $stmt = $conn->prepare("SELECT COUNT(*) as ofertas_activas FROM ofertas WHERE estado = 'activa' AND fecha_fin >= NOW()");
    $stmt->execute();
    $ofertas_activas = $stmt->fetch(PDO::FETCH_ASSOC)['ofertas_activas'] ?? 0;

    // Descuentos aplicados hoy
    $stmt = $conn->prepare("SELECT COALESCE(SUM(monto_descuento), 0) as descuentos_hoy FROM oferta_usos WHERE DATE(fecha_uso) = CURDATE()");
    $stmt->execute();
    $descuentos_hoy = $stmt->fetch(PDO::FETCH_ASSOC)['descuentos_hoy'] ?? 0;

    // Pedidos recientes
    $stmt = $conn->prepare("
        SELECT p.id_pedido, CONCAT(u.nombre, ' ', u.apellido) as cliente, 
               p.fecha_pedido, p.total, p.estado 
        FROM pedidos p 
        JOIN usuarios u ON p.id_usuario = u.id_usuario 
        ORDER BY p.fecha_pedido DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $pedidos_recientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Si hay error en las consultas, establecer valores por defecto
    $ventas_hoy = 0;
    $pedidos_pendientes = 0;
    $stock_bajo = 0;
    $nuevos_clientes = 0;
    $ofertas_activas = 0;
    $descuentos_hoy = 0;
    $pedidos_recientes = [];
    error_log("Error en dashboard admin: " . $e->getMessage());
}

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Panel de Administración</h1>
    <p>Bienvenido al centro de control de Dream House</p>
</header>

<!-- Estadísticas en GRID de 6 columnas -->
<div class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-currency-dollar stat-icon"></i>
        <h3>Ventas de Hoy</h3>
        <div class="stat-number">$<?= number_format($ventas_hoy, 2) ?></div>
        <p>Ingresos del día</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-cart-check stat-icon"></i>
        <h3>Pedidos Pendientes</h3>
        <div class="stat-number"><?= $pedidos_pendientes ?></div>
        <p>Por procesar</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-exclamation-triangle stat-icon"></i>
        <h3>Stock Bajo</h3>
        <div class="stat-number"><?= $stock_bajo ?></div>
        <p>Productos por reponer</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-person-plus stat-icon"></i>
        <h3>Nuevos Clientes</h3>
        <div class="stat-number"><?= $nuevos_clientes ?></div>
        <p>Últimos 7 días</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-percent stat-icon"></i>
        <h3>Ofertas Activas</h3>
        <div class="stat-number"><?= $ofertas_activas ?></div>
        <p>Promociones vigentes</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-tag stat-icon"></i>
        <h3>Descuentos Hoy</h3>
        <div class="stat-number">$<?= number_format($descuentos_hoy, 2) ?></div>
        <p>Total descontado</p>
    </div>
</div>

<!-- Pedidos Recientes - DEBAJO de las estadísticas -->
<div class="recent-orders">
    <h3>Pedidos Recientes</h3>
    <?php if (!empty($pedidos_recientes)): ?>
        <table class="orders-table">
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pedidos_recientes as $pedido): ?>
                    <tr>
                        <td>DH-<?= str_pad($pedido['id_pedido'], 4, '0', STR_PAD_LEFT) ?></td>
                        <td><?= htmlspecialchars($pedido['cliente']) ?></td>
                        <td><?= date('d/m/Y', strtotime($pedido['fecha_pedido'])) ?></td>
                        <td>$<?= number_format($pedido['total'], 2) ?></td>
                        <td>
                            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $pedido['estado'])) ?>">
                                <?= ucfirst($pedido['estado']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="index.php?action=ver_pedido&id=<?= $pedido['id_pedido'] ?>" class="btn-ver">
                                Ver Detalles
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; color: #7f8c8d; padding: 2rem;">No hay pedidos recientes</p>
    <?php endif; ?>
</div>

<!-- Acciones Rápidas -->
<div class="recent-orders">
    <h3>Acciones Rápidas</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
        <a href="index.php?action=productos_admin" class="btn-ver" style="display: block; text-align: center;">
            <i class="bi bi-plus-circle"></i> Agregar Producto
        </a>
        <a href="index.php?action=pedidos_admin" class="btn-ver" style="display: block; text-align: center;">
            <i class="bi bi-list-check"></i> Ver Todos los Pedidos
        </a>
        <a href="index.php?action=gestion_clientes" class="btn-ver" style="display: block; text-align: center;">
            <i class="bi bi-people-fill"></i> Gestionar Clientes
        </a>
        <a href="index.php?action=gestion_ofertas" class="btn-ver" style="display: block; text-align: center;">
            <i class="bi bi-percent"></i> Gestionar Ofertas
        </a>
        <a href="index.php?action=reportes" class="btn-ver" style="display: block; text-align: center;">
            <i class="bi bi-graph-up"></i> Ver Reportes
        </a>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>