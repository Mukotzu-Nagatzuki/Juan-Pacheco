<?php
// facturas.php (versión sin composer ni dompdf)
require_once __DIR__ . '/../../helpers/funciones.php';
require_once __DIR__ . '/../../config/database.php';

checkAuth();
$user_id = $_SESSION['usuario_id'] ?? null;
if (!$user_id) {
    header('Location: index.php?action=login');
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// === FUNCIONES ===

// Obtener facturas (pedidos) del usuario
function obtenerFacturas($conn, $user_id) {
    $sql = "
        SELECT p.*, pago.id_pago, pago.metodo AS metodo_pago, pago.monto AS monto_pago, pago.fecha_pago, pago.estado_pago
        FROM pedidos p
        LEFT JOIN pagos pago ON pago.id_pedido = p.id_pedido
        WHERE p.id_usuario = :id_usuario
        ORDER BY p.fecha_pedido DESC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id_usuario' => $user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Obtener detalle del pedido
function obtenerDetalle($conn, $id_pedido) {
    $sql = "
        SELECT dp.*, pr.nombre AS producto_nombre, pr.imagen_principal
        FROM detalle_pedido dp
        LEFT JOIN productos pr ON pr.id_producto = dp.id_producto
        WHERE dp.id_pedido = :id_pedido
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id_pedido' => $id_pedido]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Generar número de factura
function generarNumeroFactura($id_pedido, $fecha) {
    $year = date('Y', strtotime($fecha));
    return sprintf('DH-%s-%03d', $year, $id_pedido);
}

$usuario = getUserProfile($user_id);
$facturas = obtenerFacturas($conn, $user_id);

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Facturas y Comprobantes</h1>
    <p>Gestiona y descarga tus facturas de compra</p>
</header>

<section class="dashboard-section">
    <div class="section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3><i class="bi bi-receipt"></i> Mis Facturas</h3>
        <div style="color: #666; font-size: 0.9rem;">
            <span>Total: <?= count($facturas) ?> factura(s)</span>
        </div>
    </div>

    <?php if (empty($facturas)): ?>
        <div style="text-align: center; padding: 3rem; color: #7f8c8d;">
            <i class="bi bi-receipt-cutoff" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
            <h4>No hay facturas</h4>
            <p>Aún no has generado ninguna factura.</p>
            <a href="index.php?action=tienda" class="btn-ver" style="margin-top: 1rem;">
                <i class="bi bi-cart-plus"></i> Realizar Mi Primera Compra
            </a>
        </div>
    <?php endif; ?>

    <div class="invoices-grid">
        <?php foreach ($facturas as $pedido): 
            $detalle = obtenerDetalle($conn, $pedido['id_pedido']);
            $facturaNum = generarNumeroFactura($pedido['id_pedido'], $pedido['fecha_pedido']);
            $fechaEmitida = date('d/m/Y', strtotime($pedido['fecha_pedido']));
            $subtotal = 0.0;
            foreach ($detalle as $d) $subtotal += floatval($d['subtotal']);
            $impuestos = round($subtotal * 0.18, 2);
            $totalFactura = round($subtotal + $impuestos, 2);
        ?>
            <div class="invoice-card" id="factura-<?= intval($pedido['id_pedido']) ?>">
                <div class="invoice-header">
                    <div class="invoice-info">
                        <h4><?= htmlspecialchars($facturaNum) ?></h4>
                        <p class="invoice-date">Emitida el <?= htmlspecialchars($fechaEmitida) ?></p>
                        <span class="status-badge status-<?= strtolower($pedido['estado_pago'] ?? 'pendiente') ?>">
                            <?= ucfirst($pedido['estado_pago'] ?? 'Pendiente') ?>
                        </span>
                    </div>
                    <button class="btn-ver" onclick="descargarFactura(<?= intval($pedido['id_pedido']) ?>)">
                        <i class="bi bi-download"></i> Descargar PDF
                    </button>
                </div>

                <div class="invoice-content">
                    <div class="invoice-products">
                        <h5>Productos</h5>
                        <div class="products-list">
                            <?php foreach ($detalle as $item): ?>
                                <div class="product-item">
                                    <span class="product-name"><?= htmlspecialchars($item['producto_nombre']) ?></span>
                                    <span class="product-quantity">x<?= intval($item['cantidad']) ?></span>
                                    <span class="product-price">S/ <?= number_format($item['subtotal'], 2) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="invoice-summary">
                        <div class="summary-item">
                            <span>Subtotal:</span>
                            <span>S/ <?= number_format($subtotal, 2) ?></span>
                        </div>
                        <div class="summary-item">
                            <span>IGV (18%):</span>
                            <span>S/ <?= number_format($impuestos, 2) ?></span>
                        </div>
                        <div class="summary-item total">
                            <span>Total:</span>
                            <span>S/ <?= number_format($totalFactura, 2) ?></span>
                        </div>
                    </div>

                    <div class="invoice-details">
                        <div class="detail-group">
                            <h6>Información de Pago</h6>
                            <p><strong>Método:</strong> <?= htmlspecialchars(ucfirst($pedido['metodo_pago'] ?? 'No especificado')) ?></p>
                            <p><strong>Monto Pagado:</strong> S/ <?= number_format($pedido['monto_pago'] ?? $totalFactura, 2) ?></p>
                            <p><strong>Fecha de Pago:</strong> <?= $pedido['fecha_pago'] ? date('d/m/Y', strtotime($pedido['fecha_pago'])) : 'Pendiente' ?></p>
                        </div>
                        
                        <div class="detail-group">
                            <h6>Envío</h6>
                            <p><strong>Dirección:</strong> <?= htmlspecialchars($usuario['direccion'] ?? 'Sin dirección') ?></p>
                            <p><strong>Ubicación:</strong> <?= htmlspecialchars(($usuario['distrito'] ?? '') . ', ' . ($usuario['ciudad'] ?? '') . ', ' . ($usuario['provincia'] ?? '')) ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- jsPDF desde CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.1/jspdf.plugin.autotable.min.js"></script>

<script>
async function descargarFactura(id) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF("p", "mm", "a4");

    const cliente = "<?= htmlspecialchars($usuario['nombre'] . ' ' . ($usuario['apellido'] ?? '')) ?>";
    const direccion = "<?= htmlspecialchars($usuario['direccion'] ?? '') ?>";
    const distrito = "<?= htmlspecialchars($usuario['distrito'] ?? '') ?>";
    const ciudad = "<?= htmlspecialchars($usuario['ciudad'] ?? '') ?>";
    const provincia = "<?= htmlspecialchars($usuario['provincia'] ?? '') ?>";
    const logoUrl = "public/img/logoedredon.png";

    // Obtener datos específicos de la factura
    const pedidoElement = document.getElementById('factura-' + id);
    const facturaNum = pedidoElement.querySelector('h4').textContent;
    const fechaEmitida = pedidoElement.querySelector('.invoice-date').textContent.replace('Emitida el ', '');
    
    // Convertir logo a Base64
    const logoBase64 = await toBase64(logoUrl);

    // === ENCABEZADO ===
    doc.addImage(logoBase64, "PNG", 15, 10, 25, 25);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.text("Dream House", 45, 20);
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("RUC: 20612345678", 45, 26);
    doc.text("Av. Los Edredones 123 - Lima", 45, 31);
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("FACTURA ELECTRÓNICA", 150, 20, { align: "right" });
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(facturaNum, 150, 26, { align: "right" });
    doc.text("Fecha: " + fechaEmitida, 150, 31, { align: "right" });

    // Línea separadora
    doc.setDrawColor(200, 80, 80);
    doc.setLineWidth(0.5);
    doc.line(15, 35, 195, 35);

    // === INFORMACIÓN DEL CLIENTE ===
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("INFORMACIÓN DEL CLIENTE", 15, 45);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text("Señor(es): " + cliente, 15, 52);
    doc.text("Dirección: " + direccion, 15, 57);
    doc.text("Distrito: " + distrito + " - " + ciudad + " - " + provincia, 15, 62);

    // === DETALLES DE LA FACTURA ===
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("DETALLES DE LA FACTURA", 15, 75);

    // Obtener productos de la factura
    const filas = [];
    const productItems = pedidoElement.querySelectorAll('.product-item');
    productItems.forEach(item => {
        const name = item.querySelector('.product-name').textContent;
        const quantity = item.querySelector('.product-quantity').textContent;
        const price = item.querySelector('.product-price').textContent.replace('S/ ', '');
        filas.push([name, quantity, 'S/ ' + price]);
    });

    // Agregar totales
    const subtotal = pedidoElement.querySelector('.summary-item:not(.total) span:last-child').textContent;
    const igv = pedidoElement.querySelectorAll('.summary-item:not(.total)')[1].querySelector('span:last-child').textContent;
    const total = pedidoElement.querySelector('.summary-item.total span:last-child').textContent;

    // Tabla de productos
    doc.autoTable({
        startY: 80,
        head: [['Descripción', 'Cant.', 'Total']],
        body: filas,
        theme: "grid",
        styles: {
            font: "helvetica",
            fontSize: 9,
            cellPadding: 4,
            textColor: [40, 40, 40]
        },
        headStyles: {
            fillColor: [107, 93, 85],
            textColor: [255, 255, 255],
            halign: "center"
        },
        columnStyles: {
            0: { cellWidth: 110 },
            1: { cellWidth: 25, halign: "center" },
            2: { cellWidth: 35, halign: "right" }
        }
    });

    // Totales
    const yFinal = doc.lastAutoTable.finalY + 10;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("SUB TOTAL:", 140, yFinal);
    doc.text(subtotal, 180, yFinal, { align: "right" });
    
    doc.text("I.G.V. (18%):", 140, yFinal + 5);
    doc.text(igv, 180, yFinal + 5, { align: "right" });
    
    doc.setFontSize(11);
    doc.text("TOTAL:", 140, yFinal + 12);
    doc.text(total, 180, yFinal + 12, { align: "right" });

    // === PIE DE PÁGINA ===
    const pageHeight = doc.internal.pageSize.getHeight();
    doc.setDrawColor(200, 80, 80);
    doc.line(15, pageHeight - 30, 195, pageHeight - 30);
    doc.setFontSize(9);
    doc.setTextColor(100);
    doc.text("¡Gracias por su compra!", 105, pageHeight - 25, { align: "center" });
    doc.text("Dream House - Confort y calidad para tu hogar", 105, pageHeight - 20, { align: "center" });
    doc.text("Tel: +51 904 407 729 | Email: info@dreamhouse.com.pe", 105, pageHeight - 15, { align: "center" });
    doc.text("www.dreamhouse.com.pe", 105, pageHeight - 10, { align: "center" });

    // Descargar PDF
    doc.save("Factura_<?= htmlspecialchars($usuario['nombre']) ?>_" + facturaNum + ".pdf");
}

// Convertir imagen a Base64
async function toBase64(url) {
    try {
        const res = await fetch(url);
        const blob = await res.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.readAsDataURL(blob);
        });
    } catch (error) {
        console.error('Error cargando logo:', error);
        return null;
    }
}
</script>

<?php
$content = ob_get_clean();

// Incluir el layout del cliente
include __DIR__ . '/../layout/cliente_layout.php';
?>