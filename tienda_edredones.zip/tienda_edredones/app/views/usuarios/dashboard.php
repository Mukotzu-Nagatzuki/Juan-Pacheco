<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener estadísticas para el dashboard del cliente
try {
    // Total de pedidos del cliente
    $stmt = $conn->prepare("SELECT COUNT(*) as total_pedidos FROM pedidos WHERE id_usuario = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $total_pedidos = $stmt->fetch(PDO::FETCH_ASSOC)['total_pedidos'] ?? 0;

    // Pedidos pendientes del cliente
    $stmt = $conn->prepare("SELECT COUNT(*) as pedidos_pendientes FROM pedidos WHERE id_usuario = ? AND estado IN ('pendiente', 'en preparación', 'en reparto')");
    $stmt->execute([$_SESSION['usuario_id']]);
    $pedidos_pendientes = $stmt->fetch(PDO::FETCH_ASSOC)['pedidos_pendientes'] ?? 0;

    // Pedidos entregados del cliente
    $stmt = $conn->prepare("SELECT COUNT(*) as pedidos_entregados FROM pedidos WHERE id_usuario = ? AND estado = 'entregado'");
    $stmt->execute([$_SESSION['usuario_id']]);
    $pedidos_entregados = $stmt->fetch(PDO::FETCH_ASSOC)['pedidos_entregados'] ?? 0;

    // Productos en lista de deseos
    $stmt = $conn->prepare("SELECT COUNT(*) as total_deseos FROM lista_deseos WHERE id_usuario = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $total_deseos = $stmt->fetch(PDO::FETCH_ASSOC)['total_deseos'] ?? 0;

    // Descuentos utilizados
    $stmt = $conn->prepare("SELECT COUNT(*) as descuentos_usados FROM oferta_usos WHERE id_usuario = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $descuentos_usados = $stmt->fetch(PDO::FETCH_ASSOC)['descuentos_usados'] ?? 0;

    // Ahorro total por descuentos
    $stmt = $conn->prepare("SELECT COALESCE(SUM(monto_descuento), 0) as ahorro_total FROM oferta_usos WHERE id_usuario = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $ahorro_total = $stmt->fetch(PDO::FETCH_ASSOC)['ahorro_total'] ?? 0;

    // Pedidos recientes del cliente
    $stmt = $conn->prepare("
        SELECT p.id_pedido, p.fecha_pedido, p.total, p.estado 
        FROM pedidos p 
        WHERE p.id_usuario = ?
        ORDER BY p.fecha_pedido DESC 
        LIMIT 5
    ");
    $stmt->execute([$_SESSION['usuario_id']]);
    $pedidos_recientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // Si hay error en las consultas, establecer valores por defecto
    $total_pedidos = 0;
    $pedidos_pendientes = 0;
    $pedidos_entregados = 0;
    $total_deseos = 0;
    $descuentos_usados = 0;
    $ahorro_total = 0;
    $pedidos_recientes = [];
    error_log("Error en dashboard cliente: " . $e->getMessage());
}

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Mi Área Personal</h1>
    <p>Bienvenido de nuevo, <?= htmlspecialchars($_SESSION['nombre']) ?></p>
</header>

<!-- Estadísticas en GRID de 6 columnas -->
<div class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-bag-check stat-icon"></i>
        <h3>Total de Pedidos</h3>
        <div class="stat-number"><?= $total_pedidos ?></div>
        <p>Todos mis pedidos</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-clock-history stat-icon"></i>
        <h3>Pedidos Pendientes</h3>
        <div class="stat-number"><?= $pedidos_pendientes ?></div>
        <p>En proceso</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-check-circle stat-icon"></i>
        <h3>Pedidos Entregados</h3>
        <div class="stat-number"><?= $pedidos_entregados ?></div>
        <p>Completados</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-heart stat-icon"></i>
        <h3>Lista de Deseos</h3>
        <div class="stat-number"><?= $total_deseos ?></div>
        <p>Productos guardados</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-percent stat-icon"></i>
        <h3>Descuentos Usados</h3>
        <div class="stat-number"><?= $descuentos_usados ?></div>
        <p>Ofertas aplicadas</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-wallet2 stat-icon"></i>
        <h3>Total Ahorrado</h3>
        <div class="stat-number">S/ <?= number_format($ahorro_total, 2) ?></div>
        <p>En descuentos</p>
    </div>
</div>

<!-- Pedidos Recientes -->
<div class="dashboard-section">
    <h3>Mis Pedidos Recientes</h3>
    <?php if (!empty($pedidos_recientes)): ?>
        <table class="orders-table">
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pedidos_recientes as $pedido): ?>
                    <tr>
                        <td>DH-<?= str_pad($pedido['id_pedido'], 4, '0', STR_PAD_LEFT) ?></td>
                        <td><?= date('d/m/Y', strtotime($pedido['fecha_pedido'])) ?></td>
                        <td>S/ <?= number_format($pedido['total'], 2) ?></td>
                        <td>
                            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $pedido['estado'])) ?>">
                                <?= ucfirst($pedido['estado']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="index.php?action=ver_pedido&id=<?= $pedido['id_pedido'] ?>" class="btn-ver">
                                Ver Detalles
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; color: #7f8c8d; padding: 2rem;">Aún no tienes pedidos realizados</p>
    <?php endif; ?>
</div>

<!-- Acciones Rápidas -->
<div class="dashboard-section">
    <h3>Acciones Rápidas</h3>
    <div class="quick-actions">
        <a href="index.php?action=productos" class="quick-action-card">
            <i class="bi bi-bag-plus"></i>
            <h4>Continuar Comprando</h4>
            <p>Explora nuestra colección</p>
        </a>
        <a href="index.php?action=pedidos" class="quick-action-card">
            <i class="bi bi-list-check"></i>
            <h4>Ver Todos mis Pedidos</h4>
            <p>Revisa tu historial completo</p>
        </a>
        <a href="index.php?action=mis_descuentos" class="quick-action-card">
            <i class="bi bi-tag"></i>
            <h4>Mis Descuentos</h4>
            <p>Ofertas disponibles</p>
        </a>
        <a href="index.php?action=deseos" class="quick-action-card">
            <i class="bi bi-heart"></i>
            <h4>Lista de Deseos</h4>
            <p>Productos guardados</p>
        </a>
        <a href="index.php?action=historial_descuentos" class="quick-action-card">
            <i class="bi bi-receipt"></i>
            <h4>Historial Descuentos</h4>
            <p>Ofertas utilizadas</p>
        </a>
        <a href="index.php?action=perfil" class="quick-action-card">
            <i class="bi bi-person-gear"></i>
            <h4>Actualizar Perfil</h4>
            <p>Modificar mis datos</p>
        </a>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/cliente_layout.php';
?>