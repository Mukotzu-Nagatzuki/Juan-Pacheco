<?php
// perfil.php - Página para que el cliente actualice sus datos personales

// Verificar si la sesión ya está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

// Obtener la conexión a la base de datos
$db = new Database();
$conn = $db->getConnection();

$usuario_id = $_SESSION['usuario_id'];
$mensaje = '';
$tipo_mensaje = '';

// Obtener datos actuales del usuario
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    $_SESSION['mensaje'] = "Usuario no encontrado";
    header('Location: index.php');
    exit();
}

// Procesar actualización de datos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_perfil'])) {
    try {
        $nombre = trim($_POST['nombre']);
        $apellido = trim($_POST['apellido']);
        $telefono = trim($_POST['telefono']);
        $direccion = trim($_POST['direccion']);
        $distrito = trim($_POST['distrito']);
        $ciudad = trim($_POST['ciudad']);
        $provincia = trim($_POST['provincia']);
        $referencia = trim($_POST['referencia']);

        // Validaciones básicas
        if (empty($nombre)) {
            throw new Exception("El nombre es obligatorio");
        }

        // Actualizar datos del usuario
        $stmt = $conn->prepare("
            UPDATE usuarios 
            SET nombre = ?, apellido = ?, telefono = ?, direccion = ?, 
                distrito = ?, ciudad = ?, provincia = ?, referencia = ?
            WHERE id_usuario = ?
        ");

        $stmt->execute([
            $nombre, $apellido, $telefono, $direccion,
            $distrito, $ciudad, $provincia, $referencia,
            $usuario_id
        ]);

        $mensaje = "Perfil actualizado correctamente";
        $tipo_mensaje = "success";

        // Actualizar datos en la variable $usuario
        $usuario['nombre'] = $nombre;
        $usuario['apellido'] = $apellido;
        $usuario['telefono'] = $telefono;
        $usuario['direccion'] = $direccion;
        $usuario['distrito'] = $distrito;
        $usuario['ciudad'] = $ciudad;
        $usuario['provincia'] = $provincia;
        $usuario['referencia'] = $referencia;

    } catch (Exception $e) {
        $mensaje = "Error al actualizar el perfil: " . $e->getMessage();
        $tipo_mensaje = "error";
    }
}

// Procesar cambio de contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cambiar_clave'])) {
    try {
        $clave_actual = $_POST['clave_actual'];
        $nueva_clave = $_POST['nueva_clave'];
        $confirmar_clave = $_POST['confirmar_clave'];

        // Verificar que la contraseña actual sea correcta
        if (!password_verify($clave_actual, $usuario['clave'])) {
            throw new Exception("La contraseña actual es incorrecta");
        }

        // Validar nueva contraseña
        if (empty($nueva_clave)) {
            throw new Exception("La nueva contraseña es obligatoria");
        }

        if (strlen($nueva_clave) < 6) {
            throw new Exception("La nueva contraseña debe tener al menos 6 caracteres");
        }

        if ($nueva_clave !== $confirmar_clave) {
            throw new Exception("Las contraseñas no coinciden");
        }

        // Actualizar contraseña
        $nueva_clave_hash = password_hash($nueva_clave, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE usuarios SET clave = ? WHERE id_usuario = ?");
        $stmt->execute([$nueva_clave_hash, $usuario_id]);

        $mensaje = "Contraseña actualizada correctamente";
        $tipo_mensaje = "success";

    } catch (Exception $e) {
        $mensaje = "Error al cambiar la contraseña: " . $e->getMessage();
        $tipo_mensaje = "error";
    }
}

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Mi Perfil</h1>
    <p>Gestiona tu información personal y configuración de cuenta</p>
</header>

<!-- Mostrar mensajes -->
<?php if ($mensaje): ?>
    <div class="alert alert-<?= $tipo_mensaje === 'success' ? 'success' : 'error' ?>" 
         style="margin-bottom: 2rem; padding: 1rem; border-radius: var(--radio); 
                background: <?= $tipo_mensaje === 'success' ? '#d4edda' : '#f8d7da' ?>; 
                color: <?= $tipo_mensaje === 'success' ? '#155724' : '#721c24' ?>; 
                border: 1px solid <?= $tipo_mensaje === 'success' ? '#c3e6cb' : '#f5c6cb' ?>;">
        <?= htmlspecialchars($mensaje) ?>
    </div>
<?php endif; ?>

<div class="profile-container" style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">

    <!-- Sección de Información Personal -->
    <section class="personal-info" style="background: #fff; padding: 2rem; border-radius: var(--radio); box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h3 style="margin-bottom: 1.5rem; color: var(--color-texto); border-bottom: 2px solid var(--color-beige-claro); padding-bottom: 0.5rem;">
            <i class="bi bi-person"></i> Información Personal
        </h3>

        <form method="POST" action="">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                        Nombre *
                    </label>
                    <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" 
                           style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);"
                           required>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                        Apellido
                    </label>
                    <input type="text" name="apellido" value="<?= htmlspecialchars($usuario['apellido'] ?? '') ?>" 
                           style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                </div>
            </div>

            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Correo Electrónico
                </label>
                <input type="email" value="<?= htmlspecialchars($usuario['correo']) ?>" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: var(--radio); background: #f8f9fa;"
                       disabled>
                <small style="color: #666;">El correo electrónico no se puede modificar</small>
            </div>

            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Teléfono
                </label>
                <input type="tel" name="telefono" value="<?= htmlspecialchars($usuario['telefono'] ?? '') ?>" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
            </div>

            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Dirección
                </label>
                <input type="text" name="direccion" value="<?= htmlspecialchars($usuario['direccion'] ?? '') ?>" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                        Distrito
                    </label>
                    <input type="text" name="distrito" value="<?= htmlspecialchars($usuario['distrito'] ?? '') ?>" 
                           style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                        Ciudad
                    </label>
                    <input type="text" name="ciudad" value="<?= htmlspecialchars($usuario['ciudad'] ?? '') ?>" 
                           style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                </div>
            </div>

            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Provincia
                </label>
                <input type="text" name="provincia" value="<?= htmlspecialchars($usuario['provincia'] ?? '') ?>" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
            </div>

            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Referencia (Opcional)
                </label>
                <textarea name="referencia" style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio); min-height: 80px; resize: vertical;"><?= htmlspecialchars($usuario['referencia'] ?? '') ?></textarea>
                <small style="color: #666;">Puntos de referencia para la entrega</small>
            </div>

            <button type="submit" name="actualizar_perfil" class="btn-ver" style="width: 100%; padding: 12px;">
                <i class="bi bi-check-circle"></i> Actualizar Perfil
            </button>
        </form>
    </section>

    <!-- Sección de Cambio de Contraseña -->
    <section class="change-password" style="background: #fff; padding: 2rem; border-radius: var(--radio); box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h3 style="margin-bottom: 1.5rem; color: var(--color-texto); border-bottom: 2px solid var(--color-beige-claro); padding-bottom: 0.5rem;">
            <i class="bi bi-shield-lock"></i> Cambiar Contraseña
        </h3>

        <form method="POST" action="">
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Contraseña Actual *
                </label>
                <input type="password" name="clave_actual" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);"
                       required>
            </div>

            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Nueva Contraseña *
                </label>
                <input type="password" name="nueva_clave" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);"
                       required minlength="6">
                <small style="color: #666;">Mínimo 6 caracteres</small>
            </div>

            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">
                    Confirmar Nueva Contraseña *
                </label>
                <input type="password" name="confirmar_clave" 
                       style="width: 100%; padding: 10px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);"
                       required>
            </div>

            <button type="submit" name="cambiar_clave" class="btn-ver" style="width: 100%; padding: 12px; background: #936b94ff;">
                <i class="bi bi-key"></i> Cambiar Contraseña
            </button>
        </form>

        <!-- Información adicional de la cuenta -->
        <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--color-beige-claro);">
            <h4 style="margin-bottom: 1rem; color: var(--color-texto);">
                <i class="bi bi-info-circle"></i> Información de la Cuenta
            </h4>
            <div style="display: grid; gap: 0.5rem; color: #666;">
                <div><strong>Rol:</strong> <?= ucfirst($usuario['rol']) ?></div>
                <div><strong>Estado:</strong> 
                    <span style="color: <?= $usuario['estado'] === 'activo' ? '#28a745' : '#dc3545' ?>;">
                        <?= ucfirst($usuario['estado']) ?>
                    </span>
                </div>
                <div><strong>Miembro desde:</strong> <?= date('d/m/Y', strtotime($usuario['fecha_registro'])) ?></div>
            </div>
        </div>
    </section>

</div>

<?php
$content = ob_get_clean();

if ($usuario['rol'] === 'admin') {
    include __DIR__ . '/../layout/admin_layout.php';
} else {
    include __DIR__ . '/../layout/cliente_layout.php';
}
?>