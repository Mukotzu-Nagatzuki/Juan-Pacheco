<?php
// app/views/usuarios/registro.php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Dream House</title>
    <link rel="stylesheet" href="public/css/registro.css"> <!-- Cambiado a registro.css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'app/views/layout/header.php'; ?>

    <main class="auth-container">
        <div class="dual-form-registro"> <!-- Clase diferente -->
            <!-- Sección de Registro (lado izquierdo) -->
            <div class="registro-section"> <!-- Clase diferente -->
                <h2>Registrarse</h2>
                
                <form method="POST" action="index.php?action=registrarUsuario" class="registro-form">
                    <!-- Fila de Nombre y Apellido -->
                    <div class="form-row">
                        <div class="form-group half">
                            <label class="form-label">Nombre</label>
                            <input type="text" name="nombre" required>
                        </div>
                        <div class="form-group half">
                            <label class="form-label">Apellido</label>
                            <input type="text" name="apellido">
                        </div>
                    </div>

                    <!-- Campo de Correo Electrónico -->
                    <div class="form-group">
                        <label class="form-label">Correo Electrónico</label>
                        <input type="email" name="correo" required>
                    </div>

                    <!-- Campo de Contraseña -->
                    <div class="form-group">
                        <label class="form-label">Contraseña</label>
                        <input type="password" name="clave" required>
                    </div>

                    <!-- Campo de Teléfono -->
                    <div class="form-group">
                        <label class="form-label">Teléfono</label>
                        <input type="tel" name="telefono">
                    </div>

                    <!-- Campo de Dirección -->
                    <div class="form-group">
                        <label class="form-label">Dirección</label>
                        <input type="text" name="direccion">
                    </div>

                    <!-- Checkbox de Términos y Condiciones -->
                    <div class="checkbox-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="terminos" required>
                            <span class="checkmark"></span>
                            Registrarse
                        </label>
                    </div>

                    <!-- Texto de Términos y Condiciones -->
                    <div class="terms-text">
                        Al registrarte, aceptas nuestros<br>
                        <a href="#" class="terms-link">Términos y Condiciones</a>
                    </div>

                    <button type="submit" class="btn-registro">Registrarse</button> <!-- Clase diferente -->
                </form>
            </div>

            <!-- Sección de Iniciar Sesión (lado derecho) -->
            <div class="login-side-section"> <!-- Clase diferente -->
                <h2>Iniciar Sesión</h2>
                <h3>¿Ya tienes una cuenta?</h3>
                <a href="index.php?action=login" class="btn-login-side">Iniciar Sesión</a> <!-- Clase diferente -->
                
                <!-- Texto de Términos y Condiciones -->
                <div class="terms-text" style="color: rgba(255,255,255,0.8);">
                    Al registrarte, aceptas nuestros<br>
                    <a href="#" class="terms-link" style="color: white;">Términos y Condiciones</a>
                </div>
            </div>
        </div>
    </main>

    <?php include 'app/views/layout/footer.php'; ?>
</body>
</html>