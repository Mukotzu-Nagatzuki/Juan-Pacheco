<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/funciones.php';

// Verificar autenticación y obtener el ID del usuario
checkAuth();
$user_id = $_SESSION['usuario_id'] ?? null;

if (!$user_id) {
    header('Location: index.php?action=login');
    exit;
}

// Conexión a la base de datos
$db = new Database();
$conn = $db->getConnection();

// Obtener datos del usuario
$usuario = getUserProfile($user_id);

// =============================
// CONSULTA DE LISTA DE DESEOS
// =============================
try {
    $stmt = $conn->prepare("
        SELECT 
            p.id_producto, 
            p.nombre, 
            p.descripcion,
            p.precio, 
            p.medida,
            p.color,
            p.material,
            COALESCE(p.imagen_principal, 'default.png') AS imagen,
            c.nombre as categoria_nombre
        FROM lista_deseos d
        INNER JOIN productos p ON d.id_producto = p.id_producto
        LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
        WHERE d.id_usuario = :id_usuario AND p.estado = 'activo'
        ORDER BY d.fecha_agregado DESC
    ");
    $stmt->execute([':id_usuario' => $user_id]);
    $deseos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $deseos = [];
}

// Contar estadísticas
$totalDeseos = count($deseos);
$totalValor = array_sum(array_column($deseos, 'precio'));

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Mi Lista de Deseos</h1>
    <p>Guarda tus productos favoritos para comprarlos después</p>
</header>

<!-- ESTADÍSTICAS RÁPIDAS -->
<section class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-heart stat-icon"></i>
        <h3>Productos Guardados</h3>
        <span class="stat-number"><?= $totalDeseos ?></span>
        <p>En tu lista de deseos</p>
    </div>
    
    <div class="stat-card">
        <i class="bi bi-tags stat-icon"></i>
        <h3>Valor Total</h3>
        <span class="stat-number">S/ <?= number_format($totalValor, 2) ?></span>
        <p>De tus productos favoritos</p>
    </div>
    
    <div class="stat-card">
        <i class="bi bi-star stat-icon"></i>
        <h3>Categorías</h3>
        <span class="stat-number"><?= count(array_unique(array_column($deseos, 'categoria_nombre'))) ?></span>
        <p>Diferentes categorías</p>
    </div>
    
    <div class="stat-card">
        <i class="bi bi-cart-plus stat-icon"></i>
        <h3>Listos para Comprar</h3>
        <span class="stat-number"><?= $totalDeseos ?></span>
        <p>Productos disponibles</p>
    </div>
</section>

<!-- LISTA DE DESEOS -->
<section class="dashboard-section">
    <div class="section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3><i class="bi bi-heart-fill"></i> Mis Productos Favoritos</h3>
        <div style="color: #666; font-size: 0.9rem;">
            <span><?= $totalDeseos ?> producto(s) guardado(s)</span>
        </div>
    </div>

    <?php if (count($deseos) > 0): ?>
        <div class="wishlist-grid">
            <?php foreach ($deseos as $item): ?>
                <div class="wishlist-item">
                    <div class="wishlist-image">
                        <img src="public/img/productos/<?= htmlspecialchars($item['imagen']) ?>" 
                             alt="<?= htmlspecialchars($item['nombre']) ?>"
                             onerror="this.src='public/img/default-product.png'">
                        <div class="wishlist-actions">
                            <button class="btn-action btn-add-cart" onclick="agregarAlCarrito(<?= $item['id_producto'] ?>)">
                                <i class="bi bi-cart-plus"></i>
                            </button>
                            <button class="btn-action btn-remove" onclick="eliminarDeseo(<?= $item['id_producto'] ?>)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="wishlist-info">
                        <span class="wishlist-category"><?= htmlspecialchars($item['categoria_nombre'] ?? 'Sin categoría') ?></span>
                        <h4><?= htmlspecialchars($item['nombre']) ?></h4>
                        <p class="wishlist-description"><?= htmlspecialchars(substr($item['descripcion'] ?? '', 0, 80)) ?>...</p>
                        
                        <div class="wishlist-details">
                            <span class="detail-item">
                                <i class="bi bi-rulers"></i> <?= htmlspecialchars($item['medida'] ?? 'No especificado') ?>
                            </span>
                            <span class="detail-item">
                                <i class="bi bi-palette"></i> <?= htmlspecialchars($item['color'] ?? 'Varios') ?>
                            </span>
                            <span class="detail-item">
                                <i class="bi bi-text-paragraph"></i> <?= htmlspecialchars($item['material'] ?? 'No especificado') ?>
                            </span>
                        </div>
                        
                        <div class="wishlist-footer">
                            <span class="wishlist-price">S/ <?= number_format($item['precio'], 2) ?></span>
                            <button class="btn-ver" onclick="agregarAlCarrito(<?= $item['id_producto'] ?>)">
                                <i class="bi bi-cart-plus"></i> Agregar al Carrito
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- ACCIONES MASIVAS -->
        <div class="bulk-actions" style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--color-beige-claro);">
            <h4>Acciones en Lote</h4>
            <div style="display: flex; gap: 1rem; margin-top: 1rem; flex-wrap: wrap;">
                <button class="btn-ver" onclick="agregarTodosAlCarrito()">
                    <i class="bi bi-cart-check"></i> Agregar Todos al Carrito
                </button>
                <button class="btn-ver" style="background: #7a4555ff;" onclick="limpiarListaDeseos()">
                    <i class="bi bi-trash"></i> Limpiar Lista Completa
                </button>
                <a href="index.php?action=tienda" class="btn-ver" style="background: #4d8171ff;">
                    <i class="bi bi-bag-plus"></i> Seguir Comprando
                </a>
            </div>
        </div>
        
    <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon">
                <i class="bi bi-heart"></i>
            </div>
            <h3>Tu lista de deseos está vacía</h3>
            <p>Agrega productos que te gusten para verlos aquí y comprarlos más tarde</p>
            <div class="empty-actions">
                <a href="index.php?action=tienda" class="btn-ver">
                    <i class="bi bi-bag-plus"></i> Explorar Productos
                </a>
                <a href="index.php?action=productos" class="btn-ver" style="background: var(--color-beige-claro); color: var(--color-texto);">
                    <i class="bi bi-star"></i> Ver Más Populares
                </a>
            </div>
        </div>
    <?php endif; ?>
</section>

<!-- PRODUCTOS SUGERIDOS -->
<?php if ($totalDeseos > 0): ?>
<section class="dashboard-section">
    <h3><i class="bi bi-lightbulb"></i> Productos que te pueden gustar</h3>
    <div class="suggested-products">
        <?php
        // Obtener productos sugeridos basados en categorías de la lista de deseos
        $categorias_ids = array_unique(array_column($deseos, 'id_categoria'));
        if (!empty($categorias_ids)) {
            $placeholders = str_repeat('?,', count($categorias_ids) - 1) . '?';
            $stmtSuggested = $conn->prepare("
                SELECT p.*, c.nombre as categoria_nombre 
                FROM productos p 
                LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                WHERE p.id_categoria IN ($placeholders) AND p.estado = 'activo' 
                AND p.id_producto NOT IN (SELECT id_producto FROM lista_deseos WHERE id_usuario = ?)
                ORDER BY RAND() LIMIT 4
            ");
            $params = array_merge($categorias_ids, [$user_id]);
            $stmtSuggested->execute($params);
            $sugeridos = $stmtSuggested->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($sugeridos as $sugerido): ?>
                <div class="suggested-item">
                    <img src="public/img/productos/<?= htmlspecialchars($sugerido['imagen_principal'] ?? 'default.png') ?>" 
                         alt="<?= htmlspecialchars($sugerido['nombre']) ?>">
                    <h5><?= htmlspecialchars($sugerido['nombre']) ?></h5>
                    <p class="price">S/ <?= number_format($sugerido['precio'], 2) ?></p>
                    <button class="btn-ver btn-sm" onclick="agregarDeseo(<?= $sugerido['id_producto'] ?>)">
                        <i class="bi bi-heart"></i> Agregar
                    </button>
                </div>
            <?php endforeach;
        }
        ?>
    </div>
</section>
<?php endif; ?>

<script>
function eliminarDeseo(id_producto) {
    if (confirm("¿Estás seguro de que quieres eliminar este producto de tu lista de deseos?")) {
        window.location.href = "index.php?action=eliminar_deseo&id=" + id_producto;
    }
}

function agregarDeseo(id_producto) {
    window.location.href = "index.php?action=agregar_deseo&id=" + id_producto;
}

function agregarAlCarrito(id_producto) {
    if (confirm("¿Agregar este producto al carrito de compras?")) {
        window.location.href = "index.php?action=agregar_carrito&id=" + id_producto + "&from=wishlist";
    }
}

function agregarTodosAlCarrito() {
    if (confirm("¿Agregar todos los productos de tu lista de deseos al carrito?")) {
        window.location.href = "index.php?action=agregar_todos_carrito";
    }
}

function limpiarListaDeseos() {
    if (confirm("¿Estás seguro de que quieres eliminar todos los productos de tu lista de deseos? Esta acción no se puede deshacer.")) {
        window.location.href = "index.php?action=limpiar_lista_deseos";
    }
}
</script>

<style>
.wishlist-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 1.5rem;
}

.wishlist-item {
    background: #fff;
    border-radius: var(--radio);
    box-shadow: var(--sombra);
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.wishlist-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(107, 93, 85, 0.15);
}

.wishlist-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.wishlist-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.wishlist-item:hover .wishlist-image img {
    transform: scale(1.05);
}

.wishlist-actions {
    position: absolute;
    top: 10px;
    right: 10px;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.wishlist-item:hover .wishlist-actions {
    opacity: 1;
}

.btn-action {
    background: rgba(255, 255, 255, 0.9);
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    color: var(--color-texto);
}

.btn-action:hover {
    background: #fff;
    transform: scale(1.1);
}

.btn-add-cart:hover {
    color: #28a745;
}

.btn-remove:hover {
    color: #dc3545;
}

.wishlist-info {
    padding: 1.5rem;
}

.wishlist-category {
    background: var(--color-fondo);
    color: var(--color-principal);
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 0.75rem;
}

.wishlist-info h4 {
    margin: 0 0 0.5rem 0;
    color: var(--color-texto);
    font-size: 1.1rem;
    line-height: 1.4;
}

.wishlist-description {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 1rem;
    line-height: 1.5;
}

.wishlist-details {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.detail-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #666;
    font-size: 0.85rem;
}

.detail-item i {
    color: var(--color-secundario);
    width: 16px;
}

.wishlist-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid var(--color-beige-claro);
}

.wishlist-price {
    font-size: 1.25rem;
    font-weight: bold;
    color: var(--color-principal);
}

.empty-state {
    text-align: center;
    padding: 3rem;
    color: #7f8c8d;
}

.empty-icon {
    font-size: 4rem;
    color: var(--color-beige-claro);
    margin-bottom: 1.5rem;
}

.empty-state h3 {
    margin-bottom: 1rem;
    color: var(--color-texto);
}

.empty-state p {
    margin-bottom: 2rem;
    font-size: 1.1rem;
}

.empty-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.suggested-products {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}

.suggested-item {
    background: #fff;
    padding: 1rem;
    border-radius: var(--radio);
    box-shadow: var(--sombra);
    text-align: center;
    transition: transform 0.3s ease;
}

.suggested-item:hover {
    transform: translateY(-3px);
}

.suggested-item img {
    width: 100%;
    height: 120px;
    object-fit: cover;
    border-radius: 5px;
    margin-bottom: 0.75rem;
}

.suggested-item h5 {
    margin: 0.5rem 0;
    color: var(--color-texto);
    font-size: 0.9rem;
}

.suggested-item .price {
    font-weight: bold;
    color: var(--color-principal);
    margin-bottom: 0.75rem;
}

.btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.8rem;
}

.bulk-actions {
    background: var(--color-fondo);
    padding: 1.5rem;
    border-radius: var(--radio);
}

@media (max-width: 768px) {
    .wishlist-grid {
        grid-template-columns: 1fr;
    }
    
    .wishlist-footer {
        flex-direction: column;
        gap: 1rem;
        align-items: stretch;
    }
    
    .empty-actions {
        flex-direction: column;
    }
    
    .bulk-actions div {
        flex-direction: column;
    }
    
    .wishlist-actions {
        opacity: 1; /* Siempre visibles en móvil */
    }
}
</style>

<?php
$content = ob_get_clean();

// Incluir el layout del cliente
include __DIR__ . '/../layout/cliente_layout.php';
?>