<?php
// app/views/usuarios/login.php
$error = $_GET['error'] ?? '';
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Dream House</title>
    <link rel="stylesheet" href="public/css/auth.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'app/views/layout/header.php'; ?>

    <main class="auth-container">
        <div class="dual-form">
            <!-- Sección de Iniciar Sesión (lado izquierdo) -->
            <div class="login-section">
                <h2>Iniciar Sesión</h2>
                
                <?php if ($msg == 'registrado'): ?>
                    <div class="success-message message-container" id="successMessage">
                        ¡Registro exitoso! Ahora puedes iniciar sesión.
                    </div>
                <?php endif; ?>

                <?php if ($error == '1'): ?>
                    <div class="error-message message-container" id="errorMessage">
                        Correo o contraseña incorrectos.
                    </div>
                <?php endif; ?>

                <form method="POST" action="index.php?action=loginUsuario" class="login-form">
                    <!-- Campo de Correo Electrónico -->
                    <div class="form-group">
                        <input type="email" name="correo" placeholder="Correo Electrónico" required>
                    </div>

                    <!-- Campo de Contraseña -->
                    <div class="form-group">
                        <input type="password" name="clave" placeholder="Contraseña" required>
                    </div>

                    <button type="submit" class="btn-login-submit">Iniciar Sesión</button>

                    <!-- Enlace de olvidó contraseña -->
                    <div class="forgot-password">
                        <a href="#" class="forgot-link">¿Olvidaste tu Contraseña?</a>
                    </div>
                </form>
            </div>

            <!-- Sección de Registro (lado derecho) -->
            <div class="register-section">
                <h2>Registrarse</h2>
                <a href="index.php?action=registro" class="btn-register-link">Crear Cuenta</a>
                
                <!-- Texto de Términos y Condiciones -->
                <div class="terms-text">
                    Al registrarte, aceptas nuestros<br>
                    <a href="#" class="terms-link">Términos y Condiciones</a>
                </div>
            </div>
        </div>
    </main>

    <?php include 'app/views/layout/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const successMessage = document.getElementById('successMessage');
            const errorMessage = document.getElementById('errorMessage');
            
            function hideMessage(element) {
                if (element) {
                    // Agregar clase para iniciar la transición
                    element.classList.add('hiding');
                    
                    // Esperar a que termine la transición y luego remover el elemento
                    setTimeout(() => {
                        if (element.parentNode) {
                            element.parentNode.removeChild(element);
                        }
                    }, 600); // Tiempo igual a la duración de la transición
                }
            }
            
            // Ocultar mensaje de éxito después de 3 segundos
            if (successMessage) {
                setTimeout(() => hideMessage(successMessage), 3000);
            }
            
            // Ocultar mensaje de error después de 3 segundos
            if (errorMessage) {
                setTimeout(() => hideMessage(errorMessage), 3000);
            }
        });
    </script>
</body>
</html>