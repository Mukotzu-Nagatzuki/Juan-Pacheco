<?php 
require_once __DIR__ . '/../../helpers/funciones.php';
require_once __DIR__ . '/../../models/Pedido.php';

checkAuth();

$user_id = $_SESSION['usuario_id'];
$usuario = getUserProfile($user_id);

// Obtener pedidos del usuario
$pedidos = obtenerPedidosUsuario($user_id);

// Contadores por estado
$totalPedidos = count($pedidos);
$entregados = count(array_filter($pedidos, fn($p) => $p['estado'] === 'entregado'));
$enCamino = count(array_filter($pedidos, fn($p) => $p['estado'] === 'en reparto'));
$pendientes = count(array_filter($pedidos, fn($p) => $p['estado'] === 'pendiente'));

// Obtener estadísticas adicionales
$totalGastado = array_sum(array_column($pedidos, 'total'));
$pedidosRecientes = array_slice($pedidos, 0, 5); // Últimos 5 pedidos

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>¡Hola, <?= htmlspecialchars($usuario['nombre'] ?? '') ?>!</h1>
    <p>Bienvenido a tu área personal de Dream House</p>
</header>

<!-- ESTADÍSTICAS RÁPIDAS -->
<section class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-bag-check stat-icon"></i>
        <h3>Total Pedidos</h3>
        <span class="stat-number"><?= $totalPedidos ?></span>
        <p>Todos tus pedidos</p>
    </div>
    
    <div class="stat-card">
        <i class="bi bi-truck stat-icon"></i>
        <h3>En Camino</h3>
        <span class="stat-number"><?= $enCamino ?></span>
        <p>Pedidos en reparto</p>
    </div>
    
    <div class="stat-card">
        <i class="bi bi-check-circle stat-icon"></i>
        <h3>Entregados</h3>
        <span class="stat-number"><?= $entregados ?></span>
        <p>Pedidos completados</p>
    </div>
    
    <div class="stat-card">
        <i class="bi bi-currency-dollar stat-icon"></i>
        <h3>Total Gastado</h3>
        <span class="stat-number">S/ <?= number_format($totalGastado, 2) ?></span>
        <p>En todas tus compras</p>
    </div>
</section>

<!-- ACCIONES RÁPIDAS -->
<section class="dashboard-section">
    <h3><i class="bi bi-lightning"></i> Acciones Rápidas</h3>
    <div class="quick-actions">
        <a href="index.php?action=tienda" class="quick-action-card">
            <i class="bi bi-cart-plus"></i>
            <h4>Realizar Compra</h4>
            <p>Explora nuestros productos</p>
        </a>
        
        <a href="index.php?action=pedidos" class="quick-action-card">
            <i class="bi bi-bag-check"></i>
            <h4>Ver Pedidos</h4>
            <p>Revisa tus compras</p>
        </a>
        
        <a href="index.php?action=perfil" class="quick-action-card">
            <i class="bi bi-person-gear"></i>
            <h4>Mi Perfil</h4>
            <p>Actualiza tus datos</p>
        </a>
        
        <a href="index.php?action=deseos" class="quick-action-card">
            <i class="bi bi-heart"></i>
            <h4>Lista de Deseos</h4>
            <p>Tus productos favoritos</p>
        </a>
    </div>
</section>

<!-- PEDIDOS RECIENTES -->
<section class="dashboard-section">
    <h3><i class="bi bi-clock-history"></i> Pedidos Recientes</h3>
    
    <?php if (!empty($pedidosRecientes)): ?>
        <div class="recent-orders">
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>ID Pedido</th>
                        <th>Fecha</th>
                        <th>Productos</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedidosRecientes as $pedido): ?>
                        <?php
                        $cantidadProductos = contarProductosPedido($pedido['id_pedido']);
                        ?>
                        <tr>
                            <td><strong>#<?= str_pad($pedido['id_pedido'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                            <td><?= date('d/m/Y', strtotime($pedido['fecha_pedido'])) ?></td>
                            <td><?= $cantidadProductos ?> producto(s)</td>
                            <td><strong>S/ <?= number_format($pedido['total'], 2) ?></strong></td>
                            <td>
                                <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $pedido['estado'])) ?>">
                                    <?= ucfirst($pedido['estado']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="index.php?action=ver_pedido&id=<?= $pedido['id_pedido'] ?>" class="btn-ver">
                                    <i class="bi bi-eye"></i> Ver
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div style="text-align: center; margin-top: 1rem;">
            <a href="index.php?action=pedidos" class="btn-ver">
                <i class="bi bi-list-ul"></i> Ver Todos los Pedidos
            </a>
        </div>
        
    <?php else: ?>
        <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
            <i class="bi bi-bag-x" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
            <h4>No hay pedidos recientes</h4>
            <p>Aún no has realizado ningún pedido.</p>
            <a href="index.php?action=tienda" class="btn-ver" style="margin-top: 1rem;">
                <i class="bi bi-cart-plus"></i> Realizar Mi Primera Compra
            </a>
        </div>
    <?php endif; ?>
</section>

<!-- INFORMACIÓN DE CONTACTO -->
<section class="dashboard-section">
    <h3><i class="bi bi-telephone"></i> ¿Necesitas Ayuda?</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-top: 1rem;">
        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: var(--radio); text-align: center;">
            <i class="bi bi-whatsapp" style="font-size: 2rem; color: #6d405cff; margin-bottom: 1rem;"></i>
            <h4>WhatsApp</h4>
            <p>+51 904 407 729</p>
            <small style="color: #666;">Soporte inmediato</small>
        </div>
        
        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: var(--radio); text-align: center;">
            <i class="bi bi-envelope" style="font-size: 2rem; color: var(--color-secundario); margin-bottom: 1rem;"></i>
            <h4>Email</h4>
            <p>soporte@dreamhouse.com</p>
            <small style="color: #666;">Respuesta en 24h</small>
        </div>
        
        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: var(--radio); text-align: center;">
            <i class="bi bi-clock" style="font-size: 2rem; color: var(--color-principal); margin-bottom: 1rem;"></i>
            <h4>Horario</h4>
            <p>Lun - Vie: 9am - 6pm</p>
            <p>Sáb: 9am - 1pm</p>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();

// Incluir el layout del cliente
include __DIR__ . '/../layout/cliente_layout.php';
?>