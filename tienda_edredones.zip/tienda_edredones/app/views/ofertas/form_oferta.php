<?php
$esEdicion = isset($oferta);
$titulo = $esEdicion ? 'Editar Oferta' : 'Crear Nueva Oferta';

// Obtener la fecha y hora actual para usar como mínimo en los inputs
// CAMBIO: Permitir que comience desde hoy, no desde mañana
$fecha_actual = date('Y-m-d\TH:i');
ob_start();
?>

<header class="header">
    <h1><?= $esEdicion?><?= $titulo ?></h1>
    <p><?= $esEdicion ? 'Modifica los datos de la oferta existente' : 'Completa el formulario para crear una nueva oferta promocional' ?></p>
</header>

<div class="form-section">
    <div class="form-container">
        <form method="POST" class="form offer-form" id="ofertaForm">
            <!-- Información Básica -->
            <div class="form-section-card">
                <div class="section-header">
                    <i class="bi bi-info-circle"></i>
                    <h3>Información Básica</h3>
                </div>
                <div class="form-content">
                    <div class="form-group">
                        <label for="codigo_oferta" class="form-label">
                            Código de Oferta <span class="required">*</span>
                        </label>
                        <div class="input-with-icon">
                            <i class="bi bi-tag"></i>
                            <input type="text" id="codigo_oferta" name="codigo_oferta" 
                                   value="<?= $esEdicion ? htmlspecialchars($oferta['codigo_oferta']) : '' ?>" 
                                   placeholder="EJ: VERANO25"
                                   class="form-input"
                                   required>
                        </div>
                        <small class="form-hint">Este código será usado por los clientes para aplicar el descuento</small>
                    </div>

                    <div class="form-group">
                        <label for="descripcion" class="form-label">Descripción de la Oferta</label>
                        <div class="textarea-with-icon">
                            <i class="bi bi-text-paragraph"></i>
                            <textarea id="descripcion" name="descripcion" rows="3" 
                                      placeholder="Describe los detalles y beneficios de esta oferta..."
                                      class="form-textarea"><?= $esEdicion ? htmlspecialchars($oferta['descripcion']) : '' ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Configuración del Descuento -->
            <div class="form-section-card">
                <div class="section-header">
                    <i class="bi bi-percent"></i>
                    <h3>Configuración del Descuento</h3>
                </div>
                <div class="form-content">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="tipo_descuento" class="form-label">
                                Tipo de Descuento <span class="required">*</span>
                            </label>
                            <div class="select-with-icon">
                                <i class="bi bi-graph-up"></i>
                                <select id="tipo_descuento" name="tipo_descuento" class="form-select" required>
                                    <option value="porcentaje" <?= $esEdicion && $oferta['tipo_descuento'] === 'porcentaje' ? 'selected' : '' ?>>Porcentaje (%)</option>
                                    <option value="monto_fijo" <?= $esEdicion && $oferta['tipo_descuento'] === 'monto_fijo' ? 'selected' : '' ?>>Monto Fijo (S/)</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="valor_descuento" class="form-label">
                                Valor de Descuento <span class="required">*</span>
                            </label>
                            <div class="input-with-icon">
                                <i class="bi bi-currency-dollar"></i>
                                <input type="number" id="valor_descuento" name="valor_descuento" 
                                       step="0.01" 
                                       min="0" 
                                       value="<?= $esEdicion ? $oferta['valor_descuento'] : '' ?>" 
                                       placeholder="<?= $esEdicion && $oferta['tipo_descuento'] === 'porcentaje' ? '10.00' : '25.00' ?>"
                                       class="form-input"
                                       required>
                            </div>
                            <small class="form-hint" id="descuento-hint">
                                <?= $esEdicion && $oferta['tipo_descuento'] === 'porcentaje' ? 'Porcentaje de descuento (ej: 10 para 10%)' : 'Monto fijo de descuento en soles' ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Vigencia de la Oferta -->
            <div class="form-section-card">
                <div class="section-header">
                    <i class="bi bi-calendar-range"></i>
                    <h3>Vigencia de la Oferta</h3>
                </div>
                <div class="form-content">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="fecha_inicio" class="form-label">
                                Fecha de Inicio <span class="required">*</span>
                            </label>
                            <div class="input-with-icon">
                                <i class="bi bi-play-circle"></i>
                                <input type="datetime-local" id="fecha_inicio" name="fecha_inicio" 
                                       value="<?= $esEdicion ? date('Y-m-d\TH:i', strtotime($oferta['fecha_inicio'])) : $fecha_actual ?>" 
                                       min="<?= date('Y-m-d\TH:i', strtotime('-1 day')) ?>" 
                                       class="form-input"
                                       required>
                            </div>
                            <small class="form-hint">Puede comenzar hoy mismo</small>
                        </div>

                        <div class="form-group">
                            <label for="fecha_fin" class="form-label">
                                Fecha de Fin <span class="required">*</span>
                            </label>
                            <div class="input-with-icon">
                                <i class="bi bi-flag"></i>
                                <input type="datetime-local" id="fecha_fin" name="fecha_fin" 
                                       value="<?= $esEdicion ? date('Y-m-d\TH:i', strtotime($oferta['fecha_fin'])) : '' ?>" 
                                       min="<?= $fecha_actual ?>"
                                       class="form-input"
                                       required>
                            </div>
                            <small class="form-hint">La oferta debe terminar después de la fecha de inicio</small>
                        </div>
                    </div>
                    <div class="date-validation" id="date-validation" style="display: none;">
                        <div class="validation-message error">
                            <i class="bi bi-exclamation-triangle"></i>
                            <span id="validation-text"></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Restricciones y Configuraciones -->
            <div class="form-section-card">
                <div class="section-header">
                    <i class="bi bi-gear"></i>
                    <h3>Restricciones y Configuraciones</h3>
                </div>
                <div class="form-content">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="usos_maximos" class="form-label">Límite de Usos</label>
                            <div class="input-with-icon">
                                <i class="bi bi-people"></i>
                                <input type="number" id="usos_maximos" name="usos_maximos" 
                                       min="1" 
                                       value="<?= $esEdicion ? $oferta['usos_maximos'] : '' ?>"
                                       placeholder="Ej: 100"
                                       class="form-input">
                            </div>
                            <small class="form-hint">Dejar vacío para usos ilimitados</small>
                        </div>

                        <div class="form-group">
                            <label for="minimo_compra" class="form-label">Mínimo de Compra</label>
                            <div class="input-with-icon">
                                <i class="bi bi-basket"></i>
                                <input type="number" id="minimo_compra" name="minimo_compra" 
                                       step="0.01" min="0" 
                                       value="<?= $esEdicion ? $oferta['minimo_compra'] : '0' ?>"
                                       placeholder="0.00"
                                       class="form-input">
                            </div>
                            <small class="form-hint">Monto mínimo de compra para aplicar el descuento</small>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="checkbox-card">
                            <input type="checkbox" id="aplica_todo" name="aplica_todo" value="1" 
                                   <?= $esEdicion && $oferta['aplica_todo'] ? 'checked' : 'checked' ?>
                                   class="checkbox-input">
                            <label for="aplica_todo" class="checkbox-label">
                                <div class="checkbox-content">
                                    <i class="bi bi-globe"></i>
                                    <div class="checkbox-text">
                                        <span class="checkbox-title">Aplicar a todos los productos</span>
                                        <span class="checkbox-description">La oferta estará disponible para todos los productos del catálogo</span>
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="estado" class="form-label">
                            Estado de la Oferta <span class="required">*</span>
                        </label>
                        <div class="select-with-icon">
                            <i class="bi bi-power"></i>
                            <select id="estado" name="estado" class="form-select" required>
                                <option value="activa" <?= $esEdicion && $oferta['estado'] === 'activa' ? 'selected' : '' ?>>🟢 Activa - Disponible para clientes</option>
                                <option value="inactiva" <?= $esEdicion && $oferta['estado'] === 'inactiva' ? 'selected' : '' ?>>🔴 Inactiva - No disponible temporalmente</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Acciones del Formulario -->
            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-submit" id="submit-btn">
                    <i class="bi bi-<?= $esEdicion ? 'check-lg' : 'plus-circle' ?>"></i>
                    <?= $esEdicion ? 'Actualizar Oferta' : 'Crear Oferta' ?>
                </button>
                <a href="/index.php?action=gestion_ofertas" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Cancelar
                </a>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tipoDescuento = document.getElementById('tipo_descuento');
    const valorDescuento = document.getElementById('valor_descuento');
    const descuentoHint = document.getElementById('descuento-hint');
    const fechaInicio = document.getElementById('fecha_inicio');
    const fechaFin = document.getElementById('fecha_fin');
    const dateValidation = document.getElementById('date-validation');
    const validationText = document.getElementById('validation-text');
    const submitBtn = document.getElementById('submit-btn');
    const form = document.getElementById('ofertaForm');
    
    // Obtener fecha y hora actual
    const now = new Date();
    const currentDateTime = now.toISOString().slice(0, 16);
    
    // CAMBIO: Permitir que la fecha de inicio sea desde hoy (ayer)
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayDateTime = yesterday.toISOString().slice(0, 16);
    
    // Establecer mínimos
    fechaInicio.min = yesterdayDateTime; // CAMBIO: Permitir desde ayer
    fechaFin.min = currentDateTime; // Fin debe ser desde hoy en adelante
    
    function actualizarPlaceholderYHint() {
        if (tipoDescuento.value === 'porcentaje') {
            valorDescuento.placeholder = '10.00';
            descuentoHint.textContent = 'Porcentaje de descuento (ej: 10 para 10%)';
        } else {
            valorDescuento.placeholder = '25.00';
            descuentoHint.textContent = 'Monto fijo de descuento en soles';
        }
    }
    
    function validarFechas() {
        const inicio = fechaInicio.value;
        const fin = fechaFin.value;
        let isValid = true;
        let message = '';
        
        // Ocultar mensaje de validación por defecto
        dateValidation.style.display = 'none';
        fechaInicio.classList.remove('input-error');
        fechaFin.classList.remove('input-error');
        
        if (inicio && fin) {
            if (inicio > fin) {
                isValid = false;
                message = 'La fecha de fin no puede ser anterior a la fecha de inicio';
                fechaFin.classList.add('input-error');
            }
        }
        
        // CAMBIO: Eliminar validación que impedía fechas pasadas para fecha_inicio
        // Permitimos que la fecha de inicio pueda ser en el pasado (incluso ayer)
        
        if (fin && fin < currentDateTime) {
            isValid = false;
            message = 'La fecha de fin no puede ser en el pasado';
            fechaFin.classList.add('input-error');
        }
        
        if (!isValid) {
            validationText.textContent = message;
            dateValidation.style.display = 'block';
        }
        
        return isValid;
    }
    
    function actualizarMinFechaFin() {
        if (fechaInicio.value) {
            fechaFin.min = fechaInicio.value;
        } else {
            fechaFin.min = currentDateTime;
        }
    }
    
    // Event listeners
    tipoDescuento.addEventListener('change', actualizarPlaceholderYHint);
    
    fechaInicio.addEventListener('change', function() {
        actualizarMinFechaFin();
        validarFechas();
    });
    
    fechaFin.addEventListener('change', function() {
        validarFechas();
    });
    
    form.addEventListener('submit', function(e) {
        if (!validarFechas()) {
            e.preventDefault();
            // Scroll to validation message
            dateValidation.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    });
    
    // Inicializar
    actualizarPlaceholderYHint();
    actualizarMinFechaFin();
    
    // Validación en tiempo real mientras el usuario interactúa
    fechaInicio.addEventListener('input', validarFechas);
    fechaFin.addEventListener('input', validarFechas);
});
</script>

<style>
/* Contenedor principal del formulario */
.form-section {
    max-width: 900px;
    margin: 0 auto;
}

.form-container {
    background: white;
    border-radius: 12px;
    border: 1px solid var(--color-beige-claro);
    box-shadow: 0 4px 20px rgba(107, 93, 85, 0.08);
    overflow: hidden;
}

/* Tarjetas de sección */
.form-section-card {
    border-bottom: 1px solid var(--color-beige-claro);
}

.form-section-card:last-child {
    border-bottom: none;
}

.section-header {
    padding: 1.5rem 2rem;
    background: #faf7f5;
    border-bottom: 1px solid var(--color-beige-claro);
    display: flex;
    align-items: center;
    gap: 1rem;
}

.section-header i {
    color: var(--color-secundario);
    font-size: 1.25rem;
}

.section-header h3 {
    margin: 0;
    color: var(--color-texto);
    font-size: 1.1rem;
    font-weight: 600;
}

.form-content {
    padding: 2rem;
}

/* Grupos de formulario */
.form-group {
    margin-bottom: 1.5rem;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
}

.form-label {
    display: block;
    margin-bottom: 0.5rem;
    color: var(--color-texto);
    font-weight: 600;
    font-size: 0.9rem;
}

.required {
    color: #e74c3c;
}

.form-hint {
    display: block;
    margin-top: 0.5rem;
    color: var(--color-plomo);
    font-size: 0.8rem;
    line-height: 1.4;
}

/* Inputs con iconos */
.input-with-icon,
.select-with-icon,
.textarea-with-icon {
    position: relative;
    display: flex;
    align-items: center;
}

.input-with-icon i,
.select-with-icon i,
.textarea-with-icon i {
    position: absolute;
    left: 1rem;
    color: var(--color-secundario);
    z-index: 2;
}

.textarea-with-icon i {
    align-self: flex-start;
    margin-top: 1rem;
}

.form-input,
.form-select,
.form-textarea {
    width: 100%;
    padding: 0.75rem 1rem 0.75rem 2.5rem;
    border: 1px solid var(--color-beige-claro);
    border-radius: 8px;
    background: white;
    color: var(--color-texto);
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.form-textarea {
    resize: vertical;
    min-height: 80px;
    padding-top: 1rem;
}

.form-input:focus,
.form-select:focus,
.form-textarea:focus {
    outline: none;
    border-color: var(--color-secundario);
    box-shadow: 0 0 0 3px rgba(146, 109, 133, 0.1);
}

.form-input::placeholder,
.form-textarea::placeholder {
    color: var(--color-plomo);
    opacity: 0.7;
}

/* Validación de fechas */
.date-validation {
    margin-top: 1rem;
    padding: 1rem;
    border-radius: 8px;
    animation: slideDown 0.3s ease;
}

.validation-message {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    font-weight: 500;
}

.validation-message.error {
    background: rgba(231, 76, 60, 0.1);
    border: 1px solid rgba(231, 76, 60, 0.2);
    color: #6f1c72ff;
    padding: 0.75rem 1rem;
    border-radius: 6px;
}

.validation-message.error i {
    color: #e74c3c;
}

.input-error {
    border-color: #e74c3c !important;
    background: rgba(231, 76, 60, 0.02) !important;
}

.input-error:focus {
    box-shadow: 0 0 0 3px rgba(231, 76, 60, 0.1) !important;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Checkbox mejorado */
.checkbox-card {
    border: 1px solid var(--color-beige-claro);
    border-radius: 8px;
    padding: 1rem;
    background: #faf7f5;
    transition: all 0.3s ease;
}

.checkbox-card:hover {
    border-color: var(--color-secundario);
    background: white;
}

.checkbox-input {
    display: none;
}

.checkbox-label {
    display: block;
    cursor: pointer;
    margin: 0;
}

.checkbox-content {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
}

.checkbox-content i {
    color: var(--color-secundario);
    font-size: 1.25rem;
    margin-top: 0.125rem;
}

.checkbox-text {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.checkbox-title {
    color: var(--color-texto);
    font-weight: 600;
    font-size: 0.9rem;
}

.checkbox-description {
    color: var(--color-plomo);
    font-size: 0.8rem;
    line-height: 1.4;
}

.checkbox-input:checked + .checkbox-label .checkbox-card {
    background: rgba(146, 109, 133, 0.05);
    border-color: var(--color-secundario);
}

/* Acciones del formulario */
.form-actions {
    padding: 2rem;
    background: #faf7f5;
    border-top: 1px solid var(--color-beige-claro);
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    flex-wrap: wrap;
}

.btn-submit {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 2rem;
    font-weight: 600;
    font-size: 0.95rem;
}

.btn-secondary {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    text-decoration: none;
}

/* Estados de validación */
.form-input:invalid:not(:focus):not(:placeholder-shown) {
    border-color: #e74c3c;
    background: rgba(231, 76, 60, 0.02);
}

.form-input:valid:not(:focus):not(:placeholder-shown) {
    border-color: #27ae60;
    background: rgba(39, 174, 96, 0.02);
}

/* Responsive */
@media (max-width: 768px) {
    .form-section {
        margin: 0 1rem;
    }
    
    .section-header {
        padding: 1.25rem 1.5rem;
    }
    
    .form-content {
        padding: 1.5rem;
    }
    
    .form-row {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .form-actions {
        padding: 1.5rem;
        flex-direction: column;
    }
    
    .btn-submit,
    .btn-secondary {
        justify-content: center;
        width: 100%;
    }
    
    .form-input,
    .form-select,
    .form-textarea {
        padding: 0.75rem 1rem 0.75rem 2.5rem;
    }
}

@media (max-width: 480px) {
    .section-header {
        padding: 1rem 1.25rem;
    }
    
    .form-content {
        padding: 1.25rem;
    }
    
    .checkbox-content {
        flex-direction: column;
        gap: 0.5rem;
        text-align: center;
    }
    
    .checkbox-content i {
        align-self: center;
    }
}

/* Animaciones suaves */
.form-section-card {
    transition: transform 0.2s ease;
}

.form-section-card:hover {
    transform: translateX(5px);
}

.btn-submit {
    position: relative;
    overflow: hidden;
}

.btn-submit:before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
}

.btn-submit:hover:before {
    left: 100%;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>