<?php
ob_start();
?>

<header class="header">
    <h1>Estadísticas de Oferta: <?= htmlspecialchars($oferta['codigo_oferta']) ?></h1>
    <p>Análisis detallado del uso y efectividad de esta oferta</p>
</header>

<div class="breadcrumb">
    <a href="index.php?action=gestion_ofertas" class="breadcrumb-link">
        <i class="bi bi-arrow-left"></i> Volver a Gestión de Ofertas
    </a>
</div>

<!-- Estadísticas Principales -->
<div class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-graph-up-arrow stat-icon"></i>
        <h3>Total de Usos</h3>
        <div class="stat-number"><?= $estadisticas['total_usos'] ?? 0 ?></div>
        <p>Veces utilizada</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-currency-dollar stat-icon"></i>
        <h3>Total Descuento</h3>
        <div class="stat-number">S/ <?= number_format($estadisticas['total_descuento'] ?? 0, 2) ?></div>
        <p>Monto total descontado</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-calculator stat-icon"></i>
        <h3>Promedio por Uso</h3>
        <div class="stat-number">S/ <?= number_format($estadisticas['promedio_descuento'] ?? 0, 2) ?></div>
        <p>Descuento promedio</p>
    </div>

    <div class="stat-card">
        <i class="bi bi-percent stat-icon"></i>
        <h3>Tasa de Uso</h3>
        <div class="stat-number">
            <?php if ($oferta['usos_maximos']): ?>
                <?= number_format(($oferta['usos_actuales'] / $oferta['usos_maximos']) * 100, 1) ?>%
            <?php else: ?>
                Ilimitado
            <?php endif; ?>
        </div>
        <p>Capacidad utilizada</p>
    </div>
</div>

<!-- Información de la Oferta -->
<div class="info-section">
    <h3>Información de la Oferta</h3>
    <div class="info-grid">
        <div class="info-item">
            <label>Código:</label>
            <span class="info-value"><?= htmlspecialchars($oferta['codigo_oferta']) ?></span>
        </div>
        <div class="info-item">
            <label>Descripción:</label>
            <span class="info-value"><?= htmlspecialchars($oferta['descripcion']) ?></span>
        </div>
        <div class="info-item">
            <label>Tipo de Descuento:</label>
            <span class="info-value">
                <?= $oferta['tipo_descuento'] === 'porcentaje' ? 'Porcentaje (' . $oferta['valor_descuento'] . '%)' : 'Monto Fijo (S/ ' . number_format($oferta['valor_descuento'], 2) . ')' ?>
            </span>
        </div>
        <div class="info-item">
            <label>Vigencia:</label>
            <span class="info-value">
                <?= date('d/m/Y H:i', strtotime($oferta['fecha_inicio'])) ?> - <?= date('d/m/Y H:i', strtotime($oferta['fecha_fin'])) ?>
            </span>
        </div>
        <div class="info-item">
            <label>Mínimo de Compra:</label>
            <span class="info-value">S/ <?= number_format($oferta['minimo_compra'], 2) ?></span>
        </div>
        <div class="info-item">
            <label>Estado:</label>
            <span class="status-badge status-<?= $oferta['estado'] ?>">
                <?= ucfirst($oferta['estado']) ?>
            </span>
        </div>
    </div>
</div>

<!-- Historial de Usos -->
<div class="table-container">
    <h3>📝 Historial de Usos</h3>
    <?php if (empty($usos)): ?>
        <div class="empty-state">
            <i class="bi bi-receipt"></i>
            <h4>No hay registros de uso</h4>
            <p>Esta oferta aún no ha sido utilizada por ningún cliente.</p>
        </div>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Pedido</th>
                    <th>Fecha de Uso</th>
                    <th>Descuento Aplicado</th>
                    <th>Total Pedido</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usos as $uso): ?>
                    <tr>
                        <td><?= htmlspecialchars($uso['nombre'] . ' ' . $uso['apellido']) ?></td>
                        <td>DH-<?= str_pad($uso['id_pedido'], 4, '0', STR_PAD_LEFT) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($uso['fecha_uso'])) ?></td>
                        <td class="text-success">-S/ <?= number_format($uso['monto_descuento'], 2) ?></td>
                        <td>S/ <?= number_format($uso['total'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="form-actions">
    <a href="index.php?action=gestion_ofertas" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Volver a Ofertas
    </a>
    <a href="index.php?action=editar_oferta&id=<?= $oferta['id_oferta'] ?>" class="btn btn-primary">
        <i class="bi bi-pencil"></i> Editar Oferta
    </a>
</div>

<style>
.breadcrumb {
    margin-bottom: 2rem;
}

.breadcrumb-link {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--color-secundario);
    text-decoration: none;
    font-weight: 500;
}

.breadcrumb-link:hover {
    color: var(--color-pastel);
}

.info-section {
    background: white;
    border-radius: 10px;
    padding: 2rem;
    margin: 2rem 0;
    border: 1px solid var(--color-beige-claro);
}

.info-section h3 {
    margin-bottom: 1.5rem;
    color: var(--color-texto);
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background: #faf7f5;
    border-radius: 8px;
}

.info-item label {
    font-weight: 600;
    color: var(--color-texto);
}

.info-value {
    color: var(--color-plomo);
    font-weight: 500;
}

.text-success {
    color: #325b81ff;
    font-weight: 600;
}

.empty-state {
    text-align: center;
    padding: 3rem 2rem;
    color: var(--color-plomo);
}

.empty-state i {
    font-size: 3rem;
    color: var(--color-beige-claro);
    margin-bottom: 1rem;
}

.empty-state h4 {
    color: var(--color-texto);
    margin-bottom: 0.5rem;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>