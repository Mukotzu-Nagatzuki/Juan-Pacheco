<?php
ob_start();
?>

<header class="header">
    <h1>Mis Descuentos Disponibles</h1>
    <p>Descubre las promociones exclusivas que tenemos para ti</p>
</header>

<div class="ofertas-grid">
    <?php if (empty($ofertas)): ?>
        <div class="empty-state">
            <i class="bi bi-percent"></i>
            <h3>No hay ofertas disponibles</h3>
            <p>Actualmente no tenemos promociones activas. ¡Vuelve pronto para descubrir nuevas ofertas!</p>
            <a href="index.php?action=productos" class="btn btn-primary">
                <i class="bi bi-bag"></i> Explorar Productos
            </a>
        </div>
    <?php else: ?>
        <?php foreach ($ofertas as $oferta): ?>
            <div class="oferta-card">
                <div class="card-header">
                    <div class="oferta-codigo">
                        <h3><?= htmlspecialchars($oferta['codigo_oferta']) ?></h3>
                        <span class="oferta-badge <?= $oferta['tipo_descuento'] === 'porcentaje' ? 'badge-porcentaje' : 'badge-monto' ?>">
                            <?php if ($oferta['tipo_descuento'] === 'porcentaje'): ?>
                                <i class="bi bi-percent"></i> <?= $oferta['valor_descuento'] ?>% OFF
                            <?php else: ?>
                                <i class="bi bi-currency-dollar"></i> S/ <?= number_format($oferta['valor_descuento'], 2) ?> OFF
                            <?php endif; ?>
                        </span>
                    </div>
                    <?php if ($oferta['aplica_todo']): ?>
                        <span class="global-badge">
                            <i class="bi bi-globe"></i> Aplica a todos los productos
                        </span>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <p class="oferta-descripcion"><?= htmlspecialchars($oferta['descripcion']) ?></p>
                    
                    <div class="oferta-details">
                        <div class="detail-item">
                            <i class="bi bi-calendar-check"></i>
                            <div class="detail-content">
                                <span class="detail-label">Válida hasta</span>
                                <span class="detail-value"><?= date('d/m/Y', strtotime($oferta['fecha_fin'])) ?></span>
                            </div>
                        </div>
                        
                        <?php if ($oferta['minimo_compra'] > 0): ?>
                            <div class="detail-item">
                                <i class="bi bi-basket"></i>
                                <div class="detail-content">
                                    <span class="detail-label">Mínimo de compra</span>
                                    <span class="detail-value">S/ <?= number_format($oferta['minimo_compra'], 2) ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($oferta['usos_maximos']): ?>
                            <div class="detail-item">
                                <i class="bi bi-people"></i>
                                <div class="detail-content">
                                    <span class="detail-label">Usos disponibles</span>
                                    <span class="detail-value"><?= $oferta['usos_maximos'] - $oferta['usos_actuales'] ?> de <?= $oferta['usos_maximos'] ?></span>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="detail-item">
                                <i class="bi bi-infinity"></i>
                                <div class="detail-content">
                                    <span class="detail-label">Usos disponibles</span>
                                    <span class="detail-value">Ilimitados</span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card-footer">
                    <div class="uso-codigo">
                        <i class="bi bi-tag"></i>
                        <span>Usa el código: <strong><?= htmlspecialchars($oferta['codigo_oferta']) ?></strong></span>
                    </div>
                    <div class="tiempo-restante">
                        <?php
                        $fecha_fin = new DateTime($oferta['fecha_fin']);
                        $hoy = new DateTime();
                        $dias_restantes = $hoy->diff($fecha_fin)->days;
                        
                        if ($dias_restantes <= 7): ?>
                            <span class="urgente">
                                <i class="bi bi-clock"></i> Termina en <?= $dias_restantes ?> día<?= $dias_restantes != 1 ? 's' : '' ?>
                            </span>
                        <?php else: ?>
                            <span class="normal">
                                <i class="bi bi-clock"></i> <?= $dias_restantes ?> días restantes
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="info-section">
    <div class="section-header">
        <h2>¿Cómo usar los descuentos?</h2>
        <p>Sigue estos simples pasos para aplicar tus descuentos</p>
    </div>
    <div class="steps-grid">
        <div class="step-card">
            <div class="step-icon">
                <div class="step-number">1</div>
                <i class="bi bi-cart-plus"></i>
            </div>
            <div class="step-content">
                <h4>Agrega productos al carrito</h4>
                <p>Selecciona los productos que deseas comprar y agrégalos a tu carrito de compras.</p>
            </div>
        </div>
        <div class="step-card">
            <div class="step-icon">
                <div class="step-number">2</div>
                <i class="bi bi-credit-card"></i>
            </div>
            <div class="step-content">
                <h4>Ve al proceso de pago</h4>
                <p>Completa tus datos de envío y selecciona tu método de pago preferido.</p>
            </div>
        </div>
        <div class="step-card">
            <div class="step-icon">
                <div class="step-number">3</div>
                <i class="bi bi-tag"></i>
            </div>
            <div class="step-content">
                <h4>Aplica el código</h4>
                <p>Ingresa el código de descuento en el campo correspondiente antes de finalizar tu compra.</p>
            </div>
        </div>
    </div>
</div>

<div class="actions-section">
    <a href="index.php?action=historial_descuentos" class="btn btn-secondary">
        <i class="bi bi-clock-history"></i> Ver Historial de Descuentos
    </a>
    <a href="index.php?action=productos" class="btn btn-primary">
        <i class="bi bi-bag-check"></i> Comenzar a Comprar
    </a>
</div>

<style>
/* Estilos para la sección de ofertas */
.ofertas-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
    gap: 1.5rem;
    margin-bottom: 3rem;
}

.oferta-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(107, 93, 85, 0.1);
    border: 1px solid var(--color-beige-claro);
    overflow: hidden;
    transition: all 0.3s ease;
    position: relative;
}

.oferta-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(107, 93, 85, 0.15);
}

.card-header {
    padding: 1.5rem 1.5rem 1rem;
    border-bottom: 1px solid var(--color-beige-claro);
    background: linear-gradient(135deg, #faf7f5 0%, #ffffff 100%);
}

.oferta-codigo {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 0.5rem;
}

.oferta-codigo h3 {
    margin: 0;
    color: var(--color-texto);
    font-size: 1.25rem;
    font-weight: 600;
}

.oferta-badge {
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.875rem;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.badge-porcentaje {
    background: linear-gradient(135deg, var(--color-secundario), var(--color-pastel));
    color: white;
}

.badge-monto {
    background: linear-gradient(135deg, #325b81ff, #25868dff);
    color: white;
}

.global-badge {
    background: var(--color-beige-claro);
    color: var(--color-texto);
    padding: 0.25rem 0.75rem;
    border-radius: 12px;
    font-size: 0.75rem;
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
}

.card-body {
    padding: 1.5rem;
}

.oferta-descripcion {
    color: var(--color-plomo);
    line-height: 1.6;
    margin-bottom: 1.5rem;
    font-size: 0.95rem;
}

.oferta-details {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.detail-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 0.75rem;
    background: #faf7f5;
    border-radius: 8px;
}

.detail-item i {
    color: var(--color-secundario);
    font-size: 1.1rem;
    width: 20px;
    text-align: center;
}

.detail-content {
    display: flex;
    flex-direction: column;
}

.detail-label {
    font-size: 0.8rem;
    color: var(--color-plomo);
    font-weight: 500;
}

.detail-value {
    font-size: 0.95rem;
    color: var(--color-texto);
    font-weight: 600;
}

.card-footer {
    padding: 1.5rem;
    background: #faf7f5;
    border-top: 1px solid var(--color-beige-claro);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.uso-codigo {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--color-texto);
    font-size: 0.9rem;
}

.uso-codigo i {
    color: var(--color-secundario);
}

.uso-codigo strong {
    background: white;
    padding: 0.25rem 0.75rem;
    border-radius: 6px;
    border: 1px dashed var(--color-secundario);
    color: var(--color-secundario);
    font-family: 'Courier New', monospace;
}

.tiempo-restante .urgente {
    color: #e74c3c;
    font-weight: 600;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.tiempo-restante .normal {
    color: var(--color-plomo);
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

/* Sección de información */
.info-section {
    background: white;
    border-radius: 12px;
    padding: 2.5rem;
    margin-bottom: 2rem;
    border: 1px solid var(--color-beige-claro);
    box-shadow: 0 4px 15px rgba(107, 93, 85, 0.08);
}

.section-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.section-header h2 {
    color: var(--color-texto);
    margin-bottom: 0.5rem;
}

.section-header p {
    color: var(--color-plomo);
    font-size: 1.1rem;
}

.steps-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
}

.step-card {
    text-align: center;
    padding: 1.5rem;
}

.step-icon {
    position: relative;
    margin-bottom: 1.5rem;
    display: inline-block;
}

.step-number {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--color-secundario);
    color: white;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    font-weight: 600;
}

.step-icon i {
    font-size: 2.5rem;
    color: var(--color-secundario);
    background: #faf7f5;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid var(--color-beige-claro);
}

.step-content h4 {
    color: var(--color-texto);
    margin-bottom: 0.75rem;
    font-size: 1.1rem;
}

.step-content p {
    color: var(--color-plomo);
    line-height: 1.6;
    font-size: 0.9rem;
}

/* Sección de acciones */
.actions-section {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-top: 2rem;
    flex-wrap: wrap;
}

/* Estado vacío mejorado */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
    grid-column: 1 / -1;
}

.empty-state i {
    font-size: 4rem;
    color: var(--color-beige-claro);
    margin-bottom: 1.5rem;
}

.empty-state h3 {
    color: var(--color-texto);
    margin-bottom: 1rem;
    font-size: 1.5rem;
}

.empty-state p {
    color: var(--color-plomo);
    margin-bottom: 2rem;
    font-size: 1.1rem;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
}

/* Responsive */
@media (max-width: 768px) {
    .ofertas-grid {
        grid-template-columns: 1fr;
    }
    
    .card-footer {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
    
    .steps-grid {
        grid-template-columns: 1fr;
    }
    
    .actions-section {
        flex-direction: column;
    }
    
    .oferta-codigo {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/cliente_layout.php';
?>