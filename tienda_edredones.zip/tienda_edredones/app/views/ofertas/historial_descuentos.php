<?php
ob_start();
?>

<header class="header">
    <h1>📋 Historial de Descuentos Usados</h1>
    <p>Revisa todas las ofertas que has aplicado en tus compras anteriores</p>
</header>

<!-- Resumen de Ahorros -->
<?php if (!empty($usos)): ?>
    <?php
    $total_ahorro = array_sum(array_column($usos, 'monto_descuento'));
    $total_pedidos = count($usos);
    ?>
    <div class="stats-summary">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-wallet2"></i>
            </div>
            <div class="stat-content">
                <h3>Total Ahorrado</h3>
                <div class="stat-number">S/ <?= number_format($total_ahorro, 2) ?></div>
                <p>En todas tus compras</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-receipt"></i>
            </div>
            <div class="stat-content">
                <h3>Descuentos Aplicados</h3>
                <div class="stat-number"><?= $total_pedidos ?></div>
                <p>Ofertas utilizadas</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-calendar-check"></i>
            </div>
            <div class="stat-content">
                <h3>Primer Uso</h3>
                <div class="stat-number"><?= date('d/m/Y', strtotime($usos[0]['fecha_uso'])) ?></div>
                <p>Fecha del primer descuento</p>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="table-section">
    <?php if (empty($usos)): ?>
        <div class="empty-state">
            <div class="empty-icon">
                <i class="bi bi-receipt"></i>
            </div>
            <h3>No has utilizado descuentos aún</h3>
            <p>Cuando apliques una oferta en tus compras, aparecerá registrada aquí con todos los detalles.</p>
            <div class="empty-actions">
                <a href="index.php?action=mis_descuentos" class="btn btn-primary">
                    <i class="bi bi-percent"></i> Explorar Ofertas Disponibles
                </a>
                <a href="index.php?action=productos" class="btn btn-secondary">
                    <i class="bi bi-bag"></i> Ir de Compras
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="table-header">
            <h3><i class="bi bi-clock-history"></i> Historial de Descuentos</h3>
            <div class="table-info">
                <span class="info-badge">
                    <i class="bi bi-info-circle"></i>
                    Mostrando <?= count($usos) ?> descuento<?= count($usos) != 1 ? 's' : '' ?>
                </span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="data-table discount-history-table">
                <thead>
                    <tr>
                        <th class="col-codigo">Código</th>
                        <th class="col-descripcion">Oferta</th>
                        <th class="col-fecha">Fecha de Uso</th>
                        <th class="col-descuento">Descuento</th>
                        <th class="col-pedido">Pedido</th>
                        <th class="col-total">Total Pedido</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usos as $uso): ?>
                        <tr class="history-row">
                            <td class="codigo-cell">
                                <div class="codigo-badge">
                                    <i class="bi bi-tag"></i>
                                    <strong><?= htmlspecialchars($uso['codigo_oferta']) ?></strong>
                                </div>
                            </td>
                            <td class="descripcion-cell">
                                <div class="oferta-info">
                                    <div class="oferta-nombre"><?= htmlspecialchars($uso['descripcion']) ?></div>
                                    <div class="fecha-detalle">
                                        <i class="bi bi-clock"></i>
                                        <?= date('H:i', strtotime($uso['fecha_uso'])) ?>
                                    </div>
                                </div>
                            </td>
                            <td class="fecha-cell">
                                <div class="fecha-completa">
                                    <?= date('d/m/Y', strtotime($uso['fecha_uso'])) ?>
                                </div>
                            </td>
                            <td class="descuento-cell">
                                <div class="descuento-aplicado">
                                    <i class="bi bi-arrow-down-circle"></i>
                                    <span class="monto-descuento">-S/ <?= number_format($uso['monto_descuento'], 2) ?></span>
                                </div>
                            </td>
                            <td class="pedido-cell">
                                <div class="numero-pedido">
                                    <i class="bi bi-bag-check"></i>
                                    DH-<?= str_pad($uso['id_pedido'], 4, '0', STR_PAD_LEFT) ?>
                                </div>
                            </td>
                            <td class="total-cell">
                                <div class="total-pedido">
                                    S/ <?= number_format($uso['total'], 2) ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Resumen al final -->
        <div class="summary-footer">
            <div class="resumen-total">
                <div class="resumen-item">
                    <span class="resumen-label">Total ahorrado:</span>
                    <span class="resumen-valor ahorro-total">S/ <?= number_format($total_ahorro, 2) ?></span>
                </div>
                <div class="resumen-item">
                    <span class="resumen-label">Descuentos aplicados:</span>
                    <span class="resumen-valor"><?= $total_pedidos ?></span>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="actions-section">
    <a href="index.php?action=mis_descuentos" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Volver a Ofertas Disponibles
    </a>
    <?php if (!empty($usos)): ?>
        <a href="index.php?action=pedidos" class="btn btn-outline">
            <i class="bi bi-list-check"></i> Ver Mis Pedidos
        </a>
    <?php endif; ?>
</div>

<style>
/* Resumen de estadísticas */
.stats-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2.5rem;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    border: 1px solid var(--color-beige-claro);
    box-shadow: 0 4px 15px rgba(107, 93, 85, 0.08);
    display: flex;
    align-items: center;
    gap: 1rem;
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-3px);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    background: linear-gradient(135deg, var(--color-secundario), var(--color-pastel));
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
}

.stat-content h3 {
    margin: 0 0 0.5rem 0;
    color: var(--color-texto);
    font-size: 0.9rem;
    font-weight: 600;
}

.stat-number {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--color-secundario);
    margin-bottom: 0.25rem;
}

.stat-content p {
    margin: 0;
    color: var(--color-plomo);
    font-size: 0.8rem;
}

/* Sección de tabla */
.table-section {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid var(--color-beige-claro);
    box-shadow: 0 4px 15px rgba(107, 93, 85, 0.08);
    margin-bottom: 2rem;
}

.table-header {
    padding: 1.5rem 2rem;
    border-bottom: 1px solid var(--color-beige-claro);
    background: #faf7f5;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.table-header h3 {
    margin: 0;
    color: var(--color-texto);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.info-badge {
    background: var(--color-beige-claro);
    color: var(--color-texto);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

/* Tabla mejorada */
.table-responsive {
    overflow-x: auto;
}

.discount-history-table {
    width: 100%;
    border-collapse: collapse;
}

.discount-history-table thead {
    background: #faf7f5;
}

.discount-history-table th {
    padding: 1rem 1.5rem;
    text-align: left;
    font-weight: 600;
    color: var(--color-texto);
    border-bottom: 1px solid var(--color-beige-claro);
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.history-row {
    transition: background-color 0.2s ease;
    border-bottom: 1px solid var(--color-beige-claro);
}

.history-row:hover {
    background: #faf7f5;
}

.history-row td {
    padding: 1.25rem 1.5rem;
    vertical-align: middle;
}

/* Celdas específicas */
.codigo-cell .codigo-badge {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background: var(--color-beige-claro);
    padding: 0.5rem 1rem;
    border-radius: 8px;
    border: 1px dashed var(--color-secundario);
}

.codigo-badge i {
    color: var(--color-secundario);
}

.codigo-badge strong {
    color: var(--color-texto);
    font-family: 'Courier New', monospace;
}

.descripcion-cell .oferta-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.oferta-nombre {
    color: var(--color-texto);
    font-weight: 500;
}

.fecha-detalle {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    color: var(--color-plomo);
    font-size: 0.8rem;
}

.fecha-detalle i {
    font-size: 0.7rem;
}

.fecha-cell .fecha-completa {
    color: var(--color-texto);
    font-weight: 500;
}

.descuento-aplicado {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #325b81ff;
    font-weight: 600;
}

.monto-descuento {
    background: rgba(50, 91, 129, 0.1);
    padding: 0.5rem 0.75rem;
    border-radius: 6px;
    font-size: 0.9rem;
}

.pedido-cell .numero-pedido {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--color-texto);
    font-weight: 500;
}

.pedido-cell i {
    color: var(--color-secundario);
}

.total-cell .total-pedido {
    color: var(--color-texto);
    font-weight: 600;
    font-size: 1rem;
}

/* Resumen al final */
.summary-footer {
    padding: 1.5rem 2rem;
    border-top: 1px solid var(--color-beige-claro);
    background: #faf7f5;
}

.resumen-total {
    display: flex;
    justify-content: flex-end;
    gap: 2rem;
}

.resumen-item {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 0.25rem;
}

.resumen-label {
    color: var(--color-plomo);
    font-size: 0.9rem;
}

.resumen-valor {
    color: var(--color-texto);
    font-weight: 600;
    font-size: 1.1rem;
}

.ahorro-total {
    color: #325b81ff;
    font-size: 1.25rem;
}

/* Estado vacío mejorado */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
}

.empty-icon {
    margin-bottom: 1.5rem;
}

.empty-icon i {
    font-size: 4rem;
    color: var(--color-beige-claro);
}

.empty-state h3 {
    color: var(--color-texto);
    margin-bottom: 1rem;
    font-size: 1.5rem;
}

.empty-state p {
    color: var(--color-plomo);
    margin-bottom: 2rem;
    font-size: 1.1rem;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
    line-height: 1.6;
}

.empty-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

/* Sección de acciones */
.actions-section {
    display: flex;
    justify-content: center;
    gap: 1rem;
    flex-wrap: wrap;
}

.btn-outline {
    background: transparent;
    border: 1px solid var(--color-secundario);
    color: var(--color-secundario);
    text-decoration: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-weight: 500;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-outline:hover {
    background: var(--color-secundario);
    color: white;
    transform: translateY(-2px);
}

/* Responsive */
@media (max-width: 768px) {
    .stats-summary {
        grid-template-columns: 1fr;
    }
    
    .table-header {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
    
    .resumen-total {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
    
    .resumen-item {
        align-items: flex-start;
    }
    
    .empty-actions {
        flex-direction: column;
        align-items: center;
    }
    
    .actions-section {
        flex-direction: column;
        align-items: center;
    }
    
    .history-row td {
        padding: 1rem;
    }
    
    .discount-history-table th {
        padding: 0.75rem 1rem;
    }
}

@media (max-width: 480px) {
    .table-responsive {
        font-size: 0.8rem;
    }
    
    .codigo-badge,
    .descuento-aplicado {
        flex-direction: column;
        gap: 0.25rem;
        text-align: center;
    }
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/cliente_layout.php';
?>