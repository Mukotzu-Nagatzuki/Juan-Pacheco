<?php
ob_start();
?>

<header class="header">
    <h1>Gestión de Ofertas</h1>
    <p>Administra y controla todas las promociones y descuentos de tu tienda</p>
</header>

<!-- Resumen de Ofertas -->
<?php if (!empty($ofertas)): ?>
    <?php
    $ofertas_activas = array_filter($ofertas, fn($o) => $o['estado'] === 'activa');
    $ofertas_expiradas = array_filter($ofertas, fn($o) => $o['estado'] === 'expirada');
    $total_usos = array_sum(array_column($ofertas, 'usos_actuales'));
    ?>
    <div class="stats-summary">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-percent"></i>
            </div>
            <div class="stat-content">
                <h3>Total Ofertas</h3>
                <div class="stat-number"><?= count($ofertas) ?></div>
                <p>En el sistema</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-check-circle"></i>
            </div>
            <div class="stat-content">
                <h3>Ofertas Activas</h3>
                <div class="stat-number"><?= count($ofertas_activas) ?></div>
                <p>Disponibles</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-graph-up-arrow"></i>
            </div>
            <div class="stat-content">
                <h3>Total Usos</h3>
                <div class="stat-number"><?= $total_usos ?></div>
                <p>Descuentos aplicados</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="bi bi-clock-history"></i>
            </div>
            <div class="stat-content">
                <h3>Expiradas</h3>
                <div class="stat-number"><?= count($ofertas_expiradas) ?></div>
                <p>Por renovar</p>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="actions-bar">
    <a href="index.php?action=crear_oferta" class="btn btn-primary btn-crear">
        <i class="bi bi-plus-circle"></i> Crear Nueva Oferta
    </a>
    <div class="actions-right">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="search-ofertas" placeholder="Buscar ofertas...">
        </div>
    </div>
</div>

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success">
        <i class="bi bi-check-circle-fill"></i>
        <?= $_SESSION['success'] ?>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-error">
        <i class="bi bi-exclamation-circle-fill"></i>
        <?= $_SESSION['error'] ?>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<div class="table-section">
    <?php if (empty($ofertas)): ?>
        <div class="empty-state">
            <div class="empty-icon">
                <i class="bi bi-percent"></i>
            </div>
            <h3>No hay ofertas registradas</h3>
            <p>Crea tu primera oferta para empezar a atraer más clientes con promociones especiales.</p>
            <a href="index.php?action=crear_oferta" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Crear Primera Oferta
            </a>
        </div>
    <?php else: ?>
        <div class="table-header">
            <h3><i class="bi bi-list-ul"></i> Lista de Ofertas</h3>
            <div class="table-info">
                <span class="info-badge">
                    <i class="bi bi-info-circle"></i>
                    Mostrando <?= count($ofertas) ?> oferta<?= count($ofertas) != 1 ? 's' : '' ?>
                </span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="data-table offers-table">
                <thead>
                    <tr>
                        <th class="col-codigo">Código</th>
                        <th class="col-descripcion">Descripción</th>
                        <th class="col-tipo">Tipo</th>
                        <th class="col-descuento">Descuento</th>
                        <th class="col-fechas">Vigencia</th>
                        <th class="col-usos">Usos</th>
                        <th class="col-estado">Estado</th>
                        <th class="col-acciones">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ofertas as $oferta): ?>
                        <tr class="offer-row" data-codigo="<?= htmlspecialchars($oferta['codigo_oferta']) ?>" data-descripcion="<?= htmlspecialchars($oferta['descripcion']) ?>">
                            <td class="codigo-cell">
                                <div class="codigo-badge">
                                    <strong><?= htmlspecialchars($oferta['codigo_oferta']) ?></strong>
                                    <?php if ($oferta['minimo_compra'] > 0): ?>
                                        <small>Mín: S/ <?= number_format($oferta['minimo_compra'], 2) ?></small>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="descripcion-cell">
                                <div class="descripcion-content">
                                    <div class="descripcion-text"><?= htmlspecialchars($oferta['descripcion']) ?></div>
                                    <?php if ($oferta['aplica_todo']): ?>
                                        <span class="badge-global">Aplica a todos</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="tipo-cell">
                                <span class="tipo-badge tipo-<?= $oferta['tipo_descuento'] ?>">
                                    <?php if ($oferta['tipo_descuento'] === 'porcentaje'): ?>
                                        <i class="bi bi-percent"></i> Porcentaje
                                    <?php else: ?>
                                        <i class="bi bi-currency-dollar"></i> Monto Fijo
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td class="descuento-cell">
                                <div class="descuento-value">
                                    <?php if ($oferta['tipo_descuento'] === 'porcentaje'): ?>
                                        <span class="valor"><?= $oferta['valor_descuento'] ?>%</span>
                                        <small>de descuento</small>
                                    <?php else: ?>
                                        <span class="valor">S/ <?= number_format($oferta['valor_descuento'], 2) ?></span>
                                        <small>de descuento</small>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="fechas-cell">
                                <div class="fechas-info">
                                    <div class="fecha-item">
                                        <i class="bi bi-play-circle"></i>
                                        <span><?= date('d/m/Y', strtotime($oferta['fecha_inicio'])) ?></span>
                                    </div>
                                    <div class="fecha-item">
                                        <i class="bi bi-flag"></i>
                                        <span><?= date('d/m/Y', strtotime($oferta['fecha_fin'])) ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="usos-cell">
                                <div class="usos-progress">
                                    <div class="usos-text">
                                        <?= $oferta['usos_actuales'] ?>
                                        <?php if ($oferta['usos_maximos']): ?>
                                            / <?= $oferta['usos_maximos'] ?>
                                        <?php else: ?>
                                            / ∞
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($oferta['usos_maximos']): ?>
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?= min(100, ($oferta['usos_actuales'] / $oferta['usos_maximos']) * 100) ?>%"></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="estado-cell">
                                <span class="status-badge status-<?= $oferta['estado'] ?>">
                                    <i class="bi bi-circle-fill"></i>
                                    <?= ucfirst($oferta['estado']) ?>
                                </span>
                            </td>
                            <td class="acciones-cell">
                                <div class="action-buttons">
                                    <a href="index.php?action=editar_oferta&id=<?= $oferta['id_oferta'] ?>" class="btn-action btn-edit" title="Editar oferta">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="index.php?action=estadisticas_oferta&id=<?= $oferta['id_oferta'] ?>" class="btn-action btn-stats" title="Ver estadísticas">
                                        <i class="bi bi-graph-up"></i>
                                    </a>
                                    <a href="index.php?action=eliminar_oferta&id=<?= $oferta['id_oferta'] ?>" 
                                       class="btn-action btn-delete" 
                                       title="Eliminar oferta"
                                       onclick="return confirm('¿Estás seguro de eliminar la oferta <?= htmlspecialchars($oferta['codigo_oferta']) ?>?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-ofertas');
    const offerRows = document.querySelectorAll('.offer-row');
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        offerRows.forEach(row => {
            const codigo = row.getAttribute('data-codigo').toLowerCase();
            const descripcion = row.getAttribute('data-descripcion').toLowerCase();
            
            if (codigo.includes(searchTerm) || descripcion.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});
</script>

<style>
/* Resumen de estadísticas */
.stats-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    border: 1px solid var(--color-beige-claro);
    box-shadow: 0 4px 15px rgba(107, 93, 85, 0.08);
    display: flex;
    align-items: center;
    gap: 1rem;
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-3px);
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    background: linear-gradient(135deg, var(--color-secundario), var(--color-pastel));
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.25rem;
}

.stat-content h3 {
    margin: 0 0 0.25rem 0;
    color: var(--color-texto);
    font-size: 0.85rem;
    font-weight: 600;
}

.stat-number {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--color-secundario);
    margin-bottom: 0.25rem;
}

.stat-content p {
    margin: 0;
    color: var(--color-plomo);
    font-size: 0.75rem;
}

/* Barra de acciones */
.actions-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    gap: 1rem;
    flex-wrap: wrap;
}

.btn-crear {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    font-weight: 600;
}

.actions-right {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.search-box {
    position: relative;
    display: flex;
    align-items: center;
}

.search-box i {
    position: absolute;
    left: 1rem;
    color: var(--color-plomo);
}

.search-box input {
    padding: 0.75rem 1rem 0.75rem 2.5rem;
    border: 1px solid var(--color-beige-claro);
    border-radius: 8px;
    width: 250px;
    color: var(--color-texto);
    transition: all 0.3s ease;
}

.search-box input:focus {
    outline: none;
    border-color: var(--color-secundario);
    box-shadow: 0 0 0 2px rgba(146, 109, 133, 0.1);
}

/* Alertas mejoradas */
.alert {
    padding: 1rem 1.5rem;
    border-radius: 8px;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    font-weight: 500;
}

.alert-success {
    background: rgba(39, 174, 96, 0.1);
    border: 1px solid #25868dff;
    color: #336959ff;
}

.alert-error {
    background: rgba(231, 76, 60, 0.1);
    border: 1px solid #e73c92ff;
    color: #6f1c72ff;
}

/* Sección de tabla */
.table-section {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid var(--color-beige-claro);
    box-shadow: 0 4px 15px rgba(107, 93, 85, 0.08);
}

.table-header {
    padding: 1.5rem 2rem;
    border-bottom: 1px solid var(--color-beige-claro);
    background: #faf7f5;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.table-header h3 {
    margin: 0;
    color: var(--color-texto);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.info-badge {
    background: var(--color-beige-claro);
    color: var(--color-texto);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

/* Tabla mejorada */
.table-responsive {
    overflow-x: auto;
}

.offers-table {
    width: 100%;
    border-collapse: collapse;
}

.offers-table thead {
    background: #faf7f5;
}

.offers-table th {
    padding: 1rem 1.5rem;
    text-align: left;
    font-weight: 600;
    color: var(--color-texto);
    border-bottom: 1px solid var(--color-beige-claro);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.offer-row {
    transition: background-color 0.2s ease;
    border-bottom: 1px solid var(--color-beige-claro);
}

.offer-row:hover {
    background: #faf7f5;
}

.offer-row td {
    padding: 1.25rem 1.5rem;
    vertical-align: middle;
}

/* Celdas específicas */
.codigo-cell .codigo-badge {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.codigo-badge strong {
    color: var(--color-texto);
    font-family: 'Courier New', monospace;
    font-size: 0.9rem;
}

.codigo-badge small {
    color: var(--color-plomo);
    font-size: 0.75rem;
}

.descripcion-cell .descripcion-content {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.descripcion-text {
    color: var(--color-texto);
    line-height: 1.4;
}

.badge-global {
    background: var(--color-beige-claro);
    color: var(--color-texto);
    padding: 0.25rem 0.5rem;
    border-radius: 6px;
    font-size: 0.75rem;
    display: inline-block;
}

.tipo-badge {
    padding: 0.5rem 0.75rem;
    border-radius: 6px;
    font-size: 0.8rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.tipo-porcentaje {
    background: rgba(146, 109, 133, 0.1);
    color: var(--color-secundario);
    border: 1px solid rgba(146, 109, 133, 0.2);
}

.tipo-monto_fijo {
    background: rgba(50, 91, 129, 0.1);
    color: #325b81ff;
    border: 1px solid rgba(50, 91, 129, 0.2);
}

.descuento-value {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.descuento-value .valor {
    color: var(--color-texto);
    font-weight: 600;
    font-size: 0.95rem;
}

.descuento-value small {
    color: var(--color-plomo);
    font-size: 0.75rem;
}

.fechas-cell .fechas-info {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.fecha-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--color-texto);
    font-size: 0.85rem;
}

.fecha-item i {
    color: var(--color-secundario);
    font-size: 0.8rem;
}

.usos-cell .usos-progress {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.usos-text {
    color: var(--color-texto);
    font-size: 0.85rem;
    font-weight: 500;
}

.progress-bar {
    width: 100%;
    height: 6px;
    background: var(--color-beige-claro);
    border-radius: 3px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--color-secundario), var(--color-pastel));
    border-radius: 3px;
    transition: width 0.3s ease;
}

.status-badge {
    padding: 0.5rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.status-activa {
    background: rgba(39, 174, 96, 0.1);
    color: #336959ff;
    border: 1px solid rgba(39, 174, 96, 0.2);
}

.status-inactiva {
    background: rgba(231, 76, 60, 0.1);
    color: #6f1c72ff;
    border: 1px solid rgba(231, 76, 60, 0.2);
}

.status-expirada {
    background: rgba(243, 156, 18, 0.1);
    color: #7d6608ff;
    border: 1px solid rgba(243, 156, 18, 0.2);
}

/* Botones de acción */
.action-buttons {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
}

.btn-action {
    width: 35px;
    height: 35px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
}

.btn-edit {
    background: rgba(52, 152, 219, 0.1);
    color: #3498db;
}

.btn-edit:hover {
    background: #3498db;
    color: white;
    transform: translateY(-2px);
}

.btn-stats {
    background: rgba(155, 89, 182, 0.1);
    color: #9b59b6;
}

.btn-stats:hover {
    background: #9b59b6;
    color: white;
    transform: translateY(-2px);
}

.btn-delete {
    background: rgba(231, 76, 60, 0.1);
    color: #e74c3c;
}

.btn-delete:hover {
    background: #e74c3c;
    color: white;
    transform: translateY(-2px);
}

/* Estado vacío */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
}

.empty-icon {
    margin-bottom: 1.5rem;
}

.empty-icon i {
    font-size: 4rem;
    color: var(--color-beige-claro);
}

.empty-state h3 {
    color: var(--color-texto);
    margin-bottom: 1rem;
    font-size: 1.5rem;
}

.empty-state p {
    color: var(--color-plomo);
    margin-bottom: 2rem;
    font-size: 1.1rem;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
    line-height: 1.6;
}

/* Responsive */
@media (max-width: 768px) {
    .stats-summary {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .actions-bar {
        flex-direction: column;
        align-items: stretch;
    }
    
    .actions-right {
        justify-content: center;
    }
    
    .search-box input {
        width: 100%;
    }
    
    .table-header {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
    
    .offer-row td {
        padding: 1rem;
    }
    
    .offers-table th {
        padding: 0.75rem 1rem;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .btn-action {
        width: 30px;
        height: 30px;
    }
}

@media (max-width: 480px) {
    .stats-summary {
        grid-template-columns: 1fr;
    }
    
    .table-responsive {
        font-size: 0.8rem;
    }
    
    .codigo-badge,
    .descuento-value,
    .fechas-info {
        text-align: center;
    }
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>