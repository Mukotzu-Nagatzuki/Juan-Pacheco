<?php
if (session_status() === PHP_SESSION_NONE)
    session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['error'] = "Debe iniciar sesión para ver el carrito";
    header('Location: index.php?action=login');
    exit;
}

// Obtener carrito
require_once 'app/config/database.php';
require_once 'app/models/Carrito.php';
$database = new Database();
$db = $database->getConnection();
$carrito = new Carrito($db);
$items = $carrito->obtenerCarrito($_SESSION['usuario_id']);
$total = $carrito->obtenerTotal($_SESSION['usuario_id']);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras - Tienda de Edredones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <!-- 🔥 CARGAR KRYPTON EN EL HEAD - FORMA CORRECTA -->
    <link rel="stylesheet" href="/public/css/estilos.css">
    <link rel="stylesheet" href="/public/css/header.css">
    <link rel="stylesheet" href="/public/css/footer.css">
    <!-- 🔥 TEMA DE KRYPTON - NECESARIO PARA QUE EL FORMULARIO SEA VISIBLE -->
    <link rel="stylesheet"
        href="https://static.micuentaweb.pe/static/js/krypton-client/V4.0/stable/style-client-default.css">
    <!-- 🔥 LIBRERÍA DE KRYPTON - CLAVE DE PRODUCCIÓN FIJA -->
    <script src="https://static.micuentaweb.pe/static/js/krypton-client/V4.0/stable/kr-payment-form.min.js"
        kr-public-key="69697151:publickey_UxXHz1Yh5yP4zL4JFo0PqfIzis90CbBk91SSRKeNQku8E"
        kr-language="es-ES"></script>
    <style>
        
        :root {
            --color-principal: #8C6B5A;
            --color-secundario: #926d85;
            --color-fondo: #ffffff;
            --color-texto: #5A4D47;
            --color-plomo: #726660;
            --color-beige-claro: #E8DCD5;
            --color-rosado-arena: #D4B8A7;
            --color-pastel: #806783;
        }

        .product-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid var(--color-beige-claro);
        }

        .quantity-btn {
            width: 35px;
            height: 35px;
            border: 1px solid var(--color-beige-claro);
            background: white;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--color-texto);
            transition: all 0.3s ease;
        }

        .quantity-btn:hover {
            background: var(--color-secundario);
            color: white;
            border-color: var(--color-secundario);
        }

        .quantity-input {
            width: 60px;
            text-align: center;
            border: 1px solid var(--color-beige-claro);
            border-radius: 4px;
            margin: 0 5px;
            color: var(--color-texto);
        }

        .quantity-input:focus {
            outline: none;
            border-color: var(--color-secundario);
            box-shadow: 0 0 0 2px rgba(146, 109, 133, 0.2);
        }

        .cart-summary {
            background: #faf7f5;
            border-radius: 10px;
            padding: 25px;
            position: sticky;
            top: 20px;
            border: 1px solid var(--color-beige-claro);
            box-shadow: 0 4px 15px rgba(107, 93, 85, 0.08);
        }

        .empty-cart {
            text-align: center;
            padding: 80px 0;
        }

        .empty-cart i {
            font-size: 4rem;
            color: var(--color-beige-claro);
            margin-bottom: 20px;
        }

        .empty-cart h3 {
            color: var(--color-texto);
            margin-bottom: 15px;
        }

        .empty-cart p {
            color: var(--color-plomo);
            margin-bottom: 30px;
        }

        .btn-primary {
            background: var(--color-secundario);
            border-color: var(--color-secundario);
            color: white;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: var(--color-pastel);
            border-color: var(--color-pastel);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(146, 109, 133, 0.3);
        }

        .btn-outline-primary {
            border-color: var(--color-secundario);
            color: var(--color-secundario);
            transition: all 0.3s ease;
        }

        .btn-outline-primary:hover {
            background: var(--color-secundario);
            border-color: var(--color-secundario);
            color: white;
            transform: translateY(-2px);
        }

        .btn-outline-danger {
            border-color: #a8356bff;
            color: #a8356bff;
            transition: all 0.3s ease;
        }

        .btn-outline-danger:hover {
            background: #83365aff;
            border-color: #83365aff;
            color: white;
            transform: translateY(-2px);
        }

        .text-primary {
            color: var(--color-secundario) !important;
        }

        .text-muted {
            color: var(--color-plomo) !important;
        }

        .text-success {
            color: #325b81ff !important;
        }

        .breadcrumb {
            background: transparent;
            padding: 0;
        }

        .breadcrumb-item a {
            color: var(--color-secundario);
            text-decoration: none;
        }

        .breadcrumb-item.active {
            color: var(--color-texto);
        }

        .card {
            border: 1px solid var(--color-beige-claro);
            box-shadow: 0 2px 10px rgba(107, 93, 85, 0.05);
            border-radius: 12px;
        }

        .card-body {
            padding: 25px;
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border-color: #25868dff;
            color: #336959ff;
        }

        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            border-color: #e73c92ff;
            color: #6f1c72ff;
        }

        .border-bottom {
            border-color: var(--color-beige-claro) !important;
        }

        hr {
            border-color: var(--color-beige-claro);
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            color: var(--color-texto);
        }

        h1 {
            font-weight: 600;
        }

        .container {
            margin-top: 20px;
        }

        .product-item:hover {
            background: #faf7f5;
            transition: background 0.3s ease;
        }

        .stock-badge {
            background: var(--color-beige-claro);
            color: var(--color-texto);
            font-size: 0.75rem;
            padding: 2px 8px;
            border-radius: 10px;
        }

        .discount-section {
            margin-top: 20px;
            padding: 20px;
            background: white;
            border-radius: 10px;
            border: 1px solid var(--color-beige-claro);
            box-shadow: 0 2px 10px rgba(107, 93, 85, 0.05);
        }

        .discount-section h3 {
            font-size: 1.1rem;
            margin-bottom: 15px;
            color: var(--color-texto);
            font-weight: 600;
        }

        .discount-applied {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: rgba(39, 174, 96, 0.1);
            border: 1px solid #25868dff;
            border-radius: 8px;
            color: #336959ff;
        }

        .discount-info {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
        }

        .discount-amount {
            font-weight: bold;
            color: #325b81ff;
            margin-left: auto;
        }

        .btn-remove-discount {
            background: none;
            border: 1px solid #a8356bff;
            color: #a8356bff;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.875rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .btn-remove-discount:hover {
            background: #83365aff;
            color: white;
            transform: translateY(-1px);
        }

        .discount-form {
            display: flex;
            gap: 10px;
        }

        .discount-form .form-group {
            display: flex;
            flex: 1;
            gap: 10px;
        }

        .discount-form input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid var(--color-beige-claro);
            border-radius: 8px;
            color: var(--color-texto);
            transition: all 0.3s ease;
        }

        .discount-form input:focus {
            outline: none;
            border-color: var(--color-secundario);
            box-shadow: 0 0 0 2px rgba(146, 109, 133, 0.2);
        }

        .discount-form input::placeholder {
            color: var(--color-plomo);
        }

        .btn-apply-discount {
            background: var(--color-secundario);
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: 500;
        }

        .btn-apply-discount:hover {
            background: var(--color-pastel);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(146, 109, 133, 0.3);
        }

        .discount-line {
            color: #325b81ff;
            font-weight: 500;
        }

        .total-with-discount {
            color: var(--color-secundario);
            font-size: 1.25rem;
        }

        /* =========================================== */
        /* 🔥 MODAL DE PAGO - ESTILOS MEJORADOS */
        /* =========================================== */
        .payment-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.85);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .payment-modal-content {
            background: white;
            border-radius: 20px;
            max-width: 480px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            border: none;
            animation: slideUp 0.4s ease;
            position: relative;
        }

        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .close-payment-modal {
            position: absolute;
            right: 20px;
            top: 20px;
            font-size: 28px;
            cursor: pointer;
            color: var(--color-plomo);
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
            z-index: 10;
            background: #f8f9fa;
        }

        .close-payment-modal:hover {
            color: var(--color-secundario);
            background: #f0f0f0;
            transform: rotate(90deg);
        }

        .payment-modal-header {
            padding: 30px 30px 20px;
            border-bottom: 2px solid var(--color-beige-claro);
            background: linear-gradient(135deg, #faf7f5 0%, #fff 100%);
            border-radius: 20px 20px 0 0;
        }

        .payment-modal-header h4 {
            color: var(--color-texto);
            font-weight: 700;
            font-size: 1.5rem;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .payment-modal-header h4 i {
            color: var(--color-secundario);
        }

        .payment-modal-body {
            padding: 30px;
            background: white;
        }

        #paymentFormContainer {
            min-height: 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        /* =========================================== */
        /* 🔥 ESTILOS ESPECÍFICOS PARA KRYPTON */
        /* =========================================== */
        .kr-embedded {
            width: 100% !important;
            min-height: 450px !important;
            border: none !important;
            padding: 0 !important;
            margin: 0 !important;
        }

        /* BOTÓN DE PAGO - MUESTRA SOLO "PAGAR" CON PRECIO REAL */
        .kr-payment-button {
    background: var(--color-secundario) !important;
    border-radius: 12px !important;
    height: 56px !important;
    font-size: 18px !important;
    font-weight: 700 !important;
    border: none !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 6px 20px rgba(146, 109, 133, 0.4) !important;
    margin-top: 25px !important;
    width: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    position: relative !important;
    overflow: hidden !important;
    color: white !important;
    text-transform: uppercase !important;
    letter-spacing: 0.5px !important;
}

.kr-payment-button:hover {
    background: var(--color-pastel) !important;
    transform: translateY(-3px) !important;
    box-shadow: 0 8px 25px rgba(146, 109, 133, 0.5) !important;
}

.kr-payment-button:active {
    transform: translateY(-1px) !important;
}

        /* Elimina cualquier texto adicional del botón */
        .kr-payment-button:before {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 100% !important;
            height: 100% !important;
        }

        /* Esconde cualquier texto automático de Krypton */
        .kr-payment-button span,
        .kr-payment-button div {
            display: none !important;
        }

        /* CAMPOS DE TEXTO */
        .kr-pan,
        .kr-expiry,
        .kr-security-code,
        .kr-text {
            border: 2px solid #e8e8e8 !important;
            border-radius: 12px !important;
            height: 56px !important;
            padding: 16px 20px !important;
            font-size: 16px !important;
            font-weight: 500 !important;
            transition: all 0.3s ease !important;
            background: #fafafa !important;
            color: var(--color-texto) !important;
            width: 100% !important;
            box-sizing: border-box !important;
        }

        .kr-pan:focus,
        .kr-expiry:focus,
        .kr-security-code:focus,
        .kr-text:focus {
            border-color: var(--color-secundario) !important;
            background: white !important;
            box-shadow: 0 0 0 4px rgba(146, 109, 133, 0.15) !important;
            outline: none !important;
        }

        /* PLACEHOLDERS */
        .kr-pan::placeholder,
        .kr-expiry::placeholder,
        .kr-security-code::placeholder,
        .kr-text::placeholder {
            color: #a0a0a0 !important;
            font-weight: 400 !important;
        }
        /* ========================================= */
/* 🔥 VARIABLES OFICIALES KRYPTON */
/* ========================================= */
:root {
  --kr-primary-color: #926d85;
  --kr-border-radius: 12px;
  --kr-field-height: 56px;
  --kr-font-family: 'Segoe UI', system-ui, -apple-system;
}

/* ========================================= */
/* 🔥 SELECT (COMBOBOX) */
/* ========================================= */
.kr-select select {
  appearance: none !important;
  width: 100% !important;
  height: var(--kr-field-height) !important;
  padding: 16px 45px 16px 20px !important;
  font-size: 16px !important;
  font-weight: 500 !important;
  border-radius: var(--kr-border-radius) !important;
  border: 2px solid #e0e0e0 !important;
  background-color: #fafafa !important;
  color: #5A4D47 !important;
  cursor: pointer !important;
}

/* Hover */
.kr-select select:hover {
  border-color: #bfa2b6 !important;
  background-color: #f5f5f5 !important;
}

/* Focus */
.kr-select select:focus {
  outline: none !important;
  border-color: var(--kr-primary-color) !important;
  box-shadow: 0 0 0 4px rgba(146, 109, 133, 0.15) !important;
  background-color: #fff !important;
}

/* Flecha custom */
.kr-select {
  position: relative !important;
}

.kr-select::after {
  content: "▼";
  position: absolute;
  right: 18px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 12px;
  color: var(--kr-primary-color);
  pointer-events: none;
}

/* ========================================= */
/* 🔥 EXPIRY (MES / AÑO) */
/* ========================================= */
.kr-field-expiry {
  display: flex !important;
  gap: 10px !important;
}

.kr-field-expiry .kr-select {
  width: 50% !important;
}

        /* =========================================== */
        /* 🔥 COMBOBOX Y SELECT - ESTILOS ESPECIALES */
        /* =========================================== */
        .kr-select {
            position: relative !important;
            width: 100% !important;
            margin-bottom: 20px !important;
        }

        .kr-select select {
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            width: 100% !important;
            height: 56px !important;
            padding: 16px 20px !important;
            font-size: 16px !important;
            font-weight: 500 !important;
            border: 2px solid #e8e8e8 !important;
            border-radius: 12px !important;
            background: #fafafa url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%23926d85' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E") no-repeat right 20px center !important;
            background-size: 16px !important;
            color: var(--color-texto) !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
        }

        .kr-select select:focus {
            border-color: var(--color-secundario) !important;
            background-color: white !important;
            box-shadow: 0 0 0 4px rgba(146, 109, 133, 0.15) !important;
            outline: none !important;
        }

        .kr-select select:hover {
            border-color: #d0d0d0 !important;
            background-color: #f5f5f5 !important;
        }

        /* Para select de meses/años (expiry) */
        .kr-field-expiry .kr-select {
            display: inline-block !important;
            width: calc(50% - 5px) !important;
            margin-right: 10px !important;
        }

        .kr-field-expiry .kr-select:last-child {
            margin-right: 0 !important;
        }

        /* LABELS */
        .kr-label {
            color: var(--color-texto) !important;
            font-weight: 600 !important;
            margin-bottom: 8px !important;
            font-size: 14px !important;
            display: block !important;
            text-transform: uppercase !important;
            letter-spacing: 0.3px !important;
        }

        /* GRUPOS DE CAMPOS */
        .kr-field {
            margin-bottom: 20px !important;
            width: 100% !important;
        }

        /* ESPECIAL PARA GRUPO DE FECHA EXPIRACIÓN */
        .kr-field-expiry {
            display: flex !important;
            justify-content: space-between !important;
            align-items: flex-end !important;
            width: 100% !important;
        }

        .kr-field-expiry .kr-label {
            width: 100% !important;
            margin-bottom: 8px !important;
        }

        /* ERRORES */
        .kr-form-error {
            color: #ff3860 !important;
            font-size: 14px !important;
            margin-top: 8px !important;
            font-weight: 500 !important;
            display: flex !important;
            align-items: center !important;
            gap: 5px !important;
        }

        .kr-form-error:before {
            font-size: 12px !important;
        }

        /* TARJETAS ACEPTADAS */
        .kr-payment-method {
            margin-bottom: 20px !important;
            text-align: center !important;
        }

        .kr-payment-method-icons {
            display: flex !important;
            justify-content: center !important;
            gap: 15px !important;
            margin-top: 10px !important;
        }

        /* Contenedor de loading */
        #paymentLoading {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 300px;
        }

        .payment-loading-spinner {
            width: 60px;
            height: 60px;
            border: 4px solid var(--color-beige-claro);
            border-top-color: var(--color-secundario);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Detalles del pago */
        .payment-details {
            background: #faf7f5;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid var(--color-beige-claro);
        }

        .payment-details-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--color-beige-claro);
        }

        .payment-details-header h5 {
            margin: 0;
            color: var(--color-texto);
            font-weight: 600;
        }

        .payment-amount {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--color-secundario);
        }

        .payment-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .payment-info-label {
            color: var(--color-plomo);
        }

        .payment-info-value {
            font-weight: 600;
            color: var(--color-texto);
        }

        /* Footer del modal */
        .payment-modal-footer {
            padding: 20px 30px;
            border-top: 2px solid var(--color-beige-claro);
            background: #faf7f5;
            border-radius: 0 0 20px 20px;
            text-align: center;
        }

        .payment-security {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            color: var(--color-plomo);
            font-size: 14px;
        }

        .payment-security i {
            color: var(--color-secundario);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .payment-modal-content {
                max-width: 95%;
                margin: 10px;
            }
            
            .payment-modal-header,
            .payment-modal-body,
            .payment-modal-footer {
                padding: 20px;
            }
            
            .kr-embedded {
                min-height: 400px !important;
            }
            
            .kr-field-expiry .kr-select {
                width: calc(50% - 5px) !important;
            }
        }

        /* Animación suave para campos */
        .kr-field input:valid,
        .kr-field select:valid {
            border-color: #d0f0c0 !important;
            background: #f8fff8 !important;
        }

        /* Icono dentro de campos */
        .kr-field {
            position: relative !important;
        }

        .kr-field:after {
            content: "" !important;
            position: absolute !important;
            right: 20px !important;
            top: 50% !important;
            transform: translateY(-50%) !important;
            width: 20px !important;
            height: 20px !important;
            pointer-events: none !important;
        }

        .kr-field-pan:after {
            content: "💳" !important;
        }

        .kr-field-expiry:after {
            content: "📅" !important;
        }

        .kr-field-security-code:after {
            content: "🔒" !important;
        }

        .kr-field-text:after {
            content: "👤" !important;
        }
        
    </style>
</head>

<body>
    <!-- Navigation -->
    <?php
    $solo_navbar = true;
    include 'app/views/layout/header.php';
    ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                        <li class="breadcrumb-item active">Carrito de Compras</li>
                    </ol>
                </nav>

                <h1 class="mb-4">Carrito de Compras</h1>
            </div>
        </div>

        <?php if (isset($_SESSION['mensaje'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['mensaje'];
                unset($_SESSION['mensaje']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error'];
                unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-8">
                <?php if (empty($items)): ?>
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart"></i>
                        <h3>Tu carrito está vacío</h3>
                        <p class="text-muted">Agrega algunos productos increíbles a tu carrito</p>
                        <a href="/index.php?action=productos" class="btn btn-primary btn-lg">
                            <i class="fas fa-shopping-bag me-2"></i>Continuar Comprando
                        </a>
                    </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body">
                            <?php foreach ($items as $item): ?>
                                <div class="row align-items-center mb-4 pb-4 border-bottom product-item">
                                    <div class="col-md-2">
                                        <img src="/public/img/productos/<?php echo $item['imagen_principal']; ?>"
                                            alt="<?php echo htmlspecialchars($item['nombre']); ?>" class="product-img">
                                    </div>

                                    <div class="col-md-4">
                                        <h6 class="mb-1 fw-semibold"><?php echo htmlspecialchars($item['nombre']); ?></h6>
                                        <p class="text-muted mb-1 small"><?php echo htmlspecialchars($item['medida']); ?></p>
                                        <p class="text-muted mb-1 small">Color: <?php echo htmlspecialchars($item['color']); ?>
                                        </p>
                                        <p class="text-muted mb-2 small">Material:
                                            <?php echo htmlspecialchars($item['material']); ?>
                                        </p>
                                        <span class="stock-badge">Stock: <?php echo $item['stock']; ?></span>
                                    </div>

                                    <div class="col-md-2">
                                        <span class="h6 fw-semibold">S/ <?php echo number_format($item['precio'], 2); ?></span>
                                    </div>

                                    <div class="col-md-2">
                                        <div class="d-flex align-items-center">
                                            <button class="quantity-btn decrease-btn"
                                                data-producto="<?php echo $item['id_producto']; ?>">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <input type="number" class="quantity-input form-control"
                                                value="<?php echo $item['cantidad']; ?>" min="1"
                                                max="<?php echo $item['stock']; ?>"
                                                data-producto="<?php echo $item['id_producto']; ?>">
                                            <button class="quantity-btn increase-btn"
                                                data-producto="<?php echo $item['id_producto']; ?>">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="col-md-2 text-end">
                                        <span class="h6 text-primary d-block mb-2 fw-semibold">
                                            S/ <?php echo number_format($item['subtotal_calculado'], 2); ?>
                                        </span>
                                        <button class="btn btn-outline-danger btn-sm remove-btn"
                                            data-producto="<?php echo $item['id_producto']; ?>">
                                            <i class="fas fa-trash"></i> Eliminar
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <div class="row mt-4">
                                <div class="col-6">
                                    <a href="/index.php?action=productos" class="btn btn-outline-primary">
                                        <i class="fas fa-arrow-left me-2"></i>Seguir Comprando
                                    </a>
                                </div>
                                <div class="col-6 text-end">
                                    <button class="btn btn-outline-danger" id="vaciar-carrito">
                                        <i class="fas fa-trash me-2"></i>Vaciar Carrito
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($items)): ?>
                <div class="col-lg-4">
                    <div class="cart-summary">
                        <h5 class="mb-4 fw-semibold">Resumen del Pedido</h5>

                        <div class="d-flex justify-content-between mb-3">
                            <span class="text-muted">Subtotal:</span>
                            <span class="fw-semibold">S/ <?php echo number_format($total, 2); ?></span>
                        </div>

                        <!-- Sección de Descuentos -->
                        <div class="discount-section">
                            <h3>Aplicar Descuento</h3>

                            <?php if (isset($_SESSION['descuento_aplicado'])): ?>
                                <div class="discount-applied">
                                    <div class="discount-info">
                                        <i class="bi bi-check-circle-fill text-success"></i>
                                        <span><strong>Código aplicado:</strong>
                                            <?= htmlspecialchars($_SESSION['descuento_aplicado']['codigo']) ?></span>
                                        <span class="discount-amount">-S/
                                            <?= number_format($_SESSION['descuento_aplicado']['monto_descuento'], 2) ?></span>
                                    </div>
                                    <a href="/index.php?action=remover_descuento" class="btn-remove-discount">
                                        <i class="bi bi-x-circle"></i> Remover
                                    </a>
                                </div>
                            <?php else: ?>
                                <form method="POST" action="/index.php?action=aplicar_descuento" class="discount-form">
                                    <div class="form-group">
                                        <input type="text" name="codigo_descuento" placeholder="Ingresa tu código de descuento"
                                            required>
                                        <button type="submit" class="btn-apply-discount">
                                            <i class="bi bi-tag"></i> Aplicar
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>

                        <?php if (isset($_SESSION['descuento_aplicado'])): ?>
                            <div class="d-flex justify-content-between mb-3 discount-line">
                                <span>Descuento:</span>
                                <span>-S/ <?= number_format($_SESSION['descuento_aplicado']['monto_descuento'], 2) ?></span>
                            </div>
                        <?php endif; ?>

                        <div class="d-flex justify-content-between mb-3">
                            <span class="text-muted">Envío:</span>
                            <span class="text-success fw-semibold">Gratis</span>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between mb-4">
                            <strong class="fs-5">Total:</strong>
                            <strong class="h5 text-primary total-with-discount">
                                S/ <?php
                                if (isset($_SESSION['descuento_aplicado'])) {
                                    echo number_format($_SESSION['descuento_aplicado']['total_final'], 2);
                                } else {
                                    echo number_format($total, 2);
                                }
                                ?>
                            </strong>
                        </div>

                        <button id="btnPagar" class="btn btn-primary btn-lg w-100 py-3">
                            Proceder con el pago
                        </button>

                        <div class="mt-3 text-center">
                            <small class="text-muted">
                                <i class="fas fa-lock me-1"></i>
                                Pago 100% seguro
                            </small>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal para formulario de pago - ACTUALIZADO -->
    <div id="paymentModal" class="payment-modal">
        <div class="payment-modal-content">
            <span class="close-payment-modal">&times;</span>
            
            <div class="payment-modal-header">
                <h4><i class="fas fa-credit-card me-2"></i> Completa tu pago</h4>
            </div>
            
            <div class="payment-modal-body">
                <!-- Detalles del pago -->
                <div class="payment-details">
                    <div class="payment-details-header">
                        <h5>Detalles del pago</h5>
                        <div class="payment-amount" id="paymentAmount">S/ 0.00</div>
                    </div>
                    <div class="payment-info">
                        <span class="payment-info-label">Orden:</span>
                        <span class="payment-info-value" id="paymentOrderId">#000000</span>
                    </div>
                    <div class="payment-info">
                        <span class="payment-info-label">Método:</span>
                        <span class="payment-info-value">Tarjeta de crédito/débito</span>
                    </div>
                </div>
                
                <!-- Formulario de pago -->
                <div id="paymentFormContainer">
                    <!-- Spinner de carga -->
                    <div id="paymentLoading">
                        <div class="payment-loading-spinner"></div>
                        <p class="text-muted mt-3">Cargando formulario de pago seguro...</p>
                    </div>
                    <!-- El formulario se cargará aquí -->
                    <div id="paymentForm" class="kr-embedded"></div>
                </div>
            </div>
            
            <div class="payment-modal-footer">
                <div class="payment-security">
                    <i class="fas fa-shield-alt"></i>
                    <span>Pago 100% seguro - Tus datos están protegidos</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'app/views/layout/footer.php'; ?>

    <!-- Bootstrap y jQuery -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function () {
            // Variables
            let formToken = null;
            let paymentAmount = 0;

            // ===============================
            // CARRITO (código permanece igual)
            // ===============================
            $('.quantity-btn').on('click', function () {
                const productoId = $(this).data('producto');
                const input = $(`input[data-producto="${productoId}"]`);
                let cantidad = parseInt(input.val());

                if ($(this).hasClass('increase-btn')) cantidad++;
                if ($(this).hasClass('decrease-btn')) cantidad--;

                if (cantidad < 1) cantidad = 1;

                input.val(cantidad);
                actualizarCantidad(productoId, cantidad);
            });

            $('.quantity-input').on('change', function () {
                const productoId = $(this).data('producto');
                let cantidad = parseInt($(this).val());

                if (cantidad < 1) cantidad = 1;

                $(this).val(cantidad);
                actualizarCantidad(productoId, cantidad);
            });

            $('.remove-btn').on('click', function () {
                const productoId = $(this).data('producto');

                if (confirm('¿Eliminar producto del carrito?')) {
                    eliminarProducto(productoId);
                }
            });

            $('#vaciar-carrito').on('click', function () {
                if (confirm('¿Vaciar todo el carrito?')) {
                    window.location.href = '/index.php?action=vaciar_carrito';
                }
            });

            function actualizarCantidad(productoId, cantidad) {
                $.post('/index.php?action=actualizar_carrito', {
                    id_producto: productoId,
                    cantidad: cantidad
                }, function (response) {
                    const data = JSON.parse(response);
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.message);
                        location.reload();
                    }
                }).fail(() => {
                    alert('Error de conexión');
                    location.reload();
                });
            }

            function eliminarProducto(productoId) {
                $.post('/index.php?action=eliminar_carrito', {
                    id_producto: productoId
                }, function (response) {
                    const data = JSON.parse(response);
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.message);
                    }
                });
            }

            // ===============================
            // 💳 PAGO KRYPTON - MEJORADO
            // ===============================
            const btnPagar = document.getElementById('btnPagar');
            const paymentModal = document.getElementById('paymentModal');
            const closeModal = document.querySelector('.close-payment-modal');
            const paymentFormContainer = document.getElementById('paymentFormContainer');
            const paymentLoading = document.getElementById('paymentLoading');
            const paymentForm = document.getElementById('paymentForm');
            const paymentAmountElement = document.getElementById('paymentAmount');
            const paymentOrderIdElement = document.getElementById('paymentOrderId');

            // Abrir modal de pago
            if (btnPagar) {
                btnPagar.addEventListener('click', async function () {
                    // Verificar si Krypton está cargado
                    if (typeof KR === 'undefined') {
                        alert('Error: El sistema de pago no se cargó correctamente. Por favor, recarga la página.');
                        return;
                    }

                    btnPagar.disabled = true;
                    btnPagar.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Preparando pago...';

                    try {
                        // 1. Obtener formToken del backend
                        const response = await fetch('/index.php?action=crear_pago', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            }
                        });

                        const data = await response.json();
                        console.log('✅ Respuesta backend:', data);

                        if (data.error) {
                            alert('Error: ' + data.error);
                            btnPagar.disabled = false;
                            btnPagar.innerHTML = 'Proceder con el pago';
                            return;
                        }

                        if (!data.formToken || !data.success) {
                            alert('Error: No se pudo crear la transacción de pago');
                            btnPagar.disabled = false;
                            btnPagar.innerHTML = 'Proceder con el pago';
                            return;
                        }

                        // Guardar formToken y datos
                        formToken = data.formToken;
                        paymentAmount = data.amount || 0;
                        
                        // Actualizar UI con datos del pago
                        if (paymentAmountElement) {
                            paymentAmountElement.textContent = 'S/ ' + paymentAmount.toFixed(2);
                        }
                        
                        if (paymentOrderIdElement && data.orderId) {
                            paymentOrderIdElement.textContent = data.orderId;
                        }

                        // 2. Mostrar modal con animación
                        paymentModal.style.display = 'flex';
                        document.body.style.overflow = 'hidden'; // Prevenir scroll
                        
                        btnPagar.disabled = false;
                        btnPagar.innerHTML = 'Proceder con el pago';

                        // 3. Preparar contenedor
                        if (paymentLoading) {
                            paymentLoading.style.display = 'flex';
                        }
                        
                        if (paymentForm) {
                            paymentForm.style.display = 'none';
                        }

                        // 4. Configurar Krypton con mejor manejo
                        try {
                            console.log('🔧 Configurando Krypton...');

                            if (typeof KR === 'undefined') {
                                throw new Error('La librería de pagos no está disponible');
                            }

                            // Limpiar cualquier formulario anterior
                            if (typeof KR.removeForm === 'function') {
                                KR.removeForm();
                            }

                            // Registrar callbacks mejorados
                            KR.onFormReady(() => {
                                console.log('✅ Formulario de pago listo');
                                if (paymentLoading) {
                                    paymentLoading.style.display = 'none';
                                }
                                if (paymentForm) {
                                    paymentForm.style.display = 'block';
                                }
                                
                                // Animación suave para mostrar formulario
                                setTimeout(() => {
                                    if (paymentForm) {
                                        paymentForm.style.opacity = '0';
                                        paymentForm.style.transition = 'opacity 0.5s ease';
                                        paymentForm.style.opacity = '1';
                                    }
                                }, 100);
                                
                                // Forzar que el botón muestre solo "PAGAR"
                                
                            });

                            KR.onOrderUpdate((event) => {
                                console.log('📦 Orden actualizada:', event);
                                const transaction = event.transaction;

                                if (transaction && (transaction.status === 'PAID' || transaction.status === 'SUCCESS')) {
                                    console.log('🎉 Pago exitoso detectado');
                                    // Mostrar mensaje de éxito temporal
                                    if (paymentLoading) {
                                        paymentLoading.style.display = 'flex';
                                        paymentLoading.innerHTML = `
                                            <div style="color: #28a745; font-size: 48px;">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <p class="text-success mt-3">¡Pago exitoso! Redirigiendo...</p>
                                        `;
                                    }
                                }
                            });

                            KR.onError((error) => {
                                console.error('⚠️ Error en Krypton:', error);
                                let msg = error.errorMessage || 'Error en el proceso de pago';
                                
                                if (msg !== 'cancel' && msg !== 'CANCEL') {
                                    if (paymentLoading) {
                                        paymentLoading.style.display = 'flex';
                                        paymentLoading.innerHTML = `
                                            <div style="color: #dc3545; font-size: 48px;">
                                                <i class="fas fa-exclamation-circle"></i>
                                            </div>
                                            <div class="mt-3">
                                                <p class="text-danger fw-bold">Error en el pago</p>
                                                <p class="text-muted">${msg}</p>
                                                <button class="btn btn-primary mt-3" onclick="location.reload()">
                                                    Reintentar
                                                </button>
                                            </div>
                                        `;
                                    }
                                }
                            });

                            // Configuración del formulario con estilo mejorado
                            console.log('🚀 Cargando token en el formulario...');
                            
                            await KR.setFormConfig({
                                formToken: formToken,
                                'kr-language': 'es-ES',
                                'kr-style': 'classic',
                                'kr-placeholder-pan': 'Número de tarjeta',
                                'kr-placeholder-expiry': 'MM/AA',
                                'kr-placeholder-security-code': 'CVV',
                                'kr-placeholder-text': 'Nombre del titular',
                                'kr-form-label': 'true'
                            });

                        } catch (error) {
                            console.error('❌ Error configurando Krypton:', error);
                            
                            if (paymentLoading) {
                                paymentLoading.style.display = 'flex';
                                paymentLoading.innerHTML = `
                                    <div style="color: #dc3545; font-size: 48px;">
                                        <i class="fas fa-exclamation-circle"></i>
                                    </div>
                                    <div class="mt-3">
                                        <p class="text-danger fw-bold">Error de configuración</p>
                                        <p class="text-muted">${error.message}</p>
                                        <button class="btn btn-primary mt-3" onclick="location.reload()">
                                            Recargar página
                                        </button>
                                    </div>
                                `;
                            }
                        }

                    } catch (error) {
                        console.error('❌ Error general:', error);
                        alert('Error al iniciar el proceso de pago: ' + error.message);
                        btnPagar.disabled = false;
                        btnPagar.innerHTML = 'Proceder con el pago';
                        paymentModal.style.display = 'none';
                        document.body.style.overflow = 'auto';
                    }
                });
            }

            // Cerrar modal
            if (closeModal) {
                closeModal.addEventListener('click', function () {
                    closePaymentModal();
                });
            }

            // Cerrar modal al hacer clic fuera
            window.addEventListener('click', function (event) {
                if (event.target === paymentModal) {
                    closePaymentModal();
                }
            });

            // Función para cerrar modal
            function closePaymentModal() {
                paymentModal.style.display = 'none';
                document.body.style.overflow = 'auto';
                
                if (typeof KR !== 'undefined' && KR.removeForm) {
                    try {
                        KR.removeForm();
                    } catch (e) {
                        console.log('No se pudo remover el formulario:', e);
                    }
                }
            }

            // Prevenir cierre con ESC mientras se procesa
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape' && paymentModal.style.display === 'flex') {
                    if (confirm('¿Estás seguro de cancelar el pago?')) {
                        closePaymentModal();
                    }
                }
            });
        });
    </script>

</body>

</html>