<?php
// app/views/carrito/pago_exitoso.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// IMPORTANTE: Verificar que estas variables existan
// Deben venir del PagoController
if (!isset($orderId) || !isset($total_mostrar)) {
    // Si no vienen del controlador, intentar obtener de sesión
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: index.php?action=login');
        exit;
    }
    
    // Intentar obtener de parámetros GET (por si viene del callback de Izipay)
    $orderId = $_GET['orderId'] ?? 'PED-' . date('YmdHis');
    $transactionId = $_GET['transactionId'] ?? 'N/A';
    
    // Si no hay total, redirigir a pedidos
    if (!isset($total_mostrar)) {
        header('Location: index.php?action=pedidos');
        exit;
    }
}

// Validar que el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php?action=login');
    exit;
}

// Guardar en sesión para evitar recarga duplicada
if (!isset($_SESSION['ultimo_pedido_exitoso'])) {
    $_SESSION['ultimo_pedido_exitoso'] = [
        'orderId' => $orderId,
        'timestamp' => time()
    ];
}

// Deshabilitar caché para evitar recarga
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>¡Pago Exitoso! - Tienda de Edredones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="/public/css/estilos.css">
    <link rel="stylesheet" href="/public/css/header.css">
    <link rel="stylesheet" href="/public/css/footer.css">
    <style>
        :root {
            --color-principal: #8C6B5A;
            --color-secundario: #926d85;
            --color-fondo: #ffffff;
            --color-texto: #5A4D47;
            --color-success: #27ae60;
            --color-warning: #f39c12;
        }

        .success-container {
            max-width: 800px;
            margin: 60px auto;
            padding: 40px;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(140, 107, 90, 0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .success-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--color-success), var(--color-secundario));
        }

        .success-icon {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.1), rgba(146, 109, 133, 0.1));
            color: var(--color-success);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            margin: 0 auto 30px;
            animation: scaleIn 0.5s ease-out, pulse 2s infinite 0.5s;
            border: 4px solid rgba(39, 174, 96, 0.2);
        }

        @keyframes scaleIn {
            0% {
                transform: scale(0);
                opacity: 0;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        @keyframes pulse {
            0%, 100% {
                box-shadow: 0 0 0 0 rgba(39, 174, 96, 0.4);
            }
            50% {
                box-shadow: 0 0 0 15px rgba(39, 174, 96, 0);
            }
        }

        .order-details {
            background: linear-gradient(135deg, #faf7f5 0%, #f5f0ec 100%);
            border-radius: 12px;
            padding: 25px;
            margin: 30px 0;
            text-align: left;
            border: 1px solid #E8DCD5;
            box-shadow: inset 0 2px 4px rgba(140, 107, 90, 0.05);
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #E8DCD5;
            transition: all 0.3s ease;
        }

        .detail-row:hover {
            background: rgba(255, 255, 255, 0.5);
            padding-left: 10px;
            padding-right: 10px;
            margin-left: -10px;
            margin-right: -10px;
            border-radius: 6px;
        }

        .detail-row:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .detail-label {
            color: #726660;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .detail-value {
            color: var(--color-texto);
            font-weight: 600;
            font-size: 1.1em;
        }

        .total-row {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.1), rgba(146, 109, 133, 0.1));
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 1.2em;
            border: 2px solid rgba(39, 174, 96, 0.2);
        }

        .total-label {
            color: var(--color-texto);
            font-weight: 600;
        }

        .total-value {
            color: var(--color-success);
            font-weight: 700;
            font-size: 1.3em;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--color-secundario), var(--color-pastel));
            border: none;
            padding: 14px 35px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(146, 109, 133, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-primary:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 6px 20px rgba(146, 109, 133, 0.4);
        }

        .btn-outline {
            color: var(--color-secundario);
            border: 2px solid var(--color-secundario);
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-outline:hover {
            background: linear-gradient(135deg, var(--color-secundario), var(--color-pastel));
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(146, 109, 133, 0.2);
        }

        .btn-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 40px;
        }

        .confetti-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 9999;
        }

        .alert-info {
            background: rgba(52, 152, 219, 0.1);
            border: 1px solid rgba(52, 152, 219, 0.3);
            color: #2980b9;
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
            text-align: center;
        }

        .next-steps {
            background: #fff;
            border-radius: 12px;
            padding: 25px;
            margin-top: 30px;
            border: 1px solid #E8DCD5;
            text-align: left;
        }

        .step {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #f0f0f0;
        }

        .step:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .step-icon {
            width: 40px;
            height: 40px;
            background: var(--color-secundario);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .step-content h5 {
            color: var(--color-texto);
            margin-bottom: 5px;
        }

        .step-content p {
            color: #726660;
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .success-container {
                margin: 30px auto;
                padding: 25px 20px;
            }
            
            .btn-container {
                flex-direction: column;
                align-items: center;
            }
            
            .btn-primary, .btn-outline {
                width: 100%;
                justify-content: center;
            }
            
            .detail-row {
                flex-direction: column;
                gap: 5px;
            }
            
            .detail-label, .detail-value {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <?php
    $solo_navbar = true;
    include 'app/views/layout/header.php';
    ?>

    <div class="container">
        <div class="success-container">
            <div class="success-icon">
                <i class="fas fa-check"></i>
            </div>

            <h1 class="mb-2">¡Pago Confirmado con Éxito!</h1>
            <p class="text-muted fs-5">Tu pedido ha sido procesado exitosamente y estamos preparando todo para el envío.</p>
            
            <?php if (isset($_SESSION['mensaje'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['mensaje']; 
                    unset($_SESSION['mensaje']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="order-details">
                <h4 class="mb-4"><i class="fas fa-receipt me-2"></i>Resumen de la Transacción</h4>

                <div class="detail-row">
                    <span class="detail-label">
                        <i class="fas fa-hashtag"></i> Número de Pedido:
                    </span>
                    <span class="detail-value"><?php echo htmlspecialchars($orderId ?? 'N/A'); ?></span>
                </div>

                <div class="detail-row">
                    <span class="detail-label">
                        <i class="fas fa-id-card"></i> ID de Transacción:
                    </span>
                    <span class="detail-value"><?php echo htmlspecialchars($transactionId ?? 'N/A'); ?></span>
                </div>

                <div class="detail-row">
                    <span class="detail-label">
                        <i class="fas fa-credit-card"></i> Método de Pago:
                    </span>
                    <span class="detail-value">Izipay (Tarjeta)</span>
                </div>

                <div class="detail-row">
                    <span class="detail-label">
                        <i class="fas fa-calendar-check"></i> Fecha y Hora:
                    </span>
                    <span class="detail-value"><?php echo date('d/m/Y H:i:s'); ?></span>
                </div>

                <div class="detail-row">
                    <span class="detail-label">
                        <i class="fas fa-tag"></i> Estado:
                    </span>
                    <span class="detail-value text-success">
                        <i class="fas fa-check-circle me-1"></i> Completado
                    </span>
                </div>

                <div class="detail-row total-row">
                    <span class="total-label">
                        <i class="fas fa-sack-dollar"></i> Total Pagado:
                    </span>
                    <span class="total-value">S/ <?php echo number_format($total_mostrar ?? $total ?? 0, 2); ?></span>
                </div>
            </div>

            <div class="next-steps">
                <h4 class="mb-4"><i class="fas fa-list-check me-2"></i>¿Qué sigue?</h4>
                
                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="step-content">
                        <h5>Confirmación por correo</h5>
                        <p>Hemos enviado un correo con los detalles de tu compra a tu dirección de email registrada.</p>
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-box-open"></i>
                    </div>
                    <div class="step-content">
                        <h5>Preparación del pedido</h5>
                        <p>Estamos procesando y preparando tu pedido para el envío. Recibirás una notificación cuando sea despachado.</p>
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="step-content">
                        <h5>Envío y seguimiento</h5>
                        <p>Una vez despachado, recibirás un código de seguimiento para monitorear tu paquete.</p>
                    </div>
                </div>
            </div>

            <div class="alert-info">
                <i class="fas fa-info-circle me-2"></i>
                <strong>Importante:</strong> Conserva tu número de pedido <?php echo htmlspecialchars($orderId ?? ''); ?> para cualquier consulta con nuestro servicio de atención al cliente.
            </div>

            <div class="btn-container">
                <a href="/index.php?action=pedidos" class="btn btn-primary">
                    <i class="fas fa-box me-2"></i>Ver Mis Pedidos
                </a>
                <a href="/" class="btn-outline">
                    <i class="fas fa-home me-2"></i>Volver al Inicio
                </a>
                <a href="/index.php?action=productos" class="btn-outline">
                    <i class="fas fa-shopping-bag me-2"></i>Seguir Comprando
                </a>
            </div>
            
            <p class="text-muted mt-4 small">
                <i class="fas fa-headset me-1"></i>
                ¿Necesitas ayuda? <a href="/index.php?action=contacto" class="text-decoration-none">Contáctanos aquí</a>
            </p>
        </div>
    </div>

    <?php include 'app/views/layout/footer.php'; ?>

    <!-- Confetti Animation -->
    <canvas id="confetti-canvas" class="confetti-canvas"></canvas>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Confetti animation
        const canvas = document.getElementById('confetti-canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        let confettiParticles = [];
        const colors = ['#8C6B5A', '#926d85', '#D4B8A7', '#806783', '#27ae60', '#f39c12'];
        
        class Confetti {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height - canvas.height;
                this.size = Math.random() * 10 + 5;
                this.speed = Math.random() * 3 + 2;
                this.color = colors[Math.floor(Math.random() * colors.length)];
                this.rotation = Math.random() * 360;
                this.rotationSpeed = Math.random() * 5 - 2.5;
                this.shape = Math.random() > 0.5 ? 'circle' : 'rect';
            }
            
            update() {
                this.y += this.speed;
                this.x += Math.sin(this.y * 0.01) * 2;
                this.rotation += this.rotationSpeed;
                
                if (this.y > canvas.height) {
                    this.y = 0;
                    this.x = Math.random() * canvas.width;
                }
            }
            
            draw() {
                ctx.save();
                ctx.translate(this.x, this.y);
                ctx.rotate(this.rotation * Math.PI / 180);
                ctx.fillStyle = this.color;
                
                if (this.shape === 'circle') {
                    ctx.beginPath();
                    ctx.arc(0, 0, this.size, 0, Math.PI * 2);
                    ctx.fill();
                } else {
                    ctx.fillRect(-this.size/2, -this.size/2, this.size, this.size);
                }
                
                ctx.restore();
            }
        }
        
        // Create confetti particles
        for (let i = 0; i < 150; i++) {
            confettiParticles.push(new Confetti());
        }
        
        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            confettiParticles.forEach(particle => {
                particle.update();
                particle.draw();
            });
            
            requestAnimationFrame(animate);
        }
        
        // Start animation
        animate();
        
        // Resize canvas on window resize
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
        
        // Prevent form resubmission on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
        
        // Auto-redirect after 60 seconds (just in case)
        setTimeout(() => {
            console.log('Página de éxito cargada correctamente');
        }, 60000);
    </script>
</body>

</html>