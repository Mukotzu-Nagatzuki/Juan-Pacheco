<?php
// app/views/nosotros.php

// Obtener configuraciones dinámicas para la página Nosotros
$configuraciones_nosotros = [];
try {
    require_once 'app/config/database.php';
    require_once 'app/controllers/ConfiguracionController.php';
    
    $database = new Database();
    $db = $database->getConnection();
    $configController = new ConfiguracionController();
    $configuraciones_nosotros = $configController->obtenerConfiguraciones();
    
} catch (Exception $e) {
    error_log("Error cargando configuraciones de nosotros: " . $e->getMessage());
    // Configuraciones por defecto en caso de error
    $configuraciones_nosotros = [
        'logo' => 'Dream House',
        'titulo_nosotros' => 'Sobre Nosotros',
        'subtitulo_nosotros' => 'Proporcionando confort y calidad en cada descanso',
        'historia_titulo' => 'Nuestra Historia y Compromiso',
        'historia_contenido' => 'Desde Setiembre del 2025, en Dream House nos hemos dedicado a crear productos de la más alta calidad para transformar la experiencia de descanso de nuestros clientes.',
        'historia_contenido_2' => 'Utilizamos solo los mejores materiales y procesos de fabricación sostenibles para garantizar que cada edredón no solo sea cómodo, sino también duradero y respetuoso con el medio ambiente.',
        'compromiso_1' => 'Materiales 100% naturales y sostenibles',
        'compromiso_2' => 'Procesos de fabricación éticos',
        'compromiso_3' => 'Garantía de satisfacción del 100%',
        'compromiso_4' => 'Envío gratuito a todo el país',
        'mision_titulo' => 'Nuestra Misión',
        'mision_contenido' => 'Proporcionar productos de descanso de la más alta calidad que transformen las noches de nuestros clientes en experiencias de confort excepcional, utilizando materiales sostenibles y procesos éticos que respeten tanto a las personas como al medio ambiente.',
        'vision_titulo' => 'Nuestra Visión',
        'vision_contenido' => 'Ser la marca líder en soluciones de descanso premium en Latinoamérica, reconocida por nuestra innovación, calidad excepcional y compromiso con la sostenibilidad, contribuyendo a mejorar la calidad de vida de miles de familias a través del descanso reparador.',
        'valores_titulo' => 'Nuestros Valores',
        'valores_intro' => 'Estos son los principios que guían cada decisión que tomamos en Dream House:',
        'valor_1_titulo' => 'Calidad Superior',
        'valor_1_descripcion' => 'No comprometemos la excelencia en nuestros materiales y procesos de fabricación.',
        'valor_2_titulo' => 'Sostenibilidad',
        'valor_2_descripcion' => 'Utilizamos materiales naturales y procesos respetuosos con el medio ambiente.',
        'valor_3_titulo' => 'Enfoque en el Cliente',
        'valor_3_descripcion' => 'Nuestros clientes son el centro de todo lo que hacemos, su satisfacción es nuestra prioridad.',
        'valor_4_titulo' => 'Integridad',
        'valor_4_descripcion' => 'Actuamos con honestidad y transparencia en todas nuestras relaciones comerciales.',
        'valor_5_titulo' => 'Innovación',
        'valor_5_descripcion' => 'Buscamos constantemente mejorar nuestros productos y procesos a través de la innovación.',
        'imagen_nosotros' => 'public/img/nosotros/imagen_nosotros.jpg' // ACTUALIZADO
    ];
}

// Verificar si la imagen existe - USANDO LA NUEVA RUTA FIJA
$imagen_nosotros = $configuraciones_nosotros['imagen_nosotros'] ?? 'public/img/nosotros/imagen_nosotros.jpg';
$imagen_existe = file_exists($imagen_nosotros);

// Si no existe la imagen configurada, buscar cualquier imagen en el directorio
if (!$imagen_existe) {
    $imagenes_en_directorio = glob('public/img/nosotros/*.{jpg,jpeg,png,webp}', GLOB_BRACE);
    if (!empty($imagenes_en_directorio)) {
        $imagen_nosotros = $imagenes_en_directorio[0];
        $imagen_existe = true;
    } else {
        $imagen_nosotros = 'public/img/placeholder.jpg';
    }
}

include 'app/views/layout/header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($configuraciones_nosotros['titulo_nosotros'] ?? 'Sobre Nosotros'); ?> - <?php echo htmlspecialchars($configuraciones_nosotros['logo'] ?? 'Dream House'); ?></title>
    <link rel="stylesheet" href="public/css/estilos.css">
    <link rel="stylesheet" href="public/css/nosotros.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <!-- Historia y Compromiso -->
    <section class="history-section">
        <div class="container">
            <h1><?php echo htmlspecialchars($configuraciones_nosotros['titulo_nosotros'] ?? 'Sobre Nosotros'); ?></h1>
            <div class="divider"></div>
            <p><?php echo htmlspecialchars($configuraciones_nosotros['subtitulo_nosotros'] ?? 'Proporcionando confort y calidad en cada descanso'); ?></p>
            <div class="history-content">
                <div class="history-image">
                    <img src="<?php echo $imagen_nosotros; ?>" 
                         alt="<?php echo htmlspecialchars($configuraciones_nosotros['historia_titulo'] ?? 'Nuestra historia Dream House'); ?>" 
                         onerror="this.src='public/img/placeholder.jpg'">
                </div>
                <div class="history-text">
                    <h2><?php echo htmlspecialchars($configuraciones_nosotros['historia_titulo'] ?? 'Nuestra Historia y Compromiso'); ?></h2>
                    <p><?php echo htmlspecialchars($configuraciones_nosotros['historia_contenido'] ?? 'Desde Setiembre del 2025, en Dream House nos hemos dedicado a crear productos de la más alta calidad para transformar la experiencia de descanso de nuestros clientes.'); ?></p>
                    <p><?php echo htmlspecialchars($configuraciones_nosotros['historia_contenido_2'] ?? 'Utilizamos solo los mejores materiales y procesos de fabricación sostenibles para garantizar que cada edredón no solo sea cómodo, sino también duradero y respetuoso con el medio ambiente.'); ?></p>
                    
                    <div class="commitment-list">
                        <div class="commitment-item">
                            <i class="fas fa-check-circle"></i>
                            <span><?php echo htmlspecialchars($configuraciones_nosotros['compromiso_1'] ?? 'Materiales 100% naturales y sostenibles'); ?></span>
                        </div>
                        <div class="commitment-item">
                            <i class="fas fa-check-circle"></i>
                            <span><?php echo htmlspecialchars($configuraciones_nosotros['compromiso_2'] ?? 'Procesos de fabricación éticos'); ?></span>
                        </div>
                        <div class="commitment-item">
                            <i class="fas fa-check-circle"></i>
                            <span><?php echo htmlspecialchars($configuraciones_nosotros['compromiso_3'] ?? 'Garantía de satisfacción del 100%'); ?></span>
                        </div>
                        <div class="commitment-item">
                            <i class="fas fa-check-circle"></i>
                            <span><?php echo htmlspecialchars($configuraciones_nosotros['compromiso_4'] ?? 'Envío gratuito a todo el país'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Misión y Visión -->
    <section class="mission-vision">
        <div class="container">
            <div class="mv-grid">
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3><?php echo htmlspecialchars($configuraciones_nosotros['mision_titulo'] ?? 'Nuestra Misión'); ?></h3>
                    <div class="divider1"></div>
                    <p><?php echo htmlspecialchars($configuraciones_nosotros['mision_contenido'] ?? 'Proporcionar productos de descanso de la más alta calidad que transformen las noches de nuestros clientes en experiencias de confort excepcional, utilizando materiales sostenibles y procesos éticos que respeten tanto a las personas como al medio ambiente.'); ?></p>
                </div>
                
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3><?php echo htmlspecialchars($configuraciones_nosotros['vision_titulo'] ?? 'Nuestra Visión'); ?></h3>
                    <div class="divider1"></div>
                    <p><?php echo htmlspecialchars($configuraciones_nosotros['vision_contenido'] ?? 'Ser la marca líder en soluciones de descanso premium en Latinoamérica, reconocida por nuestra innovación, calidad excepcional y compromiso con la sostenibilidad, contribuyendo a mejorar la calidad de vida de miles de familias a través del descanso reparador.'); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Valores -->
    <section class="values-section">
        <div class="container">
            <div class="values-content">
                <h2><?php echo htmlspecialchars($configuraciones_nosotros['valores_titulo'] ?? 'Nuestros Valores'); ?></h2>
                <div class="divider1"></div>
                <p class="values-intro"><?php echo htmlspecialchars($configuraciones_nosotros['valores_intro'] ?? 'Estos son los principios que guían cada decisión que tomamos en Dream House:'); ?></p>
                
                <div class="values-grid">
                    <div class="value-item">
                        <div class="value-icon">
                            <i class="fas fa-award"></i>
                        </div>
                        <div class="value-text">
                            <h4><?php echo htmlspecialchars($configuraciones_nosotros['valor_1_titulo'] ?? 'Calidad Superior'); ?></h4>
                            <p><?php echo htmlspecialchars($configuraciones_nosotros['valor_1_descripcion'] ?? 'No comprometemos la excelencia en nuestros materiales y procesos de fabricación.'); ?></p>
                        </div>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">
                            <i class="fas fa-leaf"></i>
                        </div>
                        <div class="value-text">
                            <h4><?php echo htmlspecialchars($configuraciones_nosotros['valor_2_titulo'] ?? 'Sostenibilidad'); ?></h4>
                            <p><?php echo htmlspecialchars($configuraciones_nosotros['valor_2_descripcion'] ?? 'Utilizamos materiales naturales y procesos respetuosos con el medio ambiente.'); ?></p>
                        </div>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="value-text">
                            <h4><?php echo htmlspecialchars($configuraciones_nosotros['valor_3_titulo'] ?? 'Enfoque en el Cliente'); ?></h4>
                            <p><?php echo htmlspecialchars($configuraciones_nosotros['valor_3_descripcion'] ?? 'Nuestros clientes son el centro de todo lo que hacemos, su satisfacción es nuestra prioridad.'); ?></p>
                        </div>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <div class="value-text">
                            <h4><?php echo htmlspecialchars($configuraciones_nosotros['valor_4_titulo'] ?? 'Integridad'); ?></h4>
                            <p><?php echo htmlspecialchars($configuraciones_nosotros['valor_4_descripcion'] ?? 'Actuamos con honestidad y transparencia en todas nuestras relaciones comerciales.'); ?></p>
                        </div>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <div class="value-text">
                            <h4><?php echo htmlspecialchars($configuraciones_nosotros['valor_5_titulo'] ?? 'Innovación'); ?></h4>
                            <p><?php echo htmlspecialchars($configuraciones_nosotros['valor_5_descripcion'] ?? 'Buscamos constantemente mejorar nuestros productos y procesos a través de la innovación.'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'app/views/layout/footer.php'; ?>
</body>
</html>