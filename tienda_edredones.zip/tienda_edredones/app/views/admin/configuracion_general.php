<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener configuraciones
$configController = new ConfiguracionController();
$configuraciones = $configController->obtenerConfiguraciones();

// DEBUG: Verificar qué configuraciones se están cargando
error_log("Configuraciones cargadas en config_general:");
foreach ($configuraciones as $clave => $valor) {
    error_log("$clave: $valor");
}

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Configuración General del Sitio</h1>
    <p>Edita el contenido de las páginas de tu tienda</p>
</header>
<form method="POST" action="index.php?action=guardar-configuracion-general" enctype="multipart/form-data">
    <div class="recent-orders">
        <h3>Configuración del Sitio Web</h3>

        <!-- Pestañas para diferentes secciones -->
        <div class="config-tabs">
            <button type="button" class="tab-button active" data-tab="header">Header</button>
            <button type="button" class="tab-button" data-tab="inicio">Página Inicio</button>
            <button type="button" class="tab-button" data-tab="nosotros">Página Nosotros</button>
            <button type="button" class="tab-button" data-tab="contacto">Página Contacto</button>
            <button type="button" class="tab-button" data-tab="footer">Footer</button>
        </div>

        <!-- Contenido de las pestañas -->
        <div class="tab-content">
            <!-- Header -->
            <div id="tab-header" class="tab-pane active">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_logo">Título de la tienda:</label>
                        <input type="text" id="config_logo" name="config_logo"
                            value="<?php echo htmlspecialchars($configuraciones['logo'] ?? 'Dream House'); ?>"
                            placeholder="Título o nombre del logo">
                    </div>

                    <div class="form-group">
                        <label for="config_descripcion">Descripción del Header:</label>
                        <input type="text" id="config_descripcion" name="config_descripcion"
                            value="<?php echo htmlspecialchars($configuraciones['descripcion'] ?? 'Tienda Premium de Edredones'); ?>"
                            placeholder="Descripción breve del sitio">
                    </div>
                </div>

                <!-- Sección para subir logo -->
                <div class="form-group full" style="margin-top: 2rem;">
                    <h4>Logo del Sitio</h4>
                    <div class="logo-upload-section">
                        <!-- Logo actual -->
                        <div class="current-logo">
                            <label>Logo Actual:</label>
                            <div class="logo-preview">
                                <?php
                                // ACTUALIZADO: Usar la ruta de la base de datos
                                $logo_path = $configuraciones['logo_ruta'] ?? 'public/img/logo/logoedredon.png';
                                $logo_exists = file_exists($logo_path);

                                // Si no existe, verificar en ubicación anterior
                                if (!$logo_exists) {
                                    $logo_path_old = 'public/img/logoedredon.png';
                                    $logo_exists = file_exists($logo_path_old);
                                    if ($logo_exists) {
                                        $logo_path = $logo_path_old;
                                    }
                                }
                                ?>
                                <img src="<?php echo $logo_exists ? $logo_path : 'public/img/placeholder-logo.png'; ?>"
                                    alt="Logo Actual" id="currentLogoPreview"
                                    style="max-width: 200px; max-height: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                                <div class="logo-info">
                                    <p><strong>Archivo:</strong>
                                        <?php echo htmlspecialchars($configuraciones['logo_archivo'] ?? 'logoedredon.png'); ?>
                                    </p>
                                    <p><strong>Ubicación:</strong>
                                        <?php echo htmlspecialchars($configuraciones['logo_ruta'] ?? 'public/img/logo/logoedredon.png'); ?>
                                    </p>
                                    <?php if (!$logo_exists): ?>
                                        <p style="color: #dc3545;"><strong>Estado:</strong> Archivo no encontrado</p>
                                    <?php else: ?>
                                        <p style="color: #28a745;"><strong>Estado:</strong> Archivo encontrado</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Subir nuevo logo -->
                        <div class="upload-logo">
                            <label for="nuevo_logo">Subir Nuevo Logo:</label>
                            <input type="file" id="nuevo_logo" name="nuevo_logo"
                                accept="image/png, image/jpeg, image/jpg, image/svg+xml" class="file-input">

                            <div class="file-requirements">
                                <p><strong>Requisitos:</strong></p>
                                <ul>
                                    <li>Formatos: PNG, JPG, JPEG, SVG</li>
                                    <li>Tamaño máximo: 2MB</li>
                                    <li>Dimensiones recomendadas: 200x80px</li>
                                    <li>El archivo se guardará como: logoedredon.png</li>
                                </ul>
                            </div>

                            <!-- Vista previa del nuevo logo -->
                            <div id="newLogoPreview" style="display: none; margin-top: 1rem;">
                                <label>Vista Previa del Nuevo Logo:</label>
                                <div class="preview-container">
                                    <img id="logoPreviewImg" src="" alt="Vista previa del nuevo logo"
                                        style="max-width: 200px; max-height: 100px; border: 2px dashed #007bff; padding: 10px; border-radius: 5px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Página Inicio -->
            <div id="tab-inicio" class="tab-pane">
                <!-- Sección Características -->
                <h4>Sección Características</h4>
                <div class="form-grid">
                    <div class="form-group full">
                        <label for="config_caracteristicas_titulo">Título de Características:</label>
                        <input type="text" id="config_caracteristicas_titulo" name="config_caracteristicas_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['caracteristicas_titulo'] ?? 'Características Premium'); ?>">
                    </div>

                    <div class="form-group full">
                        <label for="config_caracteristicas_subtitulo">Subtítulo de Características:</label>
                        <textarea id="config_caracteristicas_subtitulo" name="config_caracteristicas_subtitulo"
                            rows="3"><?php echo htmlspecialchars($configuraciones['caracteristicas_subtitulo'] ?? 'Nuestros edredones están diseñados pensando en tu comodidad y bienestar'); ?></textarea>
                    </div>
                </div>

                <!-- Característica 1 -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_caracteristica_1_titulo">Característica 1 - Título:</label>
                        <input type="text" id="config_caracteristica_1_titulo" name="config_caracteristica_1_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['caracteristica_1_titulo'] ?? 'Regulación Térmica'); ?>">
                    </div>

                    <div class="form-group">
                        <label for="config_caracteristica_1_descripcion">Característica 1 - Descripción:</label>
                        <textarea id="config_caracteristica_1_descripcion" name="config_caracteristica_1_descripcion"
                            rows="3"><?php echo htmlspecialchars($configuraciones['caracteristica_1_descripcion'] ?? 'Mantén la temperatura ideal durante toda la noche con nuestra tecnología de regulación térmica avanzada.'); ?></textarea>
                    </div>
                </div>

                <!-- Característica 2 -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_caracteristica_2_titulo">Característica 2 - Título:</label>
                        <input type="text" id="config_caracteristica_2_titulo" name="config_caracteristica_2_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['caracteristica_2_titulo'] ?? 'Transpirabilidad'); ?>">
                    </div>

                    <div class="form-group">
                        <label for="config_caracteristica_2_descripcion">Característica 2 - Descripción:</label>
                        <textarea id="config_caracteristica_2_descripcion" name="config_caracteristica_2_descripcion"
                            rows="3"><?php echo htmlspecialchars($configuraciones['caracteristica_2_descripcion'] ?? 'Materiales que permiten la circulación del aire para una experiencia de sueño fresca y cómoda.'); ?></textarea>
                    </div>
                </div>

                <!-- Característica 3 -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_caracteristica_3_titulo">Característica 3 - Título:</label>
                        <input type="text" id="config_caracteristica_3_titulo" name="config_caracteristica_3_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['caracteristica_3_titulo'] ?? 'Materiales Naturales'); ?>">
                    </div>

                    <div class="form-group">
                        <label for="config_caracteristica_3_descripcion">Característica 3 - Descripción:</label>
                        <textarea id="config_caracteristica_3_descripcion" name="config_caracteristica_3_descripcion"
                            rows="3"><?php echo htmlspecialchars($configuraciones['caracteristica_3_descripcion'] ?? 'Fabricados con materiales 100% naturales y sostenibles para tu salud y el medio ambiente.'); ?></textarea>
                    </div>
                </div>

                <!-- Característica 4 -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_caracteristica_4_titulo">Característica 4 - Título:</label>
                        <input type="text" id="config_caracteristica_4_titulo" name="config_caracteristica_4_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['caracteristica_4_titulo'] ?? 'Hipoalergénico'); ?>">
                    </div>

                    <div class="form-group">
                        <label for="config_caracteristica_4_descripcion">Característica 4 - Descripción:</label>
                        <textarea id="config_caracteristica_4_descripcion" name="config_caracteristica_4_descripcion"
                            rows="3"><?php echo htmlspecialchars($configuraciones['caracteristica_4_descripcion'] ?? 'Protección contra alérgenos para un descanso seguro, especialmente para personas sensibles.'); ?></textarea>
                    </div>
                </div>

                <!-- Sección Testimonios -->
                <h4 style="margin-top: 2rem;">Sección Testimonios</h4>
                <div class="form-grid">
                    <div class="form-group full">
                        <label for="config_testimonios_titulo">Título de Testimonios:</label>
                        <input type="text" id="config_testimonios_titulo" name="config_testimonios_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['testimonios_titulo'] ?? 'Lo que dicen nuestros clientes'); ?>">
                    </div>

                    <div class="form-group full">
                        <label for="config_testimonios_subtitulo">Subtítulo de Testimonios:</label>
                        <textarea id="config_testimonios_subtitulo" name="config_testimonios_subtitulo"
                            rows="3"><?php echo htmlspecialchars($configuraciones['testimonios_subtitulo'] ?? 'Descubre las experiencias de quienes ya han transformado sus noches con nuestros productos'); ?></textarea>
                    </div>
                </div>

                <!-- Testimonio 1 -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_testimonio_1_texto">Testimonio 1 - Texto:</label>
                        <textarea id="config_testimonio_1_texto" name="config_testimonio_1_texto"
                            rows="3"><?php echo htmlspecialchars($configuraciones['testimonio_1_texto'] ?? 'Como persona alérgica, siempre he tenido problemas para encontrar ropa de cama adecuada. Estos edredones hipoalergénicos han cambiado mi vida.'); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="config_testimonio_1_autor">Testimonio 1 - Autor:</label>
                        <input type="text" id="config_testimonio_1_autor" name="config_testimonio_1_autor"
                            value="<?php echo htmlspecialchars($configuraciones['testimonio_1_autor'] ?? 'Laura Martínez'); ?>">
                    </div>
                </div>

                <!-- Testimonio 2 -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_testimonio_2_texto">Testimonio 2 - Texto:</label>
                        <textarea id="config_testimonio_2_texto" name="config_testimonio_2_texto"
                            rows="3"><?php echo htmlspecialchars($configuraciones['testimonio_2_texto'] ?? 'Desde que compré el edredón de invierno, mis noches son mucho más cálidas y reconfortantes. La calidad es excepcional y el envío fue muy rápido.'); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="config_testimonio_2_autor">Testimonio 2 - Autor:</label>
                        <input type="text" id="config_testimonio_2_autor" name="config_testimonio_2_autor"
                            value="<?php echo htmlspecialchars($configuraciones['testimonio_2_autor'] ?? 'María González'); ?>">
                    </div>
                </div>
            </div>

            <!-- Página Nosotros -->
            <div id="tab-nosotros" class="tab-pane">
                <!-- Contenido principal -->
                <div class="form-group full">
                    <label for="config_contenido_nosotros">Contenido Principal de la Página Nosotros:</label>
                </div>

                <!-- Encabezado -->
                <h4 style="margin-top: 2rem;">Encabezado</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_titulo_nosotros">Título Principal:</label>
                        <input type="text" id="config_titulo_nosotros" name="config_titulo_nosotros"
                            value="<?php echo htmlspecialchars($configuraciones['titulo_nosotros'] ?? 'Sobre Nosotros'); ?>"
                            placeholder="Título principal de la página">
                    </div>
                    <div class="form-group">
                        <label for="config_subtitulo_nosotros">Subtítulo:</label>
                        <input type="text" id="config_subtitulo_nosotros" name="config_subtitulo_nosotros"
                            value="<?php echo htmlspecialchars($configuraciones['subtitulo_nosotros'] ?? 'Proporcionando confort y calidad en cada descanso'); ?>"
                            placeholder="Subtítulo descriptivo">
                    </div>
                </div>

                <!-- NUEVA SECCIÓN: Imagen de la página Nosotros -->
                <!-- NUEVA SECCIÓN: Imagen de la página Nosotros -->
                <div class="form-group full" style="margin-top: 2rem;">
                    <h4>Imagen de la Página Nosotros</h4>
                    <div class="logo-upload-section">
                        <!-- Imagen actual -->
                        <div class="current-logo">
                            <label>Imagen Actual:</label>
                            <div class="logo-preview">
                                <?php
                                $imagen_nosotros_path = $configuraciones['imagen_nosotros'] ?? 'public/img/nosotros/imagen_nosotros.jpg';
                                $imagen_nosotros_exists = file_exists($imagen_nosotros_path);

                                // Si no existe, buscar cualquier imagen en el directorio
                                if (!$imagen_nosotros_exists) {
                                    $imagenes_en_directorio = glob('public/img/nosotros/*.{jpg,jpeg,png,webp}', GLOB_BRACE);
                                    if (!empty($imagenes_en_directorio)) {
                                        $imagen_nosotros_path = $imagenes_en_directorio[0];
                                        $imagen_nosotros_exists = true;
                                    } else {
                                        $imagen_nosotros_path = 'public/img/placeholder.jpg';
                                    }
                                }
                                ?>
                                <img src="<?php echo $imagen_nosotros_path; ?>" alt="Imagen Actual de Nosotros"
                                    id="currentNosotrosImagePreview"
                                    style="max-width: 300px; max-height: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 5px; object-fit: cover;">
                                <div class="logo-info">
                                    <p><strong>Archivo:</strong>
                                        <?php echo htmlspecialchars(basename($imagen_nosotros_path)); ?>
                                    </p>
                                    <p><strong>Ubicación:</strong>
                                        <?php echo htmlspecialchars($imagen_nosotros_path); ?>
                                    </p>
                                    <?php if (!$imagen_nosotros_exists): ?>
                                        <p style="color: #dc3545;"><strong>Estado:</strong> No hay imagen configurada</p>
                                    <?php else: ?>
                                        <p style="color: #28a745;"><strong>Estado:</strong> Imagen encontrada</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Subir nueva imagen -->
                        <div class="upload-logo">
                            <label for="imagen_nosotros_upload">Subir Nueva Imagen:</label>
                            <input type="file" id="imagen_nosotros_upload" name="imagen_nosotros_upload"
                                accept="image/png, image/jpeg, image/jpg, image/webp" class="file-input">

                            <div class="file-requirements">
                                <p><strong>Requisitos:</strong></p>
                                <ul>
                                    <li>Formatos: PNG, JPG, JPEG, WEBP</li>
                                    <li>Tamaño máximo: 3MB</li>
                                    <li>Dimensiones recomendadas: 600x400px o similar</li>
                                    <li>La imagen anterior se eliminará automáticamente</li>
                                    <li>Solo se mantendrá una imagen en el sistema</li>
                                </ul>
                            </div>

                            <!-- Vista previa de la nueva imagen -->
                            <div id="newNosotrosImagePreview" style="display: none; margin-top: 1rem;">
                                <label>Vista Previa de la Nueva Imagen:</label>
                                <div class="preview-container">
                                    <img id="nosotrosImagePreviewImg" src="" alt="Vista previa de la nueva imagen"
                                        style="max-width: 300px; max-height: 200px; border: 2px dashed #007bff; padding: 10px; border-radius: 5px; object-fit: cover;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Sección Historia -->
                <h4 style="margin-top: 2rem;">Sección Historia</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_historia_titulo">Título de Historia:</label>
                        <input type="text" id="config_historia_titulo" name="config_historia_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['historia_titulo'] ?? 'Nuestra Historia y Compromiso'); ?>"
                            placeholder="Título de la sección historia">
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_historia_contenido">Contenido Historia (Parte 1):</label>
                        <textarea id="config_historia_contenido" name="config_historia_contenido"
                            rows="3"><?php echo htmlspecialchars($configuraciones['historia_contenido'] ?? 'Desde Setiembre del 2025, en Dream House nos hemos dedicado a crear productos de la más alta calidad para transformar la experiencia de descanso de nuestros clientes.'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="config_historia_contenido_2">Contenido Historia (Parte 2):</label>
                        <textarea id="config_historia_contenido_2" name="config_historia_contenido_2"
                            rows="3"><?php echo htmlspecialchars($configuraciones['historia_contenido_2'] ?? 'Utilizamos solo los mejores materiales y procesos de fabricación sostenibles para garantizar que cada edredón no solo sea cómodo, sino también duradero y respetuoso con el medio ambiente.'); ?></textarea>
                    </div>
                </div>

                <!-- Compromisos -->
                <h5 style="margin-top: 1rem;">Compromisos</h5>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_compromiso_1">Compromiso 1:</label>
                        <input type="text" id="config_compromiso_1" name="config_compromiso_1"
                            value="<?php echo htmlspecialchars($configuraciones['compromiso_1'] ?? 'Materiales 100% naturales y sostenibles'); ?>"
                            placeholder="Primer compromiso">
                    </div>
                    <div class="form-group">
                        <label for="config_compromiso_2">Compromiso 2:</label>
                        <input type="text" id="config_compromiso_2" name="config_compromiso_2"
                            value="<?php echo htmlspecialchars($configuraciones['compromiso_2'] ?? 'Procesos de fabricación éticos'); ?>"
                            placeholder="Segundo compromiso">
                    </div>
                    <div class="form-group">
                        <label for="config_compromiso_3">Compromiso 3:</label>
                        <input type="text" id="config_compromiso_3" name="config_compromiso_3"
                            value="<?php echo htmlspecialchars($configuraciones['compromiso_3'] ?? 'Garantía de satisfacción del 100%'); ?>"
                            placeholder="Tercer compromiso">
                    </div>
                    <div class="form-group">
                        <label for="config_compromiso_4">Compromiso 4:</label>
                        <input type="text" id="config_compromiso_4" name="config_compromiso_4"
                            value="<?php echo htmlspecialchars($configuraciones['compromiso_4'] ?? 'Envío gratuito a todo el país'); ?>"
                            placeholder="Cuarto compromiso">
                    </div>
                </div>

                <!-- Misión y Visión -->
                <h4 style="margin-top: 2rem;">Misión y Visión</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_mision_titulo">Título Misión:</label>
                        <input type="text" id="config_mision_titulo" name="config_mision_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['mision_titulo'] ?? 'Nuestra Misión'); ?>"
                            placeholder="Título de misión">
                    </div>
                    <div class="form-group">
                        <label for="config_vision_titulo">Título Visión:</label>
                        <input type="text" id="config_vision_titulo" name="config_vision_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['vision_titulo'] ?? 'Nuestra Visión'); ?>"
                            placeholder="Título de visión">
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_mision_contenido">Contenido Misión:</label>
                        <textarea id="config_mision_contenido" name="config_mision_contenido"
                            rows="3"><?php echo htmlspecialchars($configuraciones['mision_contenido'] ?? 'Proporcionar productos de descanso de la más alta calidad que transformen las noches de nuestros clientes en experiencias de confort excepcional, utilizando materiales sostenibles y procesos éticos que respeten tanto a las personas como al medio ambiente.'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="config_vision_contenido">Contenido Visión:</label>
                        <textarea id="config_vision_contenido" name="config_vision_contenido"
                            rows="3"><?php echo htmlspecialchars($configuraciones['vision_contenido'] ?? 'Ser la marca líder en soluciones de descanso premium en Latinoamérica, reconocida por nuestra innovación, calidad excepcional y compromiso con la sostenibilidad, contribuyendo a mejorar la calidad de vida de miles de familias a través del descanso reparador.'); ?></textarea>
                    </div>
                </div>

                <!-- Valores -->
                <h4 style="margin-top: 2rem;">Valores</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_valores_titulo">Título Valores:</label>
                        <input type="text" id="config_valores_titulo" name="config_valores_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['valores_titulo'] ?? 'Nuestros Valores'); ?>"
                            placeholder="Título de la sección valores">
                    </div>
                    <div class="form-group">
                        <label for="config_valores_intro">Introducción Valores:</label>
                        <input type="text" id="config_valores_intro" name="config_valores_intro"
                            value="<?php echo htmlspecialchars($configuraciones['valores_intro'] ?? 'Estos son los principios que guían cada decisión que tomamos en Dream House:'); ?>"
                            placeholder="Texto introductorio de valores">
                    </div>
                </div>

                <!-- Valores individuales -->
                <h5 style="margin-top: 1rem;">Valores Individuales</h5>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_valor_1_titulo">Valor 1 - Título:</label>
                        <input type="text" id="config_valor_1_titulo" name="config_valor_1_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['valor_1_titulo'] ?? 'Calidad Superior'); ?>"
                            placeholder="Título del primer valor">
                    </div>
                    <div class="form-group">
                        <label for="config_valor_1_descripcion">Valor 1 - Descripción:</label>
                        <textarea id="config_valor_1_descripcion" name="config_valor_1_descripcion"
                            rows="2"><?php echo htmlspecialchars($configuraciones['valor_1_descripcion'] ?? 'No comprometemos la excelencia en nuestros materiales y procesos de fabricación.'); ?></textarea>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_valor_2_titulo">Valor 2 - Título:</label>
                        <input type="text" id="config_valor_2_titulo" name="config_valor_2_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['valor_2_titulo'] ?? 'Sostenibilidad'); ?>"
                            placeholder="Título del segundo valor">
                    </div>
                    <div class="form-group">
                        <label for="config_valor_2_descripcion">Valor 2 - Descripción:</label>
                        <textarea id="config_valor_2_descripcion" name="config_valor_2_descripcion"
                            rows="2"><?php echo htmlspecialchars($configuraciones['valor_2_descripcion'] ?? 'Utilizamos materiales naturales y procesos respetuosos con el medio ambiente.'); ?></textarea>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_valor_3_titulo">Valor 3 - Título:</label>
                        <input type="text" id="config_valor_3_titulo" name="config_valor_3_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['valor_3_titulo'] ?? 'Enfoque en el Cliente'); ?>"
                            placeholder="Título del tercer valor">
                    </div>
                    <div class="form-group">
                        <label for="config_valor_3_descripcion">Valor 3 - Descripción:</label>
                        <textarea id="config_valor_3_descripcion" name="config_valor_3_descripcion"
                            rows="2"><?php echo htmlspecialchars($configuraciones['valor_3_descripcion'] ?? 'Nuestros clientes son el centro de todo lo que hacemos, su satisfacción es nuestra prioridad.'); ?></textarea>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_valor_4_titulo">Valor 4 - Título:</label>
                        <input type="text" id="config_valor_4_titulo" name="config_valor_4_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['valor_4_titulo'] ?? 'Integridad'); ?>"
                            placeholder="Título del cuarto valor">
                    </div>
                    <div class="form-group">
                        <label for="config_valor_4_descripcion">Valor 4 - Descripción:</label>
                        <textarea id="config_valor_4_descripcion" name="config_valor_4_descripcion"
                            rows="2"><?php echo htmlspecialchars($configuraciones['valor_4_descripcion'] ?? 'Actuamos con honestidad y transparencia en todas nuestras relaciones comerciales.'); ?></textarea>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_valor_5_titulo">Valor 5 - Título:</label>
                        <input type="text" id="config_valor_5_titulo" name="config_valor_5_titulo"
                            value="<?php echo htmlspecialchars($configuraciones['valor_5_titulo'] ?? 'Innovación'); ?>"
                            placeholder="Título del quinto valor">
                    </div>
                    <div class="form-group">
                        <label for="config_valor_5_descripcion">Valor 5 - Descripción:</label>
                        <textarea id="config_valor_5_descripcion" name="config_valor_5_descripcion"
                            rows="2"><?php echo htmlspecialchars($configuraciones['valor_5_descripcion'] ?? 'Buscamos constantemente mejorar nuestros productos y procesos a través de la innovación.'); ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Página Contacto -->
            <div id="tab-contacto" class="tab-pane">

                <!-- Información de Contacto -->
                <h4 style="margin-top: 2rem;">Información de Contacto</h4>
                <div class="form-grid">
                    <div class="form-group full">
                        <label for="config_direccion">Dirección:</label>
                        <input type="text" id="config_direccion" name="config_direccion"
                            value="<?php echo htmlspecialchars($configuraciones['direccion'] ?? 'Calle Principal 123, Ciudad, CP 12345'); ?>"
                            placeholder="Dirección completa">
                    </div>

                    <div class="form-group">
                        <label for="config_telefono_contacto">Teléfono de Contacto:</label>
                        <input type="text" id="config_telefono_contacto" name="config_telefono_contacto"
                            value="<?php echo htmlspecialchars($configuraciones['telefono_contacto'] ?? '+51 987 654 321'); ?>"
                            placeholder="Número de teléfono para contacto">
                    </div>

                    <div class="form-group">
                        <label for="config_email_contacto">Email de Contacto:</label>
                        <input type="email" id="config_email_contacto" name="config_email_contacto"
                            value="<?php echo htmlspecialchars($configuraciones['email_contacto'] ?? 'info@dreamhouse.com'); ?>"
                            placeholder="Correo electrónico para contacto">
                    </div>

                    <div class="form-group full">
                        <label for="config_horario_atencion">Horario de Atención:</label>
                        <textarea id="config_horario_atencion" name="config_horario_atencion" rows="3"
                            placeholder="Ej: Lunes a Viernes 9:00 – 18:00&#10;Sábados 10:00 – 14:00"><?php echo htmlspecialchars($configuraciones['horario_atencion'] ?? 'Lunes a Viernes 9:00 – 18:00' . "\n" . 'Sábados 10:00 – 14:00'); ?></textarea>
                        <small style="color: #666; font-size: 0.85rem;">Usa saltos de línea para formatear el horario
                            (presiona Enter para nueva línea)</small>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <div id="tab-footer" class="tab-pane">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_telefono">Teléfono:</label>
                        <input type="text" id="config_telefono" name="config_telefono"
                            value="<?php echo htmlspecialchars($configuraciones['telefono'] ?? '+51 123 456 789'); ?>"
                            placeholder="Número de teléfono">
                    </div>

                    <div class="form-group full">
                        <label for="config_descripcion_footer">Descripción del Footer:</label>
                        <textarea id="config_descripcion_footer" name="config_descripcion_footer"
                            rows="4"><?php echo htmlspecialchars($configuraciones['descripcion_footer'] ?? 'Tu tienda premium de edredones y ropa de cama. Ofrecemos productos de la más alta calidad para garantizar tu confort y descanso.'); ?></textarea>
                    </div>
                </div>

                <!-- Redes Sociales -->
                <h4 style="margin-top: 2rem;">Redes Sociales</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="config_facebook_url">Facebook URL:</label>
                        <input type="url" id="config_facebook_url" name="config_facebook_url"
                            value="<?php echo htmlspecialchars($configuraciones['facebook_url'] ?? ''); ?>"
                            placeholder="https://facebook.com/tu-pagina">
                    </div>

                    <div class="form-group">
                        <label for="config_instagram_url">Instagram URL:</label>
                        <input type="url" id="config_instagram_url" name="config_instagram_url"
                            value="<?php echo htmlspecialchars($configuraciones['instagram_url'] ?? ''); ?>"
                            placeholder="https://instagram.com/tu-usuario">
                    </div>

                    <div class="form-group">
                        <label for="config_tiktok_url">TikTok URL:</label>
                        <input type="url" id="config_tiktok_url" name="config_tiktok_url"
                            value="<?php echo htmlspecialchars($configuraciones['tiktok_url'] ?? ''); ?>"
                            placeholder="https://tiktok.com/@tu-usuario">
                    </div>

                    <div class="form-group">
                        <label for="config_youtube_url">YouTube URL:</label>
                        <input type="url" id="config_youtube_url" name="config_youtube_url"
                            value="<?php echo htmlspecialchars($configuraciones['youtube_url'] ?? ''); ?>"
                            placeholder="https://youtube.com/tu-canal">
                    </div>

                    <div class="form-group">
                        <label for="config_whatsapp_url">WhatsApp URL:</label>
                        <input type="url" id="config_whatsapp_url" name="config_whatsapp_url"
                            value="<?php echo htmlspecialchars($configuraciones['whatsapp_url'] ?? ''); ?>"
                            placeholder="https://wa.me/tu-numero">
                    </div>
                </div>

                <div class="form-group full" style="margin-top: 1rem;">
                    <div class="alert alert-info"
                        style="background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; padding: 1rem; border-radius: 5px;">
                        <strong>Nota:</strong> El título del footer se tomará automáticamente del título de la tienda
                        configurado en el Header.
                    </div>
                </div>
            </div>
        </div>

        <!-- Botones de acción -->
        <div class="form-actions"
            style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--color-beige-claro);">
            <button type="submit" class="btn-ver" style="padding: 0.75rem 2rem;">
                <i class="bi bi-save"></i> Guardar Configuración
            </button>
            <a href="index.php?action=configuracion" class="btn-ver"
                style="background: #6c757d; padding: 0.75rem 2rem; margin-left: 1rem;">
                <i class="bi bi-arrow-left"></i> Volver
            </a>
        </div>
    </div>
</form>

<style>
    /* Estilos para las pestañas */
    .config-tabs {
        display: flex;
        border-bottom: 2px solid var(--color-beige-claro);
        margin-bottom: 2rem;
        flex-wrap: wrap;
    }

    .tab-button {
        background: none;
        border: none;
        padding: 1rem 1.5rem;
        cursor: pointer;
        font-weight: 600;
        color: var(--color-plomo);
        border-bottom: 3px solid transparent;
        transition: all 0.3s ease;
    }

    .tab-button:hover {
        color: var(--color-principal);
        background: var(--color-fondo);
    }

    .tab-button.active {
        color: var(--color-secundario);
        border-bottom-color: var(--color-secundario);
    }

    .tab-pane {
        display: none;
        background: white;
    }

    .tab-pane.active {
        display: block;
    }

    /* Estilos para formularios */
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }

    .form-group {
        display: flex;
        flex-direction: column;
    }

    .form-group.full {
        grid-column: 1 / -1;
    }

    .form-group label {
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: var(--color-texto);
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
        padding: 0.75rem;
        border: 1px solid var(--color-beige-claro);
        border-radius: var(--radio);
        font-size: 0.9rem;
        transition: border 0.3s;
        background-color: white;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
        outline: none;
        border-color: var(--color-secundario);
        box-shadow: 0 0 5px rgba(145, 107, 131, 0.2);
    }

    .form-group textarea {
        resize: vertical;
        min-height: 100px;
        line-height: 1.5;
    }

    /* Estilos específicos para la sección del logo */
    .logo-upload-section {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        margin-top: 1rem;
    }

    .current-logo,
    .upload-logo {
        padding: 1.5rem;
        background: var(--color-fondo);
        border-radius: var(--radio);
        border: 1px solid var(--color-beige-claro);
    }

    .logo-preview {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        margin-top: 1rem;
    }

    .logo-info {
        font-size: 0.85rem;
        color: var(--color-plomo);
    }

    .logo-info p {
        margin: 0.25rem 0;
    }

    .file-requirements {
        margin-top: 1rem;
        padding: 1rem;
        background: white;
        border-radius: var(--radio);
        border-left: 4px solid var(--color-secundario);
    }

    .file-requirements ul {
        margin: 0.5rem 0;
        padding-left: 1.5rem;
    }

    .file-requirements li {
        margin-bottom: 0.25rem;
        font-size: 0.85rem;
    }

    .file-input {
        padding: 0.75rem;
        border: 2px dashed var(--color-beige-claro);
        border-radius: var(--radio);
        background: white;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .file-input:hover {
        border-color: var(--color-secundario);
        background: rgba(145, 107, 131, 0.05);
    }

    .preview-container {
        text-align: center;
        padding: 1rem;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .config-tabs {
            flex-direction: column;
        }

        .tab-button {
            text-align: left;
            border-bottom: 1px solid var(--color-beige-claro);
            border-left: 3px solid transparent;
        }

        .tab-button.active {
            border-left-color: var(--color-secundario);
            border-bottom-color: var(--color-beige-claro);
        }

        .form-grid {
            grid-template-columns: 1fr;
        }

        .logo-upload-section {
            grid-template-columns: 1fr;
        }
    }
</style>

<script>
    // Funcionalidad de pestañas
    document.addEventListener('DOMContentLoaded', function () {
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabPanes = document.querySelectorAll('.tab-pane');

        tabButtons.forEach(button => {
            button.addEventListener('click', function () {
                const targetTab = this.getAttribute('data-tab');

                // Remover clase active de todos los botones y paneles
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanes.forEach(pane => pane.classList.remove('active'));

                // Agregar clase active al botón y panel actual
                this.classList.add('active');
                document.getElementById(`tab-${targetTab}`).classList.add('active');
            });
        });

        // Vista previa del logo
        const logoInput = document.getElementById('nuevo_logo');
        const logoPreview = document.getElementById('newLogoPreview');
        const logoPreviewImg = document.getElementById('logoPreviewImg');

        logoInput.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    logoPreviewImg.src = e.target.result;
                    logoPreview.style.display = 'block';
                }

                reader.readAsDataURL(file);
            } else {
                logoPreview.style.display = 'none';
            }
        });

        // NUEVO: Vista previa de la imagen de Nosotros
        const imagenNosotrosInput = document.getElementById('imagen_nosotros_upload');
        const imagenNosotrosPreview = document.getElementById('newNosotrosImagePreview');
        const imagenNosotrosPreviewImg = document.getElementById('nosotrosImagePreviewImg');

        imagenNosotrosInput.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    imagenNosotrosPreviewImg.src = e.target.result;
                    imagenNosotrosPreview.style.display = 'block';
                }

                reader.readAsDataURL(file);
            } else {
                imagenNosotrosPreview.style.display = 'none';
            }
        });
    });
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';