<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Verificar que el usuario sea administrador
if ($_SESSION['rol'] !== 'admin') {
    header('Location: index.php?action=dashboard');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: index.php?action=pedidos_admin');
    exit;
}

$id_pedido = $_GET['id'];

// Obtener información del pedido
$stmt = $conn->prepare("
    SELECT p.*, CONCAT(u.nombre, ' ', u.apellido) as cliente_nombre,
           u.correo, u.telefono, u.direccion,
           u.distrito, u.ciudad, u.provincia, u.referencia
    FROM pedidos p 
    JOIN usuarios u ON p.id_usuario = u.id_usuario 
    WHERE p.id_pedido = ?
");
$stmt->execute([$id_pedido]);
$pedido = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pedido) {
    header('Location: index.php?action=pedidos_admin');
    exit;
}

// Obtener detalles del pedido
$stmt = $conn->prepare("
    SELECT dp.*, pr.nombre as producto_nombre, pr.precio, pr.imagen_principal
    FROM detalle_pedido dp 
    JOIN productos pr ON dp.id_producto = pr.id_producto 
    WHERE dp.id_pedido = ?
");
$stmt->execute([$id_pedido]);
$detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
        <div>
            <h1>Detalles del Pedido</h1>
            <p>Información completa del pedido DH-<?= str_pad($pedido['id_pedido'], 4, '0', STR_PAD_LEFT) ?></p>
        </div>
        <a href="index.php?action=dashboard" class="btn-ver" style="display: inline-flex; align-items: center; gap: 0.5rem; white-space: nowrap;">
            <i class="bi bi-arrow-left"></i>
            Volver al Dashboard
        </a>
    </div>
</header>

<section class="recent-orders">
    <h3>Detalles del Pedido: DH-<?= str_pad($pedido['id_pedido'], 4, '0', STR_PAD_LEFT) ?></h3>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
        <!-- Información del cliente -->
        <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra);">
            <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal); border-bottom: 2px solid var(--color-secundario); padding-bottom: 0.5rem;">Información del Cliente</h4>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Cliente:</strong>
                    <span><?= htmlspecialchars($pedido['cliente_nombre']) ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Correo:</strong>
                    <span><?= htmlspecialchars($pedido['correo']) ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Teléfono:</strong>
                    <span><?= htmlspecialchars($pedido['telefono'] ?? 'No proporcionado') ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Dirección:</strong>
                    <span style="text-align: right;"><?= htmlspecialchars($pedido['direccion'] ?? 'No proporcionada') ?></span>
                </div>
                <?php if ($pedido['distrito']): ?>
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Ubicación:</strong>
                    <span style="text-align: right;"><?= htmlspecialchars($pedido['distrito']) ?>, <?= htmlspecialchars($pedido['ciudad']) ?>, <?= htmlspecialchars($pedido['provincia']) ?></span>
                </div>
                <?php endif; ?>
                <?php if ($pedido['referencia']): ?>
                <div style="display: flex; justify-content: space-between;">
                    <strong style="color: var(--color-texto);">Referencia:</strong>
                    <span style="text-align: right;"><?= htmlspecialchars($pedido['referencia']) ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Información del pedido -->
        <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra);">
            <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal); border-bottom: 2px solid var(--color-secundario); padding-bottom: 0.5rem;">Información del Pedido</h4>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Fecha:</strong>
                    <span><?= date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])) ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Total:</strong>
                    <span style="font-weight: bold; color: var(--color-principal);">$<?= number_format($pedido['total'], 2) ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                    <strong style="color: var(--color-texto);">Estado:</strong>
                    <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $pedido['estado'])) ?>">
                        <?= ucfirst($pedido['estado']) ?>
                    </span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <strong style="color: var(--color-texto);">Método de Pago:</strong>
                    <span><?= ucfirst(str_replace('_', ' ', $pedido['metodo_pago'])) ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Productos del pedido -->
    <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); margin-bottom: 2rem;">
        <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal); border-bottom: 2px solid var(--color-secundario); padding-bottom: 0.5rem;">Productos del Pedido</h4>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            <?php foreach ($detalles as $detalle): ?>
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 1rem; background: #f8f9fa; border-radius: var(--radio);">
                    <div style="display: flex; align-items: center; gap: 1rem; flex: 1;">
                        <?php if ($detalle['imagen_principal']): ?>
                            <img src="<?= htmlspecialchars($detalle['imagen_principal']) ?>" alt="<?= htmlspecialchars($detalle['producto_nombre']) ?>" style="width: 60px; height: 60px; object-fit: cover; border-radius: var(--radio);">
                        <?php else: ?>
                            <div style="width: 60px; height: 60px; background: #f0f0f0; border-radius: var(--radio); display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-image" style="color: #ccc; font-size: 1.5rem;"></i>
                            </div>
                        <?php endif; ?>
                        <div style="flex: 1;">
                            <div style="font-weight: bold; color: var(--color-texto); margin-bottom: 0.25rem;"><?= htmlspecialchars($detalle['producto_nombre']) ?></div>
                            <div style="color: #666; font-size: 0.9rem;">
                                $<?= number_format($detalle['precio_unitario'], 2) ?> x <?= $detalle['cantidad'] ?> unidades
                            </div>
                        </div>
                    </div>
                    <div style="font-weight: bold; color: var(--color-principal); font-size: 1.1rem;">
                        $<?= number_format($detalle['subtotal'], 2) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Total -->
    <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); margin-bottom: 2rem;">
        <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal); border-bottom: 2px solid var(--color-secundario); padding-bottom: 0.5rem;">Resumen del Total</h4>
        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
            <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                <span style="color: var(--color-texto);">Subtotal:</span>
                <span>$<?= number_format($pedido['total'], 2) ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px solid var(--color-beige-claro);">
                <span style="color: var(--color-texto);">Envío:</span>
                <span>$0.00</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: bold; color: var(--color-principal); padding-top: 0.5rem;">
                <span>Total:</span>
                <span>$<?= number_format($pedido['total'], 2) ?></span>
            </div>
        </div>
    </div>

    <!-- Botones de acción -->
    <div style="display: flex; gap: 1rem; justify-content: flex-start;">
        <a href="index.php?action=pedidos_admin" class="btn-ver" style="display: inline-flex; align-items: center; gap: 0.5rem;">
            <i class="bi bi-arrow-left"></i> Volver a Pedidos
        </a>
        
        <!-- Formulario para actualizar estado -->
        <form method="POST" action="index.php?action=actualizar_estado_pedido" style="display: inline-flex; align-items: center; gap: 0.5rem;">
            <input type="hidden" name="id_pedido" value="<?= $pedido['id_pedido'] ?>">
            <select name="estado" style="padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio); font-size: 0.9rem;">
                <option value="pendiente" <?= $pedido['estado'] == 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                <option value="pagado" <?= $pedido['estado'] == 'pagado' ? 'selected' : '' ?>>Pagado</option>
                <option value="en preparación" <?= $pedido['estado'] == 'en preparación' ? 'selected' : '' ?>>En Preparación</option>
                <option value="en reparto" <?= $pedido['estado'] == 'en reparto' ? 'selected' : '' ?>>En Reparto</option>
                <option value="entregado" <?= $pedido['estado'] == 'entregado' ? 'selected' : '' ?>>Entregado</option>
                <option value="cancelado" <?= $pedido['estado'] == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
            </select>
            <button type="submit" class="btn-ver" style="padding: 8px 16px;">
                <i class="bi bi-arrow-clockwise"></i> Actualizar Estado
            </button>
        </form>
    </div>
</section>

<style>
/* Estilos adicionales para mejorar la presentación */
.producto-imagen-placeholder {
    width: 60px;
    height: 60px;
    background: #f0f0f0;
    border-radius: var(--radio);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ccc;
}

.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: capitalize;
}

.status-pendiente { background: #fdecea; color: #c62828; }
.status-pagado { background: #e0f8e9; color: #2e7d32; }
.status-en-preparación { background: #fff4e5; color: #e65100; }
.status-en-reparto { background: #e3f2fd; color: #1565c0; }
.status-entregado { background: #f3e5f5; color: #7b1fa2; }
.status-cancelado { background: #f5f5f5; color: #616161; }

@media (max-width: 768px) {
    .info-grid-mobile {
        grid-template-columns: 1fr !important;
    }
    
    .producto-item-mobile {
        flex-direction: column !important;
        align-items: flex-start !important;
        gap: 1rem !important;
    }
    
    .acciones-mobile {
        flex-direction: column !important;
        align-items: flex-start !important;
    }
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';