<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener todos los clientes con información de pedidos
$stmt = $conn->prepare("
    SELECT u.*, 
           COUNT(p.id_pedido) as total_pedidos,
           COALESCE(SUM(p.total), 0) as total_gastado,
           MAX(p.fecha_pedido) as ultima_compra
    FROM usuarios u 
    LEFT JOIN pedidos p ON u.id_usuario = p.id_usuario 
    WHERE u.rol = 'cliente'
    GROUP BY u.id_usuario 
    ORDER BY u.fecha_registro DESC
");
$stmt->execute();
$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Gestión de Clientes</h1>
    <p>Administra y gestiona todos los clientes de la tienda</p>
</header>

<section class="recent-orders">
    <h3>Todos los Clientes</h3>

    <?php if (!empty($clientes)): ?>
        <table class="orders-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Pedidos</th>
                    <th>Registro</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($clientes as $cliente): ?>
                    <tr>
                        <td><strong>#<?= $cliente['id_usuario'] ?></strong></td>
                        <td>
                            <strong><?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?></strong>
                        </td>
                        <td><?= htmlspecialchars($cliente['correo']) ?></td>
                        <td><?= htmlspecialchars($cliente['telefono'] ?? 'No proporcionado') ?></td>
                        <td><strong><?= $cliente['total_pedidos'] ?></strong></td>
                        <td><?= date('d/m/Y', strtotime($cliente['fecha_registro'])) ?></td>
                        <td>
                            <span class="status-badge <?= $cliente['estado'] == 'activo' ? 'status-entregado' : 'status-pendiente' ?>">
                                <?= ucfirst($cliente['estado']) ?>
                            </span>
                        </td>
                        <td style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                            <button class="btn-ver" onclick="abrirModalDetalles(<?= htmlspecialchars(json_encode($cliente)) ?>)" style="padding: 6px 12px; font-size: 0.8rem;">
                                <i class="bi bi-eye"></i> Ver
                            </button>
                            <button class="btn-ver" onclick="abrirModalEditar(<?= htmlspecialchars(json_encode($cliente)) ?>)" style="padding: 6px 12px; font-size: 0.8rem; background: var(--color-principal);">
                                <i class="bi bi-pencil"></i> Editar
                            </button>
                            <button class="btn-ver" onclick="eliminarCliente(<?= $cliente['id_usuario'] ?>)" style="padding: 6px 12px; font-size: 0.8rem; background: #b14e35ff;">
                                <i class="bi bi-trash"></i> Eliminar
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div style="text-align: center; padding: 3rem; color: #7f8c8d;">
            <i class="bi bi-people" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
            <h3>No hay clientes</h3>
            <p>No se han encontrado clientes en el sistema.</p>
        </div>
    <?php endif; ?>
</section>

<!-- Modal Detalles del Cliente -->
<div id="modalDetalles" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Detalles del Cliente</h3>
            <button class="close" onclick="cerrarModal('modalDetalles')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="info-grid">
                <div class="info-card">
                    <h4>Información Personal</h4>
                    <div class="info-item">
                        <strong>Nombre:</strong>
                        <span id="detalle-nombre"></span>
                    </div>
                    <div class="info-item">
                        <strong>Email:</strong>
                        <span id="detalle-email"></span>
                    </div>
                    <div class="info-item">
                        <strong>Teléfono:</strong>
                        <span id="detalle-telefono"></span>
                    </div>
                    <div class="info-item">
                        <strong>Estado:</strong>
                        <span id="detalle-estado"></span>
                    </div>
                </div>

                <div class="info-card">
                    <h4>Información de Contacto</h4>
                    <div class="info-item">
                        <strong>Dirección:</strong>
                        <span id="detalle-direccion"></span>
                    </div>
                    <div class="info-item">
                        <strong>Ciudad:</strong>
                        <span id="detalle-ciudad"></span>
                    </div>
                    <div class="info-item">
                        <strong>Distrito:</strong>
                        <span id="detalle-distrito"></span>
                    </div>
                    <div class="info-item">
                        <strong>Provincia:</strong>
                        <span id="detalle-provincia"></span>
                    </div>
                </div>
            </div>

            <div class="info-card">
                <h4>Historial de Compras</h4>
                <div class="info-item">
                    <strong>Total de Pedidos:</strong>
                    <span id="detalle-total-pedidos"></span>
                </div>
                <div class="info-item">
                    <strong>Total Gastado:</strong>
                    <span id="detalle-total-gastado"></span>
                </div>
                <div class="info-item">
                    <strong>Última Compra:</strong>
                    <span id="detalle-ultima-compra"></span>
                </div>
            </div>

            <div class="pedidos-recientes" id="pedidos-recientes">
                <!-- Los pedidos recientes se cargarán aquí -->
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Cliente -->
<div id="modalEditar" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Editar Cliente</h3>
            <button class="close" onclick="cerrarModal('modalEditar')">&times;</button>
        </div>
        <form id="formEditarCliente" method="POST" action="index.php?action=actualizar_cliente">
            <div class="modal-body">
                <input type="hidden" id="editar-id" name="id_usuario">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nombre</label>
                        <input type="text" id="editar-nombre" name="nombre" required>
                    </div>
                    <div class="form-group">
                        <label>Apellido</label>
                        <input type="text" id="editar-apellido" name="apellido">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="editar-email" name="correo" required>
                    </div>
                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="text" id="editar-telefono" name="telefono">
                    </div>
                    <div class="form-group">
                        <label>Ciudad</label>
                        <input type="text" id="editar-ciudad" name="ciudad">
                    </div>
                    <div class="form-group full">
                        <label>Dirección</label>
                        <input type="text" id="editar-direccion" name="direccion">
                    </div>
                    <div class="form-group">
                        <label>Distrito</label>
                        <input type="text" id="editar-distrito" name="distrito">
                    </div>
                    <div class="form-group">
                        <label>Provincia</label>
                        <input type="text" id="editar-provincia" name="provincia">
                    </div>
                    <div class="form-group">
                        <label>Estado</label>
                        <select id="editar-estado" name="estado">
                            <option value="activo">Activo</option>
                            <option value="inactivo">Inactivo</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="padding: 1rem; border-top: 1px solid var(--color-beige-claro); text-align: right;">
                <button type="button" class="btn-ver" onclick="cerrarModal('modalEditar')" style="background: #6c757d; margin-right: 0.5rem;">Cancelar</button>
                <button type="submit" class="btn-ver">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>

<script>
// Funciones para los modales
function abrirModalDetalles(cliente) {
    // Llenar información del modal de detalles
    document.getElementById('detalle-nombre').textContent = cliente.nombre + ' ' + (cliente.apellido || '');
    document.getElementById('detalle-email').textContent = cliente.correo;
    document.getElementById('detalle-telefono').textContent = cliente.telefono || 'No proporcionado';
    document.getElementById('detalle-estado').textContent = cliente.estado === 'activo' ? 'Activo' : 'Inactivo';
    document.getElementById('detalle-direccion').textContent = cliente.direccion || 'No proporcionada';
    document.getElementById('detalle-ciudad').textContent = cliente.ciudad || 'No proporcionada';
    document.getElementById('detalle-distrito').textContent = cliente.distrito || 'No proporcionado';
    document.getElementById('detalle-provincia').textContent = cliente.provincia || 'No proporcionada';
    document.getElementById('detalle-total-pedidos').textContent = cliente.total_pedidos || '0';
    document.getElementById('detalle-total-gastado').textContent = '$' + (parseFloat(cliente.total_gastado) || 0).toFixed(2);
    document.getElementById('detalle-ultima-compra').textContent = cliente.ultima_compra ? 
        new Date(cliente.ultima_compra).toLocaleDateString('es-ES') : 'Sin compras';
    
    // Resetear scroll al abrir el modal
    const modalBody = document.querySelector('#modalDetalles .modal-body');
    if (modalBody) {
        modalBody.scrollTop = 0;
    }
    
    // Simular carga de pedidos
    document.getElementById('pedidos-recientes').innerHTML = '<p style="text-align: center; color: #666; padding: 1rem;">Cargando pedidos...</p>';
    
    setTimeout(() => {
        if (cliente.total_pedidos > 0) {
            document.getElementById('pedidos-recientes').innerHTML = `
                <h4>Pedidos Recientes</h4>
                <div class="pedido-item">
                    <div class="pedido-info">
                        <div>
                            <div class="pedido-id">DH-${String(cliente.id_usuario).padStart(4, '0')}01</div>
                            <div class="pedido-fecha">${new Date().toLocaleDateString('es-ES')}</div>
                        </div>
                        <div>
                            <span class="pedido-total">$${(parseFloat(cliente.total_gastado) / (cliente.total_pedidos || 1)).toFixed(2)}</span>
                            <span class="pedido-estado estado-procesando">procesando</span>
                        </div>
                    </div>
                </div>
            `;
        } else {
            document.getElementById('pedidos-recientes').innerHTML = `
                <p style="text-align: center; color: #666; padding: 1rem;">No hay pedidos recientes</p>
            `;
        }
    }, 500);
    
    document.getElementById('modalDetalles').style.display = 'block';
    document.body.style.overflow = 'hidden'; // Previene scroll del body principal
}

function abrirModalEditar(cliente) {
    // Llenar formulario de edición
    document.getElementById('editar-id').value = cliente.id_usuario;
    document.getElementById('editar-nombre').value = cliente.nombre;
    document.getElementById('editar-apellido').value = cliente.apellido || '';
    document.getElementById('editar-email').value = cliente.correo;
    document.getElementById('editar-telefono').value = cliente.telefono || '';
    document.getElementById('editar-direccion').value = cliente.direccion || '';
    document.getElementById('editar-ciudad').value = cliente.ciudad || '';
    document.getElementById('editar-distrito').value = cliente.distrito || '';
    document.getElementById('editar-provincia').value = cliente.provincia || '';
    document.getElementById('editar-estado').value = cliente.estado;
    
    // Resetear scroll al abrir el modal
    const modalBody = document.querySelector('#modalEditar .modal-body');
    if (modalBody) {
        modalBody.scrollTop = 0;
    }
    
    document.getElementById('modalEditar').style.display = 'block';
    document.body.style.overflow = 'hidden'; // Previene scroll del body principal
}

function cerrarModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto'; // Restaura scroll del body principal
}

// Cerrar modal al hacer clic fuera de él
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto'; // Restaura scroll del body principal
        }
    }
}

// Cerrar modal con tecla ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modals = document.getElementsByClassName('modal');
        for (let modal of modals) {
            if (modal.style.display === 'block') {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto'; // Restaura scroll del body principal
            }
        }
    }
});

function eliminarCliente(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este cliente? Esta acción no se puede deshacer.')) {
        // Crear formulario para enviar la petición
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'index.php?action=eliminar_cliente';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'id_usuario';
        input.value = id;
        
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>