<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener parámetros de filtro
$rango = $_GET['rango'] ?? '30';
$categoria_filtro = $_GET['categoria'] ?? '';
$estado_filtro = $_GET['estado'] ?? '';
$metodo_pago_filtro = $_GET['metodo_pago'] ?? '';

// Mostrar mensaje si se aplicó un filtro
$filtro_aplicado = false;
$mensaje_filtro = '';

// Verificar si se envió el formulario de filtros
if (isset($_GET['rango']) || isset($_GET['categoria']) || isset($_GET['estado']) || isset($_GET['metodo_pago'])) {
    $filtro_aplicado = true;
    
    $filtros = [];
    if (!empty($rango) && $rango != '30') $filtros[] = "Rango: Últimos $rango días";
    if (!empty($categoria_filtro)) $filtros[] = "Categoría: $categoria_filtro";
    if (!empty($estado_filtro)) $filtros[] = "Estado: $estado_filtro";
    if (!empty($metodo_pago_filtro)) $filtros[] = "Método de Pago: " . ucfirst(str_replace('_', ' ', $metodo_pago_filtro));
    
    if (!empty($filtros)) {
        $mensaje_filtro = "Filtros aplicados: " . implode(", ", $filtros);
    } else {
        $mensaje_filtro = "Mostrando todos los datos (sin filtros)";
    }
}

// Primero, vamos a verificar qué columnas existen en la tabla pedidos
try {
    $stmt = $conn->query("DESCRIBE pedidos");
    $columnas_pedidos = $stmt->fetchAll(PDO::FETCH_COLUMN);
    // También verificar productos
    $stmt = $conn->query("DESCRIBE productos");
    $columnas_productos = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    // Si hay error, usar nombres por defecto
    $columnas_pedidos = ['id_pedido', 'id_usuario', 'fecha_pedido', 'total', 'metodo_pago'];
    $columnas_productos = ['id_producto', 'nombre', 'stock', 'estado'];
}

// Construir condiciones WHERE para filtros - VERIFICANDO COLUMNAS EXISTENTES
$where_conditions = ["1=1"]; // Condición base siempre verdadera
$params = [];

if ($rango && $rango != '30' && in_array('fecha_pedido', $columnas_pedidos)) {
    $where_conditions[] = "p.fecha_pedido >= DATE_SUB(CURDATE(), INTERVAL ? DAY)";
    $params[] = $rango;
}

if ($categoria_filtro && in_array('id_categoria', $columnas_productos)) {
    $where_conditions[] = "c.nombre = ?";
    $params[] = $categoria_filtro;
}

// Si existe columna estado en pedidos, usarla; si no, omitir filtro de estado
if ($estado_filtro && in_array('estado', $columnas_pedidos)) {
    $where_conditions[] = "p.estado = ?";
    $params[] = $estado_filtro;
}

if ($metodo_pago_filtro && in_array('metodo_pago', $columnas_pedidos)) {
    $where_conditions[] = "p.metodo_pago = ?";
    $params[] = $metodo_pago_filtro;
}

$where_clause = implode(" AND ", $where_conditions);

// Obtener estadísticas generales con filtros
$stats = [];

// Ventas totales - CONSULTA SIMPLIFICADA
$sql_ventas = "SELECT COALESCE(SUM(p.total), 0) as ventas_totales 
               FROM pedidos p
               WHERE $where_clause";
$stmt = $conn->prepare($sql_ventas);
$stmt->execute($params);
$stats['ventas_totales'] = $stmt->fetch(PDO::FETCH_ASSOC)['ventas_totales'];

// Productos vendidos - CONSULTA SIMPLIFICADA
$sql_productos = "SELECT COALESCE(SUM(dp.cantidad), 0) as productos_vendidos 
                 FROM detalle_pedido dp 
                 JOIN pedidos p ON dp.id_pedido = p.id_pedido
                 WHERE $where_clause";
$stmt = $conn->prepare($sql_productos);
$stmt->execute($params);
$stats['productos_vendidos'] = $stmt->fetch(PDO::FETCH_ASSOC)['productos_vendidos'];

// Total clientes registrados
$stmt = $conn->prepare("SELECT COUNT(*) as total_clientes FROM usuarios WHERE rol = 'cliente'");
$stmt->execute();
$stats['total_clientes'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_clientes'];

// Tasa de conversión
$sql_clientes_pedidos = "SELECT COUNT(DISTINCT p.id_usuario) as clientes_con_pedidos 
                        FROM pedidos p
                        WHERE $where_clause";
$stmt = $conn->prepare($sql_clientes_pedidos);
$stmt->execute($params);
$clientes_con_pedidos = $stmt->fetch(PDO::FETCH_ASSOC)['clientes_con_pedidos'];
$stats['tasa_conversion'] = $stats['total_clientes'] > 0 ? round(($clientes_con_pedidos / $stats['total_clientes']) * 100, 1) : 0;

// Pedidos totales
$sql_pedidos = "SELECT COUNT(*) as total_pedidos 
               FROM pedidos p
               WHERE $where_clause";
$stmt = $conn->prepare($sql_pedidos);
$stmt->execute($params);
$stats['total_pedidos'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_pedidos'];

// Valor promedio por pedido
$stats['valor_promedio'] = $stats['total_pedidos'] > 0 ? round($stats['ventas_totales'] / $stats['total_pedidos'], 2) : 0;

// Productos en stock bajo - SI EXISTE COLUMNA STOCK
if (in_array('stock', $columnas_productos)) {
    $stmt = $conn->prepare("SELECT COUNT(*) as stock_bajo FROM productos WHERE stock <= 5");
    $stmt->execute();
    $stats['stock_bajo'] = $stmt->fetch(PDO::FETCH_ASSOC)['stock_bajo'];
} else {
    $stats['stock_bajo'] = 0;
}

// Pedidos pendientes - SOLO SI EXISTE COLUMNA ESTADO
if (in_array('estado', $columnas_pedidos)) {
    $stmt = $conn->prepare("SELECT COUNT(*) as pedidos_pendientes FROM pedidos WHERE estado IN ('pendiente', 'en preparación')");
    $stmt->execute();
    $stats['pedidos_pendientes'] = $stmt->fetch(PDO::FETCH_ASSOC)['pedidos_pendientes'];
} else {
    $stats['pedidos_pendientes'] = 0;
}

// Ventas mensuales (últimos 6 meses) - SIMPLIFICADA
$sql_ventas_mensuales = "
    SELECT 
        DATE_FORMAT(p.fecha_pedido, '%Y-%m') as mes,
        COALESCE(SUM(p.total), 0) as ventas
    FROM pedidos p
    WHERE $where_clause
        AND p.fecha_pedido >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(p.fecha_pedido, '%Y-%m')
    ORDER BY mes DESC
    LIMIT 6
";
$stmt = $conn->prepare($sql_ventas_mensuales);
$stmt->execute($params);
$ventas_mensuales = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));

// Productos más vendidos - SIMPLIFICADA
$sql_productos_populares = "
    SELECT 
        prod.nombre,
        prod.id_producto,
        COALESCE(SUM(dp.cantidad), 0) as total_vendido,
        COALESCE(SUM(dp.subtotal), 0) as ingresos_totales
    FROM productos prod
    LEFT JOIN detalle_pedido dp ON prod.id_producto = dp.id_producto
    LEFT JOIN pedidos p ON dp.id_pedido = p.id_pedido
    WHERE $where_clause
    GROUP BY prod.id_producto, prod.nombre
    ORDER BY total_vendido DESC
    LIMIT 10
";

$stmt = $conn->prepare($sql_productos_populares);
$stmt->execute($params);
$productos_populares = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Métodos de pago más utilizados - SIMPLIFICADA
$sql_metodos_pago = "
    SELECT 
        p.metodo_pago,
        COUNT(*) as total_pedidos,
        COALESCE(SUM(p.total), 0) as monto_total
    FROM pedidos p
    WHERE $where_clause
    GROUP BY p.metodo_pago
    ORDER BY total_pedidos DESC
";
$stmt = $conn->prepare($sql_metodos_pago);
$stmt->execute($params);
$metodos_pago = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Distribución de estados de pedidos - SOLO SI EXISTE COLUMNA ESTADO
if (in_array('estado', $columnas_pedidos)) {
    $sql_estados_pedidos = "
        SELECT 
            estado,
            COUNT(*) as cantidad
        FROM pedidos 
        WHERE $where_clause
        GROUP BY estado
    ";
    $stmt = $conn->prepare($sql_estados_pedidos);
    $stmt->execute($params);
    $estados_pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $estados_pedidos = [];
}

// Categorías más populares - SIMPLIFICADA
$sql_categorias_populares = "
    SELECT 
        c.nombre as categoria,
        COUNT(DISTINCT prod.id_producto) as total_productos,
        COALESCE(SUM(dp.cantidad), 0) as total_vendido,
        COALESCE(SUM(dp.subtotal), 0) as ingresos_totales
    FROM categorias c
    LEFT JOIN productos prod ON c.id_categoria = prod.id_categoria
    LEFT JOIN detalle_pedido dp ON prod.id_producto = dp.id_producto
    LEFT JOIN pedidos p ON dp.id_pedido = p.id_pedido
    WHERE $where_clause
    GROUP BY c.id_categoria, c.nombre
    ORDER BY total_vendido DESC
";

$stmt = $conn->prepare($sql_categorias_populares);
$stmt->execute($params);
$categorias_populares = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las categorías para el filtro
$stmt = $conn->prepare("SELECT nombre FROM categorias");
$stmt->execute();
$todas_categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Procesar exportaciones
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    switch ($export_type) {
        case 'pdf':
            exportarPDF($stats, $productos_populares, $categorias_populares, $ventas_mensuales, $metodos_pago, $estados_pedidos, $rango, $categoria_filtro, $estado_filtro, $metodo_pago_filtro);
            break;
        case 'excel':
            exportarExcel($stats, $productos_populares, $categorias_populares, $ventas_mensuales, $metodos_pago, $estados_pedidos, $rango, $categoria_filtro, $estado_filtro, $metodo_pago_filtro);
            break;
    }
    exit;
}

// Función para exportar PDF
function exportarPDF($stats, $productos_populares, $categorias_populares, $ventas_mensuales, $metodos_pago, $estados_pedidos, $rango, $categoria_filtro, $estado_filtro, $metodo_pago_filtro) {
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Reporte de Ventas - ' . date('Y-m-d') . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
            .section { margin-bottom: 30px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .stat-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px; }
            .stat-card { border: 1px solid #ddd; padding: 15px; text-align: center; }
            .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
            .filtros { background-color: #f9f9f9; padding: 10px; margin-bottom: 20px; border-left: 4px solid #333; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Reporte de Ventas</h1>
            <p>Generado el: ' . date('d/m/Y H:i:s') . '</p>
        </div>
        
        <div class="filtros">
            <h3>Filtros Aplicados:</h3>
            <p><strong>Rango:</strong> Últimos ' . $rango . ' días</p>
            <p><strong>Categoría:</strong> ' . ($categoria_filtro ?: 'Todas') . '</p>
            <p><strong>Estado:</strong> ' . ($estado_filtro ?: 'Todos') . '</p>
            <p><strong>Método de Pago:</strong> ' . ($metodo_pago_filtro ? ucfirst(str_replace('_', ' ', $metodo_pago_filtro)) : 'Todos') . '</p>
        </div>
        
        <div class="section">
            <h2>Estadísticas Principales</h2>
            <div class="stat-grid">
                <div class="stat-card">
                    <h3>Ventas Totales</h3>
                    <p>$' . number_format($stats['ventas_totales'], 2) . '</p>
                </div>
                <div class="stat-card">
                    <h3>Productos Vendidos</h3>
                    <p>' . number_format($stats['productos_vendidos']) . '</p>
                </div>
                <div class="stat-card">
                    <h3>Total Pedidos</h3>
                    <p>' . number_format($stats['total_pedidos']) . '</p>
                </div>
                <div class="stat-card">
                    <h3>Clientes Registrados</h3>
                    <p>' . number_format($stats['total_clientes']) . '</p>
                </div>
                <div class="stat-card">
                    <h3>Tasa de Conversión</h3>
                    <p>' . $stats['tasa_conversion'] . '%</p>
                </div>
                <div class="stat-card">
                    <h3>Valor Promedio</h3>
                    <p>$' . number_format($stats['valor_promedio'], 2) . '</p>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2>Productos Más Vendidos</h2>
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Unidades Vendidas</th>
                        <th>Ingresos</th>
                    </tr>
                </thead>
                <tbody>';
    
    foreach ($productos_populares as $producto) {
        $html .= '
                    <tr>
                        <td>' . htmlspecialchars($producto['nombre']) . '</td>
                        <td>' . number_format($producto['total_vendido']) . '</td>
                        <td>$' . number_format($producto['ingresos_totales'], 2) . '</td>
                    </tr>';
    }
    
    $html .= '
                </tbody>
            </table>
        </div>
        
        <div class="section">
            <h2>Categorías Más Populares</h2>
            <table>
                <thead>
                    <tr>
                        <th>Categoría</th>
                        <th>Productos</th>
                        <th>Unidades Vendidas</th>
                        <th>Ingresos</th>
                    </tr>
                </thead>
                <tbody>';
    
    foreach ($categorias_populares as $categoria) {
        $html .= '
                    <tr>
                        <td>' . htmlspecialchars($categoria['categoria']) . '</td>
                        <td>' . number_format($categoria['total_productos']) . '</td>
                        <td>' . number_format($categoria['total_vendido']) . '</td>
                        <td>$' . number_format($categoria['ingresos_totales'], 2) . '</td>
                    </tr>';
    }
    
    $html .= '
                </tbody>
            </table>
        </div>
        
        <div class="section">
            <h2>Métodos de Pago</h2>
            <table>
                <thead>
                    <tr>
                        <th>Método de Pago</th>
                        <th>Total Pedidos</th>
                        <th>Monto Total</th>
                    </tr>
                </thead>
                <tbody>';
    
    foreach ($metodos_pago as $metodo) {
        $html .= '
                    <tr>
                        <td>' . ucfirst(str_replace('_', ' ', $metodo['metodo_pago'])) . '</td>
                        <td>' . number_format($metodo['total_pedidos']) . '</td>
                        <td>$' . number_format($metodo['monto_total'], 2) . '</td>
                    </tr>';
    }
    
    $html .= '
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p>Reporte generado automáticamente por el Sistema de Gestión</p>
        </div>
    </body>
    </html>';
    
    header('Content-Type: application/html');
    header('Content-Disposition: attachment; filename="reporte_ventas_' . date('Y-m-d') . '.html"');
    echo $html;
}

// Función para exportar Excel
function exportarExcel($stats, $productos_populares, $categorias_populares, $ventas_mensuales, $metodos_pago, $estados_pedidos, $rango, $categoria_filtro, $estado_filtro, $metodo_pago_filtro) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="reporte_ventas_' . date('Y-m-d') . '.xls"');
    
    echo "Reporte de Ventas\n\n";
    echo "Fecha de generación:\t" . date('d/m/Y H:i:s') . "\n";
    echo "Filtros aplicados:\n";
    echo "Rango:\tÚltimos " . $rango . " días\n";
    echo "Categoría:\t" . ($categoria_filtro ?: 'Todas') . "\n";
    echo "Estado:\t" . ($estado_filtro ?: 'Todos') . "\n";
    echo "Método de Pago:\t" . ($metodo_pago_filtro ? ucfirst(str_replace('_', ' ', $metodo_pago_filtro)) : 'Todos') . "\n\n";
    
    echo "ESTADÍSTICAS PRINCIPALES\n";
    echo "Ventas Totales:\t$" . number_format($stats['ventas_totales'], 2) . "\n";
    echo "Productos Vendidos:\t" . number_format($stats['productos_vendidos']) . "\n";
    echo "Total Pedidos:\t" . number_format($stats['total_pedidos']) . "\n";
    echo "Clientes Registrados:\t" . number_format($stats['total_clientes']) . "\n";
    echo "Tasa de Conversión:\t" . $stats['tasa_conversion'] . "%\n";
    echo "Valor Promedio:\t$" . number_format($stats['valor_promedio'], 2) . "\n\n";
    
    echo "PRODUCTOS MÁS VENDIDOS\n";
    echo "Producto\tUnidades Vendidas\tIngresos Totales\n";
    foreach ($productos_populares as $producto) {
        echo htmlspecialchars($producto['nombre']) . "\t";
        echo number_format($producto['total_vendido']) . "\t";
        echo "$" . number_format($producto['ingresos_totales'], 2) . "\n";
    }
    echo "\n";
    
    echo "CATEGORÍAS MÁS POPULARES\n";
    echo "Categoría\tTotal Productos\tUnidades Vendidas\tIngresos Totales\n";
    foreach ($categorias_populares as $categoria) {
        echo htmlspecialchars($categoria['categoria']) . "\t";
        echo number_format($categoria['total_productos']) . "\t";
        echo number_format($categoria['total_vendido']) . "\t";
        echo "$" . number_format($categoria['ingresos_totales'], 2) . "\n";
    }
    echo "\n";
    
    echo "MÉTODOS DE PAGO\n";
    echo "Método\tTotal Pedidos\tMonto Total\n";
    foreach ($metodos_pago as $metodo) {
        echo ucfirst(str_replace('_', ' ', $metodo['metodo_pago'])) . "\t";
        echo number_format($metodo['total_pedidos']) . "\t";
        echo "$" . number_format($metodo['monto_total'], 2) . "\n";
    }
}

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Reportes y Estadísticas</h1>
    <p>Análisis completo del rendimiento de la tienda</p>
</header>

<!-- Mostrar mensaje de filtro aplicado -->
<?php if ($filtro_aplicado && !empty($mensaje_filtro)): ?>
<div style="background-color: #806366ff; color: #ffffffff; padding: 12px 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #775d7aff; display: flex; align-items: center; justify-content: space-between;">
    <div style="display: flex; align-items: center;">
        <i class="bi bi-check-circle-fill" style="color: #b9afafff; font-size: 1.2rem; margin-right: 10px;"></i>
        <span><?= htmlspecialchars($mensaje_filtro) ?></span>
    </div>
    <button onclick="this.parentElement.style.display='none'" style="background: none; border: none; color: #584d57ff; cursor: pointer; font-size: 1.2rem;">
        <i class="bi bi-x"></i>
    </button>
</div>
<?php endif; ?>

<!-- Filtros -->
<div class="recent-orders" style="margin-bottom: 2rem;">
    <h3>Filtros de Reportes</h3>
    <form method="GET" action="index.php" id="filtroForm">
        <input type="hidden" name="action" value="reportes">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; align-items: end;">
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Rango de Fechas</label>
                <select name="rango" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                    <option value="30" <?= $rango == '30' ? 'selected' : '' ?>>Últimos 30 días</option>
                    <option value="7" <?= $rango == '7' ? 'selected' : '' ?>>Últimos 7 días</option>
                    <option value="90" <?= $rango == '90' ? 'selected' : '' ?>>Últimos 3 meses</option>
                    <option value="180" <?= $rango == '180' ? 'selected' : '' ?>>Últimos 6 meses</option>
                    <option value="365" <?= $rango == '365' ? 'selected' : '' ?>>Último año</option>
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Categoría</label>
                <select name="categoria" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                    <option value="">Todas las categorías</option>
                    <?php foreach ($todas_categorias as $categoria): ?>
                        <option value="<?= $categoria['nombre'] ?>" <?= $categoria_filtro == $categoria['nombre'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($categoria['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if (in_array('estado', $columnas_pedidos)): ?>
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Estado de Pedido</label>
                <select name="estado" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                    <option value="">Todos los estados</option>
                    <option value="pendiente" <?= $estado_filtro == 'pendiente' ? 'selected' : '' ?>>Pendientes</option>
                    <option value="en preparación" <?= $estado_filtro == 'en preparación' ? 'selected' : '' ?>>En Preparación</option>
                    <option value="en reparto" <?= $estado_filtro == 'en reparto' ? 'selected' : '' ?>>En Reparto</option>
                    <option value="entregado" <?= $estado_filtro == 'entregado' ? 'selected' : '' ?>>Entregados</option>
                </select>
            </div>
            <?php endif; ?>
            <?php if (in_array('metodo_pago', $columnas_pedidos)): ?>
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Método de Pago</label>
                <select name="metodo_pago" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                    <option value="">Todos los métodos</option>
                    <option value="yape" <?= $metodo_pago_filtro == 'yape' ? 'selected' : '' ?>>Yape</option>
                    <option value="plin" <?= $metodo_pago_filtro == 'plin' ? 'selected' : '' ?>>Plin</option>
                    <option value="transferencia" <?= $metodo_pago_filtro == 'transferencia' ? 'selected' : '' ?>>Transferencia</option>
                    <option value="efectivo" <?= $metodo_pago_filtro == 'efectivo' ? 'selected' : '' ?>>Efectivo</option>
                    <option value="tarjeta" <?= $metodo_pago_filtro == 'tarjeta' ? 'selected' : '' ?>>Tarjeta</option>
                    <option value="contra_entrega" <?= $metodo_pago_filtro == 'contra_entrega' ? 'selected' : '' ?>>Contra Entrega</option>
                </select>
            </div>
            <?php endif; ?>
            <div>
                <button type="submit" class="btn-ver" style="width: 100%;" id="btnFiltrar">
                    <i class="bi bi-funnel"></i> Aplicar Filtros
                </button>
                <?php if ($filtro_aplicado): ?>
                <a href="index.php?action=reportes" class="btn-ver" style="width: 100%; margin-top: 0.5rem; background-color: #6c757d; text-align: center;">
                    <i class="bi bi-x-circle"></i> Limpiar Filtros
                </a>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>

<!-- Botones de Exportación -->
<div class="recent-orders" style="margin-bottom: 2rem;">
    <h3>Exportar Reportes</h3>
    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
        <a href="?action=reportes&export=pdf&rango=<?= $rango ?>&categoria=<?= urlencode($categoria_filtro) ?>&estado=<?= urlencode($estado_filtro) ?>&metodo_pago=<?= urlencode($metodo_pago_filtro) ?>" class="btn-ver" target="_blank">
            <i class="bi bi-file-earmark-pdf"></i> Exportar PDF
        </a>
        <a href="?action=reportes&export=excel&rango=<?= $rango ?>&categoria=<?= urlencode($categoria_filtro) ?>&estado=<?= urlencode($estado_filtro) ?>&metodo_pago=<?= urlencode($metodo_pago_filtro) ?>" class="btn-ver" target="_blank">
            <i class="bi bi-file-earmark-excel"></i> Exportar Excel
        </a>
        <button type="button" class="btn-ver" onclick="imprimirReporte()">
            <i class="bi bi-printer"></i> Imprimir Reporte
        </button>
    </div>
</div>

<!-- Estadísticas Principales -->
<section class="recent-orders">
    <h3>Estadísticas Principales <?= $filtro_aplicado ? '<small style="font-size: 0.8rem; color: #666;">(con filtros aplicados)</small>' : '' ?></h3>
    
    <div class="stats-grid">
        <div class="stat-card">
            <i class="bi bi-currency-dollar stat-icon"></i>
            <h3>Ventas Totales</h3>
            <div class="stat-number">$<?= number_format($stats['ventas_totales'], 2) ?></div>
            <p>Ingresos acumulados</p>
            <?php if ($filtro_aplicado): ?>
            <div style="font-size: 0.8rem; color: #666; margin-top: 0.5rem;">
                <i class="bi bi-funnel"></i> Con filtros
            </div>
            <?php endif; ?>
        </div>

        <div class="stat-card">
            <i class="bi bi-box-seam stat-icon"></i>
            <h3>Productos Vendidos</h3>
            <div class="stat-number"><?= number_format($stats['productos_vendidos']) ?></div>
            <p>Unidades totales</p>
        </div>

        <div class="stat-card">
            <i class="bi bi-people stat-icon"></i>
            <h3>Clientes Registrados</h3>
            <div class="stat-number"><?= number_format($stats['total_clientes']) ?></div>
            <p>Usuarios activos</p>
        </div>

        <div class="stat-card">
            <i class="bi bi-graph-up-arrow stat-icon"></i>
            <h3>Tasa de Conversión</h3>
            <div class="stat-number"><?= $stats['tasa_conversion'] ?>%</div>
            <p>Clientes con compras</p>
        </div>

        <div class="stat-card">
            <i class="bi bi-cart-check stat-icon"></i>
            <h3>Total Pedidos</h3>
            <div class="stat-number"><?= number_format($stats['total_pedidos']) ?></div>
            <p>Órdenes completadas</p>
        </div>

        <div class="stat-card">
            <i class="bi bi-calculator stat-icon"></i>
            <h3>Valor Promedio</h3>
            <div class="stat-number">$<?= number_format($stats['valor_promedio'], 2) ?></div>
            <p>Por pedido</p>
        </div>
    </div>
</section>

<!-- Gráficos -->
<section class="recent-orders">
    <h3>Gráficos y Visualizaciones</h3>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 2rem; margin-bottom: 2rem;">
        <!-- Ventas Mensuales -->
        <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra);">
            <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal);">Ventas Mensuales (Últimos 6 Meses)</h4>
            <div style="height: 300px;">
                <canvas id="ventasMensualesChart"></canvas>
            </div>
        </div>

        <!-- Productos Más Vendidos -->
        <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra);">
            <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal);">Productos Más Vendidos</h4>
            <div style="height: 300px;">
                <canvas id="productosPopularesChart"></canvas>
            </div>
        </div>

        <!-- Métodos de Pago - Gráfico Circular (Torta) -->
        <?php if (!empty($metodos_pago)): ?>
        <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra);">
            <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal);">Distribución de Métodos de Pago</h4>
            <div style="height: 300px;">
                <canvas id="metodosPagoChart"></canvas>
            </div>
            <div style="margin-top: 1rem; text-align: center;">
                <?php
                $total_pedidos_metodos = array_sum(array_column($metodos_pago, 'total_pedidos'));
                ?>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-top: 1rem;">
                    <?php 
                    $colores = ['#916b83', '#a77b86', '#926d85', '#8C6B5A', '#726660', '#5A4D47'];
                    $contador = 0;
                    foreach ($metodos_pago as $metodo): 
                        $porcentaje = $total_pedidos_metodos > 0 ? round(($metodo['total_pedidos'] / $total_pedidos_metodos) * 100, 1) : 0;
                    ?>
                    <div style="text-align: center; padding: 0.5rem; background: <?= $colores[$contador % count($colores)] ?>10; border-radius: 8px;">
                        <div style="font-weight: bold; color: <?= $colores[$contador % count($colores)] ?>;">
                            <?= strtoupper($metodo['metodo_pago']) ?>
                        </div>
                        <div style="font-size: 0.9rem; color: #666;">
                            <?= number_format($metodo['total_pedidos']) ?> pedidos<br>
                            $<?= number_format($metodo['monto_total'], 2) ?><br>
                            <small>(<?= $porcentaje ?>%)</small>
                        </div>
                    </div>
                    <?php $contador++; endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Estados de Pedidos -->
        <?php if (!empty($estados_pedidos)): ?>
        <div style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra);">
            <h4 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-principal);">Estados de Pedidos</h4>
            <div style="height: 300px;">
                <canvas id="estadosPedidosChart"></canvas>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Tablas de Datos -->
<section class="recent-orders">
    <h3>Productos Más Populares</h3>
    <table class="orders-table">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Unidades Vendidas</th>
                <th>Ingresos Totales</th>
                <th>Rendimiento</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($productos_populares)): ?>
                <?php foreach ($productos_populares as $producto): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($producto['nombre']) ?></strong></td>
                        <td><?= number_format($producto['total_vendido']) ?></td>
                        <td><strong>$<?= number_format($producto['ingresos_totales'], 2) ?></strong></td>
                        <td>
                            <span class="status-badge <?= $producto['total_vendido'] > 10 ? 'status-entregado' : 'status-en-preparacion' ?>">
                                <?= $producto['total_vendido'] > 10 ? 'Alto' : 'Medio' ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <i class="bi bi-exclamation-triangle" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                        No hay datos con los filtros aplicados
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<section class="recent-orders">
    <h3>Categorías Más Populares</h3>
    <table class="orders-table">
        <thead>
            <tr>
                <th>Categoría</th>
                <th>Productos</th>
                <th>Unidades Vendidas</th>
                <th>Ingresos Totales</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($categorias_populares)): ?>
                <?php foreach ($categorias_populares as $categoria): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($categoria['categoria']) ?></strong></td>
                        <td><?= number_format($categoria['total_productos']) ?></td>
                        <td><?= number_format($categoria['total_vendido']) ?></td>
                        <td><strong>$<?= number_format($categoria['ingresos_totales'], 2) ?></strong></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <i class="bi bi-exclamation-triangle" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                        No hay datos con los filtros aplicados
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<!-- Tabla de Métodos de Pago -->
<?php if (!empty($metodos_pago)): ?>
<section class="recent-orders">
    <h3>Métodos de Pago Utilizados</h3>
    <table class="orders-table">
        <thead>
            <tr>
                <th>Método de Pago</th>
                <th>Total Pedidos</th>
                <th>Monto Total</th>
                <th>Porcentaje</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_pedidos_metodos = array_sum(array_column($metodos_pago, 'total_pedidos'));
            foreach ($metodos_pago as $metodo): 
                $porcentaje = $total_pedidos_metodos > 0 ? round(($metodo['total_pedidos'] / $total_pedidos_metodos) * 100, 1) : 0;
            ?>
                <tr>
                    <td><strong><?= ucfirst(str_replace('_', ' ', $metodo['metodo_pago'])) ?></strong></td>
                    <td><?= number_format($metodo['total_pedidos']) ?></td>
                    <td><strong>$<?= number_format($metodo['monto_total'], 2) ?></strong></td>
                    <td>
                        <span class="status-badge <?= $porcentaje > 50 ? 'status-entregado' : ($porcentaje > 25 ? 'status-en-preparacion' : 'status-pendiente') ?>">
                            <?= $porcentaje ?>%
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($filtro_aplicado): ?>
    // Mostrar notificación de filtro aplicado
    setTimeout(() => {
        showNotification('Filtros aplicados correctamente', 'success');
    }, 500);
    <?php endif; ?>
    
    // Configuración de gráficos
    <?php if (!empty($ventas_mensuales)): ?>
    const ventasCtx = document.getElementById('ventasMensualesChart').getContext('2d');
    const ventasMensualesChart = new Chart(ventasCtx, {
        type: 'line',
        data: {
            labels: [<?php echo implode(',', array_map(function($mes) { 
                return "'" . date('M Y', strtotime($mes['mes'] . '-01')) . "'"; 
            }, $ventas_mensuales)); ?>],
            datasets: [{
                label: 'Ventas Mensuales',
                data: [<?php echo implode(',', array_column($ventas_mensuales, 'ventas')); ?>],
                borderColor: '#77596fff',
                backgroundColor: 'rgba(159, 91, 180, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    <?php endif; ?>

    <?php if (!empty($productos_populares)): ?>
    // Productos Populares - Gráfico de Barras
    const productosCtx = document.getElementById('productosPopularesChart').getContext('2d');
    const productosPopularesChart = new Chart(productosCtx, {
        type: 'bar',
        data: {
            labels: [<?php echo implode(',', array_map(function($prod) { 
                return "'" . addslashes(substr($prod['nombre'], 0, 15)) . (strlen($prod['nombre']) > 15 ? '...' : '') . "'"; 
            }, array_slice($productos_populares, 0, 5))); ?>],
            datasets: [{
                label: 'Unidades Vendidas',
                data: [<?php echo implode(',', array_column(array_slice($productos_populares, 0, 5), 'total_vendido')); ?>],
                backgroundColor: [
                    '#726660', '#5A4D47', '#8C6B5A', '#916b83', '#926d85', '#a77b86'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    <?php endif; ?>

    <?php if (!empty($metodos_pago)): ?>
    // Métodos de Pago - Gráfico Circular (Torta)
    const metodosPagoCtx = document.getElementById('metodosPagoChart').getContext('2d');
    const metodosPagoChart = new Chart(metodosPagoCtx, {
        type: 'pie',
        data: {
            labels: [<?php 
                $labels = [];
                foreach ($metodos_pago as $metodo) {
                    $labels[] = "'" . ucfirst(str_replace('_', ' ', $metodo['metodo_pago'])) . "'";
                }
                echo implode(',', $labels);
            ?>],
            datasets: [{
                data: [<?php echo implode(',', array_column($metodos_pago, 'total_pedidos')); ?>],
                backgroundColor: [
                    '#916b83', '#a77b86', '#926d85', '#8C6B5A', '#726660', '#5A4D47'
                ],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 15,
                        padding: 15,
                        font: {
                            size: 12,
                            weight: 'bold'
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return `${label}: ${value} pedidos (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });
    <?php endif; ?>

    <?php if (!empty($estados_pedidos)): ?>
    // Estados de Pedidos - Gráfico de Pie
    const estadosCtx = document.getElementById('estadosPedidosChart').getContext('2d');
    const estadosPedidosChart = new Chart(estadosCtx, {
        type: 'pie',
        data: {
            labels: [<?php echo implode(',', array_map(function($estado) { return "'" . ucfirst($estado['estado']) . "'"; }, $estados_pedidos)); ?>],
            datasets: [{
                data: [<?php echo implode(',', array_column($estados_pedidos, 'cantidad')); ?>],
                backgroundColor: [
                    '#8C6B5A', '#926d85', '#a77b86', '#916b83', '#726660', '#5A4D47'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    <?php endif; ?>
    
    // Botón de filtrar - mostrar mensaje
    document.getElementById('btnFiltrar').addEventListener('click', function(e) {
        // Muestra un mensaje de carga
        const originalText = this.innerHTML;
        this.innerHTML = '<i class="bi bi-hourglass-split"></i> Aplicando filtros...';
        this.disabled = true;
    });
});

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background-color: ${type === 'success' ? '#28a745' : '#dc3545'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease, fadeOut 0.3s ease 4.7s;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
    `;
    
    const icon = type === 'success' ? 
        '<i class="bi bi-check-circle-fill" style="font-size: 1.2rem;"></i>' :
        '<i class="bi bi-exclamation-triangle-fill" style="font-size: 1.2rem;"></i>';
    
    notification.innerHTML = `${icon} ${message}`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

function imprimirReporte() {
    window.print();
}
</script>

<style>
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes fadeOut {
    from {
        opacity: 1;
    }
    to {
        opacity: 0;
    }
}

/* Estilos para las tablas vacías */
td[colspan] {
    background-color: #f8f9fa;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>