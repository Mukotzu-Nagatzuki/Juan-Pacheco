<?php
$current_page = 'admin';
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<?php include 'app/views/layout/header.php'; ?>

<div class="admin-container">
    <div class="admin-header">
        <h1>Editar Imagen del Carrusel</h1>
        <a href="index.php?action=configuracion-carrusel" class="btn-volver">
            <i class="fas fa-arrow-left"></i>
            Volver al Carrusel
        </a>
    </div>

    <!-- Mensajes de alerta -->
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <div class="form-section">
        <form action="index.php?action=editar-imagen-carrusel&id=<?php echo $imagen['id_carrusel']; ?>" method="POST" enctype="multipart/form-data" class="carrusel-form">
            <div class="form-grid">
                <div class="form-group">
                    <label for="titulo">Título *</label>
                    <input type="text" id="titulo" name="titulo" required 
                           value="<?php echo htmlspecialchars($imagen['titulo']); ?>"
                           placeholder="Ej: La Comodidad Perfecta Para Tus Noches">
                </div>

                <div class="form-group">
                    <label for="subtitulo">Subtítulo</label>
                    <textarea id="subtitulo" name="subtitulo" rows="3" 
                              placeholder="Ej: Descubre nuestra colección premium de edredones..."><?php echo htmlspecialchars($imagen['subtitulo']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="orden">Orden de Visualización</label>
                    <input type="number" id="orden" name="orden" min="0" 
                           value="<?php echo $imagen['orden']; ?>"
                           placeholder="0 para orden automático">
                </div>

                <div class="form-group">
                    <label for="estado">Estado</label>
                    <select id="estado" name="estado" required>
                        <option value="activo" <?php echo $imagen['estado'] === 'activo' ? 'selected' : ''; ?>>Activo</option>
                        <option value="inactivo" <?php echo $imagen['estado'] === 'inactivo' ? 'selected' : ''; ?>>Inactivo</option>
                    </select>
                </div>

                <div class="form-group full-width">
                    <label for="imagen">Imagen del Carrusel</label>
                    
                    <!-- Imagen actual -->
                    <?php if (!empty($imagen['imagen_url'])): ?>
                        <div class="current-image">
                            <p><strong>Imagen actual:</strong></p>
                            <img src="public/img/carrusel/<?php echo htmlspecialchars($imagen['imagen_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($imagen['titulo']); ?>"
                                 style="max-width: 300px; max-height: 200px; border-radius: 8px; margin-bottom: 1rem;">
                        </div>
                    <?php endif; ?>

                    <div class="file-upload">
                        <input type="file" id="imagen" name="imagen" accept="image/*"
                               onchange="previewEditImage(this)">
                        <label for="imagen" class="file-upload-label">
                            <i class="fas fa-upload"></i>
                            <span>Seleccionar nueva imagen (opcional)</span>
                        </label>
                    </div>
                    <div id="edit-image-preview" class="image-preview-carrusel"></div>
                    <small class="file-info">Dejar vacío para mantener la imagen actual. Formatos: JPG, PNG, GIF, WEBP. Tamaño máximo: 5MB</small>
                </div>
            </div>

            <div class="form-actions">
                <a href="index.php?action=configuracion-carrusel" class="btn-cancel">Cancelar</a>
                <button type="submit" class="btn-submit">Actualizar Imagen</button>
            </div>
        </form>
    </div>
</div>

<style>
/* Usa los mismos estilos que en configuracion_carrusel.php */
.admin-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 2rem;
}

.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.btn-volver {
    background: #6c757d;
    color: white;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.3s ease;
}

.btn-volver:hover {
    background: #5a6268;
    color: white;
    text-decoration: none;
}

.form-section {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group.full-width {
    grid-column: 1 / -1;
}

.form-group label {
    font-weight: 600;
    margin-bottom: 0.5rem;
    color: #333;
}

.form-group input,
.form-group select,
.form-group textarea {
    padding: 0.75rem;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #667eea;
}

.form-group textarea {
    resize: vertical;
    min-height: 80px;
}

.current-image {
    margin-bottom: 1.5rem;
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 4px solid #28a745;
}

.file-upload {
    position: relative;
    margin-bottom: 0.5rem;
}

.file-upload input[type="file"] {
    position: absolute;
    left: -9999px;
}

.file-upload-label {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    background: #f8f9fa;
    border: 2px dashed #dee2e6;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    color: #6c757d;
}

.file-upload-label:hover {
    background: #e9ecef;
    border-color: #667eea;
}

.file-info {
    color: #6c757d;
    font-size: 0.875rem;
}

.image-preview-carrusel {
    margin-top: 1rem;
    text-align: center;
}

.image-preview-carrusel img {
    max-width: 300px;
    max-height: 200px;
    border-radius: 8px;
    border: 2px solid #e9ecef;
}

.form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    padding-top: 1.5rem;
    border-top: 1px solid #e9ecef;
    margin-top: 2rem;
}

.btn-cancel,
.btn-submit {
    padding: 0.75rem 2rem;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.btn-cancel {
    background: #6c757d;
    color: white;
}

.btn-cancel:hover {
    background: #5a6268;
    color: white;
    text-decoration: none;
}

.btn-submit {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.btn-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.alert {
    padding: 1rem 1.5rem;
    border-radius: 8px;
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 600;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

@media (max-width: 768px) {
    .admin-container {
        padding: 1rem;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .form-actions {
        flex-direction: column;
    }
    
    .btn-cancel,
    .btn-submit {
        width: 100%;
    }
}
</style>

<script>
function previewEditImage(input) {
    const preview = document.getElementById('edit-image-preview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" alt="Vista previa de nueva imagen">`;
        }
        
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.innerHTML = '';
    }
}
</script>

<?php include 'app/views/layout/footer.php'; ?>