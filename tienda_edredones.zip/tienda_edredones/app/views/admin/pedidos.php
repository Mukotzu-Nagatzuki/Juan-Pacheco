<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener todos los pedidos
$stmt = $conn->prepare("
    SELECT p.*, CONCAT(u.nombre, ' ', u.apellido) as cliente_nombre,
           u.correo, u.telefono,
           (SELECT COUNT(*) FROM detalle_pedido dp WHERE dp.id_pedido = p.id_pedido) as cantidad_productos
    FROM pedidos p 
    JOIN usuarios u ON p.id_usuario = u.id_usuario 
    ORDER BY p.fecha_pedido DESC
");
$stmt->execute();
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Gestión de Pedidos</h1>
    <p>Administra y gestiona todos los pedidos de la tienda</p>
</header>

<section class="recent-orders">
    <h3>Todos los Pedidos</h3>

    <!-- Filtros -->
    <div class="filtros" style="margin-bottom: 2rem; background: #f8f9fa; padding: 1.5rem; border-radius: var(--radio);">
        <form method="GET" action="index.php">
            <input type="hidden" name="action" value="pedidos_admin">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; align-items: end;">
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Estado del Pedido</label>
                    <select name="estado" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                        <option value="">Todos los estados</option>
                        <option value="pendiente">Pendiente</option>
                        <option value="pagado">Pagado</option>
                        <option value="en preparación">En Preparación</option>
                        <option value="en reparto">En Reparto</option>
                        <option value="entregado">Entregado</option>
                        <option value="cancelado">Cancelado</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Fecha Desde</label>
                    <input type="date" name="fecha_desde" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Fecha Hasta</label>
                    <input type="date" name="fecha_hasta" style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
                </div>
                <div>
                    <button type="submit" class="btn-ver" style="width: 100%;">
                        <i class="bi bi-funnel"></i> Filtrar
                    </button>
                </div>
            </div>
        </form>
    </div>

    <?php if (!empty($pedidos)): ?>
        <table class="orders-table">
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Productos</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pedidos as $pedido): ?>
                    <tr>
                        <td><strong>DH-<?= str_pad($pedido['id_pedido'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                        <td>
                            <div><strong><?= htmlspecialchars($pedido['cliente_nombre']) ?></strong></div>
                            <small style="color: #666;"><?= htmlspecialchars($pedido['correo']) ?></small>
                        </td>
                        <td><?= date('d/m/Y', strtotime($pedido['fecha_pedido'])) ?></td>
                        <td><?= $pedido['cantidad_productos'] ?> producto(s)</td>
                        <td><strong>$<?= number_format($pedido['total'], 2) ?></strong></td>
                        <td>
                            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $pedido['estado'])) ?>">
                                <?= ucfirst($pedido['estado']) ?>
                            </span>
                        </td>
                        <td style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
                            <a href="index.php?action=ver_pedido&id=<?= $pedido['id_pedido'] ?>" class="btn-ver" style="padding: 6px 12px; font-size: 0.8rem;">
                                <i class="bi bi-eye"></i> Ver
                            </a>
                            <form method="POST" action="index.php?action=actualizar_estado_pedido" style="display: inline;">
                                <input type="hidden" name="id_pedido" value="<?= $pedido['id_pedido'] ?>">
                                <select name="estado" style="padding: 6px 8px; border: 1px solid var(--color-beige-claro); border-radius: var(--radio); font-size: 0.8rem;" onchange="this.form.submit()">
                                    <option value="pendiente" <?= $pedido['estado'] == 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                    <option value="pagado" <?= $pedido['estado'] == 'pagado' ? 'selected' : '' ?>>Pagado</option>
                                    <option value="en preparación" <?= $pedido['estado'] == 'en preparación' ? 'selected' : '' ?>>En Prep.</option>
                                    <option value="en reparto" <?= $pedido['estado'] == 'en reparto' ? 'selected' : '' ?>>En Reparto</option>
                                    <option value="entregado" <?= $pedido['estado'] == 'entregado' ? 'selected' : '' ?>>Entregado</option>
                                    <option value="cancelado" <?= $pedido['estado'] == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div style="text-align: center; padding: 3rem; color: #7f8c8d;">
            <i class="bi bi-inbox" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
            <h3>No hay pedidos</h3>
            <p>No se han encontrado pedidos en el sistema.</p>
        </div>
    <?php endif; ?>
</section>

<script>
// Función para actualizar el estado del pedido con confirmación
function actualizarEstado(pedidoId, nuevoEstado) {
    if (confirm('¿Estás seguro de que quieres cambiar el estado del pedido?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'index.php?action=actualizar_estado_pedido';
        
        const inputId = document.createElement('input');
        inputId.type = 'hidden';
        inputId.name = 'id_pedido';
        inputId.value = pedidoId;
        
        const inputEstado = document.createElement('input');
        inputEstado.type = 'hidden';
        inputEstado.name = 'estado';
        inputEstado.value = nuevoEstado;
        
        form.appendChild(inputId);
        form.appendChild(inputEstado);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>