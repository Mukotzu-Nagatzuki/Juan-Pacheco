<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Obtener las imágenes del carrusel
$carruselModel = new Carrusel($conn);
$imagenes = $carruselModel->obtenerTodos();

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
        <div>
            <h1>Configuración del Carrusel</h1>
            <p>Gestiona las imágenes del carrusel principal de tu tienda</p>
        </div>
        <a href="index.php?action=configuracion" class="btn-ver" style="display: inline-flex; align-items: center; gap: 0.5rem; white-space: nowrap;">
            <i class="bi bi-arrow-left"></i>
            Volver a Configuración
        </a>
    </div>
</header>
<!-- Estadísticas -->
<div class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-images stat-icon"></i>
        <h3><?php echo count($imagenes); ?></h3>
        <p>Total Imágenes</p>
    </div>
    <div class="stat-card">
        <i class="bi bi-check-circle stat-icon"></i>
        <h3><?php echo count(array_filter($imagenes, function($img) { return $img['estado'] === 'activo'; })); ?></h3>
        <p>Imágenes Activas</p>
    </div>
    <div class="stat-card">
        <i class="bi bi-ban stat-icon"></i>
        <h3><?php echo count(array_filter($imagenes, function($img) { return $img['estado'] === 'inactivo'; })); ?></h3>
        <p>Imágenes Inactivas</p>
    </div>
    
    <!-- NUEVO: Espacios disponibles -->
    <div class="stat-card">
        <i class="bi bi-plus-circle stat-icon"></i>
        <h3><?php echo max(0, 5 - count(array_filter($imagenes, function($img) { return $img['estado'] === 'activo'; }))); ?></h3>
        <p>Espacios Disponibles</p>
    </div>
</div>

<!-- Formulario para agregar nueva imagen -->
<div class="recent-orders">
    <h3>Agregar Nueva Imagen al Carrusel</h3>
    
    <div style="background: #f8f9fa; padding: 1rem; border-radius: var(--radio); margin-bottom: 1.5rem;">
        <p style="margin: 0; color: var(--color-texto); font-weight: 600;">
            <i class="bi bi-info-circle"></i>
            <strong>Límite:</strong> Máximo 5 imágenes activas en el carrusel
        </p>
    </div>
    
    <form action="index.php?action=agregar-imagen-carrusel" method="POST" enctype="multipart/form-data" style="background: white; padding: 2rem; border-radius: var(--radio); box-shadow: var(--sombra);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Título *</label>
                <input type="text" name="titulo" required 
                       placeholder="Ej: La Comodidad Perfecta Para Tus Noches"
                       style="width: 100%; padding: 0.75rem; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
            </div>

            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Orden de Visualización</label>
                <input type="number" name="orden" min="0" value="0" 
                       placeholder="0 para orden automático"
                       style="width: 100%; padding: 0.75rem; border: 1px solid var(--color-beige-claro); border-radius: var(--radio);">
            </div>

            <div style="grid-column: 1 / -1;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Subtítulo</label>
                <textarea name="subtitulo" rows="3" 
                          placeholder="Ej: Descubre nuestra colección premium de edredones..."
                          style="width: 100%; padding: 0.75rem; border: 1px solid var(--color-beige-claro); border-radius: var(--radio); resize: vertical;"></textarea>
            </div>

            <div style="grid-column: 1 / -1;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--color-texto);">Imagen del Carrusel *</label>
                <div style="border: 2px dashed var(--color-beige-claro); border-radius: var(--radio); padding: 2rem; text-align: center; margin-bottom: 1rem;">
                    <input type="file" id="imagen" name="imagen" accept="image/*" required
                           onchange="previewNewImage(this)"
                           style="display: none;">
                    <label for="imagen" style="cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 1rem;">
                        <i class="bi bi-cloud-upload" style="font-size: 3rem; color: var(--color-secundario);"></i>
                        <span style="font-weight: 600; color: var(--color-texto);">Seleccionar imagen para el carrusel</span>
                        <span style="color: var(--color-plomo); font-size: 0.9rem;">Haz clic para seleccionar una imagen</span>
                    </label>
                </div>
                <div id="new-image-preview" style="margin-bottom: 1rem;"></div>
                <small style="color: var(--color-plomo);">
                    <strong>Formatos:</strong> JPG, PNG, GIF, WEBP. 
                    <strong>Tamaño máximo:</strong> 5MB. 
                    <strong>Recomendado:</strong> 1920x1080px
                </small>
            </div>
        </div>

        <div style="display: flex; gap: 1rem; justify-content: flex-end;">
            <button type="reset" class="btn-ver" style="background: #6c757d;">
                <i class="bi bi-arrow-clockwise"></i> Limpiar
            </button>
            <button type="submit" class="btn-ver">
                <i class="bi bi-plus-circle"></i> Agregar al Carrusel
            </button>
        </div>
    </form>
</div>

<!-- Lista de imágenes existentes -->
<div class="recent-orders">
    <h3>Imágenes del Carrusel</h3>
    
    <?php if (empty($imagenes)): ?>
        <div style="text-align: center; padding: 3rem; color: #7f8c8d;">
            <i class="bi bi-images" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
            <p>No hay imágenes en el carrusel</p>
        </div>
    <?php else: ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 1.5rem;">
            <?php foreach ($imagenes as $imagen): ?>
                <div style="background: white; border-radius: var(--radio); box-shadow: var(--sombra); overflow: hidden; transition: all 0.3s ease;">
                    <div style="position: relative; height: 200px; overflow: hidden;">
                        <img src="public/img/carrusel/<?php echo htmlspecialchars($imagen['imagen_url']); ?>" 
                             alt="<?php echo htmlspecialchars($imagen['titulo']); ?>"
                             style="width: 100%; height: 100%; object-fit: cover;"
                             onerror="this.src='public/img/cama.webp'">
                        <div style="position: absolute; top: 0; left: 0; right: 0; background: linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, transparent 100%); padding: 1rem; display: flex; justify-content: space-between;">
                            <span style="background: rgba(255,255,255,0.9); color: var(--color-texto); padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600;">
                                Orden: <?php echo $imagen['orden']; ?>
                            </span>
                            <span class="status-badge status-<?php echo $imagen['estado']; ?>" style="font-size: 0.8rem;">
                                <?php echo $imagen['estado'] === 'activo' ? 'Activo' : 'Inactivo'; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div style="padding: 1.5rem;">
                        <h4 style="margin: 0 0 0.5rem 0; color: var(--color-principal); font-size: 1.1rem;">
                            <?php echo htmlspecialchars($imagen['titulo']); ?>
                        </h4>
                        <?php if (!empty($imagen['subtitulo'])): ?>
                            <p style="color: var(--color-texto); line-height: 1.4; margin-bottom: 1rem; font-size: 0.9rem;">
                                <?php echo htmlspecialchars($imagen['subtitulo']); ?>
                            </p>
                        <?php endif; ?>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; color: var(--color-plomo); font-size: 0.8rem; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid var(--color-beige-claro);">
                            <span>Creado: <?php echo date('d/m/Y', strtotime($imagen['fecha_creacion'])); ?></span>
                        </div>
                        
                        <div style="display: flex; gap: 0.5rem;">
                            <button class="btn-ver" onclick="abrirModalEditar(<?= htmlspecialchars(json_encode($imagen)) ?>)" style="flex: 1; text-align: center; padding: 0.5rem;">
                                <i class="bi bi-pencil"></i> Editar
                            </button>
                            <a href="index.php?action=eliminar-imagen-carrusel&id=<?php echo $imagen['id_carrusel']; ?>" 
                               class="btn-ver" style="flex: 1; text-align: center; padding: 0.5rem; background: #933955;"
                               onclick="return confirm('¿Estás seguro de eliminar esta imagen del carrusel?')">
                                <i class="bi bi-trash"></i> Eliminar
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Modal Editar Imagen -->
<div id="modalEditar" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Editar Imagen del Carrusel</h3>
            <button class="close" onclick="cerrarModal('modalEditar')">&times;</button>
        </div>
        <form id="formEditarCarrusel" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <input type="hidden" id="editar-id" name="id_carrusel">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="editar-titulo">Título *</label>
                        <input type="text" id="editar-titulo" name="titulo" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="editar-orden">Orden de Visualización</label>
                        <input type="number" id="editar-orden" name="orden" min="0" value="0">
                    </div>
                    
                    <div class="form-group">
                        <label for="editar-estado">Estado</label>
                        <select id="editar-estado" name="estado" required>
                            <option value="activo">Activo</option>
                            <option value="inactivo">Inactivo</option>
                        </select>
                    </div>
                    
                    <div class="form-group full">
                        <label for="editar-subtitulo">Subtítulo</label>
                        <textarea id="editar-subtitulo" name="subtitulo" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group full">
                        <label>Imagen Actual</label>
                        <div id="imagen-actual-container" style="margin-top: 0.5rem;">
                            <img id="imagen-actual" src="" alt="Imagen actual" style="max-width: 100%; max-height: 200px; border-radius: var(--radio); border: 2px solid var(--color-beige-claro);">
                        </div>
                    </div>
                    
                    <div class="form-group full">
                        <label for="editar-imagen">Nueva Imagen (opcional)</label>
                        <input type="file" id="editar-imagen" name="imagen" accept="image/*" onchange="previewEditImage(this)">
                        <div id="edit-image-preview" style="margin-top: 1rem;"></div>
                        <small style="color: var(--color-plomo);">
                            Dejar vacío para mantener la imagen actual. Formatos: JPG, PNG, GIF, WEBP. Tamaño máximo: 5MB
                        </small>
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="padding: 1rem; border-top: 1px solid var(--color-beige-claro); text-align: right;">
                <button type="button" class="btn-ver" onclick="cerrarModal('modalEditar')" style="background: #6c757d; margin-right: 0.5rem;">Cancelar</button>
                <button type="submit" class="btn-ver">Actualizar Imagen</button>
            </div>
        </form>
    </div>
</div>

<style>
/* Estilos para la vista previa de imagen */
#new-image-preview img,
#edit-image-preview img {
    max-width: 100%;
    max-height: 200px;
    border-radius: var(--radio);
    box-shadow: var(--sombra);
}

/* Efectos hover para las tarjetas */
.recent-orders > div > div:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(107, 93, 85, 0.15);
}

/* Estilos para los badges de estado */
.status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: capitalize;
}

.status-activo { 
    background: #e0f8e9; 
    color: #2e7d32; 
}

.status-inactivo { 
    background: #fdecea; 
    color: #c62828; 
}

/* Responsive */
@media (max-width: 768px) {
    .recent-orders form > div {
        grid-template-columns: 1fr !important;
    }
    
    .recent-orders > div {
        grid-template-columns: 1fr !important;
    }
    
    .recent-orders form {
        padding: 1.5rem !important;
    }
    
    .modal-content {
        width: 95%;
        margin: 5% auto;
    }
}
</style>

<script>
function previewNewImage(input) {
    const preview = document.getElementById('new-image-preview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.innerHTML = `
                <div style="text-align: center;">
                    <img src="${e.target.result}" alt="Vista previa">
                    <p style="margin-top: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                        Vista previa de la imagen seleccionada
                    </p>
                </div>
            `;
        }
        
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.innerHTML = '';
    }
}

function previewEditImage(input) {
    const preview = document.getElementById('edit-image-preview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.innerHTML = `
                <div style="text-align: center;">
                    <img src="${e.target.result}" alt="Vista previa de nueva imagen">
                    <p style="margin-top: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                        Vista previa de la nueva imagen
                    </p>
                </div>
            `;
        }
        
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.innerHTML = '';
    }
}

function abrirModalEditar(imagen) {
    // Llenar formulario de edición
    document.getElementById('editar-id').value = imagen.id_carrusel;
    document.getElementById('editar-titulo').value = imagen.titulo;
    document.getElementById('editar-subtitulo').value = imagen.subtitulo || '';
    document.getElementById('editar-orden').value = imagen.orden;
    document.getElementById('editar-estado').value = imagen.estado;
    
    // Mostrar imagen actual
    const imagenActual = document.getElementById('imagen-actual');
    imagenActual.src = 'public/img/carrusel/' + imagen.imagen_url;
    imagenActual.alt = imagen.titulo;
    
    // Resetear preview de nueva imagen
    document.getElementById('edit-image-preview').innerHTML = '';
    
    // Configurar acción del formulario
    document.getElementById('formEditarCarrusel').action = 'index.php?action=editar-imagen-carrusel&id=' + imagen.id_carrusel;
    
    // Resetear scroll al abrir el modal
    const modalBody = document.querySelector('#modalEditar .modal-body');
    if (modalBody) {
        modalBody.scrollTop = 0;
    }
    
    document.getElementById('modalEditar').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function cerrarModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Cerrar modal al hacer clic fuera de él
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }
}

// Cerrar modal con tecla ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modals = document.getElementsByClassName('modal');
        for (let modal of modals) {
            if (modal.style.display === 'block') {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }
    }
});

// Efectos de hover mejorados
document.addEventListener('DOMContentLoaded', function() {
    const carruselCards = document.querySelectorAll('.recent-orders > div > div');
    
    carruselCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';