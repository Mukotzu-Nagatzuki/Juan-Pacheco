<?php
// Obtener la conexión a la base de datos desde el layout
$db = new Database();
$conn = $db->getConnection();

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Configuración del Sitio Web</h1>
    <p>Gestiona todas las configuraciones y ajustes de tu tienda</p>
</header>
<!-- Grid de opciones de configuración -->
<div class="recent-orders">
    <h3>Opciones de Configuración</h3>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 1.5rem;">
        <!-- Carrusel Hero -->
        <div
            style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); transition: all 0.3s ease; border-left: 4px solid var(--color-secundario); display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div
                    style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--color-principal), var(--color-secundario)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                    <i class="bi bi-images"></i>
                </div>
                <h4 style="margin: 0; color: var(--color-principal);">Carrusel de imagenes</h4>
            </div>

            <div style="flex: 1; margin-bottom: 1.5rem;">
                <p style="color: var(--color-texto); line-height: 1.6; margin-bottom: 1rem;">
                    Gestiona las imágenes del carrusel principal en la página de inicio. Máximo 5 imágenes.
                </p>
                <div
                    style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                    <i class="bi bi-image"></i>
                    <span>Configurar Imágenes</span>
                </div>
            </div>

            <div>
                <a href="index.php?action=configuracion-carrusel" class="btn-ver"
                    style="display: block; text-align: center;">
                    <i class="bi bi-gear"></i>
                    Configurar Carrusel
                </a>
            </div>
        </div>

        <!-- Métodos de Pago -->
        <div
            style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); transition: all 0.3s ease; border-left: 4px solid var(--color-secundario); display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div
                    style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--color-principal), var(--color-secundario)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                    <i class="bi bi-credit-card"></i>
                </div>
                <h4 style="margin: 0; color: var(--color-principal);">Métodos de Pago</h4>
            </div>

            <div style="flex: 1; margin-bottom: 1.5rem;">
                <p style="color: var(--color-texto); line-height: 1.6; margin-bottom: 1rem;">
                    Configura y activa los diferentes métodos de pago disponibles para tus clientes.
                </p>
                <div
                    style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                    <i class="bi bi-wallet2"></i>
                    <span>Pasarelas de Pago</span>
                </div>
            </div>

            <div>
                <button class="btn-ver" onclick="mostrarMensaje('Configuración de pagos - Próximamente disponible')"
                    style="width: 100%;">
                    <i class="bi bi-gear"></i>
                    Configurar Pagos
                </button>
            </div>
        </div>

        <!-- Configuración de Envíos -->
        <div
            style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); transition: all 0.3s ease; border-left: 4px solid var(--color-secundario); display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div
                    style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--color-principal), var(--color-secundario)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                    <i class="bi bi-truck"></i>
                </div>
                <h4 style="margin: 0; color: var(--color-principal);">Configuración de Envíos</h4>
            </div>

            <div style="flex: 1; margin-bottom: 1.5rem;">
                <p style="color: var(--color-texto); line-height: 1.6; margin-bottom: 1rem;">
                    Gestiona zonas de envío, costos y políticas de entrega para tu tienda.
                </p>
                <div
                    style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                    <i class="bi bi-geo-alt"></i>
                    <span>Zonas y Costos</span>
                </div>
            </div>

            <div>
                <button class="btn-ver" onclick="mostrarMensaje('Configuración de envíos - Próximamente disponible')"
                    style="width: 100%;">
                    <i class="bi bi-gear"></i>
                    Configurar Envíos
                </button>
            </div>
        </div>

        <!-- Configuración General -->
        <div
            style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); transition: all 0.3s ease; border-left: 4px solid var(--color-secundario); display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div
                    style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--color-principal), var(--color-secundario)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                    <i class="bi bi-sliders"></i>
                </div>
                <h4 style="margin: 0; color: var(--color-principal);">Configuración General</h4>
            </div>

            <div style="flex: 1; margin-bottom: 1.5rem;">
                <p style="color: var(--color-texto); line-height: 1.6; margin-bottom: 1rem;">
                    Ajustes generales del sitio, información de contacto y configuración básica.
                </p>
                <div
                    style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                    <i class="bi bi-info-circle"></i>
                    <span>Información de la Tienda</span>
                </div>
            </div>

            <div>
                <a href="index.php?action=configuracion-general" class="btn-ver"
                    style="display: block; text-align: center; width: 100%; text-decoration: none;">
                    <i class="bi bi-gear"></i>
                    Configurar General
                </a>
            </div>
        </div>

        <!-- Notificaciones -->
        <div
            style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); transition: all 0.3s ease; border-left: 4px solid var(--color-secundario); display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div
                    style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--color-principal), var(--color-secundario)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                    <i class="bi bi-bell"></i>
                </div>
                <h4 style="margin: 0; color: var(--color-principal);">Notificaciones</h4>
            </div>

            <div style="flex: 1; margin-bottom: 1.5rem;">
                <p style="color: var(--color-texto); line-height: 1.6; margin-bottom: 1rem;">
                    Configura las notificaciones por email y alertas del sistema.
                </p>
                <div
                    style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                    <i class="bi bi-envelope"></i>
                    <span>Email y Alertas</span>
                </div>
            </div>

            <div>
                <button class="btn-ver"
                    onclick="mostrarMensaje('Configuración de notificaciones - Próximamente disponible')"
                    style="width: 100%;">
                    <i class="bi bi-gear"></i>
                    Configurar Notificaciones
                </button>
            </div>
        </div>

        <!-- Seguridad -->
        <div
            style="background: white; padding: 1.5rem; border-radius: var(--radio); box-shadow: var(--sombra); transition: all 0.3s ease; border-left: 4px solid var(--color-secundario); display: flex; flex-direction: column; height: 100%;">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <div
                    style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--color-principal), var(--color-secundario)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                    <i class="bi bi-shield-check"></i>
                </div>
                <h4 style="margin: 0; color: var(--color-principal);">Seguridad</h4>
            </div>

            <div style="flex: 1; margin-bottom: 1.5rem;">
                <p style="color: var(--color-texto); line-height: 1.6; margin-bottom: 1rem;">
                    Configuración de seguridad, permisos de usuario y políticas de acceso.
                </p>
                <div
                    style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-plomo); font-size: 0.9rem;">
                    <i class="bi bi-lock"></i>
                    <span>Permisos y Accesos</span>
                </div>
            </div>

            <div>
                <button class="btn-ver" onclick="mostrarMensaje('Configuración de seguridad - Próximamente disponible')"
                    style="width: 100%;">
                    <i class="bi bi-gear"></i>
                    Configurar Seguridad
                </button>
            </div>
        </div>
    </div>
</div>

<style>
    /* Efectos hover para las tarjetas */
    .recent-orders>div>div:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(107, 93, 85, 0.15);
    }

    /* Estilos para el mensaje de próximamente */
    .mensaje-proximamente {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 1.5rem 2.5rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 1.1rem;
        z-index: 1000;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        animation: fadeIn 0.3s ease;
        text-align: center;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translate(-50%, -40%);
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%);
        }
    }

    /* Responsive */
    @media (max-width: 768px) {
        .recent-orders>div {
            grid-template-columns: 1fr;
        }

        .recent-orders>div>div {
            padding: 1.25rem;
        }
    }
</style>

<script>
    function mostrarMensaje(mensaje) {
        // Crear elemento de mensaje
        const mensajeDiv = document.createElement('div');
        mensajeDiv.className = 'mensaje-proximamente';
        mensajeDiv.textContent = mensaje;

        // Agregar al body
        document.body.appendChild(mensajeDiv);

        // Remover después de 2 segundos
        setTimeout(() => {
            if (mensajeDiv.parentNode) {
                mensajeDiv.parentNode.removeChild(mensajeDiv);
            }
        }, 2000);
    }

    // Efectos de hover mejorados
    document.addEventListener('DOMContentLoaded', function () {
        const configCards = document.querySelectorAll('.recent-orders > div > div');

        configCards.forEach(card => {
            card.addEventListener('mouseenter', function () {
                this.style.transform = 'translateY(-5px)';
            });

            card.addEventListener('mouseleave', function () {
                this.style.transform = 'translateY(0)';
            });
        });
    });
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';