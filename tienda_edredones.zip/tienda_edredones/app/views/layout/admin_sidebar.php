<aside class="sidebar">
    <!-- Sidebar Header -->
    <div class="sidebar-header">
        <div class="user-section">
            <div class="user-info">
                <span class="user-greeting">Hola, <?= htmlspecialchars($usuario['nombre']) ?></span>
                <button class="sidebar-toggle">
                    <i class="bi bi-list"></i>
                </button>
            </div>
            <?php
            // Obtener configuraciones para el logo
            require_once 'app/config/database.php';
            require_once 'app/controllers/ConfiguracionController.php';
            $configController = new ConfiguracionController();
            $configuraciones = $configController->obtenerConfiguraciones();
            
            // Determinar la ruta del logo
            $logo_path = $configuraciones['logo_ruta'] ?? 'public/img/logo/logoedredon.png';
            $logo_exists = file_exists($logo_path);
            
            // Si no existe en la ruta configurada, verificar en ubicación anterior
            if (!$logo_exists) {
                $logo_path_old = 'public/img/logoedredon.png';
                $logo_exists = file_exists($logo_path_old);
                if ($logo_exists) {
                    $logo_path = $logo_path_old;
                }
            }
            
            // Si todavía no existe, usar placeholder
            $logo_url = $logo_exists ? $logo_path : 'public/img/placeholder-logo.png';
            $site_title = $configuraciones['logo'] ?? 'Dream House';
            ?>
            <img src="<?php echo $logo_url; ?>" alt="<?php echo htmlspecialchars($site_title); ?>" class="header-logo">
        </div>
    </div>

    <div class="sidebar-content">
        <!-- Sidebar Menu -->
        <ul class="menu-list">
            <li class="menu-item">
                <a href="index.php?action=dashboard" class="menu-link <?= isActiveLink('dashboard') ?>" data-tooltip="Dashboard">
                    <i class="bi bi-speedometer2"></i>
                    <span class="menu-label">Dashboard</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=admin" class="menu-link <?= isActiveLink('admin') ?>" data-tooltip="Productos">
                    <i class="bi bi-box-seam"></i>
                    <span class="menu-label">Gestión de Productos</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=pedidos_admin" class="menu-link <?= isActiveLink('pedidos_admin') ?>" data-tooltip="Pedidos">
                    <i class="bi bi-bag-check"></i>
                    <span class="menu-label">Gestión de Pedidos</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=gestion_clientes" class="menu-link <?= isActiveLink('gestion_clientes') ?>" data-tooltip="Clientes">
                    <i class="bi bi-people"></i>
                    <span class="menu-label">Gestión de Clientes</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=gestion_ofertas" class="menu-link <?= isActiveLink('gestion_ofertas') ?>" data-tooltip="Ofertas">
                    <i class="bi bi-percent"></i>
                    <span class="menu-label">Gestión de Ofertas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=reportes" class="menu-link <?= isActiveLink('reportes') ?>" data-tooltip="Reportes">
                    <i class="bi bi-graph-up"></i>
                    <span class="menu-label">Reportes</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=configuracion" class="menu-link <?= isActiveLink('configuracion') ?>" data-tooltip="Configuración">
                    <i class="bi bi-gear"></i>
                    <span class="menu-label">Configuración</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=home" class="menu-link" data-tooltip="Tienda">
                    <i class="bi bi-shop"></i>
                    <span class="menu-label">Volver a la Tienda</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Sidebar Footer -->
    <div class="sidebar-footer">
        <button class="logout-btn">
            <div class="logout-label">
                <i class="bi bi-box-arrow-right"></i>
                <span class="logout-text">Cerrar Sesión</span>
            </div>
        </button>
    </div>
</aside>