<?php
// app/views/layout/footer.php

// Obtener configuraciones dinámicas para el footer
$configuraciones_footer = [];
try {
    require_once 'app/config/database.php';
    require_once 'app/controllers/ConfiguracionController.php';
    
    $database = new Database();
    $db = $database->getConnection();
    $configController = new ConfiguracionController();
    $configuraciones_footer = $configController->obtenerConfiguraciones();
    
} catch (Exception $e) {
    error_log("Error cargando configuraciones del footer: " . $e->getMessage());
    // Configuraciones por defecto en caso de error
    $configuraciones_footer = [
        'logo' => 'Dream House',
        'descripcion_footer' => 'Tu tienda premium de edredones y ropa de cama. Ofrecemos productos de la más alta calidad para garantizar tu confort y descanso.',
        'telefono' => '+51 123 456 789'
    ];
}
?>
<!-- Footer -->
<footer class="footer">
    <div class="footer-content">
        <!-- Columna 1: Logo y descripción -->
        <div class="footer-section">
            <div class="footer-logo"><?php echo htmlspecialchars($configuraciones_footer['logo'] ?? 'Dream House'); ?></div>
            <div class="divider2"></div>
            <p class="footer-description">
                <?php echo htmlspecialchars($configuraciones_footer['descripcion_footer'] ?? 'Tu tienda premium de edredones y ropa de cama. Ofrecemos productos de la más alta calidad para garantizar tu confort y descanso.'); ?>
            </p>
            <div class="social-icons">
                <?php if (!empty($configuraciones_footer['whatsapp_url'])): ?>
                <a href="<?php echo htmlspecialchars($configuraciones_footer['whatsapp_url']); ?>" class="social-link" aria-label="WhatsApp" target="_blank">
                    <i class="fab fa-whatsapp"></i>
                </a>
                <?php endif; ?>

                <?php if (!empty($configuraciones_footer['facebook_url'])): ?>
                <a href="<?php echo htmlspecialchars($configuraciones_footer['facebook_url']); ?>" class="social-link" aria-label="Facebook" target="_blank">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <?php endif; ?>

                <?php if (!empty($configuraciones_footer['tiktok_url'])): ?>
                <a href="<?php echo htmlspecialchars($configuraciones_footer['tiktok_url']); ?>" class="social-link" aria-label="TikTok" target="_blank">
                    <i class="fab fa-tiktok"></i>
                </a>
                <?php endif; ?>

                <?php if (!empty($configuraciones_footer['instagram_url'])): ?>
                <a href="<?php echo htmlspecialchars($configuraciones_footer['instagram_url']); ?>" class="social-link" aria-label="Instagram" target="_blank">
                    <i class="fab fa-instagram"></i>
                </a>
                <?php endif; ?>

                <?php if (!empty($configuraciones_footer['youtube_url'])): ?>
                <a href="<?php echo htmlspecialchars($configuraciones_footer['youtube_url']); ?>" class="social-link" aria-label="YouTube" target="_blank">
                    <i class="fab fa-youtube"></i>
                </a>
                <?php endif; ?>
            </div>

            <!-- Información de contacto -->
            <?php if (!empty($configuraciones_footer['telefono'])): ?>
            <div class="footer-contact" style="margin-top: 1rem; color: #b0b0b0; font-size: 0.9rem;">
                <i class="fas fa-phone" style="margin-right: 0.5rem;"></i>
                <?php echo htmlspecialchars($configuraciones_footer['telefono']); ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Columna 2: Enlaces rápidos -->
        <div class="footer-section">
            <h4 class="footer-title">Enlaces Rápidos</h4>
            <div class="divider2"></div>
            <ul class="footer-links">
                <li><a href="/index.php?action=home">Inicio</a></li>
                <li><a href="/index.php?action=productos">Productos</a></li>
                <li><a href="/index.php?action=nosotros">Nosotros</a></li>
                <li><a href="/index.php?action=contacto">Contacto</a></li>
                <li><a href="/index.php?action=carrito">Carrito</a></li>
            </ul>
        </div>

        <!-- Columna 3: Categorías -->
        <div class="footer-section">
            <h4 class="footer-title">Categorías</h4>
            <div class="divider2"></div>
            <ul class="footer-links">
                <?php
                // Intentar obtener categorías dinámicamente
                try {
                    require_once 'app/models/Categoria.php';
                    $categoriaModel = new Categoria($db);
                    $categorias_footer = $categoriaModel->obtenerTodasActivas(4); // Limitar a 4 categorías
                    
                    if (!empty($categorias_footer)) {
                        foreach ($categorias_footer as $categoria): ?>
                            <li><a href="/index.php?action=categoria&id=<?php echo $categoria['id_categoria']; ?>">
                                <?php echo htmlspecialchars($categoria['nombre']); ?>
                            </a></li>
                        <?php endforeach;
                    } else {
                        // Fallback a categorías estáticas
                        ?>
                        <li><a href="/index.php?action=categoria&id=1">Sábanas</a></li>
                        <li><a href="/index.php?action=categoria&id=2">Edredón Reversible</a></li>
                        <li><a href="/index.php?action=categoria&id=3">Edredón de Sherpa</a></li>
                        <li><a href="/index.php?action=categoria&id=4">Cubrecamas</a></li>
                        <?php
                    }
                } catch (Exception $e) {
                    // Fallback en caso de error
                    ?>
                    <li><a href="/index.php?action=categoria&id=1">Sábanas</a></li>
                    <li><a href="/index.php?action=categoria&id=2">Edredón Reversible</a></li>
                    <li><a href="/index.php?action=categoria&id=3">Edredón de Sherpa</a></li>
                    <li><a href="/index.php?action=categoria&id=4">Cubrecamas</a></li>
                    <?php
                }
                ?>
            </ul>
        </div>

        <!-- Columna 4: Newsletter -->
        <div class="footer-section">
            <h4 class="footer-title">Newsletter</h4>
            <div class="divider2"></div>
            <p class="footer-newsletter-text">
                Suscríbete para recibir ofertas exclusivas y novedades sobre nuestros productos.
            </p>
            <form class="newsletter-form" action="/index.php" method="POST">
                <input type="hidden" name="action" value="suscripcion_newsletter">
                <input type="email" name="email" placeholder="Tu correo electrónico" required>
                <button type="submit">Suscribirse</button>
            </form>
        </div>
    </div>

    <!-- Línea divisoria -->
    <div class="footer-divider"></div>

    <!-- Footer inferior -->
    <div class="footer-bottom">
        <div class="footer-bottom-content">
            <p class="footer-copyright">
                &copy; <?php echo date('Y'); ?> <strong><?php echo htmlspecialchars($configuraciones_footer['logo'] ?? 'Dream House'); ?></strong>. Todos los derechos reservados.
            </p>
        </div>
    </div>
</footer>

<?php if (!isset($solo_navbar)): ?>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="/public/js/main.js"></script>
<?php endif; ?>