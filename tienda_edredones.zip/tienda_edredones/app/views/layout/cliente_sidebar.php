<aside class="sidebar">
    <!-- Sidebar Header -->
    <div class="sidebar-header">
        <div class="user-section">
            <div class="user-info">
                <span class="user-greeting">Hola, <?= htmlspecialchars($usuario['nombre'] ?? 'Usuario') ?></span>
                <button class="sidebar-toggle">
                    <i class="bi bi-list"></i>
                </button>
            </div>
            <?php
            // Obtener configuraciones para el logo
            require_once 'app/config/database.php';
            require_once 'app/controllers/ConfiguracionController.php';
            $configController = new ConfiguracionController();
            $configuraciones = $configController->obtenerConfiguraciones();
            
            // Determinar la ruta del logo
            $logo_path = $configuraciones['logo_ruta'] ?? 'public/img/logo/logoedredon.png';
            $logo_exists = file_exists($logo_path);
            
            // Si no existe en la ruta configurada, verificar en ubicación anterior
            if (!$logo_exists) {
                $logo_path_old = 'public/img/logoedredon.png';
                $logo_exists = file_exists($logo_path_old);
                if ($logo_exists) {
                    $logo_path = $logo_path_old;
                }
            }
            
            // Si todavía no existe, usar placeholder
            $logo_url = $logo_exists ? $logo_path : 'public/img/placeholder-logo.png';
            $site_title = $configuraciones['logo'] ?? 'Dream House';
            ?>
            <img src="<?php echo $logo_url; ?>" alt="<?php echo htmlspecialchars($site_title); ?>" class="header-logo">
        </div>
    </div>

    <div class="sidebar-content">
        <!-- Sidebar Menu para Clientes -->
        <ul class="menu-list">
            <li class="menu-item">
                <a href="index.php?action=dashboard" class="menu-link <?= isActiveLink('dashboard') ?>" data-tooltip="Dashboard">
                    <i class="bi bi-speedometer2"></i>
                    <span class="menu-label">Mi Dashboard</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=perfil" class="menu-link <?= isActiveLink('perfil') ?>" data-tooltip="Perfil">
                    <i class="bi bi-person"></i>
                    <span class="menu-label">Mi Perfil</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=pedidos" class="menu-link <?= isActiveLink('pedidos') ?>" data-tooltip="Pedidos">
                    <i class="bi bi-bag-check"></i>
                    <span class="menu-label">Mis Pedidos</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=mis_descuentos" class="menu-link <?= isActiveLink('mis_descuentos') ?>" data-tooltip="Descuentos">
                    <i class="bi bi-tag"></i>
                    <span class="menu-label">Mis Descuentos</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=facturas" class="menu-link <?= isActiveLink('facturas') ?>" data-tooltip="Facturas">
                    <i class="bi bi-receipt"></i>
                    <span class="menu-label">Mis Facturas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=deseos" class="menu-link <?= isActiveLink('deseos') ?>" data-tooltip="Deseos">
                    <i class="bi bi-heart"></i>
                    <span class="menu-label">Lista de Deseos</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="index.php?action=home" class="menu-link" data-tooltip="Tienda">
                    <i class="bi bi-shop"></i>
                    <span class="menu-label">Volver a la Tienda</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Sidebar Footer -->
    <div class="sidebar-footer">
        <button class="logout-btn">
            <div class="logout-label">
                <i class="bi bi-box-arrow-right"></i>
                <span class="logout-text">Cerrar Sesión</span>
            </div>
        </button>
    </div>
</aside>