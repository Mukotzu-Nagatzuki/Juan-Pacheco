<?php
require_once __DIR__ . '/../../helpers/funciones.php';
require_once __DIR__ . '/../../config/database.php';

checkAuth();
$user_id = $_SESSION['usuario_id'];

// Conexión a la base de datos
$db = new Database();
$conn = $db->getConnection();

// Obtener información del usuario administrador
$usuario = getUserProfile($user_id);

// Función para determinar si el enlace está activo
function isActiveLink($action) {
    $currentAction = $_GET['action'] ?? 'dashboard';
    return $currentAction === $action ? 'active' : '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Dream House</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="public/css/dashboard.css">
    <link rel="stylesheet" href="public/css/admin.css">
</head>
<body>
<div class="dashboard">
    <!-- Sidebar -->
    <?php include __DIR__ . '/admin_sidebar.php'; ?>

    <!-- Contenido Principal -->
    <main class="main-content">
        <?php echo $content; ?>
    </main>
</div>

<script src="public/js/dashboart.js"></script>
</body>
</html>