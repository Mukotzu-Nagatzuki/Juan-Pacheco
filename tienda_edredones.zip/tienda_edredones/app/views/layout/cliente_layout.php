<?php
require_once __DIR__ . '/../../helpers/funciones.php';
require_once __DIR__ . '/../../config/database.php';

checkAuth();
$user_id = $_SESSION['usuario_id'];

// Obtener información del usuario cliente usando tu función existente
$usuario = getUserProfile($user_id);

// Verificar que se obtuvo el usuario
if (!$usuario) {
    // Si no se puede obtener el usuario, redirigir al login
    session_destroy();
    header('Location: index.php?action=login');
    exit;
}

// Función para determinar si el enlace está activo
function isActiveLink($action) {
    $currentAction = $_GET['action'] ?? 'dashboard';
    return $currentAction === $action ? 'active' : '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Cuenta - Dream House</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="public/css/dashboard.css">
    <link rel="stylesheet" href="public/css/cliente.css">
</head>
<body>
<div class="dashboard">
    <!-- Sidebar del Cliente -->
    <?php include __DIR__ . '/cliente_sidebar.php'; ?>

    <!-- Contenido Principal -->
    <main class="main-content">
        <?php echo $content; ?>
    </main>
</div>

<script src="public/js/dashboart.js"></script>
</body>
</html>