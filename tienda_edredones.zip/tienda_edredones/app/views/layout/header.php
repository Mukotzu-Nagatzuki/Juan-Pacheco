<?php
// app/views/layout/header.php

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Detectar la página actual
$current_page = basename($_SERVER['PHP_SELF']);
$action = $_GET['action'] ?? '';

// Obtener término de búsqueda si existe
$search_term = $_GET['search'] ?? '';

// OBTENER CONFIGURACIONES DINÁMICAS DESDE LA BASE DE DATOS
$configuraciones_header = [];
try {
    require_once 'app/config/database.php';
    require_once 'app/controllers/ConfiguracionController.php';
    
    $database = new Database();
    $db = $database->getConnection();
    $configController = new ConfiguracionController();
    $configuraciones_header = $configController->obtenerConfiguraciones();
    
} catch (Exception $e) {
    error_log("Error cargando configuraciones del header: " . $e->getMessage());
    $configuraciones_header = [
        'logo' => 'Dream House',
        'descripcion' => 'Tienda Premium de Edredones',
        'logo_ruta' => 'public/img/logo/logoedredon.png'
    ];
}

// VARIABLE PARA EL TÍTULO DINÁMICO DEL HEADER
$header_title = "Sábanas";
$show_header_section = false;

// Obtener categorías desde la base de datos
$categorias = [];
try {
    require_once 'app/models/Categoria.php';
    
    $categoriaModel = new Categoria($db);
    $categorias = $categoriaModel->obtenerTodasActivas();
    
    // DETERMINAR EL TÍTULO DINÁMICO
    if ($action === 'categoria' && isset($_GET['id'])) {
        $id_categoria = $_GET['id'];
        $categoria_actual = $categoriaModel->obtenerPorId($id_categoria);
        if ($categoria_actual) {
            $header_title = $categoria_actual['nombre'];
            $show_header_section = true;
        }
    } elseif ($action === 'buscar' && !empty($search_term)) {
        $header_title = "Resultados de búsqueda";
        $show_header_section = true;
    }
    
} catch (Exception $e) {
    $categorias = [
        ['id_categoria' => 1, 'nombre' => 'Sábanas'],
        ['id_categoria' => 2, 'nombre' => 'Edredón Reversible'],
        ['id_categoria' => 3, 'nombre' => 'Edredón de Sherpa'],
        ['id_categoria' => 4, 'nombre' => 'Cubrecamas']
    ];
    error_log("Error cargando categorías: " . $e->getMessage());
}

// Obtener contador del carrito si el usuario está logueado
$carrito_count = 0;
if (isset($_SESSION['usuario_id']) && isset($db)) {
    try {
        require_once 'app/models/Carrito.php';
        $carritoModel = new Carrito($db);
        $carrito_count = $carritoModel->obtenerCantidadItems($_SESSION['usuario_id']);
    } catch (Exception $e) {
        error_log("Error cargando carrito: " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($configuraciones_header['logo'] ?? 'Dream House'); ?> - Tienda Premium de Edredones</title>
    
    <!-- CSS Globales - RUTAS DIRECTAS -->
    <link rel="stylesheet" href="/public/css/estilos.css">
    <link rel="stylesheet" href="/public/css/header.css">
    <link rel="stylesheet" href="/public/css/footer.css">
    
    <!-- CSS específicos por página -->
    <?php if ($current_page == 'home.php' || $_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/index.php' || $action == 'home' || empty($action)): ?>
        <link rel="stylesheet" href="/public/css/home.css">
    <?php endif; ?>
    
    <?php if ($current_page == 'login.php' || $action == 'login'): ?>
        <link rel="stylesheet" href="/public/css/auth.css">
    <?php endif; ?>
    
    <?php if ($current_page == 'registro.php' || $action == 'registro'): ?>
        <link rel="stylesheet" href="/public/css/registro.css">
    <?php endif; ?>

    <?php if ($action == 'editar_producto' || $action == 'agregar_producto'): ?>
        <link rel="stylesheet" href="/public/css/formulariosproductos.css">
    <?php endif; ?>
    
    <?php if ($action == 'admin'): ?>
        <link rel="stylesheet" href="/public/css/admin.css">
    <?php endif; ?>

    <?php if ($action == 'nosotros'): ?>
        <link rel="stylesheet" href="/public/css/nosotros.css">
    <?php endif; ?>

    <?php if ($action == 'contacto'): ?>
        <link rel="stylesheet" href="/public/css/contacto.css">
    <?php endif; ?>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
</head>
<body>
    <?php if (!isset($solo_navbar)): ?>
    <!-- Overlay para el carrito -->
    <div class="cart-overlay" id="cartOverlay"></div>

    <!-- Carrito lateral -->
    <div class="cart-sidebar" id="cartSidebar">
        <div class="cart-header">
            <h3 class="cart-title">Tu Carrito</h3>
            <button class="close-cart" id="closeCart">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="cart-content" id="cartContent">
            <div class="empty-cart-message">
                <i class="fas fa-shopping-cart"></i>
                <h4>Cargando carrito...</h4>
            </div>
        </div>
        
        <div class="cart-footer">
            <div class="cart-total">
                <span>Total:</span>
                <span id="cartTotal">S/ 0.00</span>
            </div>
            <button class="checkout-btn" id="checkoutBtn" disabled>
                Continuar con la Compra
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Header -->
    <header>
        <nav class="navbar">
            <!-- Logo -->
            <div class="logo-brand">
                <a href="/index.php" class="logo-link">
                    <img src="/public/img/logo/logoedredon.png" 
                         alt="<?php echo htmlspecialchars($configuraciones_header['logo'] ?? 'Dream House'); ?>" 
                         class="logo-img">
                    <div class="brand-text">
                        <div class="brand-main"><?php echo htmlspecialchars($configuraciones_header['logo'] ?? 'Dream House'); ?></div>
                        <div class="brand-subtitle"><?php echo htmlspecialchars($configuraciones_header['descripcion'] ?? 'Tienda Premium de Edredones'); ?></div>
                    </div>
                </a>
            </div>

            <!-- Navegación central -->
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="/index.php?action=home" class="nav-link">Inicio</a>
                </li>
                <li class="nav-item dropdown">
                    <a href="/index.php?action=productos" class="nav-link dropdown-toggle">
                        Productos <i class="fas fa-chevron-down"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <?php if (!empty($categorias)): ?>
                            <?php foreach ($categorias as $categoria): ?>
                                <li>
                                    <a href="/index.php?action=categoria&id=<?php echo $categoria['id_categoria']; ?>" 
                                       class="dropdown-item">
                                        <?php echo htmlspecialchars($categoria['nombre']); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li><a href="/index.php?action=categoria&id=1" class="dropdown-item">Sábanas</a></li>
                            <li><a href="/index.php?action=categoria&id=2" class="dropdown-item">Edredón Reversible</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="/index.php?action=nosotros" class="nav-link">Nosotros</a>
                </li>
                <li class="nav-item">
                    <a href="/index.php?action=contacto" class="nav-link">Contactenos</a>
                </li>
            </ul>

            <!-- Iconos a la derecha -->
            <div class="nav-icons">
                <!-- Buscador -->
                <div class="icon-item search-container">
                    <form action="/index.php" method="GET" class="search-form">
                        <input type="hidden" name="action" value="buscar">
                        <div class="search-input-wrapper">
                            <input type="text" name="search" class="search-input" placeholder="Buscar productos..." value="<?php echo htmlspecialchars($search_term); ?>">
                            <button type="submit" class="search-button">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Carrito -->
                <div class="icon-item">
                    <?php if (isset($_SESSION['usuario_id'])): ?>
                        <a href="#" class="icon-link" id="openCart">
                            <i class="fas fa-shopping-cart"></i>
                            <?php if ($carrito_count > 0): ?>
                                <span class="cart-count"><?php echo $carrito_count; ?></span>
                            <?php endif; ?>
                        </a>
                    <?php else: ?>
                        <a href="/index.php?action=login" class="icon-link">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="cart-count">0</span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Usuario -->
                <div class="icon-item">
                    <?php if (isset($_SESSION['usuario_id'])): ?>
                        <div class="user-dropdown">
                            <button class="user-btn">
                                <i class="fas fa-user-circle"></i>
                                <span class="user-name"><?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="dropdown-menu">
                                <a href="/index.php?action=dashboard" class="dropdown-item">
                                    <i class="fas fa-user"></i> Mi Perfil
                                </a>

                                <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin'): ?>
                                    <a href="/index.php?action=admin" class="dropdown-item">
                                        <i class="fas fa-cog"></i> Administración
                                    </a>
                                <?php endif; ?>
                                <div class="dropdown-divider"></div>
                                <a href="/index.php?action=logout" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="/index.php?action=login" class="login-link">
                            <i class="fas fa-user"></i>
                            <span>Iniciar Sesión</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>

        <!-- SECCIÓN DEL HEADER DINÁMICO -->
        <?php if ($show_header_section && !isset($solo_navbar)): ?>
        <div class="page-header-section">
            <div class="container">
                <h1 class="page-title"><?php echo htmlspecialchars($header_title); ?></h1>
                <p class="page-subtitle">
                    <?php 
                    if ($action === 'categoria' && isset($categoria_actual)) {
                        echo htmlspecialchars($categoria_actual['descripcion'] ?? 'Descubre nuestra selección premium');
                    } elseif ($action === 'buscar' && !empty($search_term)) {
                        echo "Resultados para: " . htmlspecialchars($search_term);
                    }
                    ?>
                </p>
            </div>
        </div>
        <?php endif; ?> 
    </header>

    <?php if (!isset($solo_navbar)): ?>
    <!-- JavaScript simplificado -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        const cartSidebar = $('#cartSidebar');
        const cartOverlay = $('#cartOverlay');
        const cartContent = $('#cartContent');
        const cartTotal = $('#cartTotal');
        const checkoutBtn = $('#checkoutBtn');

        // Abrir carrito
        $('#openCart').on('click', function(e) {
            e.preventDefault();
            loadCart();
            cartSidebar.addClass('active');
            cartOverlay.addClass('active');
            $('body').css('overflow', 'hidden');
        });

        // Cerrar carrito
        $('#closeCart, #cartOverlay').on('click', function() {
            cartSidebar.removeClass('active');
            cartOverlay.removeClass('active');
            $('body').css('overflow', 'auto');
        });

        // Cargar contenido del carrito
        function loadCart() {
            cartContent.html(`
                <div class="empty-cart-message">
                    <i class="fas fa-spinner fa-spin"></i>
                    <h4>Cargando carrito...</h4>
                </div>
            `);

            $.ajax({
                url: '/index.php?action=carrito_sidebar',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success && response.items && response.items.length > 0) {
                        let html = '';
                        let total = 0;
                        
                        response.items.forEach(item => {
                            const itemTotal = item.precio * item.cantidad;
                            total += itemTotal;
                            
                            html += `
                                <div class="cart-item" data-producto="${item.id_producto}">
                                    <img src="/public/img/productos/${item.imagen_principal}" 
                                         alt="${item.nombre}" 
                                         class="cart-item-img">
                                    <div class="cart-item-details">
                                        <div class="cart-item-name">${item.nombre}</div>
                                        <div class="cart-item-price">S/ ${parseFloat(item.precio).toFixed(2)}</div>
                                        <div class="cart-item-quantity">
                                            <button class="quantity-btn decrease-btn" 
                                                    data-producto="${item.id_producto}">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <input type="number" 
                                                   class="quantity-input" 
                                                   value="${item.cantidad}" 
                                                   min="1" 
                                                   max="${item.stock}"
                                                   data-producto="${item.id_producto}">
                                            <button class="quantity-btn increase-btn" 
                                                    data-producto="${item.id_producto}">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                        <button class="remove-item" data-producto="${item.id_producto}">
                                            <i class="fas fa-trash"></i> Eliminar
                                        </button>
                                    </div>
                                </div>
                            `;
                        });
                        
                        cartContent.html(html);
                        cartTotal.text('S/ ' + total.toFixed(2));
                        checkoutBtn.prop('disabled', false);
                        
                        // Agregar event listeners
                        attachCartEventListeners();
                    } else {
                        cartContent.html(`
                            <div class="empty-cart-message">
                                <i class="fas fa-shopping-cart"></i>
                                <h4>Tu carrito está vacío</h4>
                                <p>Agrega algunos productos increíbles</p>
                            </div>
                        `);
                        cartTotal.text('S/ 0.00');
                        checkoutBtn.prop('disabled', true);
                    }
                },
                error: function() {
                    cartContent.html(`
                        <div class="empty-cart-message">
                            <i class="fas fa-exclamation-triangle"></i>
                            <h4>Error al cargar el carrito</h4>
                            <p>Intenta nuevamente</p>
                        </div>
                    `);
                }
            });
        }

        function attachCartEventListeners() {
            // Botones de cantidad
            $('.quantity-btn').on('click', function() {
                const productoId = $(this).data('producto');
                const input = $(`.quantity-input[data-producto="${productoId}"]`);
                let cantidad = parseInt(input.val());
                
                if ($(this).hasClass('increase-btn')) {
                    cantidad++;
                } else if ($(this).hasClass('decrease-btn')) {
                    cantidad--;
                }
                
                if (cantidad < 1) cantidad = 1;
                input.val(cantidad);
                updateCartItem(productoId, cantidad);
            });

            // Cambio directo en input
            $('.quantity-input').on('change', function() {
                const productoId = $(this).data('producto');
                let cantidad = parseInt($(this).val());
                
                if (cantidad < 1) cantidad = 1;
                $(this).val(cantidad);
                updateCartItem(productoId, cantidad);
            });

            // Eliminar producto
            $('.remove-item').on('click', function() {
                const productoId = $(this).data('producto');
                if (confirm('¿Eliminar este producto del carrito?')) {
                    removeCartItem(productoId);
                }
            });
        }

        // Actualizar cantidad de producto
        function updateCartItem(productoId, cantidad) {
            $.post('/index.php?action=actualizar_carrito', {
                id_producto: productoId,
                cantidad: cantidad
            }, function(response) {
                try {
                    const data = JSON.parse(response);
                    if (data.success) {
                        loadCart();
                    } else {
                        alert(data.message || 'Error al actualizar el carrito');
                        loadCart();
                    }
                } catch (e) {
                    alert('Error de conexión');
                    loadCart();
                }
            }).fail(function() {
                alert('Error de conexión. Intenta nuevamente.');
                loadCart();
            });
        }

        // Eliminar producto del carrito
        function removeCartItem(productoId) {
            $.post('/index.php?action=eliminar_carrito', {
                id_producto: productoId
            }, function(response) {
                try {
                    const data = JSON.parse(response);
                    if (data.success) {
                        loadCart();
                    } else {
                        alert(data.message || 'Error al eliminar el producto');
                    }
                } catch (e) {
                    alert('Error de conexión');
                }
            }).fail(function() {
                alert('Error de conexión. Intenta nuevamente.');
            });
        }

        // Botón de checkout
        checkoutBtn.on('click', function() {
            window.location.href = '/index.php?action=carrito';
        });

        // Prevenir que el clic en el carrito lateral cierre el sidebar
        cartSidebar.on('click', function(e) {
            e.stopPropagation();
        });
    });
    </script>
    <?php endif; ?>