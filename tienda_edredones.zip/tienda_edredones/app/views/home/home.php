<?php
// app/views/home.php

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Obtener configuraciones dinámicas para la página de inicio
$configuraciones_home = [];
try {
    require_once 'app/config/database.php';
    require_once 'app/controllers/ConfiguracionController.php';

    $database = new Database();
    $db = $database->getConnection();
    $configController = new ConfiguracionController();
    $configuraciones_home = $configController->obtenerConfiguraciones();

} catch (Exception $e) {
    error_log("Error cargando configuraciones del home: " . $e->getMessage());
    // Configuraciones por defecto en caso de error
    $configuraciones_home = [
        'caracteristicas_titulo' => 'Características Premium',
        'caracteristicas_subtitulo' => 'Nuestros edredones están diseñados pensando en tu comodidad y bienestar',
        'caracteristica_1_titulo' => 'Regulación Térmica',
        'caracteristica_1_descripcion' => 'Mantén la temperatura ideal durante toda la noche con nuestra tecnología de regulación térmica avanzada.',
        'caracteristica_2_titulo' => 'Transpirabilidad',
        'caracteristica_2_descripcion' => 'Materiales que permiten la circulación del aire para una experiencia de sueño fresca y cómoda.',
        'caracteristica_3_titulo' => 'Materiales Naturales',
        'caracteristica_3_descripcion' => 'Fabricados con materiales 100% naturales y sostenibles para tu salud y el medio ambiente.',
        'caracteristica_4_titulo' => 'Hipoalergénico',
        'caracteristica_4_descripcion' => 'Protección contra alérgenos para un descanso seguro, especialmente para personas sensibles.',
        'testimonios_titulo' => 'Lo que dicen nuestros clientes',
        'testimonios_subtitulo' => 'Descubre las experiencias de quienes ya han transformado sus noches con nuestros productos',
        'testimonio_1_texto' => 'Como persona alérgica, siempre he tenido problemas para encontrar ropa de cama adecuada. Estos edredones hipoalergénicos han cambiado mi vida.',
        'testimonio_1_autor' => 'Laura Martínez',
        'testimonio_2_texto' => 'Desde que compré el edredón de invierno, mis noches son mucho más cálidas y reconfortantes. La calidad es excepcional y el envío fue muy rápido.',
        'testimonio_2_autor' => 'María González'
    ];
}

// Función para verificar si un producto está en favoritos
function estaEnFavoritos($producto_id)
{
    if (!isset($_SESSION['usuario_id'])) {
        return false;
    }

    try {
        require_once 'app/config/database.php';
        require_once 'app/models/ListaDeseos.php';

        $database = new Database();
        $db = $database->getConnection();
        $listaDeseos = new ListaDeseos($db);
        return $listaDeseos->estaEnLista($_SESSION['usuario_id'], $producto_id);
    } catch (Exception $e) {
        error_log("Error verificando favoritos: " . $e->getMessage());
        return false;
    }
}

// Debug: Ver qué productos llegan
error_log("Vista home - Productos recibidos: " . (isset($productosRecientes) ? count($productosRecientes) : '0') . " productos");

// Base URL para recursos
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$base_url = $protocol . $_SERVER['HTTP_HOST'] . '/';
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - <?php echo htmlspecialchars($configuraciones_home['logo'] ?? 'Dream House'); ?></title>

    <!-- CSS Globales -->
    <link rel="stylesheet" href="<?php echo $base_url; ?>public/css/estilos.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>public/css/header.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>public/css/footer.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>public/css/home.css">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

    <!-- Estilos específicos del chatbot -->
    <style>
        /* ===== CHATBOT FLOTANTE ESTILOS ELEGANTES ===== */

        /* Botón flotante */
        #chatbot-toggle {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #916b83 0%, #a77b86 100%);
            border-radius: 50%;
            border: none;
            cursor: pointer;
            box-shadow: 0 6px 20px rgba(145, 107, 131, 0.3),
                0 0 0 4px rgba(212, 184, 167, 0.2);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        #chatbot-toggle:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 10px 25px rgba(145, 107, 131, 0.4),
                0 0 0 6px rgba(212, 184, 167, 0.3);
            background: linear-gradient(135deg, #91747bff 0%, #8b7082ff 100%);
        }

        #chatbot-toggle.active {
            background: linear-gradient(135deg, #927769ff 0%, #6b615cff 100%);
        }

        #chatbot-toggle i {
            font-size: 28px;
            color: white;
            transition: transform 0.4s ease;
        }

        #chatbot-toggle:hover i {
            transform: scale(1.1);
        }

        /* Contenedor del chatbot */
        #chatbot-container {
            position: fixed;
            bottom: 120px;
            right: 30px;
            width: 380px;
            height: 550px;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(107, 93, 85, 0.15),
                0 0 0 1px rgba(212, 184, 167, 0.2);
            z-index: 999;
            display: none;
            flex-direction: column;
            overflow: hidden;
            border: 1px solid rgba(212, 184, 167, 0.3);
            transform: translateY(20px);
            opacity: 0;
            transition: transform 0.4s ease, opacity 0.3s ease;
        }

        #chatbot-container.active {
            display: flex;
            transform: translateY(0);
            opacity: 1;
            animation: floatIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        @keyframes floatIn {
            0% {
                transform: translateY(30px) scale(0.9);
                opacity: 0;
            }

            100% {
                transform: translateY(0) scale(1);
                opacity: 1;
            }
        }

        /* Header del chatbot */
        .chatbot-header {
            background: linear-gradient(135deg, #917587ff 0%, #7c7579ff 100%);
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-radius: 20px 20px 0 0;
        }

        .chatbot-header-content {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .chatbot-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #D4B8A7 0%, #C4A99B 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .chatbot-avatar i {
            font-size: 24px;
            color: #5A4D47;
        }

        .chatbot-info h3 {
            margin: 0;
            color: white;
            font-size: 1.2rem;
            font-weight: 600;
        }

        .chatbot-info p {
            margin: 3px 0 0;
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.85rem;
        }

        #chatbot-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 5px;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        #chatbot-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        /* Área de mensajes */
        .chatbot-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #ffffffff;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        /* Estilos de scrollbar */
        .chatbot-messages::-webkit-scrollbar {
            width: 6px;
        }

        .chatbot-messages::-webkit-scrollbar-track {
            background: rgba(212, 184, 167, 0.1);
            border-radius: 3px;
        }

        .chatbot-messages::-webkit-scrollbar-thumb {
            background: rgba(140, 107, 90, 0.3);
            border-radius: 3px;
        }

        .chatbot-messages::-webkit-scrollbar-thumb:hover {
            background: rgba(140, 107, 90, 0.5);
        }

        /* Mensajes */
        .chat-message {
            max-width: 80%;
            padding: 12px 16px;
            border-radius: 18px;
            line-height: 1.4;
            animation: messageAppear 0.3s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            word-wrap: break-word;
        }

        @keyframes messageAppear {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .chat-message.user {
            align-self: flex-end;
            background: linear-gradient(135deg, #6e5d55ff 0%, #615853ff 100%);
            color: white;
            border-bottom-right-radius: 5px;
        }

        .chat-message.bot {
            align-self: flex-start;
            background: white;
            color: #473830ff;
            border: 1px solid rgba(97, 76, 63, 0.9);
            border-bottom-left-radius: 5px;
        }

        .chat-message.bot strong {
            color: #916b83;
            font-weight: 600;
        }

        .chat-message.bot ul,
        .chat-message.bot ol {
            padding-left: 20px;
            margin: 8px 0;
        }

        .chat-message.bot li {
            margin-bottom: 5px;
        }

        /* Área de entrada */
        .chatbot-input-area {
            padding: 20px;
            background: white;
            border-top: 1px solid rgba(212, 184, 167, 0.3);
            display: flex;
            gap: 10px;
            align-items: center;
        }

        #chatbot-input {
            flex: 1;
            padding: 14px 18px;
            border: 2px solid rgba(212, 184, 167, 0.4);
            border-radius: 50px;
            font-size: 0.95rem;
            color: #3f3028ff;
            background: #faf9f7;
            transition: all 0.3s ease;
            outline: none;
        }

        #chatbot-input:focus {
            border-color: #a77b86;
            background: white;
            box-shadow: 0 0 0 3px rgba(167, 123, 134, 0.1);
        }

        #chatbot-input::placeholder {
            color: #8A7D75;
        }

        #chatbot-send {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #916b83 0%, #a77b86 100%);
            border: none;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        #chatbot-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(145, 107, 131, 0.3);
            background: linear-gradient(135deg, #a77b86 0%, #916b83 100%);
        }

        #chatbot-send i {
            font-size: 18px;
        }

        /* Indicador de escritura */
        .typing-indicator {
            display: none;
            align-items: center;
            gap: 5px;
            padding: 10px 15px;
            background: white;
            border-radius: 18px;
            border: 1px solid rgba(212, 184, 167, 0.4);
            align-self: flex-start;
            margin-bottom: 10px;
        }

        .typing-indicator.active {
            display: flex;
        }

        .typing-dot {
            width: 8px;
            height: 8px;
            background: #C4A99B;
            border-radius: 50%;
            animation: typingAnimation 1.4s infinite ease-in-out;
        }

        .typing-dot:nth-child(1) {
            animation-delay: -0.32s;
        }

        .typing-dot:nth-child(2) {
            animation-delay: -0.16s;
        }

        @keyframes typingAnimation {

            0%,
            80%,
            100% {
                transform: scale(0);
            }

            40% {
                transform: scale(1);
            }
        }

        /* Sugerencias rápidas */
        .chatbot-suggestions {
            padding: 15px 20px;
            background: rgba(212, 184, 167, 0.1);
            border-top: 1px solid rgba(212, 184, 167, 0.2);
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .suggestion-chip {
            padding: 8px 16px;
            background: white;
            border: 1px solid rgba(109, 82, 103, 0.73);
            border-radius: 50px;
            font-size: 0.85rem;
            color: #6e4b5fff;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .suggestion-chip:hover {
            background: #886c7dff;
            color: white;
            border-color: #816577ff;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(145, 107, 131, 0.2);
        }

        /* Responsive */
        @media (max-width: 480px) {
            #chatbot-container {
                width: calc(100vw - 40px);
                height: 65vh;
                right: 20px;
                bottom: 100px;
            }

            #chatbot-toggle {
                width: 60px;
                height: 60px;
                right: 20px;
                bottom: 20px;
            }

            .chatbot-header {
                padding: 15px;
            }

            .chatbot-avatar {
                width: 45px;
                height: 45px;
            }
        }

        /* Estilos para notificaciones del carrito */
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }

            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }

            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        .cart-notification .notification-icon {
            font-weight: bold;
            font-size: 1.2em;
        }

        .no-products {
            grid-column: 1 / -1;
            text-align: center;
            padding: 40px 20px;
            background: #f8f9fa;
            border-radius: 10px;
            border: 2px dashed #dee2e6;
        }

        .no-products i {
            font-size: 3rem;
            color: #6c757d;
            margin-bottom: 1rem;
        }

        .no-products h4 {
            color: #495057;
            margin-bottom: 0.5rem;
        }

        .no-products p {
            color: #6c757d;
            margin-bottom: 1.5rem;
        }
    </style>
</head>

<body>
    <?php include 'app/views/layout/header.php'; ?>

    <!-- Hero Section con Carrusel Dinámico -->
    <section class="hero-carrusel">
        <div class="carrusel-container">
            <div class="carrusel-slides">
                <?php
                // Obtener imágenes del carrusel desde la base de datos
                try {
                    require_once 'app/config/database.php';
                    require_once 'app/models/Carrusel.php';

                    $database = new Database();
                    $db = $database->getConnection();
                    $carruselModel = new Carrusel($db);
                    $imagenesCarrusel = $carruselModel->obtenerActivos();

                    if (empty($imagenesCarrusel)) {
                        // Imagen por defecto si no hay carrusel configurado
                        echo '
                        <div class="carrusel-slide active">
                            <div class="slide-image" style="background-image: url(' . $base_url . 'public/img/cama.webp)"></div>
                            <div class="slide-overlay"></div>
                            <div class="slide-content">
                                <h1>La Comodidad Perfecta Para Tus<br><span class="highlight">Noches</span></h1>
                                <p>Descubre nuestra colección premium de edredones diseñados para ofrecerte el máximo confort y calidad en cada descanso.</p>
                                <div class="hero-buttons">
                                    <a href="' . $base_url . 'index.php?action=productos" class="btn-primary">Ver Colección</a>
                                    <a href="' . $base_url . 'index.php?action=nosotros" class="btn-secondary">Conoce Más</a>
                                </div>
                            </div>
                        </div>';
                    } else {
                        foreach ($imagenesCarrusel as $index => $imagen) {
                            $active = $index === 0 ? 'active' : '';
                            echo '
                            <div class="carrusel-slide ' . $active . '">
                                <div class="slide-image" style="background-image: url(' . $base_url . 'public/img/carrusel/' . htmlspecialchars($imagen['imagen_url']) . ')"></div>
                                <div class="slide-overlay"></div>
                                <div class="slide-content">
                                    <h1>' . htmlspecialchars($imagen['titulo']) . '</h1>
                                    <p>' . htmlspecialchars($imagen['subtitulo']) . '</p>
                                    <div class="hero-buttons">
                                        <a href="' . $base_url . 'index.php?action=productos" class="btn-primary">Ver Colección</a>
                                        <a href="' . $base_url . 'index.php?action=nosotros" class="btn-secondary">Conoce Más</a>
                                    </div>
                                </div>
                            </div>';
                        }
                    }
                } catch (Exception $e) {
                    // Fallback en caso de error
                    echo '
                    <div class="carrusel-slide active">
                        <div class="slide-image" style="background-image: url(' . $base_url . 'public/img/cama.webp)"></div>
                        <div class="slide-overlay"></div>
                        <div class="slide-content">
                            <h1>La Comodidad Perfecta Para Tus<br><span class="highlight">Noches</span></h1>
                            <p>Descubre nuestra colección premium de edredones diseñados para ofrecerte el máximo confort y calidad en cada descanso.</p>
                            <div class="hero-buttons">
                                <a href="' . $base_url . 'index.php?action=productos" class="btn-primary">Ver Colección</a>
                                <a href="' . $base_url . 'index.php?action=nosotros" class="btn-secondary">Conoce Más</a>
                            </div>
                        </div>
                    </div>';
                }
                ?>
            </div>

            <!-- Controles del carrusel -->
            <div class="carrusel-controls">
                <button class="carrusel-prev">‹</button>
                <button class="carrusel-next">›</button>
            </div>

            <!-- Indicadores -->
            <div class="carrusel-indicators">
                <?php
                if (!empty($imagenesCarrusel)) {
                    foreach ($imagenesCarrusel as $index => $imagen) {
                        $active = $index === 0 ? 'active' : '';
                        echo '<span class="indicator ' . $active . '" data-slide="' . $index . '"></span>';
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Collection Section con productos dinámicos -->
    <section class="collection section-animate">
        <div class="container">
            <h2 class="fade-in-up">Nuestros Productos Destacados</h2>
            <div class="divider fade-in-up" style="animation-delay: 0.1s;"></div>
            <p class="section-subtitle fade-in-up" style="animation-delay: 0.2s;">Descubre los productos más recientes
                agregados a nuestra tienda</p>

            <div class="products-grid">
                <?php if (!empty($productosRecientes) && is_array($productosRecientes)): ?>
                    <?php foreach ($productosRecientes as $index => $producto):
                        // Verificar si está en favoritos
                        $enFavoritos = false;
                        if (isset($_SESSION['usuario_id'])) {
                            $enFavoritos = estaEnFavoritos($producto['id_producto']);
                        }

                        // Validar que el producto tenga ID
                        if (empty($producto['id_producto'])) {
                            error_log("ERROR: Producto sin ID en home.php: " . print_r($producto, true));
                            continue; // Saltar este producto
                        }
                        ?>
                        <div class="product-card fade-in-up" style="animation-delay: <?php echo ($index % 6) * 0.1 + 0.3; ?>s;">
                            <div class="product-badge">
                                <?php
                                // Mostrar categoría como badge
                                echo htmlspecialchars($producto['nombre_categoria'] ?? $producto['categoria'] ?? 'Producto');
                                ?>
                            </div>

                            <div class="product-image"
                                onclick="window.location.href='<?php echo $base_url; ?>index.php?action=detalle_producto&id=<?php echo $producto['id_producto']; ?>'">
                                <?php if (!empty($producto['imagen_principal'])): ?>
                                    <img src="<?php echo $base_url; ?>public/img/productos/<?php echo htmlspecialchars($producto['imagen_principal']); ?>"
                                        alt="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                        onerror="this.src='<?php echo $base_url; ?>public/img/edredonfondo.png'">
                                <?php else: ?>
                                    <img src="<?php echo $base_url; ?>public/img/edredonfondo.png"
                                        alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                                <?php endif; ?>
                            </div>

                            <h3
                                onclick="window.location.href='<?php echo $base_url; ?>index.php?action=detalle_producto&id=<?php echo $producto['id_producto']; ?>'">
                                <?php echo htmlspecialchars($producto['nombre']); ?>
                            </h3>

                            <!-- Información adicional del producto -->
                            <div class="product-meta">
                                <?php if (!empty($producto['material'])): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-tag"></i>
                                        <span class="meta-text"><?php echo htmlspecialchars($producto['material']); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($producto['color'])): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-palette"></i>
                                        <span class="meta-text"><?php echo htmlspecialchars($producto['color']); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($producto['medida'])): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-ruler"></i>
                                        <span class="meta-text"><?php echo htmlspecialchars($producto['medida']); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Precio y Rating juntos -->
                            <div class="price-rating">
                                <div class="price">
                                    <span class="current-price">S/ <?php echo number_format($producto['precio'], 2); ?></span>
                                    <?php if (isset($producto['precio_anterior']) && $producto['precio_anterior'] > $producto['precio']): ?>
                                        <span class="old-price">S/
                                            <?php echo number_format($producto['precio_anterior'], 2); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                </div>
                            </div>

                            <div class="product-actions" onclick="event.stopPropagation()">
                                <button class="btn-add-to-cart" data-product-id="<?php echo $producto['id_producto']; ?>"
                                    data-product-name="<?php echo htmlspecialchars($producto['nombre']); ?>">
                                    <i class="fas fa-shopping-cart"></i> Agregar
                                </button>
                                <a href="<?php echo $base_url; ?>index.php?action=<?php echo $enFavoritos ? 'eliminar_deseo' : 'agregar_deseo'; ?>&id=<?php echo $producto['id_producto']; ?>"
                                    class="btn-favorites <?php echo $enFavoritos ? 'in-favorites' : ''; ?>">
                                    <i class="<?php echo $enFavoritos ? 'fas' : 'far'; ?> fa-heart"></i>
                                    <?php echo $enFavoritos ? 'Mi Favorito' : 'Favorito'; ?>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Mensaje cuando no hay productos -->
                    <div class="no-products">
                        <i class="fas fa-box-open"></i>
                        <h4>No hay productos disponibles</h4>
                        <p>Pronto agregaremos nuevos productos a nuestra tienda.</p>
                        <a href="<?php echo $base_url; ?>index.php?action=productos" class="btn-primary">
                            Ver Todos los Productos
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Botón para ver todos los productos -->
            <div class="text-center fade-in-up" style="margin-top: 3rem; animation-delay: 0.8s;">
                <a href="<?php echo $base_url; ?>index.php?action=productos" class="btn-primary">Ver Todos los
                    Productos</a>
            </div>
        </div>
    </section>

    <!-- Premium Features Section - ACTUALIZADO CON CONFIGURACIONES DINÁMICAS -->
    <section class="premium-features section-animate">
        <div class="container">
            <h3 class="fade-in-up">
                <?php echo htmlspecialchars($configuraciones_home['caracteristicas_titulo'] ?? 'Características Premium'); ?>
            </h3>
            <div class="divider fade-in-up" style="animation-delay: 0.1s;"></div>
            <p class="section-subtitle fade-in-up" style="animation-delay: 0.2s;">
                <?php echo htmlspecialchars($configuraciones_home['caracteristicas_subtitulo'] ?? 'Nuestros edredones están diseñados pensando en tu comodidad y bienestar'); ?>
            </p>
            <div class="features-grid">
                <div class="feature-item fade-in-up" style="animation-delay: 0.3s;">
                    <i class="fas fa-thermometer-half"></i>
                    <h4><?php echo htmlspecialchars($configuraciones_home['caracteristica_1_titulo'] ?? 'Regulación Térmica'); ?>
                    </h4>
                    <p><?php echo htmlspecialchars($configuraciones_home['caracteristica_1_descripcion'] ?? 'Mantén la temperatura ideal durante toda la noche con nuestra tecnología de regulación térmica avanzada.'); ?>
                    </p>
                </div>
                <div class="feature-item fade-in-up" style="animation-delay: 0.4s;">
                    <i class="fas fa-wind"></i>
                    <h4><?php echo htmlspecialchars($configuraciones_home['caracteristica_2_titulo'] ?? 'Transpirabilidad'); ?>
                    </h4>
                    <p><?php echo htmlspecialchars($configuraciones_home['caracteristica_2_descripcion'] ?? 'Materiales que permiten la circulación del aire para una experiencia de sueño fresca y cómoda.'); ?>
                    </p>
                </div>
                <div class="feature-item fade-in-up" style="animation-delay: 0.5s;">
                    <i class="fas fa-leaf"></i>
                    <h4><?php echo htmlspecialchars($configuraciones_home['caracteristica_3_titulo'] ?? 'Materiales Naturales'); ?>
                    </h4>
                    <p><?php echo htmlspecialchars($configuraciones_home['caracteristica_3_descripcion'] ?? 'Fabricados con materiales 100% naturales y sostenibles para tu salud y el medio ambiente.'); ?>
                    </p>
                </div>
                <div class="feature-item fade-in-up" style="animation-delay: 0.6s;">
                    <i class="fas fa-shield-alt"></i>
                    <h4><?php echo htmlspecialchars($configuraciones_home['caracteristica_4_titulo'] ?? 'Hipoalergénico'); ?>
                    </h4>
                    <p><?php echo htmlspecialchars($configuraciones_home['caracteristica_4_descripcion'] ?? 'Protección contra alérgenos para un descanso seguro, especialmente para personas sensibles.'); ?>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section - ACTUALIZADO CON CONFIGURACIONES DINÁMICAS -->
    <section class="testimonials section-animate">
        <div class="container">
            <h3 class="fade-in-up">
                <?php echo htmlspecialchars($configuraciones_home['testimonios_titulo'] ?? 'Lo que dicen nuestros clientes'); ?>
            </h3>
            <div class="divider fade-in-up" style="animation-delay: 0.1s;"></div>
            <p class="section-subtitle fade-in-up" style="animation-delay: 0.2s;">
                <?php echo htmlspecialchars($configuraciones_home['testimonios_subtitulo'] ?? 'Descubre las experiencias de quienes ya han transformado sus noches con nuestros productos'); ?>
            </p>
            <div class="testimonials-grid">
                <div class="testimonial-card fade-in-up" style="animation-delay: 0.3s;">
                    <div class="testimonial-content">
                        <p class="testimonial-text">
                            "<?php echo htmlspecialchars($configuraciones_home['testimonio_1_texto'] ?? 'Como persona alérgica, siempre he tenido problemas para encontrar ropa de cama adecuada. Estos edredones hipoalergénicos han cambiado mi vida.'); ?>"
                        </p>
                        <div class="testimonial-author">
                            <strong>–
                                <?php echo htmlspecialchars($configuraciones_home['testimonio_1_autor'] ?? 'Laura Martínez'); ?></strong>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card fade-in-up" style="animation-delay: 0.4s;">
                    <div class="testimonial-content">
                        <p class="testimonial-text">
                            "<?php echo htmlspecialchars($configuraciones_home['testimonio_2_texto'] ?? 'Desde que compré el edredón de invierno, mis noches son mucho más cálidas y reconfortantes. La calidad es excepcional y el envío fue muy rápido.'); ?>"
                        </p>
                        <div class="testimonial-author">
                            <strong>–
                                <?php echo htmlspecialchars($configuraciones_home['testimonio_2_autor'] ?? 'María González'); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'app/views/layout/footer.php'; ?>

    <!-- CHATBOT ELEGANTE Y MODERNO -->
    <div id="chatbot-container">
        <div class="chatbot-header">
            <div class="chatbot-header-content">
                <div class="chatbot-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="chatbot-info">
                    <h3>Dream House Bot</h3>
                    <p>Asistente virtual</p>
                </div>
            </div>
            <button id="chatbot-close">×</button>
        </div>

        <div class="chatbot-messages" id="chatbot-messages">
            <!-- Los mensajes se agregarán aquí dinámicamente -->
        </div>

        <div class="chatbot-suggestions">
            <button class="suggestion-chip" data-question="¿Qué productos tienes?">Productos</button>
            <button class="suggestion-chip" data-question="¿Cómo hago un pedido?">Pedidos</button>
            <button class="suggestion-chip" data-question="¿Cuál es el tiempo de envío?">Envíos</button>
            <button class="suggestion-chip" data-question="¿Tienen garantía?">Garantía</button>
        </div>

        <div class="chatbot-input-area">
            <input type="text" id="chatbot-input" placeholder="Escribe tu mensaje...">
            <button id="chatbot-send">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>

    <button id="chatbot-toggle">
        <i class="fas fa-comment-dots"></i>
    </button>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo $base_url; ?>public/js/carrusel.js"></script>

    <!-- Script principal -->
    <script>
        $(document).ready(function () {
            // Pasar variable PHP a JavaScript
            const usuarioLogueado = <?php echo isset($_SESSION['usuario_id']) ? 'true' : 'false'; ?>;
            const baseUrl = '<?php echo $base_url; ?>';

            // Funcionalidad para agregar al carrito (EXISTENTE - SIN CAMBIOS)
            $('.btn-add-to-cart').on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();

                const productId = $(this).data('product-id');
                const productName = $(this).data('product-name');

                console.log('Producto ID:', productId, 'Nombre:', productName);

                // Validar ID
                if (!productId || productId <= 0) {
                    console.error('ID de producto inválido:', productId);
                    alert('Error: No se pudo obtener el ID del producto.');
                    return;
                }

                if (usuarioLogueado) {
                    agregarAlCarrito(productId, productName);
                } else {
                    alert('Debes iniciar sesión para agregar productos al carrito');
                    window.location.href = baseUrl + 'index.php?action=login';
                }
            });

            // Función para agregar producto al carrito
            function agregarAlCarrito(productId, productName) {
                console.log('Agregando al carrito producto ID:', productId);

                $.ajax({
                    url: baseUrl + 'index.php?action=agregar_carrito',
                    type: 'POST',
                    data: {
                        id_producto: productId,
                        cantidad: 1
                    },
                    success: function (response) {
                        console.log('Respuesta del servidor:', response);
                        try {
                            const data = typeof response === 'string' ? JSON.parse(response) : response;

                            if (data.success) {
                                // Mostrar mensaje de éxito
                                mostrarNotificacion('success', 'Producto agregado al carrito');

                                // Actualizar contador del carrito en el header
                                if (data.total_items !== undefined) {
                                    $('.cart-count').text(data.total_items);
                                }

                                // Si el carrito sidebar está abierto, recargarlo
                                if ($('#cartSidebar').hasClass('active') && typeof window.loadCart === 'function') {
                                    window.loadCart();
                                }
                            } else {
                                mostrarNotificacion('error', data.message || 'Error al agregar producto');
                            }
                        } catch (e) {
                            console.error('Error parsing JSON:', e, 'Response:', response);
                            mostrarNotificacion('error', 'Error al procesar la respuesta');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('Error AJAX:', error);
                        mostrarNotificacion('error', 'Error de conexión al servidor');
                    }
                });
            }

            // Función para mostrar notificaciones
            function mostrarNotificacion(tipo, mensaje) {
                // Eliminar notificaciones anteriores
                $('.cart-notification').remove();

                const clase = tipo === 'success' ? 'success' : 'error';

                const notificacion = $('<div class="cart-notification ' + clase + '">' +
                    '<span class="notification-text">' + mensaje + '</span>' +
                    '</div>');

                $('body').append(notificacion);

                // Mostrar con animación
                notificacion.css({
                    position: 'fixed',
                    top: '20px',
                    right: '20px',
                    padding: '15px 25px',
                    background: tipo === 'success' ? '#8f6e81ff' : '#8f6e81ff',
                    color: tipo === 'success' ? '#ffffffff' : '#ffffffff',
                    border: '1px solid ' + (tipo === 'success' ? '#8f6e81ff' : '#8f6e81ff'),
                    borderRadius: '8px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                    zIndex: '10000',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    minWidth: '250px',
                    animation: 'slideInRight 0.3s ease',
                    fontWeight: '500',
                    fontSize: '16px',
                    textAlign: 'center'
                });

                // Ocultar después de 3 segundos
                setTimeout(() => {
                    notificacion.css('animation', 'slideOutRight 0.3s ease');
                    setTimeout(() => notificacion.remove(), 300);
                }, 3000);
            }

            // Animación al hacer scroll (EXISTENTE - SIN CAMBIOS)
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate-in');
                    }
                });
            }, observerOptions);

            // Observar elementos con animaciones
            document.querySelectorAll('.section-animate, .fade-in-up').forEach(el => {
                observer.observe(el);
            });

            // Funcionalidad para hacer click en toda la tarjeta (EXISTENTE - SIN CAMBIOS)
            $('.product-card').on('click', function (e) {
                // Evitar que se active cuando se hace clic en los botones
                if (!$(e.target).closest('.product-actions').length &&
                    !$(e.target).closest('.product-image').length &&
                    !$(e.target).is('h3')) {
                    const productId = $(this).find('.btn-add-to-cart').data('product-id');
                    if (productId) {
                        window.location.href = baseUrl + 'index.php?action=detalle_producto&id=' + productId;
                    }
                }
            });

            // ============================================
            // FUNCIONALIDAD DEL CHATBOT ELEGANTE
            // ============================================

            // Elementos del chatbot
            const toggleBtn = document.getElementById('chatbot-toggle');
            const chatbot = document.getElementById('chatbot-container');
            const closeBtn = document.getElementById('chatbot-close');
            const sendBtn = document.getElementById('chatbot-send');
            const input = document.getElementById('chatbot-input');
            const messages = document.getElementById('chatbot-messages');

            // Inicializar chatbot si existen los elementos
            if (toggleBtn && chatbot && closeBtn && sendBtn && input && messages) {
                console.log('✅ Chatbot cargado correctamente');

                // Mostrar/ocultar chatbot con animación
                toggleBtn.addEventListener('click', () => {
                    chatbot.classList.toggle('active');
                    toggleBtn.classList.toggle('active');

                    if (chatbot.classList.contains('active')) {
                        input.focus();
                        // Mostrar mensaje de bienvenida si es la primera vez
                        if (messages.children.length === 0) {
                            setTimeout(() => {
                                addChatMessage('¡Hola! Soy Dream Bot, tu asistente virtual de Dream House. 😊<br><br>Estoy aquí para ayudarte con información sobre nuestros productos, pedidos, envíos y más. ¿En qué puedo asistirte hoy?', 'bot welcome');
                            }, 300);
                        }
                    }
                });

                // Cerrar chatbot
                closeBtn.addEventListener('click', () => {
                    chatbot.classList.remove('active');
                    toggleBtn.classList.remove('active');
                });

                // Enviar mensaje con botón
                sendBtn.addEventListener('click', sendChatMessage);

                // Enviar mensaje con Enter
                input.addEventListener('keypress', e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        sendChatMessage();
                    }
                });

                // Sugerencias rápidas
                document.querySelectorAll('.suggestion-chip').forEach(chip => {
                    chip.addEventListener('click', () => {
                        const question = chip.getAttribute('data-question');
                        input.value = question;
                        sendChatMessage();
                    });
                });

                // Función para agregar mensaje al chat
                function addChatMessage(text, type) {
                    const div = document.createElement('div');
                    div.className = `chat-message ${type}`;

                    // Usar innerHTML para permitir etiquetas HTML de la respuesta del bot
                    div.innerHTML = text;

                    messages.appendChild(div);
                    messages.scrollTop = messages.scrollHeight;

                    // Animar la entrada
                    setTimeout(() => {
                        div.style.animation = 'messageAppear 0.3s ease';
                    }, 10);
                }

                // Función para mostrar indicador de "escribiendo"
                function showTypingIndicator() {
                    const typingDiv = document.createElement('div');
                    typingDiv.className = 'typing-indicator active';
                    typingDiv.innerHTML = `
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                    <span class="typing-dot"></span>
                `;
                    messages.appendChild(typingDiv);
                    messages.scrollTop = messages.scrollHeight;
                    return typingDiv;
                }

                // Función para enviar mensaje
                async function sendChatMessage() {
                    const text = input.value.trim();
                    if (!text) return;

                    // Agregar mensaje del usuario
                    addChatMessage(text, 'user');
                    input.value = '';

                    // Mostrar indicador de "escribiendo"
                    const typingDiv = showTypingIndicator();

                    try {
                        // Enviar al backend
                        const response = await fetch(baseUrl + 'public/api/chatbot.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'Accept': 'application/json'
                            },
                            body: JSON.stringify({
                                message: text,
                                timestamp: new Date().toISOString()
                            })
                        });

                        // Remover indicador de "escribiendo"
                        if (typingDiv.parentNode) {
                            typingDiv.remove();
                        }

                        if (!response.ok) {
                            throw new Error(`Error HTTP: ${response.status}`);
                        }

                        const data = await response.json();

                        if (data.reply) {
                            addChatMessage(data.reply, 'bot');
                        } else if (data.error) {
                            addChatMessage(`Lo siento, hubo un error: ${data.error}`, 'bot');
                        } else {
                            addChatMessage('Lo siento, no pude procesar tu pregunta. ¿Podrías intentarlo de nuevo?', 'bot');
                        }

                    } catch (error) {
                        console.error('Error en chatbot:', error);

                        // Remover indicador de "escribiendo"
                        if (typingDiv.parentNode) {
                            typingDiv.remove();
                        }

                        addChatMessage('⚠️ Error de conexión. Por favor, verifica tu conexión a internet e intenta nuevamente.', 'bot');
                    }
                }

            } else {
                console.error('❌ Error: No se encontraron todos los elementos del chatbot');
            }

            // Cerrar chatbot al hacer clic fuera de él
            document.addEventListener('click', function (event) {
                if (chatbot && chatbot.classList.contains('active') &&
                    !chatbot.contains(event.target) &&
                    event.target !== toggleBtn &&
                    !toggleBtn.contains(event.target)) {
                    chatbot.classList.remove('active');
                    toggleBtn.classList.remove('active');
                }
            });

            // Prevenir que el clic dentro del chatbot cierre el mismo
            chatbot.addEventListener('click', function (event) {
                event.stopPropagation();
            });
        });
    </script>
</body>

</html>