<h2>Agregar Nuevo Producto</h2>
<form action="index.php?action=agregar_producto" method="POST" enctype="multipart/form-data">
    <label>Nombre:</label>
    <input type="text" name="nombre" required>

    <label>Categoría:</label>
    <select name="categoria" required>
        <option value="Sábanas">Sábanas</option>
        <option value="Edredón Reversible">Edredón Reversible</option>
        <option value="Edredón con Sherpa">Edredón con Sherpa</option>
        <option value="Cubrecamas">Cubrecamas</option>
    </select>

    <label>Precio:</label>
    <input type="number" step="0.01" name="precio" required>

    <label>Precio Oferta (opcional):</label>
    <input type="number" step="0.01" name="precio_oferta">

    <label>Descripción:</label>
    <textarea name="descripcion"></textarea>

    <label>Imagen:</label>
    <input type="file" name="imagen">

    <label>Estado:</label>
    <select name="estado">
        <option value="1">Activo</option>
        <option value="0">Inactivo</option>
    </select>

    <button type="submit" class="btn-guardar">Guardar</button>
</form>
