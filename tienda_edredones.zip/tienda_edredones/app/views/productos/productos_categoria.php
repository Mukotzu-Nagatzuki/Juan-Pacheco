<?php
// app/views/productos/producto_categoria.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/funciones.php';

// Verificar si el usuario está logueado para la funcionalidad de favoritos
if (session_status() === PHP_SESSION_NONE)
    session_start();
$usuario_id = $_SESSION['usuario_id'] ?? null;

// Función para verificar si un producto está en favoritos (MISMA LÓGICA QUE HOME)
function estaEnFavoritos($producto_id)
{
    if (session_status() === PHP_SESSION_NONE)
        session_start();
    if (!isset($_SESSION['usuario_id']))
        return false;

    require_once 'app/config/database.php';
    require_once 'app/models/ListaDeseos.php';

    try {
        $database = new Database();
        $db = $database->getConnection();
        $listaDeseos = new ListaDeseos($db);
        return $listaDeseos->estaEnLista($_SESSION['usuario_id'], $producto_id);
    } catch (Exception $e) {
        return false;
    }
}

$titulo = $categoria_nombre ?? "Categoría";
$descripcion = "Descubre nuestra colección de " . strtolower($categoria_nombre ?? "productos");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo) ?> - Dream House</title>
    <link rel="stylesheet" href="public/css/home.css">
    <link rel="stylesheet" href="public/css/estilos.css">
    <link rel="stylesheet" href="public/css/categoria.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/../layout/header.php'; ?>

    <!-- Filtros Section -->
    <section class="filters-section section-animate">
        <div class="container">
            <div class="filtros-header">
                <h3 class="filtros-titulo">Filtrar Productos</h3>
            </div>
            <div class="filter-options">
                <div class="filter-group">
                    <label for="filter-order" class="filter-label">Ordenar por:</label>
                    <select id="filter-order" class="filter-select">
                        <option value="newest">Más recientes</option>
                        <option value="price-low">Precio: Menor a Mayor</option>
                        <option value="price-high">Precio: Mayor a Menor</option>
                        <option value="name">Orden A-Z</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-stock" class="filter-label">Estado de stock:</label>
                    <select id="filter-stock" class="filter-select">
                        <option value="all">Todos los productos</option>
                        <option value="in-stock">En stock</option>
                        <option value="low-stock">Poco stock</option>
                        <option value="out-of-stock">Agotados</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label class="filter-label">&nbsp;</label>
                    <button class="btn-reset-filters" onclick="resetearFiltros()">
                        <i class="fas fa-undo"></i> Resetear
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Productos Section con diseño del home -->
    <section id="productos-section" class="collection section-animate">
        <div class="container">
            <h2 class="fade-in-up">Productos de <?= htmlspecialchars($titulo) ?></h2>
            <div class="divider fade-in-up" style="animation-delay: 0.1s;"></div>
            <p class="section-subtitle fade-in-up" style="animation-delay: 0.2s;">
                Encuentra los mejores productos en esta categoría
            </p>

            <div class="results-info fade-in-up" style="animation-delay: 0.3s;">
                <span id="contador-filtrado">Mostrando <?= count($productos) ?> producto(s)</span>
            </div>

            <?php if (empty($productos)): ?>
                <div class="no-products fade-in-up">
                    <i class="fas fa-box-open" style="font-size: 4rem; margin-bottom: 1.5rem; color: #C4A99B;"></i>
                    <h3>No hay productos en esta categoría</h3>
                    <p>Pronto agregaremos nuevos productos. <a href="index.php?action=productos">Ver todos los productos</a></p>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($productos as $index => $producto): 
                        // Verificar si está en favoritos (MISMA LÓGICA QUE HOME)
                        $enFavoritos = false;
                        if (isset($_SESSION['usuario_id'])) {
                            $enFavoritos = estaEnFavoritos($producto['id_producto']);
                        }
                    ?>
                        <div class="product-card fade-in-up" 
                             style="animation-delay: <?= ($index % 6) * 0.1 + 0.4 ?>s;"
                             data-price="<?= $producto['precio'] ?>" 
                             data-stock="<?= $producto['stock'] ?>"
                             data-name="<?= htmlspecialchars($producto['nombre']) ?>">
                            
                            <!-- Badge de categoría -->
                            <div class="product-badge">
                                <?= htmlspecialchars($producto['categoria'] ?? 'Producto') ?>
                            </div>

                            <!-- Badges de stock -->
                            <?php if ($producto['stock'] <= 0): ?>
                                <div class="out-of-stock-badge">Agotado</div>
                            <?php elseif ($producto['stock'] < 10): ?>
                                <div class="low-stock-badge">Últimas unidades</div>
                            <?php endif; ?>

                            <!-- Imagen del producto -->
                            <div class="product-image">
                                <?php if (!empty($producto['imagen_principal'])): ?>
                                    <img src="public/img/productos/<?= htmlspecialchars($producto['imagen_principal']); ?>"
                                        alt="<?= htmlspecialchars($producto['nombre']); ?>"
                                        onerror="this.src='public/img/edredonfondo.png'"
                                        onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'">
                                <?php else: ?>
                                    <img src="public/img/edredonfondo.png" 
                                         alt="<?= htmlspecialchars($producto['nombre']); ?>"
                                         onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'">
                                <?php endif; ?>
                            </div>

                            <!-- Información del producto -->
                            <div class="product-info">
                                <h3 onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                    <?= htmlspecialchars($producto['nombre']) ?>
                                </h3>

                                <!-- Meta información (material, color, medida) -->
                                <div class="product-meta" onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                    <?php if (!empty($producto['material'])): ?>
                                        <div class="meta-item">
                                            <i class="fas fa-tag"></i>
                                            <span class="meta-text"><?= htmlspecialchars($producto['material']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($producto['color'])): ?>
                                        <div class="meta-item">
                                            <i class="fas fa-palette"></i>
                                            <span class="meta-text"><?= htmlspecialchars($producto['color']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($producto['medida'])): ?>
                                        <div class="meta-item">
                                            <i class="fas fa-ruler"></i>
                                            <span class="meta-text"><?= htmlspecialchars($producto['medida']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Precio y Stock -->
                                <div class="price-rating" onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                    <div class="price">
                                        <span class="current-price">S/ <?= number_format($producto['precio'], 2) ?></span>
                                        <?php if (isset($producto['precio_anterior']) && $producto['precio_anterior'] > $producto['precio']): ?>
                                            <span class="old-price">S/ <?= number_format($producto['precio_anterior'], 2) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="stock-info">
                                        <span class="stock-badge <?= $producto['stock'] > 10 ? 'stock-high' : ($producto['stock'] > 0 ? 'stock-medium' : 'stock-low') ?>">
                                            <?= $producto['stock'] ?> unidades
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <!-- Acciones del producto -->
                            <div class="product-actions">
                                <button class="btn-add-to-cart <?= $producto['stock'] <= 0 ? 'disabled' : '' ?>" 
                                        data-product-id="<?= $producto['id_producto'] ?>"
                                        <?= $producto['stock'] <= 0 ? 'disabled' : '' ?>>
                                    <i class="fas fa-shopping-cart"></i>
                                    <?= $producto['stock'] <= 0 ? 'Agotado' : 'Agregar' ?>
                                </button>
                                <a href="index.php?action=<?= $enFavoritos ? 'eliminar_deseo' : 'agregar_deseo'; ?>&id=<?= $producto['id_producto'] ?>" 
                                   class="btn-favorites <?= $enFavoritos ? 'in-favorites' : ''; ?>">
                                    <i class="<?= $enFavoritos ? 'fas' : 'far'; ?> fa-heart"></i>
                                    <?= $enFavoritos ? 'Mi Favorito' : 'Favorito' ?>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include __DIR__ . '/../layout/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Pasar variable PHP a JavaScript -->
    <script>
        const usuarioLogueado = <?php echo isset($_SESSION['usuario_id']) ? 'true' : 'false'; ?>;
    </script>
    
    <script src="public/js/carrito.js"></script>
    
    <script>
    // Filtros para los productos
    document.addEventListener('DOMContentLoaded', function () {
        const filterOrder = document.getElementById('filter-order');
        const filterStock = document.getElementById('filter-stock');
        const productCards = document.querySelectorAll('.product-card');
        const contadorFiltrado = document.getElementById('contador-filtrado');

        function aplicarFiltros() {
            const ordenValor = filterOrder.value;
            const stockValor = filterStock.value;
            let productosVisibles = 0;

            productCards.forEach(card => {
                let mostrar = true;

                // Filtro por stock
                const stock = parseInt(card.dataset.stock);
                if (stockValor === 'in-stock' && stock <= 0) {
                    mostrar = false;
                } else if (stockValor === 'low-stock' && (stock >= 10 || stock <= 0)) {
                    mostrar = false;
                } else if (stockValor === 'out-of-stock' && stock > 0) {
                    mostrar = false;
                }

                // Mostrar/ocultar
                if (mostrar) {
                    card.style.display = 'block';
                    productosVisibles++;
                } else {
                    card.style.display = 'none';
                }
            });

            // Actualizar contador
            actualizarContadorFiltrado(productosVisibles);

            // Ordenar productos
            if (ordenValor === 'price-low') {
                ordenarProductos('price', 'asc');
            } else if (ordenValor === 'price-high') {
                ordenarProductos('price', 'desc');
            } else if (ordenValor === 'name') {
                ordenarProductos('name', 'asc');
            } else {
                // Orden por defecto (más recientes)
                ordenarProductos('default', 'asc');
            }
        }

        function ordenarProductos(por, direccion) {
            const container = document.querySelector('.products-grid');
            const cards = Array.from(productCards).filter(card => card.style.display !== 'none');

            cards.sort((a, b) => {
                let valorA, valorB;
                
                if (por === 'price') {
                    valorA = parseFloat(a.dataset.price);
                    valorB = parseFloat(b.dataset.price);
                } else if (por === 'name') {
                    valorA = a.dataset.name.toLowerCase();
                    valorB = b.dataset.name.toLowerCase();
                } else {
                    // Orden por defecto (posición original)
                    return 0;
                }

                if (direccion === 'asc') {
                    return valorA > valorB ? 1 : -1;
                } else {
                    return valorA < valorB ? 1 : -1;
                }
            });

            // Reordenar en el DOM
            container.innerHTML = '';
            cards.forEach(card => container.appendChild(card));
        }

        function actualizarContadorFiltrado(cantidad) {
            if (contadorFiltrado) {
                contadorFiltrado.textContent = `Mostrando ${cantidad} producto(s)`;
            }
        }

        function resetearFiltros() {
            filterOrder.value = 'newest';
            filterStock.value = 'all';
            aplicarFiltros();
        }

        filterOrder.addEventListener('change', aplicarFiltros);
        filterStock.addEventListener('change', aplicarFiltros);

        // Inicializar filtros
        aplicarFiltros();

        // Animación al hacer scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observar elementos con animaciones
        document.querySelectorAll('.section-animate, .fade-in-up').forEach(el => {
            observer.observe(el);
        });
    });

    // Funcionalidad para hacer click en elementos específicos para ir al detalle
    document.querySelectorAll('.product-image img, .product-info h3, .product-meta, .price-rating').forEach(element => {
        element.style.cursor = 'pointer';
        element.addEventListener('click', function (e) {
            const productCard = this.closest('.product-card');
            const productId = productCard.querySelector('.btn-add-to-cart')?.getAttribute('data-product-id');
            if (productId) {
                window.location.href = 'index.php?action=detalle_producto&id=' + productId;
            }
        });
    });
    </script>
</body>
</html>