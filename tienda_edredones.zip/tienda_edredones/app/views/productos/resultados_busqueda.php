<?php
// app/views/productos/resultadobusqueda.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/funciones.php';

// Verificar si el usuario está logueado para la funcionalidad de favoritos
if (session_status() === PHP_SESSION_NONE)
    session_start();
$usuario_id = $_SESSION['usuario_id'] ?? null;

// Función para verificar si un producto está en favoritos (MISMA LÓGICA QUE HOME)
function estaEnFavoritos($producto_id)
{
    if (session_status() === PHP_SESSION_NONE)
        session_start();
    if (!isset($_SESSION['usuario_id']))
        return false;

    require_once 'app/config/database.php';
    require_once 'app/models/ListaDeseos.php';

    try {
        $database = new Database();
        $db = $database->getConnection();
        $listaDeseos = new ListaDeseos($db);
        return $listaDeseos->estaEnLista($_SESSION['usuario_id'], $producto_id);
    } catch (Exception $e) {
        return false;
    }
}

$titulo = "Resultados de Búsqueda";
$termino_busqueda = $_GET['q'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo) ?> - Dream House</title>
    <link rel="stylesheet" href="public/css/home.css">
    <link rel="stylesheet" href="public/css/estilos.css">
    <link rel="stylesheet" href="public/css/buscar.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/../layout/header.php'; ?>

    <!-- Productos Section con diseño del home -->
    <section id="productos-section" class="collection section-animate">
        <div class="container">
            <h2 class="fade-in-up">Productos Encontrados</h2>
            <div class="divider fade-in-up" style="animation-delay: 0.1s;"></div>
            <p class="section-subtitle fade-in-up" style="animation-delay: 0.2s;">
                Descubre los productos que coinciden con tu búsqueda
            </p>

            <?php if (empty($productos)): ?>
                <div class="no-results fade-in-up">
                    <i class="fas fa-search" style="font-size: 4rem; margin-bottom: 1.5rem; color: #C4A99B;"></i>
                    <h3>No se encontraron productos</h3>
                    <p>Intenta con otros términos de búsqueda o <a href="index.php?action=productos">ver todos los productos</a></p>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($productos as $index => $producto): 
                        // Verificar si está en favoritos (MISMA LÓGICA QUE HOME)
                        $enFavoritos = false;
                        if (isset($_SESSION['usuario_id'])) {
                            $enFavoritos = estaEnFavoritos($producto['id_producto']);
                        }
                    ?>
                        <div class="product-card fade-in-up" 
                             style="animation-delay: <?= ($index % 6) * 0.1 + 0.4 ?>s;"
                             data-categoria="<?= $producto['id_categoria'] ?>" 
                             data-precio="<?= $producto['precio'] ?>">
                            
                            <!-- Badge de categoría -->
                            <div class="product-badge">
                                <?= htmlspecialchars($producto['categoria_nombre'] ?? $producto['categoria'] ?? 'Producto') ?>
                            </div>

                            <!-- Imagen del producto -->
                            <div class="product-image">
                                <?php if (!empty($producto['imagen_principal'])): ?>
                                    <img src="public/img/productos/<?= htmlspecialchars($producto['imagen_principal']); ?>"
                                        alt="<?= htmlspecialchars($producto['nombre']); ?>"
                                        onerror="this.src='public/img/edredonfondo.png'"
                                        onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'">
                                <?php else: ?>
                                    <img src="public/img/edredonfondo.png" 
                                         alt="<?= htmlspecialchars($producto['nombre']); ?>"
                                         onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'">
                                <?php endif; ?>
                                
                                <!-- Badge popular si aplica -->
                                <?php if (isset($producto['ventas']) && $producto['ventas'] > 0): ?>
                                    <div class="popular-badge">
                                        <i class="fas fa-star"></i> Popular
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Información del producto -->
                            <div class="product-info">
                                <h3 onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                    <?= htmlspecialchars($producto['nombre']) ?>
                                </h3>

                                <!-- Meta información (material, color, medida) -->
                                <div class="product-meta" onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                    <?php if (!empty($producto['material'])): ?>
                                        <div class="meta-item">
                                            <i class="fas fa-tag"></i>
                                            <span class="meta-text"><?= htmlspecialchars($producto['material']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($producto['color'])): ?>
                                        <div class="meta-item">
                                            <i class="fas fa-palette"></i>
                                            <span class="meta-text"><?= htmlspecialchars($producto['color']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($producto['medida'])): ?>
                                        <div class="meta-item">
                                            <i class="fas fa-ruler"></i>
                                            <span class="meta-text"><?= htmlspecialchars($producto['medida']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Precio y Rating -->
                                <div class="price-rating" onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                    <div class="price">
                                        <span class="current-price">S/ <?= number_format($producto['precio'], 2) ?></span>
                                        <?php if (isset($producto['precio_anterior']) && $producto['precio_anterior'] > $producto['precio']): ?>
                                            <span class="old-price">S/ <?= number_format($producto['precio_anterior'], 2) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star-half-alt"></i>
                                    </div>
                                </div>
                            </div>

                            <!-- Acciones del producto -->
                            <div class="product-actions">
                                <button class="btn-add-to-cart" data-product-id="<?= $producto['id_producto'] ?>">
                                    <i class="fas fa-shopping-cart"></i> Agregar
                                </button>
                                <a href="index.php?action=<?= $enFavoritos ? 'eliminar_deseo' : 'agregar_deseo'; ?>&id=<?= $producto['id_producto'] ?>" 
                                   class="btn-favorites <?= $enFavoritos ? 'in-favorites' : ''; ?>">
                                    <i class="<?= $enFavoritos ? 'fas' : 'far'; ?> fa-heart"></i>
                                    <?= $enFavoritos ? 'Mi Favorito' : 'Favorito'; ?>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include __DIR__ . '/../layout/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Pasar variable PHP a JavaScript -->
    <script>
        const usuarioLogueado = <?php echo isset($_SESSION['usuario_id']) ? 'true' : 'false'; ?>;
    </script>
    
    <script src="public/js/carrito.js"></script>
    
    <script>
    // Animación al hacer scroll
    document.addEventListener('DOMContentLoaded', function () {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observar elementos con animaciones
        document.querySelectorAll('.section-animate, .fade-in-up').forEach(el => {
            observer.observe(el);
        });
    });

    // Funcionalidad para hacer click en elementos específicos para ir al detalle
    document.querySelectorAll('.product-image img, .product-info h3, .product-meta, .price-rating').forEach(element => {
        element.style.cursor = 'pointer';
        element.addEventListener('click', function (e) {
            const productCard = this.closest('.product-card');
            const productId = productCard.querySelector('.btn-add-to-cart')?.getAttribute('data-product-id');
            if (productId) {
                window.location.href = 'index.php?action=detalle_producto&id=' + productId;
            }
        });
    });
    </script>
</body>
</html>