<?php
// app/views/productos/productos_lista.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/funciones.php';

// Verificar si el usuario está logueado para la funcionalidad de favoritos
if (session_status() === PHP_SESSION_NONE)
    session_start();
$usuario_id = $_SESSION['usuario_id'] ?? null;

// Función para verificar si un producto está en favoritos (MISMA LÓGICA QUE HOME)
function estaEnFavoritos($producto_id)
{
    if (session_status() === PHP_SESSION_NONE)
        session_start();
    if (!isset($_SESSION['usuario_id']))
        return false;

    require_once 'app/config/database.php';
    require_once 'app/models/ListaDeseos.php';

    try {
        $database = new Database();
        $db = $database->getConnection();
        $listaDeseos = new ListaDeseos($db);
        return $listaDeseos->estaEnLista($_SESSION['usuario_id'], $producto_id);
    } catch (Exception $e) {
        return false;
    }
}

$titulo = "Todos Nuestros Productos";
$descripcion = "Descubre nuestra colección completa de edredones, sábanas y accesorios para tu hogar";

// Obtener conexión a la base de datos para las categorías
$database = new Database();
$db = $database->getConnection();

// Obtener categorías para el filtro
require_once __DIR__ . '/../../models/Categoria.php';
$categoriaModel = new Categoria($db);
$categorias = $categoriaModel->obtenerTodasActivas();

// Determinar título y descripción según la acción
if (isset($_GET['action']) && $_GET['action'] === 'populares') {
    $titulo = "Productos Más Populares";
    $descripcion = "Descubre los productos más vendidos y mejor valorados por nuestros clientes";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo) ?> - Dream House</title>
    <link rel="stylesheet" href="public/css/home.css">
    <link rel="stylesheet" href="public/css/estilos.css">
    <link rel="stylesheet" href="public/css/listar.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
</head>
<body>
    <?php include __DIR__ . '/../layout/header.php'; ?>

    <!-- Hero Section estilo listarproductos -->
    <section class="hero-tienda">
        <div class="container">
            <h1><?= htmlspecialchars($titulo) ?></h1>
            <p><?= htmlspecialchars($descripcion) ?></p>
            <div class="productos-count">
                <span id="contador-productos"><?= count($productos) ?> producto(s) encontrado(s)</span>
            </div>
        </div>
    </section>

    <!-- Filtros Section Mejorada -->
    <section class="filtros-section section-animate">
        <div class="container">
            <div class="filtros-grid">
                <!-- Filtro por categoría -->
                <div class="filtro-group fade-in-up">
                    <label for="categoria">Filtrar por categoría:</label>
                    <select id="categoria" onchange="filtrarProductos()">
                        <option value="">Todas las categorías</option>
                        <?php foreach ($categorias as $categoria): ?>
                            <option value="<?= $categoria['id_categoria'] ?>">
                                <?= htmlspecialchars($categoria['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Filtro por precio -->
                <div class="filtro-group fade-in-up" style="animation-delay: 0.1s;">
                    <label for="precio">Ordenar por precio:</label>
                    <select id="precio" onchange="ordenarProductos()">
                        <option value="">Por defecto</option>
                        <option value="asc">Menor a mayor precio</option>
                        <option value="desc">Mayor a menor precio</option>
                    </select>
                </div>

                <!-- Búsqueda -->
                <div class="filtro-group fade-in-up" style="animation-delay: 0.2s;">
                    <label for="busqueda">Buscar producto:</label>
                    <div class="search-box">
                        <input type="text" id="busqueda" placeholder="Nombre del producto..." onkeypress="if(event.key=='Enter') buscarProductos()">
                        <button onclick="buscarProductos()"><i class="fas fa-search"></i></button>
                    </div>
                </div>

                <!-- Resetear filtros -->
                <div class="filtro-group fade-in-up" style="animation-delay: 0.3s;">
                    <label>&nbsp;</label>
                    <button class="btn-reset" onclick="resetearFiltros()">
                        <i class="fas fa-undo"></i> Resetear
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Productos Section con diseño del home -->
    <section id="productos-section" class="collection section-animate">
        <div class="container">
            <h2 class="fade-in-up">Nuestra Colección Completa</h2>
            <div class="divider fade-in-up" style="animation-delay: 0.1s;"></div>
            <p class="section-subtitle fade-in-up" style="animation-delay: 0.2s;">
                Encuentra el producto perfecto para tu hogar entre nuestra amplia selección
            </p>

            <?php if (empty($productos)): ?>
                <div class="no-productos fade-in-up">
                    <i class="fas fa-search" style="font-size: 4rem; margin-bottom: 1.5rem; color: #C4A99B;"></i>
                    <h3>No se encontraron productos</h3>
                    <p>Intenta con otros filtros o términos de búsqueda.</p>
                    <a href="index.php?action=productos" class="btn-primary">Ver Todos los Productos</a>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($productos as $index => $producto): 
                        // Verificar si está en favoritos (MISMA LÓGICA QUE HOME)
                        $enFavoritos = false;
                        if (isset($_SESSION['usuario_id'])) {
                            $enFavoritos = estaEnFavoritos($producto['id_producto']);
                        }
                    ?>
                        <div class="product-card fade-in-up" 
                             style="animation-delay: <?= ($index % 6) * 0.1 + 0.4 ?>s;"
                             data-categoria="<?= $producto['id_categoria'] ?>" 
                             data-precio="<?= $producto['precio'] ?>">
                            
                            <!-- Badge de categoría -->
                            <div class="product-badge">
                                <?= htmlspecialchars($producto['categoria'] ?? 'Producto') ?>
                            </div>

                            <!-- Imagen del producto -->
                            <div class="product-image">
                                <img src="public/img/productos/<?= htmlspecialchars($producto['imagen_principal'] ?? 'default.png') ?>" 
                                     alt="<?= htmlspecialchars($producto['nombre']) ?>"
                                     onerror="this.src='public/img/edredonfondo.png'"
                                     onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'">
                                
                                <!-- Badge popular si aplica -->
                                <?php if (isset($producto['ventas']) && $producto['ventas'] > 0): ?>
                                    <div class="popular-badge">
                                        <i class="fas fa-star"></i> Popular
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Información del producto -->
                            <h3 onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                <?= htmlspecialchars($producto['nombre']) ?>
                            </h3>

                            <!-- Meta información (material, color, medida) -->
                            <div class="product-meta" onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                <?php if (!empty($producto['material'])): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-tag"></i>
                                        <span class="meta-text"><?= htmlspecialchars($producto['material']) ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($producto['color'])): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-palette"></i>
                                        <span class="meta-text"><?= htmlspecialchars($producto['color']) ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($producto['medida'])): ?>
                                    <div class="meta-item">
                                        <i class="fas fa-ruler"></i>
                                        <span class="meta-text"><?= htmlspecialchars($producto['medida']) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Precio y Rating -->
                            <div class="price-rating" onclick="window.location.href='index.php?action=detalle_producto&id=<?= $producto['id_producto'] ?>'" style="cursor: pointer;">
                                <div class="price">
                                    <span class="current-price">S/ <?= number_format($producto['precio'], 2) ?></span>
                                    <?php if (isset($producto['precio_anterior']) && $producto['precio_anterior'] > $producto['precio']): ?>
                                        <span class="old-price">S/ <?= number_format($producto['precio_anterior'], 2) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                </div>
                            </div>

                            <!-- Acciones del producto -->
                            <div class="product-actions">
                                <button class="btn-add-to-cart" data-product-id="<?= $producto['id_producto'] ?>">
                                    <i class="fas fa-shopping-cart"></i> Agregar
                                </button>
                                <a href="index.php?action=<?= $enFavoritos ? 'eliminar_deseo' : 'agregar_deseo'; ?>&id=<?= $producto['id_producto'] ?>" 
                                   class="btn-favorites <?= $enFavoritos ? 'in-favorites' : ''; ?>">
                                    <i class="<?= $enFavoritos ? 'fas' : 'far'; ?> fa-heart"></i>
                                    <?= $enFavoritos ? 'Mi Favorito' : 'Favorito'; ?>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include __DIR__ . '/../layout/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Pasar variable PHP a JavaScript -->
    <script>
        const usuarioLogueado = <?php echo isset($_SESSION['usuario_id']) ? 'true' : 'false'; ?>;
    </script>
    
    <script src="public/js/carrito.js"></script>
    
    <script>
    // Funciones de filtrado y búsqueda
    function filtrarProductos() {
        const categoriaId = document.getElementById('categoria').value;
        const productos = document.querySelectorAll('.product-card');
        let visibleCount = 0;
        
        productos.forEach(producto => {
            if (!categoriaId || producto.dataset.categoria === categoriaId) {
                producto.style.display = 'block';
                visibleCount++;
            } else {
                producto.style.display = 'none';
            }
        });
        
        actualizarContador(visibleCount);
    }

    function ordenarProductos() {
        const orden = document.getElementById('precio').value;
        if (!orden) return;
        
        const grid = document.querySelector('.products-grid');
        const productos = Array.from(document.querySelectorAll('.product-card'));
        
        productos.sort((a, b) => {
            const precioA = parseFloat(a.dataset.precio);
            const precioB = parseFloat(b.dataset.precio);
            
            return orden === 'asc' ? precioA - precioB : precioB - precioA;
        });
        
        // Limpiar y reinsertar en orden
        grid.innerHTML = '';
        productos.forEach(producto => grid.appendChild(producto));
    }

    function buscarProductos() {
        const termino = document.getElementById('busqueda').value.toLowerCase();
        const productos = document.querySelectorAll('.product-card');
        let visibleCount = 0;
        
        productos.forEach(producto => {
            const nombre = producto.querySelector('h3').textContent.toLowerCase();
            const descripcion = producto.querySelector('.product-meta')?.textContent.toLowerCase() || '';
            const categoria = producto.querySelector('.product-badge').textContent.toLowerCase();
            
            if (nombre.includes(termino) || descripcion.includes(termino) || categoria.includes(termino)) {
                producto.style.display = 'block';
                visibleCount++;
            } else {
                producto.style.display = 'none';
            }
        });
        
        actualizarContador(visibleCount);
    }

    function resetearFiltros() {
        document.getElementById('categoria').value = '';
        document.getElementById('precio').value = '';
        document.getElementById('busqueda').value = '';
        
        const productos = document.querySelectorAll('.product-card');
        productos.forEach(producto => {
            producto.style.display = 'block';
        });
        
        actualizarContador(productos.length);
    }

    function actualizarContador(count) {
        const contador = document.getElementById('contador-productos');
        if (contador) {
            contador.textContent = count + ' producto(s) encontrado(s)';
        }
    }

    // Animación al hacer scroll
    document.addEventListener('DOMContentLoaded', function () {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observar elementos con animaciones
        document.querySelectorAll('.section-animate, .fade-in-up').forEach(el => {
            observer.observe(el);
        });

        // Inicializar contador
        const productos = document.querySelectorAll('.product-card');
        actualizarContador(productos.length);
    });

    // Funcionalidad para hacer click en elementos específicos para ir al detalle
    document.querySelectorAll('.product-image img, .product-card h3, .product-meta, .price-rating').forEach(element => {
        element.style.cursor = 'pointer';
        element.addEventListener('click', function (e) {
            const productCard = this.closest('.product-card');
            const productId = productCard.querySelector('.btn-add-to-cart')?.getAttribute('data-product-id');
            if (productId) {
                window.location.href = 'index.php?action=detalle_producto&id=' + productId;
            }
        });
    });
    </script>
</body>
</html>