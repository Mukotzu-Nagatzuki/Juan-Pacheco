<?php
// Obtener la conexión a la base de datos
$db = new Database();
$conn = $db->getConnection();

// Obtener todos los productos con información de categorías
$stmt = $conn->prepare("
    SELECT p.*, c.nombre as categoria 
    FROM productos p 
    LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
    ORDER BY p.fecha_registro DESC
");
$stmt->execute();
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener categorías para el modal
$stmt = $conn->prepare("SELECT id_categoria, nombre FROM categorias WHERE estado = 'activo' ORDER BY nombre");
$stmt->execute();
$categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Preparar el contenido para el layout
ob_start();
?>

<header class="header">
    <h1>Gestión de Productos</h1>
    <p>Administra y gestiona todos los productos de la tienda</p>
</header>

<section class="recent-orders">
    <div class="header-actions">
        <h3>Todos los Productos</h3>
        <div class="action-buttons">
            <button class="btn-ver" onclick="abrirModalAgregar()">
                <i class="fas fa-plus"></i> Agregar Nuevo Producto
            </button>
        </div>
    </div>

    <!-- Mensajes de alerta -->
    <?php if (isset($_SESSION['mensaje'])): ?>
        <div class="alert alert-success" style="margin: 1rem 0; padding: 1rem; background: #8f6e81ff; color: #ffffffff; border-radius: 5px; border: 1px solid #8f6e81ff;">
             <?php echo $_SESSION['mensaje']; unset($_SESSION['mensaje']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error" style="margin: 1rem 0; padding: 1rem; background: #806366ff; color: #ffffffff; border-radius: 5px; border: 1px solid #806366ff;">
            <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <!-- Estadísticas rápidas -->
    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1.5rem 0;">
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: center;">
            <div class="stat-icon" style="font-size: 2rem; color: var(--color-principal); margin-bottom: 0.5rem;">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="stat-info">
                <h3 style="margin: 0; font-size: 1.5rem; color: var(--color-texto);"><?php echo count($productos); ?></h3>
                <p style="margin: 0; color: var(--color-texto-suave);">Total Productos</p>
            </div>
        </div>
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: center;">
            <div class="stat-icon" style="font-size: 2rem; color: #10b981; margin-bottom: 0.5rem;">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <h3 style="margin: 0; font-size: 1.5rem; color: var(--color-texto);"><?php echo count(array_filter($productos, function($p) { return $p['estado'] === 'activo'; })); ?></h3>
                <p style="margin: 0; color: var(--color-texto-suave);">Productos Activos</p>
            </div>
        </div>
        <div class="stat-card" style="background: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: center;">
            <div class="stat-icon" style="font-size: 2rem; color: #f59e0b; margin-bottom: 0.5rem;">
                <i class="fas fa-pause-circle"></i>
            </div>
            <div class="stat-info">
                <h3 style="margin: 0; font-size: 1.5rem; color: var(--color-texto);"><?php echo count(array_filter($productos, function($p) { return $p['estado'] === 'inactivo'; })); ?></h3>
                <p style="margin: 0; color: var(--color-texto-suave);">Productos Inactivos</p>
            </div>
        </div>
    </div>

    <!-- Tabla de productos -->
    <div class="table-container" style="background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <div class="table-header" style="padding: 1.5rem; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0;">Lista de Productos</h3>
            <div class="search-box" style="position: relative;">
                <i class="fas fa-search" style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: #666;"></i>
                <input type="text" id="search-products" placeholder="Buscar productos..." style="padding: 0.5rem 1rem 0.5rem 2rem; border: 1px solid #ddd; border-radius: 5px; width: 250px;">
            </div>
        </div>
        
        <table class="orders-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($productos)): ?>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 3rem; color: #666;">
                        <i class="fas fa-box-open" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
                        <p>No hay productos registrados</p>
                        <button class="btn-ver" onclick="abrirModalAgregar()" style="margin-top: 1rem; display: inline-block;">
                            <i class="fas fa-plus"></i> Agregar Primer Producto
                        </button>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($productos as $row): ?>
                    <tr>
                        <td><strong>#<?= $row['id_producto']; ?></strong></td>
                        <td>
                            <?php if (!empty($row['imagen_principal'])): ?>
                                <img src="public/img/productos/<?= htmlspecialchars($row['imagen_principal']); ?>" 
                                     alt="<?= htmlspecialchars($row['nombre']); ?>"
                                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; border: 1px solid #ddd;"
                                     onerror="this.src='public/img/edredonfondo.png'">
                            <?php else: ?>
                                <img src="public/img/edredonfondo.png" alt="Sin imagen" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; border: 1px solid #ddd;">
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($row['nombre']); ?></strong>
                            <?php if (!empty($row['material'])): ?>
                                <br><small style="color: #666;">Material: <?= htmlspecialchars($row['material']); ?></small>
                            <?php endif; ?>
                            <?php if (!empty($row['color'])): ?>
                                <br><small style="color: #666;">Color: <?= htmlspecialchars($row['color']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="status-badge" style="background: #e0e7ff; color: #3730a3; padding: 0.25rem 0.5rem; border-radius: 15px; font-size: 0.8rem;">
                                <?= htmlspecialchars($row['categoria']); ?>
                            </span>
                        </td>
                        <td><strong>S/ <?= number_format($row['precio'], 2); ?></strong></td>
                        <td>
                            <span class="status-badge <?= $row['stock'] > 10 ? 'status-entregado' : ($row['stock'] > 0 ? 'status-pendiente' : 'status-cancelado'); ?>">
                                <?= $row['stock']; ?> unidades
                            </span>
                        </td>
                        <td>
                            <span class="status-badge <?= $row['estado'] == 'activo' ? 'status-entregado' : 'status-cancelado'; ?>">
                                <?= $row['estado'] === 'activo' ? 'Activo' : 'Inactivo'; ?>
                            </span>
                        </td>
                        <td style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                            <button class="btn-ver" onclick="abrirModalEditar(<?= htmlspecialchars(json_encode($row)) ?>)" style="padding: 6px 12px; font-size: 0.8rem;">
                                <i class="fas fa-edit"></i> Editar
                            </button>
                            <a href="index.php?action=eliminar-producto&id=<?= $row['id_producto']; ?>" 
                               class="btn-ver" 
                               style="padding: 6px 12px; font-size: 0.8rem; background: #b14e35ff;"
                               onclick="return confirm('¿Estás seguro de que deseas eliminar el producto: <?= addslashes($row['nombre']); ?>?')">
                                <i class="fas fa-trash"></i> Eliminar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<!-- Modal Agregar Producto -->
<div id="modalAgregarProducto" class="modal">
    <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
        <div class="modal-header">
            <h3>Agregar Nuevo Producto</h3>
            <button class="close" onclick="cerrarModal('modalAgregarProducto')">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data" action="index.php?action=agregar-producto">
            <div class="modal-body">
                <div class="form-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <!-- Columna izquierda -->
                    <div class="form-column">
                        <div class="form-group">
                            <label for="agregar-nombre">Nombre del Producto *</label>
                            <input type="text" name="nombre" id="agregar-nombre" required>
                        </div>

                        <div class="form-group">
                            <label for="agregar-id_categoria">Categoría *</label>
                            <select name="id_categoria" id="agregar-id_categoria" required>
                                <option value="">-- Seleccione una categoría --</option>
                                <?php foreach ($categorias as $cat): ?>
                                    <option value="<?= $cat['id_categoria']; ?>">
                                        <?= htmlspecialchars($cat['nombre']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="agregar-precio">Precio (S/) *</label>
                            <input type="number" step="0.01" name="precio" id="agregar-precio" required min="0">
                        </div>

                        <div class="form-group">
                            <label for="agregar-material">Material</label>
                            <input type="text" name="material" id="agregar-material">
                        </div>
                    </div>

                    <!-- Columna derecha -->
                    <div class="form-column">
                        <div class="form-group">
                            <label for="agregar-color">Color</label>
                            <input type="text" name="color" id="agregar-color">
                        </div>

                        <div class="form-group">
                            <label for="agregar-medida">Medida *</label>
                            <select name="medida" id="agregar-medida" required>
                                <option value="">-- Seleccione medida --</option>
                                <option value="1½ plazas">1½ plazas</option>
                                <option value="2 plazas">2 plazas</option>
                                <option value="2½ plazas">2½ plazas</option>
                                <option value="3 plazas">3 plazas</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="agregar-estado">Estado *</label>
                            <select name="estado" id="agregar-estado" required>
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="agregar-stock">Stock *</label>
                            <input type="number" name="stock" id="agregar-stock" required min="0" value="0">
                        </div>
                    </div>
                </div>

                <!-- Campos de ancho completo -->
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label for="agregar-descripcion">Descripción</label>
                    <textarea name="descripcion" id="agregar-descripcion" rows="4"></textarea>
                </div>

                <div class="form-group" style="grid-column: 1 / -1;">
                    <label for="agregar-imagen">Imagen del Producto</label>
                    <input type="file" name="imagen" id="agregar-imagen" accept="image/*">
                    <div id="agregar-image-preview" style="margin-top: 1rem; display: none;">
                        <p style="margin-bottom: 0.5rem; font-weight: 600;">Vista previa:</p>
                        <img id="agregar-preview-img" src="" width="150" style="border-radius: 5px; border: 1px solid #ddd;">
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="padding: 1rem; border-top: 1px solid var(--color-beige-claro); text-align: right;">
                <button type="button" class="btn-ver" onclick="cerrarModal('modalAgregarProducto')" style="background: #6c757d; margin-right: 0.5rem;">Cancelar</button>
                <button type="submit" class="btn-ver">Agregar Producto</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Editar Producto -->
<div id="modalEditarProducto" class="modal">
    <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
        <div class="modal-header">
            <h3>Editar Producto</h3>
            <button class="close" onclick="cerrarModal('modalEditarProducto')">&times;</button>
        </div>
        <form id="formEditarProducto" method="POST" enctype="multipart/form-data" action="index.php?action=editar-producto">
            <div class="modal-body">
                <input type="hidden" id="editar-id" name="id_producto">
                
                <div class="form-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <!-- Columna izquierda -->
                    <div class="form-column">
                        <div class="form-group">
                            <label for="editar-nombre">Nombre del Producto *</label>
                            <input type="text" name="nombre" id="editar-nombre" required>
                        </div>

                        <div class="form-group">
                            <label for="editar-id_categoria">Categoría *</label>
                            <select name="id_categoria" id="editar-id_categoria" required>
                                <option value="">-- Seleccione una categoría --</option>
                                <?php foreach ($categorias as $cat): ?>
                                    <option value="<?= $cat['id_categoria']; ?>">
                                        <?= htmlspecialchars($cat['nombre']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="editar-precio">Precio (S/) *</label>
                            <input type="number" step="0.01" name="precio" id="editar-precio" required>
                        </div>

                        <div class="form-group">
                            <label for="editar-material">Material</label>
                            <input type="text" name="material" id="editar-material">
                        </div>
                    </div>

                    <!-- Columna derecha -->
                    <div class="form-column">
                        <div class="form-group">
                            <label for="editar-color">Color</label>
                            <input type="text" name="color" id="editar-color">
                        </div>

                        <div class="form-group">
                            <label for="editar-medida">Medida</label>
                            <select name="medida" id="editar-medida">
                                <option value="1½ plazas">1½ plazas</option>
                                <option value="2 plazas">2 plazas</option>
                                <option value="2½ plazas">2½ plazas</option>
                                <option value="3 plazas">3 plazas</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="editar-estado">Estado</label>
                            <select name="estado" id="editar-estado">
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="editar-stock">Stock</label>
                            <input type="number" name="stock" id="editar-stock" min="0">
                        </div>
                    </div>
                </div>

                <!-- Campos de ancho completo -->
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label for="editar-descripcion">Descripción</label>
                    <textarea name="descripcion" id="editar-descripcion" rows="4"></textarea>
                </div>

                <div class="form-group" style="grid-column: 1 / -1;">
                    <label for="editar-imagen">Imagen del Producto</label>
                    <input type="file" name="imagen" id="editar-imagen" accept="image/*">
                    <div id="imagen-actual-container" style="margin-top: 1rem; display: none;">
                        <p style="margin-bottom: 0.5rem; font-weight: 600;">Imagen actual:</p>
                        <img id="imagen-actual" src="" width="150" style="border-radius: 5px; border: 1px solid #ddd;">
                        <input type="hidden" name="imagen_actual" id="imagen-actual-input">
                    </div>
                    <div id="image-preview" style="margin-top: 1rem; display: none;">
                        <p style="margin-bottom: 0.5rem; font-weight: 600;">Vista previa:</p>
                        <img id="preview-img" src="" width="150" style="border-radius: 5px; border: 1px solid #ddd;">
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="padding: 1rem; border-top: 1px solid var(--color-beige-claro); text-align: right;">
                <button type="button" class="btn-ver" onclick="cerrarModal('modalEditarProducto')" style="background: #6c757d; margin-right: 0.5rem;">Cancelar</button>
                <button type="submit" class="btn-ver">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>

<script>
// Funciones para los modales
function abrirModalAgregar() {
    // Limpiar formulario
    document.getElementById('agregar-nombre').value = '';
    document.getElementById('agregar-id_categoria').value = '';
    document.getElementById('agregar-precio').value = '';
    document.getElementById('agregar-material').value = '';
    document.getElementById('agregar-color').value = '';
    document.getElementById('agregar-medida').value = '';
    document.getElementById('agregar-stock').value = '0';
    document.getElementById('agregar-descripcion').value = '';
    document.getElementById('agregar-estado').value = 'activo';
    document.getElementById('agregar-imagen').value = '';
    document.getElementById('agregar-image-preview').style.display = 'none';
    
    document.getElementById('modalAgregarProducto').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function abrirModalEditar(producto) {
    // Llenar formulario de edición
    document.getElementById('editar-id').value = producto.id_producto;
    document.getElementById('editar-nombre').value = producto.nombre;
    document.getElementById('editar-id_categoria').value = producto.id_categoria;
    document.getElementById('editar-precio').value = producto.precio;
    document.getElementById('editar-material').value = producto.material || '';
    document.getElementById('editar-color').value = producto.color || '';
    document.getElementById('editar-medida').value = producto.medida;
    document.getElementById('editar-stock').value = producto.stock || 0;
    document.getElementById('editar-descripcion').value = producto.descripcion || '';
    document.getElementById('editar-estado').value = producto.estado;
    
    // Manejar imagen actual
    const imagenContainer = document.getElementById('imagen-actual-container');
    const imagenActual = document.getElementById('imagen-actual');
    const imagenActualInput = document.getElementById('imagen-actual-input');
    
    if (producto.imagen_principal) {
        imagenContainer.style.display = 'block';
        imagenActual.src = 'public/img/productos/' + producto.imagen_principal;
        imagenActualInput.value = producto.imagen_principal;
    } else {
        imagenContainer.style.display = 'none';
        imagenActualInput.value = '';
    }
    
    // Resetear preview
    document.getElementById('image-preview').style.display = 'none';
    
    document.getElementById('modalEditarProducto').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function cerrarModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Cerrar modal al hacer clic fuera de él
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }
}

// Cerrar modal con tecla ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modals = document.getElementsByClassName('modal');
        for (let modal of modals) {
            if (modal.style.display === 'block') {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }
    }
});

// Previsualización de imagen para agregar
document.getElementById('agregar-imagen').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('agregar-image-preview');
    const previewImg = document.getElementById('agregar-preview-img');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.style.display = 'block';
            previewImg.src = e.target.result;
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});

// Previsualización de imagen para editar
document.getElementById('editar-imagen').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.style.display = 'block';
            previewImg.src = e.target.result;
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});

// Script para búsqueda en tiempo real
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-products');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('.orders-table tbody tr');
            
            rows.forEach(row => {
                const productName = row.querySelector('td:nth-child(3) strong').textContent.toLowerCase();
                const productCategory = row.querySelector('td:nth-child(4) .status-badge').textContent.toLowerCase();
                
                if (productName.includes(searchTerm) || productCategory.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
    
    // Cerrar alertas automáticamente después de 5 segundos
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.display = 'none';
        }, 5000);
    });

    // Validaciones para formularios
    const precioInput = document.getElementById('agregar-precio');
    if (precioInput) {
        precioInput.addEventListener('blur', function() {
            if (this.value < 0) {
                this.value = 0;
            }
        });
    }
    
    const stockInput = document.getElementById('agregar-stock');
    if (stockInput) {
        stockInput.addEventListener('blur', function() {
            if (this.value < 0) {
                this.value = 0;
            }
        });
    }
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin_layout.php';
?>