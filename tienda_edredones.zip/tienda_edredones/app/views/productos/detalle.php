<?php
include 'app/views/layout/header.php';

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si hay sesión de usuario
$usuario_logueado = isset($_SESSION['usuario_id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($producto['nombre']); ?> - Tienda de Edredones</title>
    <link rel="stylesheet" href="public/css/detalles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'app/views/layout/navbar.php'; ?>

    <section class="product-detail-page">
        <div class="container">
            <!-- Migas de pan -->
            <div class="detail-breadcrumb">
                <a href="index.php">Inicio</a> / 
                <a href="index.php?action=productos">Productos</a> / 
                <span><?php echo htmlspecialchars($producto['nombre']); ?></span>
            </div>

            <div class="detail-container">
                <!-- Imagen del producto -->
                <div class="detail-image-section">
                    <div class="detail-main-image">
                        <?php if (!empty($producto['imagen_principal'])): ?>
                            <img src="public/img/productos/<?php echo htmlspecialchars($producto['imagen_principal']); ?>" 
                                 alt="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                 onerror="this.src='public/img/edredonfondo.png'">
                        <?php else: ?>
                            <img src="public/img/edredonfondo.png" 
                                 alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                        <?php endif; ?>
                    </div>

                    <!-- Beneficios SOLO debajo de la imagen -->
                    <div class="detail-benefits">
                        <h4>Beneficios de compra</h4>
                        <div class="detail-benefits-list">
                            <div class="detail-benefit-item">
                                <i class="fas fa-shipping-fast"></i>
                                <span>Envío gratis en compras mayores a S/ 100</span>
                            </div>
                            <div class="detail-benefit-item">
                                <i class="fas fa-undo"></i>
                                <span>Devoluciones gratuitas en 30 días</span>
                            </div>
                            <div class="detail-benefit-item">
                                <i class="fas fa-shield-alt"></i>
                                <span>Garantía de calidad</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Información del producto -->
                <div class="detail-info-section">
                    <div class="detail-badge">
                        <?php echo htmlspecialchars($producto['categoria'] ?? 'Producto'); ?>
                    </div>
                    
                    <h1 class="detail-title"><?php echo htmlspecialchars($producto['nombre']); ?></h1>
                    
                    <div class="detail-price-section">
                        <span class="detail-current-price">S/ <?php echo number_format($producto['precio'], 2); ?></span>
                    </div>

                    <div class="detail-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                        <span class="detail-rating-text">(4.5)</span>
                    </div>

                    <?php if (!empty($producto['descripcion'])): ?>
                        <div class="detail-description">
                            <h3>Descripción</h3>
                            <p><?php echo nl2br(htmlspecialchars($producto['descripcion'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="detail-specs">
                        <h3>Especificaciones</h3>
                        <div class="detail-specs-grid">
                            <?php if (!empty($producto['material'])): ?>
                                <div class="detail-spec-item">
                                    <strong><i class="fas fa-tag"></i> Material:</strong>
                                    <span><?php echo htmlspecialchars($producto['material']); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($producto['color'])): ?>
                                <div class="detail-spec-item">
                                    <strong><i class="fas fa-palette"></i> Color:</strong>
                                    <span><?php echo htmlspecialchars($producto['color']); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($producto['medida'])): ?>
                                <div class="detail-spec-item">
                                    <strong><i class="fas fa-ruler"></i> Medida:</strong>
                                    <span><?php echo htmlspecialchars($producto['medida']); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (isset($producto['stock'])): ?>
                                <div class="detail-spec-item">
                                    <strong><i class="fas fa-box"></i> Stock:</strong>
                                    <span><?php echo htmlspecialchars($producto['stock']); ?> unidades</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="detail-actions">
                        <?php if (isset($producto['stock']) && $producto['stock'] > 0): ?>
                            <button class="detail-btn-cart <?= $producto['stock'] <= 0 ? 'disabled' : '' ?>" 
                                    id="btnAddToCart" 
                                    data-product-id="<?php echo $producto['id_producto']; ?>"
                                    <?= $producto['stock'] <= 0 ? 'disabled' : '' ?>>
                                <i class="fas fa-shopping-cart"></i> 
                                <?= $producto['stock'] <= 0 ? 'Agotado' : 'Agregar al Carrito' ?>
                            </button>
                        <?php else: ?>
                            <button class="detail-btn-out-of-stock" disabled>
                                <i class="fas fa-times-circle"></i> Agotado
                            </button>
                        <?php endif; ?>
                        
                        <!-- BOTÓN DE FAVORITOS -->
                        <?php
                        // Verificar si el producto está en lista de deseos
                        $enListaDeseos = false;
                        if (isset($_SESSION['usuario_id'])) {
                            // Usar el modelo directamente para verificar
                            require_once 'app/models/ListaDeseos.php';
                            require_once 'app/config/database.php';
                            $database = new Database();
                            $db = $database->getConnection();
                            $listaDeseos = new ListaDeseos($db);
                            $enListaDeseos = $listaDeseos->estaEnLista($_SESSION['usuario_id'], $producto['id_producto']);
                        }
                        ?>
                        <a href="index.php?action=<?= $enListaDeseos ? 'eliminar_deseo' : 'agregar_deseo'; ?>&id=<?php echo $producto['id_producto']; ?>" 
                        class="detail-btn-wishlist <?php echo $enListaDeseos ? 'in-wishlist' : ''; ?>">
                            <i class="<?php echo $enListaDeseos ? 'fas' : 'far'; ?> fa-heart"></i> 
                            <?php echo $enListaDeseos ? 'En Favoritos' : 'Favoritos'; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Productos relacionados -->
    <section class="detail-related">
        <div class="container">
            <h2>Productos Relacionados</h2>
            <div class="detail-related-grid">
                <p style="text-align: center; color: #6B5D55; grid-column: 1 / -1;">
                    Próximamente: productos relacionados de la misma categoría...
                </p>
            </div>
        </div>
    </section>

    <?php include 'app/views/layout/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Pasar variable PHP a JavaScript - FORMA SEGURA -->
    <script>
        const usuarioLogueado = <?php echo $usuario_logueado ? 'true' : 'false'; ?>;
        const baseUrl = '<?php echo $base_url ?? ''; ?>' || window.location.origin + '/';
        
        // Depuración: verificar valores
        console.log('usuarioLogueado:', usuarioLogueado);
        console.log('baseUrl:', baseUrl);
    </script>
    
    <!-- Incluir carrito.js para funcionalidad de carrito -->
    <script src="public/js/carrito.js"></script>
    
    <script>
    $(document).ready(function() {
        // Depuración: verificar que jQuery esté cargado
        console.log('jQuery cargado, usuarioLogueado:', usuarioLogueado);
        
        // Función para mostrar notificación
        function showNotification(message, type = 'success') {
            console.log('Mostrando notificación:', message, type);
            
            let notification = $('#cartNotification');
            let notificationText = $('#cartNotificationText');
            
            // Crear notificación si no existe
            if (notification.length === 0) {
                $('body').append(`
                    <div id="cartNotification" class="cart-notification">
                        <div id="cartNotificationText"></div>
                    </div>
                    <style>
                    .cart-notification {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        padding: 15px 25px;
                        border-radius: 5px;
                        color: white;
                        font-weight: 500;
                        z-index: 9999;
                        transform: translateX(150%);
                        transition: transform 0.3s ease;
                        max-width: 300px;
                    }
                    .cart-notification.show {
                        transform: translateX(0);
                    }
                    .cart-notification.success {
                        background: #8f6e81ff;
                        box-shadow: 0 4px 12px rgba(175, 76, 122, 0.3);
                    }
                    .cart-notification.error {
                        background: #854444ff;
                        box-shadow: 0 4px 12px rgba(99, 7, 0, 0.3);
                    }
                    </style>
                `);
                notification = $('#cartNotification');
                notificationText = $('#cartNotificationText');
            }
            
            notificationText.text(message);
            notification.removeClass('success error show').addClass(type + ' show');
            
            setTimeout(() => {
                notification.removeClass('show');
            }, 3000);
        }

        // Agregar al carrito - usando la misma lógica que en productos_categoria.php
        $('#btnAddToCart').on('click', function(e) {
            e.preventDefault();
            console.log('Click en agregar al carrito');
            
            const button = $(this);
            const productId = button.data('product-id');
            
            console.log('Producto ID:', productId);
            console.log('Usuario logueado:', usuarioLogueado);
            
            // Verificar si está deshabilitado (agotado)
            if (button.hasClass('disabled') || button.prop('disabled')) {
                showNotification('Este producto está agotado', 'error');
                return;
            }
            
            if (!usuarioLogueado) {
                showNotification('Debe iniciar sesión para agregar productos al carrito', 'error');
                setTimeout(() => {
                    window.location.href = 'index.php?action=login';
                }, 1500);
                return;
            }

            // Mostrar estado de carga
            const originalText = button.html();
            button.prop('disabled', true).addClass('loading');
            button.html('<i class="fas fa-spinner fa-spin"></i> Agregando...');

            // Hacer la petición AJAX
            $.ajax({
                url: 'index.php?action=agregar_carrito',
                type: 'POST',
                data: {
                    id_producto: productId,
                    cantidad: 1
                },
                dataType: 'json',
                success: function(data) {
                    console.log('Respuesta del servidor:', data);
                    
                    if (data.success) {
                        showNotification(data.message || 'Producto agregado al carrito');
                        
                        // Actualizar contador del carrito en el header si existe
                        if (data.total_items !== undefined) {
                            const cartCount = $('.cart-count');
                            if (cartCount.length) {
                                cartCount.text(data.total_items);
                            }
                        }
                        
                        // Animación de confirmación
                        button.html('<i class="fas fa-check"></i> ¡Agregado!');
                        setTimeout(() => {
                            button.html(originalText);
                        }, 1500);
                        
                    } else {
                        showNotification(data.message || 'Error al agregar al carrito', 'error');
                        button.html(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error AJAX:', status, error);
                    console.log('Respuesta:', xhr.responseText);
                    
                    try {
                        const data = JSON.parse(xhr.responseText);
                        showNotification(data.message || 'Error al agregar al carrito', 'error');
                    } catch(e) {
                        showNotification('Error de conexión. Intente nuevamente.', 'error');
                    }
                    button.html(originalText);
                },
                complete: function() {
                    setTimeout(() => {
                        button.prop('disabled', false).removeClass('loading');
                        if (!button.html().includes('¡Agregado!') && !button.html().includes('Agregando...')) {
                            button.html(originalText);
                        }
                    }, 1000);
                }
            });
        });

        // Efecto hover en botones
        $('.detail-btn-cart:not(.disabled), .detail-btn-wishlist').on('mouseenter', function() {
            if (!$(this).prop('disabled')) {
                $(this).css('transform', 'translateY(-2px)');
            }
        }).on('mouseleave', function() {
            $(this).css('transform', 'translateY(0)');
        });

        // Confirmación para eliminar de favoritos
        $(document).on('click', '.detail-btn-wishlist.in-wishlist', function(e) {
            if (!confirm('¿Estás seguro de que quieres eliminar este producto de tus favoritos?')) {
                e.preventDefault();
            }
        });
    });

    // Función global para agregar al carrito (para compatibilidad)
    function agregarAlCarrito(idProducto) {
        const button = $('#btnAddToCart');
        if (button.length) {
            button.click();
        }
    }
    </script>
</body>
</html>