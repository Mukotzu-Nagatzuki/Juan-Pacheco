<?php
// app/views/contacto.php

// Obtener configuraciones dinámicas para el contacto
$configuraciones_contacto = [];
try {
    require_once 'app/config/database.php';
    require_once 'app/controllers/ConfiguracionController.php';
    
    $database = new Database();
    $db = $database->getConnection();
    $configController = new ConfiguracionController();
    $configuraciones_contacto = $configController->obtenerConfiguraciones();
    
} catch (Exception $e) {
    error_log("Error cargando configuraciones del contacto: " . $e->getMessage());
    // Configuraciones por defecto en caso de error
    $configuraciones_contacto = [
        'direccion' => 'Calle Principal 123, Ciudad, CP 12345',
        'telefono_contacto' => '+51 987 654 321',
        'email_contacto' => 'info@dreamhouse.com',
        'horario_atencion' => 'Lunes a Viernes 9:00 – 18:00' . "\n" . 'Sábados 10:00 – 14:00',
        'testimonios_titulo' => 'Lo que dicen nuestros clientes',
        'testimonios_subtitulo' => 'Descubre las experiencias de quienes ya han transformado sus noches con nuestros productos',
        'testimonio_1_texto' => 'Como persona alérgica, siempre he tenido problemas para encontrar ropa de cama adecuada. Estos edredones hipoalergénicos han cambiado mi vida.',
        'testimonio_1_autor' => 'Laura Martínez',
        'testimonio_2_texto' => 'Desde que compré el edredón de invierno, mis noches son mucho más cálidas y reconfortantes. La calidad es excepcional y el envío fue muy rápido.',
        'testimonio_2_autor' => 'María González'
    ];
}

// Procesar el horario de atención para mostrar saltos de línea
$horario_atencion = nl2br(htmlspecialchars($configuraciones_contacto['horario_atencion'] ?? 'Lunes a Viernes 9:00 – 18:00<br>Sábados 10:00 – 14:00'));

include 'app/views/layout/header.php';

// Mostrar mensajes de éxito o error
if (isset($_SESSION['mensaje_exito'])) {
    echo '<div class="alert alert-success">' . $_SESSION['mensaje_exito'] . '</div>';
    unset($_SESSION['mensaje_exito']);
}

if (isset($_SESSION['mensaje_error'])) {
    echo '<div class="alert alert-danger">' . $_SESSION['mensaje_error'] . '</div>';
    unset($_SESSION['mensaje_error']);
}

if (isset($_SESSION['errores_contacto'])) {
    echo '<div class="alert alert-danger">';
    foreach ($_SESSION['errores_contacto'] as $error) {
        echo '<p>' . $error . '</p>';
    }
    echo '</div>';
    unset($_SESSION['errores_contacto']);
}

// Rellenar formulario con datos previos si hay errores
$datos_previos = $_SESSION['datos_contacto'] ?? [
    'nombre' => '',
    'correo' => '',
    'asunto' => '',
    'mensaje' => ''
];
unset($_SESSION['datos_contacto']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contáctenos - <?php echo htmlspecialchars($configuraciones_contacto['logo'] ?? 'Dream House'); ?></title>
    <link rel="stylesheet" href="public/css/estilos.css">
    <link rel="stylesheet" href="public/css/contacto.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="container">
            <h1>Contáctenos</h1>
            <div class="divider"></div>
            <p>¿Tienes preguntas? Estamos aquí para ayudarte</p>
            <div class="contact-grid">
                <!-- Información de Contacto -->
                <div class="contact-info">
                    <h2>Información de contacto</h2>
                    
                    <div class="contact-details">
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="contact-text">
                                <h4>Dirección:</h4>
                                <p><?php echo htmlspecialchars($configuraciones_contacto['direccion'] ?? 'Calle Principal 123, Ciudad, CP 12345'); ?></p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="contact-text">
                                <h4>Teléfono:</h4>
                                <p><?php echo htmlspecialchars($configuraciones_contacto['telefono_contacto'] ?? '+51 987 654 321'); ?></p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="contact-text">
                                <h4>Email:</h4>
                                <p><?php echo htmlspecialchars($configuraciones_contacto['email_contacto'] ?? 'info@dreamhouse.com'); ?></p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="contact-text">
                                <h4>Horario de Atención:</h4>
                                <p><?php echo $horario_atencion; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Formulario de Contacto -->
                <div class="contact-form">
                    <form action="index.php?action=enviar_contacto" method="POST" class="contact-form-wrapper">
                        <div class="form-group">
                            <label for="nombre">Nombre Completo</label>
                            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($datos_previos['nombre']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="correo">Correo Electrónico</label>
                            <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($datos_previos['correo']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="asunto">Asunto</label>
                            <input type="text" id="asunto" name="asunto" value="<?php echo htmlspecialchars($datos_previos['asunto']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="mensaje">Mensaje</label>
                            <textarea id="mensaje" name="mensaje" rows="5" required><?php echo htmlspecialchars($datos_previos['mensaje']); ?></textarea>
                        </div>
                        
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane"></i>
                            Enviar Mensaje
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials">
        <div class="container">
            <h3><?php echo htmlspecialchars($configuraciones_contacto['testimonios_titulo'] ?? 'Lo que dicen nuestros clientes'); ?></h3>
            <div class="divider"></div>
            <p class="section-subtitle"><?php echo htmlspecialchars($configuraciones_contacto['testimonios_subtitulo'] ?? 'Descubre las experiencias de quienes ya han transformado sus noches con nuestros productos'); ?></p>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <p class="testimonial-text">"<?php echo htmlspecialchars($configuraciones_contacto['testimonio_1_texto'] ?? 'Como persona alérgica, siempre he tenido problemas para encontrar ropa de cama adecuada. Estos edredones hipoalergénicos han cambiado mi vida.'); ?>"</p>
                        <div class="testimonial-author">
                            <strong>– <?php echo htmlspecialchars($configuraciones_contacto['testimonio_1_autor'] ?? 'Laura Martínez'); ?></strong>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <p class="testimonial-text">"<?php echo htmlspecialchars($configuraciones_contacto['testimonio_2_texto'] ?? 'Desde que compré el edredón de invierno, mis noches son mucho más cálidas y reconfortantes. La calidad es excepcional y el envío fue muy rápido.'); ?>"</p>
                        <div class="testimonial-author">
                            <strong>– <?php echo htmlspecialchars($configuraciones_contacto['testimonio_2_autor'] ?? 'María González'); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'app/views/layout/footer.php'; ?>
</body>
</html>