<?php
// index.php
session_start();
require_once 'app/config/config.php';
require_once 'app/config/database.php';
require_once 'app/controllers/UsuarioController.php';
require_once 'app/controllers/HomeController.php';

// Función para incluir el chatbot

// Enrutamiento básico
$action = $_GET['action'] ?? 'home';

// Guardar la página actual en sesión para los CSS
$_SESSION['current_page'] = $action;

// Crear instancia de HomeController
$homeController = new HomeController();

switch ($action) {
    // Páginas públicas
    case 'home':
        $homeController->home();
        break;

    case 'nosotros':
        $homeController->nosotros();
        break;

    case 'contacto':
        require_once 'app/controllers/ContactoController.php';
        $controller = new ContactoController();
        $controller->mostrarContacto();
        break;

    case 'enviar_contacto':
        require_once 'app/controllers/ContactoController.php';
        $controller = new ContactoController();
        $controller->enviarContacto();
        break;

    case 'buscar':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->buscar();
        break;

    case 'configuracion':
        require_once 'app/controllers/ConfiguracionController.php';
        $controller = new ConfiguracionController();
        $controller->mostrarConfiguracion();
        break;

    case 'configuracion-carrusel':
        require_once 'app/controllers/CarruselController.php';
        $controller = new CarruselController();
        $controller->configuracionCarrusel();
        break;

    case 'agregar-imagen-carrusel':
        require_once 'app/controllers/CarruselController.php';
        $controller = new CarruselController();
        $controller->agregarImagen();
        break;

    case 'editar-imagen-carrusel':
        require_once 'app/controllers/CarruselController.php';
        $controller = new CarruselController();
        $controller->editarImagen();
        break;

    case 'eliminar-imagen-carrusel':
        require_once 'app/controllers/CarruselController.php';
        $controller = new CarruselController();
        $controller->eliminarImagenCarrusel();
        break;

    case 'productos':
        $homeController->productos();
        break;

    case 'categoria':
        $homeController->categoria();
        break;

    // Autenticación de usuarios
    case 'login':
        $controller = new UsuarioController();
        $controller->mostrarLogin();
        break;

    case 'registro':
        $controller = new UsuarioController();
        $controller->mostrarRegistro();
        break;

    case 'loginUsuario':
        $controller = new UsuarioController();
        $controller->loginUsuario();
        break;

    case 'registrarUsuario':
        $controller = new UsuarioController();
        $controller->registrarUsuario();
        break;

    case 'logout':
        $controller = new UsuarioController();
        $controller->logout();
        break;

    // Dashboard y perfil de usuario
    case 'dashboard':
        $controller = new UsuarioController();
        $controller->mostrarDashboard();
        break;

    case 'perfil':
        $controller = new UsuarioController();
        $controller->mostrarPerfil();
        break;

    case 'actualizar_perfil':
        $controller = new UsuarioController();
        $controller->actualizarPerfil();
        break;

    case 'actualizar_password':
        $controller = new UsuarioController();
        $controller->actualizarPassword();
        break;

    // Funcionalidades de cliente
    case 'pedidos':
        $controller = new UsuarioController();
        $controller->mostrarPedidos();
        break;

    case 'facturas':
        $controller = new UsuarioController();
        $controller->mostrarFacturas();
        break;

    case 'agregar_deseo':
        $controller = new UsuarioController();
        $controller->agregarDeseo();
        break;

    case 'deseos':
        $controller = new UsuarioController();
        $controller->mostrarDeseos();
        break;

    case 'eliminar_deseo':
        $controller = new UsuarioController();
        $controller->eliminarDeseo();
        break;

    // Rutas del carrito - AGREGADAS
    case 'carrito':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->verCarrito();
        break;

    case 'agregar_carrito':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->agregar();
        break;

    case 'actualizar_carrito':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->actualizar();
        break;

    case 'eliminar_carrito':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->eliminar();
        break;

    case 'vaciar_carrito':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->vaciar();
        break;

    case 'contador_carrito':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->obtenerContador();
        break;

    case 'checkout':
        require_once 'app/controllers/PedidoController.php';
        $controller = new PedidoController();
        $controller->mostrarCheckout();
        break;

    case 'procesar_pedido':
        require_once 'app/controllers/PedidoController.php';
        $controller = new PedidoController();
        $controller->procesarPedido();
        break;

    case 'carrito_sidebar':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->carritoSidebar();
        break;

    // Panel de administración - Productos
    case 'admin':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->adminPanel();
        break;

    case 'productos_admin':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->adminPanel();
        break;

    case 'agregar-producto':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->agregar();
        break;

    case 'editar-producto':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->editar();
        break;

    case 'eliminar-producto':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->eliminar();
        break;

    // Panel de administración - Pedidos y Clientes
    case 'pedidos_admin':
        $controller = new UsuarioController();
        $controller->mostrarPedidosAdmin();
        break;

    case 'ver_pedido':
        $controller = new UsuarioController();
        $controller->mostrarDetallePedido();
        break;

    case 'actualizar_estado_pedido':
        $controller = new UsuarioController();
        $controller->actualizarEstadoPedido();
        break;

    case 'gestion_clientes':
        $controller = new UsuarioController();
        $controller->mostrarGestionClientes();
        break;

    case 'actualizar_cliente':
        $controller = new UsuarioController();
        $controller->actualizarCliente();
        break;

    case 'eliminar_cliente':
        $controller = new UsuarioController();
        $controller->eliminarCliente();
        break;

    case 'populares':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->populares();
        break;

    // Rutas para ofertas (Administrador) - AGREGAR REQUIRES
    case 'gestion_ofertas':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->gestionOfertas();
        break;
    case 'crear_oferta':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->crearOferta();
        break;
    case 'editar_oferta':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->editarOferta();
        break;
    case 'eliminar_oferta':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->eliminarOferta();
        break;
    case 'estadisticas_oferta':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->estadisticasOfertas();
        break;

    // Rutas para ofertas (Cliente) - AGREGAR REQUIRES
    case 'mis_descuentos':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->misDescuentos();
        break;
    case 'historial_descuentos':
        require_once 'app/controllers/OfertasController.php';
        $controller = new OfertasController();
        $controller->historialDescuentos();
        break;

    // Rutas para descuentos en el carrito
    case 'aplicar_descuento':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->aplicarDescuento();
        break;
    case 'remover_descuento':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->removerDescuento();
        break;
    case 'obtener_info_descuento':
        require_once 'app/controllers/CarritoController.php';
        $controller = new CarritoController();
        $controller->obtenerInfoDescuento();
        break;

    // Reportes
    case 'reportes':
        $controller = new UsuarioController();
        $controller->mostrarReportes();
        break;

    case 'detalle_producto':
        require_once 'app/controllers/ProductoController.php';
        $controller = new ProductoController();
        $controller->detalle();
        break;
    case 'configuracion-general':
        require_once 'app/controllers/ConfiguracionController.php';
        $controller = new ConfiguracionController();
        $controller->mostrarConfiguracionGeneral();
        break;
    case 'crear_pago':
        require_once 'app/controllers/PagoController.php';
        (new PagoController())->crear_pago();
        break;
    case 'guardar-configuracion-general':
        require_once 'app/controllers/ConfiguracionController.php';
        $controller = new ConfiguracionController();
        $controller->guardarConfiguracionGeneral();
        break;

    case 'pago_exitoso':
        require_once 'app/controllers/PagoController.php';
        $controller = new PagoController();
        $controller->pago_exitoso();
        break;

    // Ruta por defecto
    default:
        $homeController->home();
        break;
}

?>