// public/js/carrito.js - Funcionalidad para agregar productos al carrito

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    inicializarBotonesCarrito();
    agregarEstilosCarrito();
});

// Funcionalidad para agregar al carrito
function inicializarBotonesCarrito() {
    // Para botones existentes
    document.querySelectorAll('.btn-add-to-cart').forEach(button => {
        button.addEventListener('click', manejarClickCarrito);
    });

    // Para botones agregados dinámicamente
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1) {
                    if (node.classList && node.classList.contains('btn-add-to-cart')) {
                        node.addEventListener('click', manejarClickCarrito);
                    }
                    if (node.querySelectorAll) {
                        const buttons = node.querySelectorAll('.btn-add-to-cart');
                        buttons.forEach(button => {
                            button.addEventListener('click', manejarClickCarrito);
                        });
                    }
                }
            });
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// Manejar clic en botón de carrito
function manejarClickCarrito(e) {
    e.preventDefault();
    e.stopPropagation();
    
    const productId = this.getAttribute('data-product-id');
    
    if (typeof usuarioLogueado !== 'undefined' && usuarioLogueado) {
        agregarAlCarrito(productId);
    } else {
        alert('Debes iniciar sesión para agregar productos al carrito');
        window.location.href = 'index.php?action=login';
    }
}

// Función para agregar producto al carrito via AJAX
function agregarAlCarrito(productId) {
    console.log('Agregando producto ID:', productId);
    
    $.ajax({
        url: 'index.php?action=agregar_carrito',
        type: 'POST',
        data: {
            id_producto: productId,
            cantidad: 1
        },
        success: function(response) {
            console.log('Respuesta del servidor:', response);
            try {
                const data = JSON.parse(response);
                if (data.success) {
                    mostrarMensajeCarrito('Producto agregado al carrito', 'success');
                    
                    // Actualizar contador del carrito en el header
                    $('#headerCartCount').text(data.total_items);
                    
                    // Si el carrito está abierto, recargarlo
                    if ($('#cartSidebar').hasClass('active') && typeof window.loadCart === 'function') {
                        window.loadCart();
                    }
                } else {
                    mostrarMensajeCarrito(data.message, 'error');
                }
            } catch (e) {
                console.error('Error parsing JSON:', e);
                mostrarMensajeCarrito('Error al procesar la respuesta', 'error');
            }
        },
        error: function(xhr, status, error) {
            console.error('Error AJAX:', error);
            mostrarMensajeCarrito('Error al agregar producto al carrito', 'error');
        }
    });
}

// Función para mostrar mensajes temporales
function mostrarMensajeCarrito(mensaje, tipo) {
    // Crear elemento de mensaje
    const mensajeDiv = document.createElement('div');
    mensajeDiv.className = `cart-message ${tipo}`;
    mensajeDiv.innerHTML = `
        <div class="cart-message-content">
            <i class="fas fa-${tipo === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${mensaje}</span>
        </div>
    `;
    
    // Estilos para el mensaje
    mensajeDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${tipo === 'success' ? '#8f6e81ff' : '#8f6e81ff'};
        color: ${tipo === 'success' ? '#ffffffff' : '#61373bff'};
        padding: 15px 20px;
        border-radius: 8px;
        border: 1px solid ${tipo === 'success' ? '#8f6e81ff' : '#8f6e81ff'};
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(mensajeDiv);
    
    // Remover después de 3 segundos
    setTimeout(() => {
        mensajeDiv.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (mensajeDiv.parentNode) {
                mensajeDiv.parentNode.removeChild(mensajeDiv);
            }
        }, 300);
    }, 3000);
}

// Agregar estilos CSS para las animaciones de mensajes
function agregarEstilosCarrito() {
    if (!document.getElementById('carrito-styles')) {
        const style = document.createElement('style');
        style.id = 'carrito-styles';
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            .cart-message .cart-message-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .cart-message.success {
                background: #8f6e81ff !important;
                color: #ffffffff !important;
                border-color: #8f6e81ff !important;
            }
            
            .cart-message.error {
                background: #72555dff !important;
                color: #ffffffff !important;
                border-color: #865f5fff !important;
            }
        `;
        document.head.appendChild(style);
    }
}