// public/js/carrito-sidebar.js - Funcionalidad del carrito lateral

// Hacer la función loadCart global
window.loadCart = function() {
    $.get('index.php?action=contador_carrito', function(data) {
        const response = JSON.parse(data);
        $('#headerCartCount').text(response.total_items || 0);
    });

    $.get('index.php?action=carrito_sidebar', function(data) {
        const response = JSON.parse(data);
        
        if (response.success && response.items.length > 0) {
            let html = '';
            let total = 0;
            
            response.items.forEach(item => {
                const itemTotal = item.precio * item.cantidad;
                total += itemTotal;
                
                html += `
                    <div class="cart-item" data-producto="${item.id_producto}">
                        <img src="public/img/productos/${item.imagen_principal}" 
                             alt="${item.nombre}" 
                             class="cart-item-img">
                        <div class="cart-item-details">
                            <div class="cart-item-name">${item.nombre}</div>
                            <div class="cart-item-price">S/ ${item.precio.toFixed(2)}</div>
                            <div class="cart-item-quantity">
                                <button class="quantity-btn decrease-btn" 
                                        data-producto="${item.id_producto}">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <input type="number" 
                                       class="quantity-input" 
                                       value="${item.cantidad}" 
                                       min="1" 
                                       max="${item.stock}"
                                       data-producto="${item.id_producto}">
                                <button class="quantity-btn increase-btn" 
                                        data-producto="${item.id_producto}">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <button class="remove-item" data-producto="${item.id_producto}">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </div>
                    </div>
                `;
            });
            
            $('#cartContent').html(html);
            $('#cartTotal').text('S/ ' + total.toFixed(2));
            $('#checkoutBtn').prop('disabled', false);
            
            // Agregar event listeners a los botones
            attachCartEventListeners();
        } else {
            $('#cartContent').html(`
                <div class="empty-cart-message">
                    <i class="fas fa-shopping-cart"></i>
                    <h4>Tu carrito está vacío</h4>
                    <p>Agrega algunos productos increíbles</p>
                </div>
            `);
            $('#cartTotal').text('S/ 0.00');
            $('#checkoutBtn').prop('disabled', true);
        }
    });
};

$(document).ready(function() {
    const cartSidebar = $('#cartSidebar');
    const cartOverlay = $('#cartOverlay');

    // Abrir carrito
    $('#openCart').on('click', function(e) {
        e.preventDefault();
        window.loadCart();
        cartSidebar.addClass('active');
        cartOverlay.addClass('active');
        $('body').css('overflow', 'hidden');
    });

    // Cerrar carrito
    $('#closeCart, #cartOverlay').on('click', function() {
        cartSidebar.removeClass('active');
        cartOverlay.removeClass('active');
        $('body').css('overflow', 'auto');
    });

    // Botón de checkout
    $('#checkoutBtn').on('click', function() {
        window.location.href = 'index.php?action=carrito';
    });
});

// Adjuntar event listeners a los elementos del carrito
function attachCartEventListeners() {
    // Botones de cantidad
    $('.quantity-btn').on('click', function() {
        const productoId = $(this).data('producto');
        const input = $(`input[data-producto="${productoId}"]`);
        let cantidad = parseInt(input.val());
        
        if ($(this).hasClass('increase-btn')) {
            cantidad++;
        } else if ($(this).hasClass('decrease-btn')) {
            cantidad--;
        }
        
        if (cantidad < 1) cantidad = 1;
        input.val(cantidad);
        updateCartItem(productoId, cantidad);
    });

    // Cambio directo en input
    $('.quantity-input').on('change', function() {
        const productoId = $(this).data('producto');
        let cantidad = parseInt($(this).val());
        
        if (cantidad < 1) cantidad = 1;
        $(this).val(cantidad);
        updateCartItem(productoId, cantidad);
    });

    // Eliminar producto
    $('.remove-item').on('click', function() {
        const productoId = $(this).data('producto');
        if (confirm('¿Eliminar este producto del carrito?')) {
            removeCartItem(productoId);
        }
    });
}

// Actualizar cantidad de producto
function updateCartItem(productoId, cantidad) {
    $.post('index.php?action=actualizar_carrito', {
        id_producto: productoId,
        cantidad: cantidad
    }, function(response) {
        const data = JSON.parse(response);
        if (data.success) {
            window.loadCart(); // Recargar carrito
        } else {
            alert(data.message);
            window.loadCart(); // Recargar para resetear valores
        }
    });
}

// Eliminar producto del carrito
function removeCartItem(productoId) {
    $.post('index.php?action=eliminar_carrito', {
        id_producto: productoId
    }, function(response) {
        const data = JSON.parse(response);
        if (data.success) {
            window.loadCart();
        } else {
            alert(data.message);
        }
    });
}