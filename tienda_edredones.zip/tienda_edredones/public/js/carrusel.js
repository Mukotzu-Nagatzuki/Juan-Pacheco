document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.carrusel-slide');
    const indicators = document.querySelectorAll('.indicator');
    const prevBtn = document.querySelector('.carrusel-prev');
    const nextBtn = document.querySelector('.carrusel-next');
    let currentSlide = 0;
    let slideInterval;

    function showSlide(index) {
        // Ocultar todas las slides
        slides.forEach(slide => slide.classList.remove('active'));
        indicators.forEach(indicator => indicator.classList.remove('active'));
        
        // Mostrar slide actual
        slides[index].classList.add('active');
        indicators[index].classList.add('active');
        currentSlide = index;
    }

    function nextSlide() {
        let next = currentSlide + 1;
        if (next >= slides.length) next = 0;
        showSlide(next);
    }

    function prevSlide() {
        let prev = currentSlide - 1;
        if (prev < 0) prev = slides.length - 1;
        showSlide(prev);
    }

    // Event listeners
    nextBtn.addEventListener('click', nextSlide);
    prevBtn.addEventListener('click', prevSlide);

    // Indicadores
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            showSlide(index);
            resetInterval();
        });
    });

    // Carrusel automático
    function startInterval() {
        slideInterval = setInterval(nextSlide, 5000); // Cambia cada 5 segundos
    }

    function resetInterval() {
        clearInterval(slideInterval);
        startInterval();
    }

    // Pausar carrusel al hacer hover
    const carrusel = document.querySelector('.carrusel-container');
    carrusel.addEventListener('mouseenter', () => clearInterval(slideInterval));
    carrusel.addEventListener('mouseleave', startInterval);

    // Iniciar carrusel
    startInterval();
});