class Chatbot {
    constructor() {
        this.isOpen = false;
        this.messageHistory = [];
        this.init();
    }

    init() {
        console.log('Inicializando chatbot...');
        this.createWidget();
        this.bindEvents();
        this.loadHistory();
        setTimeout(() => this.showWelcomeMessage(), 1500);
    }

    createWidget() {
        console.log('Creando widget del chatbot...');
        
        // Verificar si ya existe el widget para evitar duplicados
        if (document.querySelector('.chatbot-widget')) {
            console.log('Widget ya existe, eliminando duplicado...');
            document.querySelector('.chatbot-widget').remove();
        }
        if (document.querySelector('.chatbot-toggle')) {
            console.log('Botón ya existe, eliminando duplicado...');
            document.querySelector('.chatbot-toggle').remove();
        }

        const widgetHTML = `
            <button class="chatbot-toggle" title="Asistente Dream House">
                <span class="chatbot-icon"><i class="fas fa-comment-dots"></i></span>
                <span class="chatbot-pulse"></span>
            </button>
            <div class="chatbot-widget">
                <div class="chatbot-header">
                    <div class="chatbot-title">
                        <div class="message-avatar"><i class="fas fa-home"></i></div>
                        <div class="chatbot-info">
                            <div class="chatbot-name">Asistente Dream</div>
                            <div class="chatbot-status">
                                <span class="status-dot"></span>
                                En línea
                            </div>
                        </div>
                    </div>
                    <div class="chatbot-actions">
                        <button class="chatbot-clear" title="Limpiar conversación"><i class="fas fa-trash-alt"></i></button>
                        <button class="chatbot-close" title="Cerrar">×</button>
                    </div>
                </div>
                <div class="chatbot-messages" id="chatMessages"></div>
                <div class="chatbot-suggestions">
                    <div class="suggestions-title">¿Necesitas ayuda rápida?</div>
                    <div class="suggestions-buttons">
                        <button class="suggestion-btn" data-question="Recomiéndame un edredón"><i class="fas fa-bed"></i> Recomendaciones</button>
                        <button class="suggestion-btn" data-question="Cómo comprar"><i class="fas fa-shopping-cart"></i> Proceso de compra</button>
                        <button class="suggestion-btn" data-question="Ver mis pedidos"><i class="fas fa-box"></i> Estado de pedido</button>
                        <button class="suggestion-btn" data-question="Cupones de descuento"><i class="fas fa-tag"></i> Ofertas</button>
                    </div>
                </div>
                <div class="chatbot-input-container">
                    <div class="chatbot-input">
                        <input type="text" id="chatInput" placeholder="Escribe tu mensaje sobre edredones, pedidos, precios..." maxlength="500">
                        <button class="chatbot-send" id="sendMessage" title="Enviar mensaje">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                            </svg>
                        </button>
                    </div>
                    <div class="chatbot-footer">
                        <span class="chatbot-tip"><i class="fas fa-lightbulb"></i> Presiona Enter para enviar</span>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', widgetHTML);
        
        // Seleccionar elementos después de crearlos
        this.toggleBtn = document.querySelector('.chatbot-toggle');
        this.widget = document.querySelector('.chatbot-widget');
        this.messagesContainer = document.getElementById('chatMessages');
        this.input = document.getElementById('chatInput');
        this.sendBtn = document.getElementById('sendMessage');
        this.closeBtn = document.querySelector('.chatbot-close');
        this.clearBtn = document.querySelector('.chatbot-clear');
        this.suggestionBtns = document.querySelectorAll('.suggestion-btn');
        
        console.log('Elementos seleccionados:', {
            toggleBtn: !!this.toggleBtn,
            widget: !!this.widget,
            messagesContainer: !!this.messagesContainer,
            input: !!this.input,
            sendBtn: !!this.sendBtn
        });
    }

    bindEvents() {
        console.log('Configurando event listeners...');
        
        // Botón toggle principal
        if (this.toggleBtn) {
            this.toggleBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('Botón toggle clickeado');
                this.toggleChat();
            });
        } else {
            console.error('No se encontró el botón toggle');
        }
        
        // Botón cerrar
        if (this.closeBtn) {
            this.closeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('Botón cerrar clickeado');
                this.closeChat();
            });
        }
        
        // Botón enviar
        if (this.sendBtn) {
            this.sendBtn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('Botón enviar clickeado');
                this.sendMessage();
            });
        }
        
        // Input - Enter para enviar
        if (this.input) {
            this.input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    console.log('Enter presionado');
                    this.sendMessage();
                }
            });
            
            this.input.addEventListener('input', () => {
                this.toggleSendButton();
            });
        }
        
        // Botón limpiar conversación
        if (this.clearBtn) {
            this.clearBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('Botón limpiar clickeado');
                this.clearConversation();
            });
        }
        
        // Sugerencias rápidas
        if (this.suggestionBtns) {
            this.suggestionBtns.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const question = e.target.getAttribute('data-question');
                    console.log('Sugerencia seleccionada:', question);
                    if (this.input) {
                        this.input.value = question;
                        this.sendMessage();
                    }
                });
            });
        }
        
        // Cerrar al hacer clic fuera del widget
        document.addEventListener('click', (e) => {
            if (this.isOpen && this.widget && this.toggleBtn) {
                if (!this.widget.contains(e.target) && !this.toggleBtn.contains(e.target)) {
                    console.log('Clic fuera del widget, cerrando...');
                    this.closeChat();
                }
            }
        });
        
        // Prevenir que los clics dentro del widget cierren el chat
        if (this.widget) {
            this.widget.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
        
        // Tecla Escape para cerrar
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                console.log('Tecla Escape presionada, cerrando chat...');
                this.closeChat();
            }
        });
        
        console.log('Event listeners configurados correctamente');
    }

    toggleChat() {
        console.log('Toggle chat - Estado actual:', this.isOpen);
        
        this.isOpen = !this.isOpen;
        
        if (this.widget) {
            if (this.isOpen) {
                this.widget.style.display = 'flex';
                this.widget.classList.add('open');
                console.log('Chat abierto - display: flex, clase: open');
            } else {
                this.widget.style.display = 'none';
                this.widget.classList.remove('open');
                console.log('Chat cerrado - display: none, clase removida');
            }
        } else {
            console.error('Widget no encontrado');
        }
        
        if (this.toggleBtn) {
            this.toggleBtn.classList.toggle('active', this.isOpen);
        }
        
        if (this.isOpen) {
            if (this.input) {
                this.input.focus();
            }
            this.scrollToBottom();
            this.showSuggestions();
        } else {
            this.hideSuggestions();
        }
        
        console.log('Toggle completado - Nuevo estado:', this.isOpen);
    }

    closeChat() {
        console.log('Cerrando chat...');
        this.isOpen = false;
        
        if (this.widget) {
            this.widget.style.display = 'none';
            this.widget.classList.remove('open');
        }
        
        if (this.toggleBtn) {
            this.toggleBtn.classList.remove('active');
        }
        
        this.hideSuggestions();
        console.log('Chat cerrado');
    }

    toggleSendButton() {
        if (this.sendBtn && this.input) {
            const hasText = this.input.value.trim().length > 0;
            this.sendBtn.style.opacity = hasText ? '1' : '0.5';
            this.sendBtn.style.cursor = hasText ? 'pointer' : 'not-allowed';
        }
    }

    async sendMessage() {
        if (!this.input) {
            console.error('Input no encontrado');
            return;
        }
        
        const message = this.input.value.trim();
        if (!message) {
            console.log('Mensaje vacío, ignorando...');
            return;
        }

        console.log('Enviando mensaje:', message);
        
        // Agregar mensaje del usuario
        this.addMessage('user', message);
        this.saveToHistory('user', message);
        this.input.value = '';
        this.toggleSendButton();
        this.hideSuggestions();
        
        // Mostrar "escribiendo..."
        this.showTypingIndicator();
        
        try {
            const response = await this.getBotResponse(message);
            this.hideTypingIndicator();
            this.addMessage('bot', response);
            this.saveToHistory('bot', response);
            console.log('Respuesta recibida correctamente');
        } catch (error) {
            this.hideTypingIndicator();
            const errorMessage = '⚠️ Lo siento, hubo un error al procesar tu mensaje. Por favor intenta nuevamente.';
            this.addMessage('bot', errorMessage);
            this.saveToHistory('bot', errorMessage);
            console.error('Error del chatbot:', error);
        }
    }

async getBotResponse(message) {
    try {
        console.log('Solicitando respuesta al servidor...');
        const response = await fetch('/tienda_edredones/?action=chatbot_message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                message: message,
                timestamp: new Date().toISOString(),
                history: this.messageHistory.slice(-4)
            })
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.reply) {
            return data.reply;
        } else {
            throw new Error('Respuesta vacía del servidor');
        }

    } catch (error) {
        console.error('Error del chatbot:', error);
        return this.getFallbackResponse(message);
    }
}

    getFallbackResponse(message) {
        const lowerMessage = message.toLowerCase();
        
        const fallbackResponses = {
            'hola': "¡Hola! <i class='fas fa-hand-wave'></i> Soy Asistente Dream de **Dream House**. ¿En qué puedo ayudarte con nuestros edredones y productos de descanso?",
            'precio': "💰 **Nuestros edredones**:\n• Básicos: S/ 50 - S/ 80\n• Premium: S/ 80 - S/ 150\n• Lujo: S/ 150 - S/ 250\n\n¿Qué tipo te interesa?",
            'compra': "🛒 **Para comprar**:\n1. Elige tu edredón\n2. Agrega al carrito\n3. Completa tus datos\n4. ¡Listo! Envío en 24-48h",
            'contacto': "📞 **Contacto**:\n• Email: admin@tienda.com\n• Teléfono: +51 XXX XXX XXX\n• Horario: L-V 9am-6pm",
            'default': "¡Gracias por tu mensaje! <i class='fas fa-star'></i> Como Asistente Dream, puedo ayudarte con:\n\n• <i class='fas fa-bed'></i> Recomendaciones de edredones\n• <i class='fas fa-shopping-cart'></i> Proceso de compra y envíos\n• <i class='fas fa-tag'></i> Cupones y promociones\n• <i class='fas fa-box'></i> Estado de pedidos\n\n¿En qué te puedo asistir específicamente?"
        };

        for (const [keyword, response] of Object.entries(fallbackResponses)) {
            if (lowerMessage.includes(keyword)) {
                return response;
            }
        }

        return fallbackResponses.default;
    }

    addMessage(sender, text) {
        if (!this.messagesContainer) {
            console.error('Contenedor de mensajes no encontrado');
            return;
        }
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.innerHTML = sender === 'bot' ? '<i class="fas fa-home"></i>' : '<i class="fas fa-user"></i>';
        
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        
        // Permitir HTML seguro en los mensajes
        const formattedText = text.replace(/\n/g, '<br>');
        bubble.innerHTML = formattedText;
        
        const time = document.createElement('div');
        time.className = 'message-time';
        time.textContent = this.getCurrentTime();
        
        if (sender === 'user') {
            messageDiv.appendChild(bubble);
            messageDiv.appendChild(avatar);
        } else {
            messageDiv.appendChild(avatar);
            messageDiv.appendChild(bubble);
        }
        
        messageDiv.appendChild(time);
        this.messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    }

    showTypingIndicator() {
        if (!this.messagesContainer) return;
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot typing';
        typingDiv.id = 'typingIndicator';
        
        typingDiv.innerHTML = `
            <div class="message-avatar"><i class="fas fa-home"></i></div>
            <div class="message-bubble">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                    <div class="typing-text">Asistente Dream está escribiendo...</div>
                </div>
            </div>
        `;
        
        this.messagesContainer.appendChild(typingDiv);
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    showWelcomeMessage() {
        if (!this.isOpen && this.messagesContainer && this.messagesContainer.children.length === 0) {
            setTimeout(() => {
                const welcomeMessage = "¡Hola! <i class='fas fa-hand-wave'></i> Soy **Asistente Dream** de **Dream House** <i class='fas fa-home'></i>\n\nTransformamos hogares en santuarios de descanso con nuestros edredones y ropa de cama premium.\n\n¿En qué puedo ayudarte hoy?";
                this.addMessage('bot', welcomeMessage);
                this.saveToHistory('bot', welcomeMessage);
            }, 1000);
        }
    }

    showSuggestions() {
        const suggestions = document.querySelector('.chatbot-suggestions');
        if (suggestions && this.messagesContainer && this.messagesContainer.children.length <= 2) {
            suggestions.style.display = 'block';
        }
    }

    hideSuggestions() {
        const suggestions = document.querySelector('.chatbot-suggestions');
        if (suggestions) {
            suggestions.style.display = 'none';
        }
    }

    clearConversation() {
        if (confirm('¿Estás seguro de que quieres limpiar toda la conversación?')) {
            if (this.messagesContainer) {
                this.messagesContainer.innerHTML = '';
            }
            this.messageHistory = [];
            localStorage.removeItem('dreamhouse_chat_history');
            this.showWelcomeMessage();
            this.showSuggestions();
        }
    }

    saveToHistory(sender, text) {
        this.messageHistory.push({
            sender: sender,
            text: text,
            timestamp: new Date().toISOString()
        });
        
        if (this.messageHistory.length > 50) {
            this.messageHistory = this.messageHistory.slice(-50);
        }
        
        localStorage.setItem('dreamhouse_chat_history', JSON.stringify(this.messageHistory));
    }

    loadHistory() {
        try {
            const saved = localStorage.getItem('dreamhouse_chat_history');
            if (saved) {
                this.messageHistory = JSON.parse(saved);
                
                const recentMessages = this.messageHistory.slice(-10);
                recentMessages.forEach(msg => {
                    this.addMessage(msg.sender, msg.text);
                });
            }
        } catch (error) {
            console.error('Error loading chat history:', error);
        }
    }

    getCurrentTime() {
        return new Date().toLocaleTimeString('es-PE', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }

    scrollToBottom() {
        if (this.messagesContainer) {
            this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
        }
    }
}

// Inicialización mejorada
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM cargado, inicializando chatbot...');
    
    // Esperar un poco más para asegurar que todo esté listo
    setTimeout(() => {
        try {
            window.dreamhouseChatbot = new Chatbot();
            console.log('✅ Chatbot inicializado correctamente');
        } catch (error) {
            console.error('❌ Error al inicializar el chatbot:', error);
            
            // Intentar una segunda inicialización
            setTimeout(() => {
                try {
                    window.dreamhouseChatbot = new Chatbot();
                    console.log('✅ Chatbot inicializado en segundo intento');
                } catch (error2) {
                    console.error('❌ Error crítico en segundo intento:', error2);
                }
            }, 1000);
        }
    }, 100);
});