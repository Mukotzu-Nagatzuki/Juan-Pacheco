document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.sidebar');
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const menuLinks = document.querySelectorAll('.menu-link');
    const logoutBtn = document.querySelector('.logout-btn');

    // Crear tooltip global
    const tooltip = document.createElement('div');
    tooltip.className = 'custom-tooltip';
    document.body.appendChild(tooltip);

    // Toggle sidebar
    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        updateToggleIcon();
        hideTooltip();
    });

    // Actualizar ícono del toggle
    function updateToggleIcon() {
        const toggleIcon = sidebarToggle.querySelector('i');
        if (sidebar.classList.contains('collapsed')) {
            toggleIcon.className = 'bi bi-list';
        } else {
            toggleIcon.className = 'bi bi-list';
        }
    }

    // Expand sidebar por defecto en pantallas grandes
    if (window.innerWidth > 768) {
        sidebar.classList.remove('collapsed');
    }
    updateToggleIcon();

    // Funcionalidad de logout
    logoutBtn.addEventListener('click', () => {
        window.location.href = 'index.php?action=logout';
    });

    // Tooltips para menú colapsado
    menuLinks.forEach(link => {
        link.addEventListener('mouseenter', function(e) {
            if (!sidebar.classList.contains('collapsed')) return;
            
            const tooltipText = this.getAttribute('data-tooltip') || this.querySelector('.menu-label').textContent;
            if (!tooltipText) return;
            
            showTooltip(this, tooltipText);
        });
        
        link.addEventListener('mouseleave', function() {
            hideTooltip();
        });
        
        link.addEventListener('click', function() {
            hideTooltip();
        });
    });

    // Mostrar tooltip
    function showTooltip(element, text) {
        const rect = element.getBoundingClientRect();
        
        tooltip.textContent = text;
        tooltip.style.left = (rect.right + 10) + 'px';
        tooltip.style.top = (rect.top + (rect.height / 2)) + 'px';
        tooltip.style.transform = 'translateY(-50%)';
        
        const tooltipRect = tooltip.getBoundingClientRect();
        if (tooltipRect.right > window.innerWidth - 10) {
            tooltip.style.left = (rect.left - tooltipRect.width - 10) + 'px';
        }
        
        tooltip.classList.add('show');
    }

    // Ocultar tooltip
    function hideTooltip() {
        tooltip.classList.remove('show');
    }

    // Event listeners globales
    window.addEventListener('scroll', hideTooltip);
    window.addEventListener('resize', hideTooltip);

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.menu-link') && !e.target.closest('.custom-tooltip')) {
            hideTooltip();
        }
    });
});