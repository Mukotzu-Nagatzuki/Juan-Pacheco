<?php
header('Content-Type: application/json');

function markdownToHtml($text) {
    // Convertir negritas **texto** o __texto__ a <strong>
    $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text);
    $text = preg_replace('/__(.*?)__/', '<strong>$1</strong>', $text);
    
    // Convertir emojis de texto a Unicode
    $emojiMap = [
        '✨' => '✨',
        '🛍️' => '🛍️',
        '👨‍💼' => '👨‍💼',
        '💡' => '💡',
        '😊' => '😊',
        '🤖' => '🤖',
        '🔒' => '🔒',
        '📦' => '📦',
        '💰' => '💰',
        '🚚' => '🚚',
        '⭐' => '⭐',
        '👤' => '👤',
        '👑' => '👑',
        '📊' => '📊',
        '🔔' => '🔔'
    ];
    
    foreach ($emojiMap as $textEmoji => $unicodeEmoji) {
        $text = str_replace($textEmoji, $unicodeEmoji, $text);
    }
    
    // Convertir listas con puntos
    $text = preg_replace('/^[•\-\*]\s+(.*)$/m', '<li>$1</li>', $text);
    
    // Reemplazar saltos de línea por <br>
    $text = nl2br($text);
    
    return $text;
}

$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['message']) || empty(trim($input['message']))) {
    echo json_encode(['error' => 'Mensaje vacío']);
    exit;
}

$mensaje = $input['message'];

$apiKey = "RX8JCVG-fhkeyaaHfTVzcCoUjwW7WjFyCVg9Nyh8sDw"; // 🔒 TU CLAVE
$model = "asistente_dream";

$data = [
    "model" => $model,
    "messages" => [
        ["role" => "user", "content" => $mensaje]
    ]
];

$ch = curl_init("https://api.poe.com/v1/chat/completions");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "Authorization: Bearer $apiKey"
    ],
    CURLOPT_POSTFIELDS => json_encode($data)
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(['error' => 'Error de conexión']);
    exit;
}

curl_close($ch);

$result = json_decode($response, true);

if (!isset($result['choices'][0]['message']['content'])) {
    echo json_encode(['error' => 'Respuesta inválida']);
    exit;
}

$rawResponse = $result['choices'][0]['message']['content'];
$formattedResponse = markdownToHtml($rawResponse);

echo json_encode([
    'reply' => $formattedResponse,
    'raw' => $rawResponse // Opcional: para debugging
]);